package com.newgen.KYC.KYCodDownloadBBG4;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.format.CellDateFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.newgen.KYC.KYCodDownloadBBG3.KYCodDownloadLogBBG3;
import com.newgen.KYC.KYCodDownloadBBG4.KYCodDownloadLogBBG4;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;

import ISPack.CImageServer;
import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;
import Jdts.DataObject.JPDBString;

public class KYCodDownloadBBG4 implements Runnable
{
	private static String cifFromExtTable;
	private static String sessionID = "";
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	private static String queueID = "";
	private static String FileDownloadLoc = "";
	private static StringBuffer filePath, filePath1;
	private static String DocLocation = "";
	private static int sleepIntervalInMin=0;
	private static String ofUserName = "";
	private static String ofUserPassword = "";
	private static String ofCabinetName = "";
	private static String ofjtsIP = "";
	private static String ofjtsPort = "";
	private static String volumeID = "";
	private static String iBpsDocsAttached = "";
	private static String OFDocsAttached = "";
	private static String SMSPort = "";
	private static String pointToSegment = "";
	private static String sortOrder = "";
	private static String DocumentTypes = "";
	private static int RandomNumberVariable;
	
	Map<String,Integer>folderCount=new LinkedHashMap<String,Integer>();
	Map<String,Integer>folderPrefix=new LinkedHashMap<String,Integer>();
	Map<String,Integer>folderSuffix=new LinkedHashMap<String,Integer>();
	
	private static NGEjbClient ngEjbClientODDoc;

	static Map<String, String> ODDocConfigParamMap= new HashMap<String, String>();
	
	public void run()
	{
		try
		{
			KYCodDownloadLogBBG4.setLogger();
			
			int configReadStatus = readConfig();

			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("configReadStatus "+configReadStatus);
			if(configReadStatus !=0)
			{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("Could not Read Config Properties KYC_Od_Download_Config.properties");
				return;
			}
			
			volumeID = CommonConnection.getsVolumeID();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("volumeID: " + volumeID);
			
			cabinetName = CommonConnection.getCabinetName();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("JTSPORT: " + jtsPort);						
			
			SMSPort = CommonConnection.getsSMSPort();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("SMSPort: " + SMSPort);
			
			queueID = ODDocConfigParamMap.get("queueID");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("QueueID: " + queueID);

			sleepIntervalInMin=Integer.parseInt(ODDocConfigParamMap.get("SleepIntervalInMin"));
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("SleepIntervalInMin: "+sleepIntervalInMin);
			
			DocLocation=ODDocConfigParamMap.get("DocPathBBG4");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("DocPathBBG4: " + DocLocation);
			
			pointToSegment = ODDocConfigParamMap.get("BBG4ThreadPointTo");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("BBG4ThreadPointTo: " + pointToSegment);
			
			sortOrder = ODDocConfigParamMap.get("SortOrderBBG4Thread");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("SortOrderBBG4Thread: " + sortOrder);
			
			DocumentTypes = ODDocConfigParamMap.get("DocumentTypes");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("DocumentTypes: " + DocumentTypes);
			
			RandomNumberVariable = Integer.parseInt(ODDocConfigParamMap.get("RandomNumberVariable"));
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("RandomNumberVariable: "+RandomNumberVariable);
			
			ofUserName=CommonConnection.getOFUserName();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("ofUserName: " + ofUserName);
			
			ofUserPassword=CommonConnection.getOFPassword();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("ofUserPassword: " + ofUserPassword);
			
			ofCabinetName=CommonConnection.getOFCabinetName();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("ofCabinetName: " + ofCabinetName);
			
			ofjtsIP=CommonConnection.getOFJTSIP();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("ofjtsIP: " + ofjtsIP);
			
			ofjtsPort=CommonConnection.getOFJTSPort();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("ofjtsPort: " + ofjtsPort);
			
			
		sessionID = CommonConnection.getSessionID(KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger, false);

			if(sessionID.trim().equalsIgnoreCase("")){
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("Could Not Connect to Server!");
			}
			else{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Session ID found: " + sessionID);
				while(true){
					sessionID = CommonConnection.getSessionID(KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger, false);
					KYCodDownloadLogBBG4.setLogger();
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("KYC Doc Utility...123");				
					startKYCDownloadDocUtility(cabinetName, jtsIP, jtsPort,sessionID,queueID);
					System.out.println("No More workitems to Process at KYC_Download, Sleeping!");
					Thread.sleep(sleepIntervalInMin*6*1000);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception Occurred in ODDD : "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception Occurred in ODDD : "+result);
		}
	}
	
	private void startKYCDownloadDocUtility(String cabinetName,String sJtsIp,String iJtsPort,String sessionId,String queueID)
	{
		final String ws_name="Attach_Document";
		try{
			sessionID = CommonConnection.getSessionID(KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger, false);

			if(sessionId==null || sessionId.equalsIgnoreCase("") || sessionId.equalsIgnoreCase("null")){
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.error("Could Not Get Session ID "+sessionId);
				return;
			}
			//Fetch all Work-Items on given queueID.
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Fetching all Workitems on KYC_Download queue");
			System.out.println("Fetching all Workitems on KYC_Download queue");
			//String fetchWorkitemListInputXML=CommonMethods.fetchWorkItemsInput(cabinetName, sessionId, queueID);
			//KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("InputXML for fetchWorkList Call KYC_Download: "+fetchWorkitemListInputXML);

			//String FilterString = "VAR_STR8 = '"+pointToSegment+"'";
			String FilterString = "VAR_STR8 = '"+pointToSegment+"' AND (VAR_STR3 NOT IN ('In Progress','Done') OR VAR_STR3 IS NULL)";
			StringBuffer ipXMLBufferFetchWI=new StringBuffer();

			ipXMLBufferFetchWI.append("<?xml version=\"1.0\"?>\n");
			ipXMLBufferFetchWI.append("<WMFetchWorkItems_Input>\n");
			ipXMLBufferFetchWI.append("<Option>WMFetchWorkItem</Option>\n");
			ipXMLBufferFetchWI.append("<EngineName>");
			ipXMLBufferFetchWI.append(cabinetName);
			ipXMLBufferFetchWI.append("</EngineName>\n");
			ipXMLBufferFetchWI.append("<SessionID>");
			ipXMLBufferFetchWI.append(sessionID);
			ipXMLBufferFetchWI.append("</SessionID>\n");
			ipXMLBufferFetchWI.append("<QueueId>");
			ipXMLBufferFetchWI.append(queueID);
			ipXMLBufferFetchWI.append("</QueueId>\n");
			
			ipXMLBufferFetchWI.append("<Filter>");
			ipXMLBufferFetchWI.append("<Type>");
			ipXMLBufferFetchWI.append("256");
			ipXMLBufferFetchWI.append("</Type>\n");
			ipXMLBufferFetchWI.append("<Comparison>");
			ipXMLBufferFetchWI.append("0");
			ipXMLBufferFetchWI.append("</Comparison>\n");
			ipXMLBufferFetchWI.append("<DynamicQueueFlag>");
			ipXMLBufferFetchWI.append("Y");
			ipXMLBufferFetchWI.append("</DynamicQueueFlag>\n");
			ipXMLBufferFetchWI.append("<QueueId>");
			ipXMLBufferFetchWI.append(queueID);
			ipXMLBufferFetchWI.append("</QueueId>\n");
			ipXMLBufferFetchWI.append("<FilterString>");
			ipXMLBufferFetchWI.append(FilterString);
			ipXMLBufferFetchWI.append("</FilterString>\n");
			ipXMLBufferFetchWI.append("<Length>");
			ipXMLBufferFetchWI.append("0");
			ipXMLBufferFetchWI.append("</Length>\n");
			ipXMLBufferFetchWI.append("</Filter>");
		
			ipXMLBufferFetchWI.append("<BatchInfo>\n");
			ipXMLBufferFetchWI.append("<NoOfRecordsToFetch>1</NoOfRecordsToFetch>\n");
			ipXMLBufferFetchWI.append("<LastWorkItem></LastWorkItem>\n");
			ipXMLBufferFetchWI.append("<LastValue></LastValue>\n");
			ipXMLBufferFetchWI.append("<LastProcessInstance></LastProcessInstance>\n");
			ipXMLBufferFetchWI.append("<SortOrder>"+sortOrder+"</SortOrder>\n");
			ipXMLBufferFetchWI.append("</BatchInfo>\n");
			ipXMLBufferFetchWI.append("</WMFetchWorkItems_Input>\n");
			String fetchWorkitemListInputXML=ipXMLBufferFetchWI.toString();
			
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("WMFetchWorkList Input KYC_Download: "+fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML= CommonMethods.WFNGExecute(fetchWorkitemListInputXML,sJtsIp,iJtsPort,1);

			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("WMFetchWorkList OutputXML KYC_Download: "+fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("FetchWorkItemListMainCode: "+fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("RetrievedCount for WMFetchWorkList Call: "+fetchWorkitemListCount);

			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Number of workitems retrieved on KYC_Download: "+fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on KYC_Download: "+fetchWorkitemListCount);
			String WI_AddDoc_Status = "";
			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0)
			{
				for(int i=0; i<fetchWorkitemListCount; i++)
				{
					WI_AddDoc_Status = "";
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Current ProcessInstanceID: " + processInstanceID);

					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Processing Workitem: " + processInstanceID);
					System.out.println("\nProcessing Workitem: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Current WorkItemID: " + WorkItemID);

					String entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Current EntryDateTime: " + entryDateTime);

					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ActivityName: " + ActivityName);

					String ProcessDefID = xmlParserfetchWorkItemData.getValueOf("ProcessDefID");
					String activityId = xmlParserfetchWorkItemData.getValueOf("ActivityId");
					String activityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					String queueId = xmlParserfetchWorkItemData.getValueOf("QueueID");

					String WIattachStatus = WIAttachStatus(processInstanceID);
					if("".equalsIgnoreCase(WIattachStatus) || "NULL".equalsIgnoreCase(WIattachStatus) || WIattachStatus == null)
					{
						for(int j=1;j<=5;j++)
						{
							int rnd = CommonMethods.getRandomNumber(RandomNumberVariable);
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("random number generated for iteration ["+j+"]: " + rnd);
							Thread.sleep(rnd*1000);
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("After sleep...");
							WIattachStatus = WIAttachStatus(processInstanceID);
							if(!"".equalsIgnoreCase(WIattachStatus) && !"NULL".equalsIgnoreCase(WIattachStatus) && WIattachStatus != null)
								break;
						}
					}
					if(!("In Progress".equalsIgnoreCase(WIattachStatus) || "Done".equalsIgnoreCase(WIattachStatus))){
					// Lock Workitem.
					updateAttachDocStatus(processInstanceID,"In Progress");
					String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionId,processInstanceID, WorkItemID);
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
					String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, sJtsIp, iJtsPort, 1);
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

					XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
					String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

					if (getWorkItemMainCode.trim().equals("0")) {
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("WMgetWorkItemCall Successful: " + getWorkItemMainCode);
						
						String Query = "SELECT CIF_ID FROM RB_KYC_REM_EXTTABLE with (nolock) where WINAME = '"
								+ processInstanceID + "'";
						String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
						String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
						XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
						String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
						int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
						if (apSelectMaincode.equals("0") && TotalRecords > 0) {
							cifFromExtTable = xmlParserAPSelect.getValueOf("CIF_ID");
						} else {
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Cif id not recieved ");
						}
						// cif extract external table from here
						// search variable
						if (!"".equalsIgnoreCase(cifFromExtTable)) {
							String Query1 = "SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with (nolock) WHERE IsActive = 'Y'";
							String ApSelectInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName,
									sessionID);
							String ApSelectOutputXML = CommonMethods.WFNGExecute(ApSelectInputXML, jtsIP, jtsPort, 1);
							XMLParser xmlParserAPSelectDataclass = new XMLParser(ApSelectOutputXML);
							String apSelectMaincodeDataclass = xmlParserAPSelectDataclass.getValueOf("MainCode");
							int TotalRecordsDataclassName = Integer
									.parseInt(xmlParserAPSelectDataclass.getValueOf("TotalRetrieved"));
							if (apSelectMaincodeDataclass.equals("0") && TotalRecordsDataclassName > 0) {
								List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
								DataFromDB = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
								int counter = 0;
								int dataMasterSize = DataFromDB.size();
								for (Map<String, String> entry : DataFromDB) {
									String dataClassName = entry.get("DATA_CLASS_NAME");
									String dataFieldType = entry.get("FIELD_TYPE");
									String dataClassNameDefId = entry.get("iBPS_DATA_DEF_ID");
									String dataFieldTypeDefId = entry.get("iBPS_FIELD_INDEX_ID");
									String OFdataClassNameDefId = entry.get("OF_DATA_DEF_ID");
									String OFdataFieldTypeDefId = entry.get("OF_FIELD_INDEX_ID");
									
									if(!("".equalsIgnoreCase(dataClassNameDefId) && "".equalsIgnoreCase(dataFieldTypeDefId)))
									{
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Attaching docs from new OD for dataclass - "+dataClassName);
										String attachStatus = getDocAttachStatus(processInstanceID);
										
										if(!"Y".equalsIgnoreCase(attachStatus))
										{
											String result = searchInFolder(dataClassNameDefId,dataFieldTypeDefId,OFdataClassNameDefId,OFdataFieldTypeDefId,sessionId,processInstanceID,dataClassName);
											if("success".equalsIgnoreCase(result)){
											String searchDocInputXML = CommonMethods.NGOSearchDocument(dataClassNameDefId,
													dataFieldTypeDefId, cifFromExtTable, cabinetName, sessionId);
																													
											String searchDocOutputXML = CommonMethods.WFNGExecute(searchDocInputXML, jtsIP,
													jtsPort, 1);
											XMLParser xmlParserAPSearch = new XMLParser(searchDocOutputXML);
											String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
											System.out.print("Ap Search Main Code" + apSearchMaincode);
											
											int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
											System.out.print("TotalNoOfRecords" + Record);
											if (apSearchMaincode.equals("0") && Record > 0) 
											{
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Documents Found");
												NGXmlList objWorkList = xmlParserAPSearch.createList("SearchResults",
														"SearchResult");
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkList " + objWorkList);
												for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
												{
													String docDetail = xmlParserAPSearch.getNextValueOf("SearchResult");
													XMLParser xmlDocDetail = new XMLParser(docDetail);
													String ISIndex = xmlDocDetail.getValueOf("ISIndex");
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex" + ISIndex);
													
													String indexes = getIndexes(processInstanceID);
													if(!indexes.contains(ISIndex))
													{
														
														String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,
																xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
														KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex substring " + StrimgIndex);
														String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
														KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
														String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
														KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocumentIndex" + DocIndex);
														String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
														if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
														{
															String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
															String lstrDocFileSize = xmlDocDetail.getValueOf("DocumentSize");
															String DocType = xmlDocDetail.getValueOf("DocumentType");
															String NoOfPages = xmlDocDetail.getValueOf("NoOfPages");
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("StrDocumentName:"
																	+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
															String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime");
															String[] splitCreationDate = CreationDateTime.split(" ");
															String creationDate = splitCreationDate[0];
															String comment = StrDocumentName+" "+creationDate;
															String docName = "Previous_Doc";
															if("Processed_Documents".equalsIgnoreCase(dataClassName))
															{
																comment = xmlDocDetail.getValueOf("Comment");
																String[] docFields = comment.split("\\^");
																if(docFields.length == 4){
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(" Doc Search Doc Fields Length" + docFields.length);
																    String strCcif =docFields[0].trim();
																    String strRcif =docFields[1].trim();
																    String strRpName =docFields[2].trim();//complete docName
																    String docNameID =docFields[3].trim();
																    if(!strRcif.equalsIgnoreCase(""))
																    {
																    	comment = strRcif+"_"+docNameID;
																    }
																    else if("".equalsIgnoreCase(strRcif) && "".equalsIgnoreCase(strRpName) && !"".equalsIgnoreCase(strCcif))
																    {
																    	comment = strCcif+"_"+docNameID;
																    }
																    else if("".equalsIgnoreCase(strRcif) && !"".equalsIgnoreCase(strRpName))
																    {
																    	comment = strRpName+"_"+docNameID;
																    }
																    }
																    else if(docFields.length >= 5){
																    	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("In else Doc Fields Length" + docFields.length);
																	    String doc="";
																    	String strCcif =docFields[0].trim();
																	    String strRcif =docFields[1].trim();
																	    String strRpName =docFields[2].trim();//complete docName
																	    String DocDate =docFields[3].trim();
																	    String docNameID =docFields[4].trim();
																	  //to remove the extension
																	    int dotIndex = docNameID.indexOf('.');
																    	if (dotIndex != -1) {
																    		doc= docNameID.substring(0, dotIndex);	
																    		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("doc"+doc);
																    	}
																	    if(!strRcif.equalsIgnoreCase(""))
																	    {
																	    	comment = strRcif+"_"+doc+"_"+DocDate;
																	    }
																	    else if("".equalsIgnoreCase(strRcif) && "".equalsIgnoreCase(strRpName) && !"".equalsIgnoreCase(strCcif))
																	    {
																	    	comment = strCcif+"_"+doc+"_"+DocDate;
																	    }
																	    else if("".equalsIgnoreCase(strRcif) && !"".equalsIgnoreCase(strRpName))
																	    {
																	    	comment = strRpName+"_"+doc+"_"+DocDate;
																	    }
																	    
																    }
																if(StrDocumentName.contains("^"))
																{
																	docName = StrDocumentName.substring(StrDocumentName.lastIndexOf("^")+1);
																	System.out.println("docName from processed dataclass-> "+docName);
																	if(!DocumentTypes.contains(docName.replaceAll(" ", "")))
																		docName = "Previous_Doc";
																}
																else
																{
																	docName = StrDocumentName;
																	if(!DocumentTypes.contains(docName.replaceAll(" ", "")))
																		docName = "Previous_Doc";
																}
															}
															// StrDocumentName+="_"+DocIndex;
															// getting parentFolderIndex of the
															// Workitem
															String query = "Select folderindex from pdbfolder with(nolock) where name = '"
																	+ processInstanceID + "'";
															String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query,
																	cabinetName, sessionID);
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																	.debug("apSelectInputXML--- " + apSelectInputXML);
															String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP,
																	jtsPort, 1);
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																	.debug("apSelectOutXml--- " + apSelectOutXml);
															XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
															.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
															String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex
																	.getValueOf("MainCode");
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
															.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
															if (apSearchMaincodefolderIndex.equalsIgnoreCase("0")) 
															{
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																.debug("inside if of apSearchMaincodefolderIndex");
																String parentFolderIndex = xmlParserAPSearchfolderIndex.getValueOf("folderindex");
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																.debug("parentFolderIndex--- "+parentFolderIndex+DocType+" "+StrCreatedByAppName+" "+ISIndex+" "+lstrDocFileSize+" "+StrVolId+" "+cabinetName+" "+sessionId+" "+StrDocumentName+" "+NoOfPages);
																
																//
																StringBuffer ipXMLBuffer=new StringBuffer();

																ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
																ipXMLBuffer.append("<NGOAddDocument_Input>\n");
																ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
																ipXMLBuffer.append("<CabinetName>");
																ipXMLBuffer.append(cabinetName);
																ipXMLBuffer.append("</CabinetName>\n");
																ipXMLBuffer.append("<UserDBId>");
																ipXMLBuffer.append(sessionId);
																ipXMLBuffer.append("</UserDBId>\n");
																ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
																ipXMLBuffer.append("<Document>\n");
																ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
																ipXMLBuffer.append("<ParentFolderIndex>");
																ipXMLBuffer.append(parentFolderIndex);
																ipXMLBuffer.append("</ParentFolderIndex>\n");
																ipXMLBuffer.append("<DocumentName>");
																ipXMLBuffer.append(docName);
																ipXMLBuffer.append("</DocumentName>\n");
																ipXMLBuffer.append("<VolumeIndex>");
																ipXMLBuffer.append(volumeID);
																ipXMLBuffer.append("</VolumeIndex>\n");
																ipXMLBuffer.append("<ISIndex>");
																ipXMLBuffer.append(ISIndex);
																ipXMLBuffer.append("</ISIndex>\n");
																ipXMLBuffer.append("<NoOfPages>");
																ipXMLBuffer.append(NoOfPages);
																ipXMLBuffer.append("</NoOfPages>\n");
																ipXMLBuffer.append("<DocumentType>");
																ipXMLBuffer.append(DocType);
																ipXMLBuffer.append("</DocumentType>\n");
																ipXMLBuffer.append("<Comment>");              
														        ipXMLBuffer.append(comment);
														        ipXMLBuffer.append("</Comment>\n");
																ipXMLBuffer.append("<DocumentSize>");
																ipXMLBuffer.append(lstrDocFileSize);
																ipXMLBuffer.append("</DocumentSize>\n");
																ipXMLBuffer.append("<CreatedByAppName>");
																ipXMLBuffer.append(StrCreatedByAppName);
																ipXMLBuffer.append("</CreatedByAppName>\n");
																ipXMLBuffer.append("</Document>\n");
																ipXMLBuffer.append("</NGOAddDocument_Input>\n");
																String NGOaddDocInputXML =  ipXMLBuffer.toString();
																/*
																String NGOaddDocInputXML = CommonMethods.getNGOAddDocumentKYC(
																		parentFolderIndex, "Previous_Doc", DocType, StrCreatedByAppName,
																		ISIndex, lstrDocFileSize, StrVolId, cabinetName, sessionId,StrDocumentName,NoOfPages);*/
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
																String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML,jtsIP, jtsPort, 1);
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);
																XMLParser XMLParseraddDoc = new XMLParser(NGOaddDocOutXml);
																String addDocMainCode = XMLParseraddDoc.getValueOf("Status");
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("addDocMainCode--- " + addDocMainCode);
																if (addDocMainCode.equalsIgnoreCase("0")) 
																{
																	appendIndex(processInstanceID,ISIndex,indexes);
																	WI_AddDoc_Status = "Success";
																}
																else
																{
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in Add document in API " + addDocMainCode);
																	WI_AddDoc_Status = "Error";
																	break;
																}
															} 
															else
															{
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in getting folder Index");
																WI_AddDoc_Status = "Error";
																break;
															}
														}
														else
														{
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Audit Trail doc not added");
														}
													}
													else
													{
														KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document already added");
													}
												}
												if ("Success".equalsIgnoreCase(WI_AddDoc_Status)) {
													iBpsDocsAttached = "Success";
													//updateDocAttachStatus(processInstanceID);
												}
												if ("Error".equalsIgnoreCase(WI_AddDoc_Status)) {
													break;
												}
											}
											else{
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("No docs available in CIF");
												iBpsDocsAttached = "Success";
												//updateDocAttachStatus(processInstanceID);
												WI_AddDoc_Status = "Success";
											}
										}else{
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("error in searchInFolder Method().");
											WI_AddDoc_Status = "Error";
											//25 June 2024
											iBpsDocsAttached = "Error";
											break;
										}
										}else{
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("iBps Docs already attached as status received is Y");
											WI_AddDoc_Status = "Success";
									}
								  }
									
									///  for searching on of server adding this block/////////////////////////
									
									if(!("".equalsIgnoreCase(OFdataClassNameDefId) && "".equalsIgnoreCase(OFdataFieldTypeDefId))){
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("attaching docs from old omnidocs for dataclass - "+dataClassName);
										String attachStatus = getOFDocAttachStatus(processInstanceID);
										
										if(!"Y".equalsIgnoreCase(attachStatus))
										{
											try{
										String OFsessionID = CommonConnection.getOFSessionID(KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger, false);
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(" Out OFsessionID" + OFsessionID);
										String result = searchInFolderOF(dataClassNameDefId,dataFieldTypeDefId,OFdataClassNameDefId,OFdataFieldTypeDefId,sessionId,OFsessionID,processInstanceID);
										if("success".equalsIgnoreCase(result)){
										String searchDocInputXML = CommonMethods.NGOSearchDocument(OFdataClassNameDefId,OFdataFieldTypeDefId, cifFromExtTable, ofCabinetName, OFsessionID);
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(" searchDocInputXML OFsessionID" + searchDocInputXML);										
										String searchDocOutputXML = CommonMethods.WFNGExecute(searchDocInputXML, ofjtsIP, ofjtsPort, 1);
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(" searchDocOutputXML OFsessionID" + searchDocOutputXML);
										
										XMLParser xmlParserAPSearch = new XMLParser(searchDocOutputXML);
										String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
										System.out.print("Ap Search Main Code" + apSearchMaincode);
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSearchMaincode-- "+apSearchMaincode);
										int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Recorde-- "+Record);
										System.out.print("TotalNoOfRecords" + Record);
										if (apSearchMaincode.equals("0") && Record > 0) {
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Documents Found");
											NGXmlList objWorkList = xmlParserAPSearch.createList("SearchResults",
													"SearchResult");
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkList " + objWorkList);
											for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) {
												String docDetail = xmlParserAPSearch.getNextValueOf("SearchResult");
												XMLParser xmlDocDetail = new XMLParser(docDetail);
												String ISIndex = xmlDocDetail.getValueOf("ISIndex");
											
												String indexes = getOFIndexes(processInstanceID);
												if(!indexes.contains(ISIndex))
												{
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex" + ISIndex);
												String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
												
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex substring " + StrimgIndex);
												String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
												String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocumentIndex" + DocIndex);
												String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
												String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
												if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
												{	
												String NoOfPages = xmlDocDetail.getValueOf("NoOfPages");
												String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime");
												String[] splitCreationDate = CreationDateTime.split(" ");
												String creationDate = splitCreationDate[0];
												String comment = StrDocumentName+" "+creationDate;
												if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside if of special character replacement");
													StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document name after special character replacement - " + StrDocumentName);
												}
												String nextFlePath = DocLocation+File.separator+StrDocumentName;
												String c_Site = "1";
												String msg = "";
												boolean status ;
												try
												{
													CImageServer cImageServer=null;
													try 
													{
														cImageServer = new CImageServer(null, ofjtsIP, Short.parseShort(ofjtsPort));
													}
													catch (JPISException e) 
													{
														e.printStackTrace();
														msg = e.getMessage();
														status=false;
														WI_AddDoc_Status = "Error";
														break;
													}
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("values passed -> "+ ofjtsIP+" "+ofjtsPort+" "+ofCabinetName+" "+StrVolId+" "+c_Site+" "+StrimgIndex+" "+nextFlePath.toString());
													
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("document name and imageindex for "+processInstanceID+" -- "+StrDocumentName+", "+StrimgIndex);
													JPISIsIndex ISINDEX = new JPISIsIndex();
													JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
									
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Fetching OD Download Code ::::::");
													int odDownloadCode;
													odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,ofjtsIP, Short.parseShort(ofjtsPort), ofCabinetName, Short.parseShort(c_Site),Short.parseShort(StrVolId), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("OD Download Code :"+odDownloadCode);
													if(odDownloadCode == -6012){
														nextFlePath = DocLocation+File.separator+"ApplicatioDoc."+StrCreatedByAppName;
														odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,ofjtsIP, Short.parseShort(ofjtsPort), ofCabinetName, Short.parseShort(c_Site),Short.parseShort(StrVolId), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
														KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ODDownloadCode after changing doc name --> "+odDownloadCode);
													}
														try {
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("trying to add doc on image server");
															
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Values passed -- >jtsip-"+jtsIP+" , jtsPort->"+jtsPort+",cabinetName->"+cabinetName+",volumeID->"+volumeID+", File path-->"+nextFlePath);
															CPISDocumentTxn.AddDocument_MT(null, jtsIP , Short.parseShort(SMSPort), cabinetName, Short.parseShort(volumeID), nextFlePath.toString(),JPISDEC,"",ISINDEX);
															
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("after CPISDocumentTxn AddDocument MT: ");
															String sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("sISIndex after adding on SMS - "+sISIndex);
															
																String lstrDocFileSize = xmlDocDetail.getValueOf("DocumentSize");
																String DocType = xmlDocDetail.getValueOf("DocumentType");
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("StrDocumentName:"
																		+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
																// StrDocumentName+="_"+DocIndex;
																// getting parentFolderIndex of the
																// Workitem
																String query = "Select folderindex from pdbfolder with(nolock) where name = '"
																		+ processInstanceID + "'";
																String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query,
																		cabinetName, sessionID);
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																		.debug("apSelectInputXML--- " + apSelectInputXML);
																String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP,
																		jtsPort, 1);
																KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																		.debug("apSelectOutXml--- " + apSelectOutXml);
																XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
																String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex
																		.getValueOf("MainCode");
																if (apSearchMaincodefolderIndex.equalsIgnoreCase("0")) {
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																	.debug("Inside if of folder index");
																	String parentFolderIndex = xmlParserAPSearchfolderIndex.getValueOf("folderindex");
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																	.debug("parentFolderIndex--- "+parentFolderIndex+DocType+" "+StrCreatedByAppName+" "+ISIndex+" "+lstrDocFileSize+" "+StrVolId+" "+cabinetName+" "+sessionId+" "+StrDocumentName+" "+NoOfPages);
																	
																	StringBuffer ipXMLBuffer=new StringBuffer();

																	ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
																	ipXMLBuffer.append("<NGOAddDocument_Input>\n");
																	ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
																	ipXMLBuffer.append("<CabinetName>");
																	ipXMLBuffer.append(cabinetName);
																	ipXMLBuffer.append("</CabinetName>\n");
																	ipXMLBuffer.append("<UserDBId>");
																	ipXMLBuffer.append(sessionId);
																	ipXMLBuffer.append("</UserDBId>\n");
																	ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
																	ipXMLBuffer.append("<Document>\n");
																	ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
																	ipXMLBuffer.append("<ParentFolderIndex>");
																	ipXMLBuffer.append(parentFolderIndex);
																	ipXMLBuffer.append("</ParentFolderIndex>\n");
																	ipXMLBuffer.append("<DocumentName>");
																	ipXMLBuffer.append("Previous_Doc");
																	ipXMLBuffer.append("</DocumentName>\n");
																	ipXMLBuffer.append("<VolumeIndex>");
																	ipXMLBuffer.append(volumeID);
																	ipXMLBuffer.append("</VolumeIndex>\n");
																	ipXMLBuffer.append("<ISIndex>");
																	ipXMLBuffer.append(sISIndex);
																	ipXMLBuffer.append("</ISIndex>\n");
																	ipXMLBuffer.append("<NoOfPages>");
																	ipXMLBuffer.append(NoOfPages);
																	ipXMLBuffer.append("</NoOfPages>\n");
																	ipXMLBuffer.append("<DocumentType>");
																	ipXMLBuffer.append(DocType);
																	ipXMLBuffer.append("</DocumentType>\n");
																	ipXMLBuffer.append("<Comment>");              
															        ipXMLBuffer.append(comment);
															        ipXMLBuffer.append("</Comment>\n");
																	ipXMLBuffer.append("<DocumentSize>");
																	ipXMLBuffer.append(lstrDocFileSize);
																	ipXMLBuffer.append("</DocumentSize>\n");
																	ipXMLBuffer.append("<CreatedByAppName>");
																	ipXMLBuffer.append(StrCreatedByAppName);
																	ipXMLBuffer.append("</CreatedByAppName>\n");
																	ipXMLBuffer.append("</Document>\n");
																	ipXMLBuffer.append("</NGOAddDocument_Input>\n");
																	String NGOaddDocInputXML =  ipXMLBuffer.toString();
																	//
																	/*String NGOaddDocInputXML = CommonMethods.getNGOAddDocumentKYC(
																			parentFolderIndex, "Previous_Doc", DocType, StrCreatedByAppName,
																			sISIndex, lstrDocFileSize, volumeID, cabinetName, sessionId,StrDocumentName,NoOfPages);*/
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
																	String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML,
																			jtsIP, jtsPort, 1);
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																			.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);
																	appendOFIndex(processInstanceID,ISIndex,indexes);
																	deleteDownloadedDocs(nextFlePath);
																	WI_AddDoc_Status = "Success";

																} else {
																	WI_AddDoc_Status = "Error";
																	break;
																}
																/*}
																else {
																	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
																	.debug("Audit Trail doc not added");
																}*/
															
														} catch (JPISException e) {
															KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
															.debug("Inside exception--"+e);
															final Writer result1 = new StringWriter();
															final PrintWriter printWriter = new PrintWriter(result1);
															e.printStackTrace(printWriter);
															msg=e.getMessage();
															status=false;
															e.printStackTrace();
															WI_AddDoc_Status = "Error";
															break;
														}
												}
													catch (Exception e) 
													{
														KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exsception occured in DownloadDocument method : "+e);
														System.out.println("Some exception occured while downloading the document.");
														
														final Writer result1 = new StringWriter();
														final PrintWriter printWriter = new PrintWriter(result1);
														e.printStackTrace(printWriter);
														msg=e.getMessage();
														status=false;
														WI_AddDoc_Status = "Error";
														break;
													}
												}
												else
												{
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Audit Trail doc not added");
												}
											}
												else
												{
													KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Doc already added from ofserver");
												}	
											}
											if ("Success".equalsIgnoreCase(WI_AddDoc_Status)) {
												OFDocsAttached = "Success";
												//updateOFDocAttachStatus(processInstanceID);
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("updating of Doc attach status after all docs added");
											}
											if ("Error".equalsIgnoreCase(WI_AddDoc_Status)) {
												break;
											}
										}
										else{
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("No docs available in CIF");
											OFDocsAttached = "Success";
											//updateOFDocAttachStatus(processInstanceID);
											WI_AddDoc_Status = "Success";
										}
											}else
											{
												KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("error in searchInFolder Method().");
												WI_AddDoc_Status = "Error";
												OFDocsAttached = "Error";
												break;
											}
											}
										catch(Exception e){
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("INside catch of ofServer if--->"+e.getMessage());
										}
										}
									  }
									/////OF server block end
									counter++;
								}
								if("Success".equalsIgnoreCase(iBpsDocsAttached)){
									if(counter==dataMasterSize)
									updateDocAttachStatus(processInstanceID);
								}
								if("Success".equalsIgnoreCase(OFDocsAttached)){
									if(counter==dataMasterSize)
									updateOFDocAttachStatus(processInstanceID);
								}
							} else {
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Data Class Name not found ");
							}
						}
						else {
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("CIF not found");
						}
					} else {
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in getting WorkItem");
						//WI_AddDoc_Status = "Error";
						continue;
					}
					
					String getWorkItemInputXML1 = CommonMethods.getWorkItemInput(cabinetName, sessionId, processInstanceID,WorkItemID);
					String getWorkItemOutputXml1 = CommonMethods.WFNGExecute(getWorkItemInputXML,sJtsIp,iJtsPort,1);
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Output XML For WmgetWorkItemCall: "+ getWorkItemOutputXml);
					
					XMLParser xmlParserGetWorkItem1 = new XMLParser(getWorkItemOutputXml);
					String getWorkItemMainCode1 = xmlParserGetWorkItem.getValueOf("MainCode");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("WmgetWorkItemCall Maincode:  "+ getWorkItemMainCode);

					String remark = "";
					if (getWorkItemMainCode.trim().equals("0")){
					//completeWI
						String Final_Status ="";
						String uploadStatus = "";
						if("Success".equalsIgnoreCase(WI_AddDoc_Status)){
							Final_Status ="Success";
							remark = "Documents attached successfully";
							uploadStatus = "Done";
						}
						else{
							Final_Status="Error";
							remark = "Error in attaching document";
							uploadStatus = "";
						}
					String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
                            + "<Option>WMAssignWorkItemAttributes</Option>"
                            + "<EngineName>"+cabinetName+"</EngineName>"
                            + "<SessionId>"+sessionId+"</SessionId>"
                            + "<ProcessInstanceId>"+processInstanceID+"</ProcessInstanceId>"
                            + "<WorkItemId>"+WorkItemID+"</WorkItemId>"
                            + "<ActivityId>"+activityId+"</ActivityId>"
                            + "<ProcessDefId>"+ProcessDefID+"</ProcessDefId>"
                            + "<LastModifiedTime></LastModifiedTime>"
                            + "<ActivityType></ActivityType>"
                            + "<complete>D</complete>"
                            + "<AuditStatus></AuditStatus>"
                            + "<Comments></Comments>"
                            + "<UserDefVarFlag>Y</UserDefVarFlag>"
                            + "<Attributes><DECISION>"+Final_Status+"</DECISION><qAttachDocStatus>"+uploadStatus+"</qAttachDocStatus></Attributes>"
                            + "</WMAssignWorkItemAttributes_Input>";


					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("assignInputXML--- "+assignInputXML);
					String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("assignOutXml--- "+assignOutXml);
					// PRINT MAINCODE
					XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
					String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
					if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")){
						
						Date d = new Date();
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String strDate = dateFormat.format(d);
						
						String tableName = "NG_KYC_REM_GR_HISTORY";
						String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
						String values = "'"+strDate+"','Attach_Document','"+Final_Status+"','rakBPMutility','"+remark+"','"+processInstanceID+"','"+entryDateTime+"'";
						
						String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnName,values,tableName);
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("APInsertInputXML: "+apInsertInputXML);

						String apInsertOutputXML =CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("APInsertOutputXML: "+ apInsertOutputXML);

						XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
						String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Status of apInsertMaincode  "+ apInsertMaincode);
						if(apInsertMaincode.equalsIgnoreCase("0"))
						{
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ApInsert successful: "+apInsertMaincode);
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Data Inserted in history table successfully.");
						}
					}
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("xmlParserAPSelectFinalMaincode :"+xmlParserAPSelectFinalMaincode);
					}
					}
					else 
					{
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("attachDocStatus is  WI - "+WIattachStatus);
						continue;
					}
				}
			}
		}
		catch (Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception ui: "+e.getMessage());
		}
	}
	
	private String searchInFolderOF(String dataClassNameDefId, String dataFieldTypeDefId, String oFdataClassNameDefId,
			String oFdataFieldTypeDefId, String sessionId, String oFsessionID, String processInstanceID) {
		String status = "";
		try{
			String searchFolderInputXML = CommonMethods.apNGOSearchFolder(ofCabinetName,oFsessionID,oFdataClassNameDefId,
					oFdataFieldTypeDefId, cifFromExtTable);
																					
			String searchFolderOutputXML = CommonMethods.WFNGExecute(searchFolderInputXML, ofjtsIP,
					ofjtsPort, 1);
			XMLParser xmlParserAPSearch = new XMLParser(searchFolderOutputXML);
			String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
			System.out.print("Ap Search Main Code" + apSearchMaincode);
			/*int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
			System.out.print("TotalNoOfRecords" + Record);*/
			if (apSearchMaincode.equals("0")) 
			{
				String Record = xmlParserAPSearch.getValueOf("TotalNoOfRecords");
				if(!"".equalsIgnoreCase(Record)){
				int RecordInt = Integer.parseInt(Record);
				if(RecordInt > 0){
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Folders Found");
				NGXmlList objWorkList = xmlParserAPSearch.createList("Folders","Folder");
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkList " + objWorkList);
				for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
				{
					String FolderDetail = xmlParserAPSearch.getNextValueOf("Folder");
					XMLParser xmlFolderDetail = new XMLParser(FolderDetail);
					String searchedFolderIndex = xmlFolderDetail.getFirstValueOf("FolderIndex");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("searchedFolderIndex " + searchedFolderIndex);
					
					String documentListInputXML = CommonMethods.getDocumentList(searchedFolderIndex, oFsessionID, ofCabinetName);
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("documentListInputXML " + documentListInputXML);
					String documentListOutputXML = CommonMethods.WFNGExecute(documentListInputXML, ofjtsIP,ofjtsPort,1);
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("documentListOutputXML " + documentListOutputXML);
					XMLParser xmlParserDocList = new XMLParser(documentListOutputXML);
					String DocListMainCode = xmlParserDocList.getValueOf("Status");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocListMainCode " + DocListMainCode);
					int DocListRecord = Integer.parseInt(xmlParserDocList.getValueOf("TotalNoOfRecords"));
					if (DocListMainCode.equals("0") && DocListRecord > 0) 
					{
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Documents Found");
						NGXmlList objWorkLists = xmlParserDocList.createList("Documents","Document");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkLists " + objWorkLists);
						for (; objWorkLists.hasMoreElements(true); objWorkLists.skip(true)) 
						{
							String docDetail = xmlParserDocList.getNextValueOf("Document");
							XMLParser xmlDocDetail = new XMLParser(docDetail);
							String ISIndex = xmlDocDetail.getValueOf("ISIndex");
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex" + ISIndex);
							
							String indexes = getOFIndexes(processInstanceID);
							if(!indexes.contains(ISIndex))
							{
								
								String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,
										xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex substring " + StrimgIndex);
								String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
								String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocumentIndex" + DocIndex);
								String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
								if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
								{
									String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
									String lstrDocFileSize = xmlDocDetail.getValueOf("DocumentSize");
									String DocType = xmlDocDetail.getValueOf("DocumentType");
									String NoOfPages = xmlDocDetail.getValueOf("NoOfPages");
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
									String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime");
									String[] splitCreationDate = CreationDateTime.split(" ");
									String creationDate = splitCreationDate[0];
									String comment = StrDocumentName+" "+creationDate;
									// StrDocumentName+="_"+DocIndex;
									// getting parentFolderIndex of the
									// Workitem
									
									if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside if of special character replacement");
										StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
									}
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("document name after special character replacement - "+StrDocumentName);
									String nextFlePath = DocLocation+File.separator+StrDocumentName;
									
									String c_Site = "1"; //Clarification
									String msg = "";
									//boolean status ;
									
									CImageServer cImageServer=null;
									try 
									{
										cImageServer = new CImageServer(null, ofjtsIP, Short.parseShort(ofjtsPort));
									}
									catch (JPISException e) 
									{
										e.printStackTrace();
										msg = e.getMessage();
										status="error";
										return status;
									}
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("values passed -> "+ ofjtsIP+" "+ofjtsPort+" "+ofCabinetName+" "+StrVolId+" "+c_Site+" "+StrimgIndex+" "+nextFlePath.toString());
									
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("document name and imageindex for "+processInstanceID+" -- "+StrDocumentName+", "+StrimgIndex);
									JPISIsIndex ISINDEX = new JPISIsIndex();
									JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
									String volumeIDold = StrVolId.substring(0,StrVolId.indexOf("#"));
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Fetching OD Download Code ::::::");
									int odDownloadCode;
									odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,ofjtsIP, Short.parseShort(ofjtsPort), ofCabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("OD Download Code :"+odDownloadCode);
									if(odDownloadCode == -6012)
									{
										nextFlePath = DocLocation+File.separator+"ApplicationDoc."+StrCreatedByAppName;
										odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,ofjtsIP, Short.parseShort(ofjtsPort), ofCabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ODDownloadCode after changing doc name --> "+odDownloadCode);

									}
									String sISIndex = "";
									try {
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("trying to add doc on image server");
										
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Values passed -- >jtsip-"+jtsIP+" , jtsPort->"+jtsPort+",cabinetName->"+cabinetName+",volumeID->"+volumeID+", File path-->"+nextFlePath);
										CPISDocumentTxn.AddDocument_MT(null, jtsIP , Short.parseShort(SMSPort), cabinetName, Short.parseShort(volumeID), nextFlePath.toString(),JPISDEC,"",ISINDEX);
										
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("after CPISDocumentTxn AddDocument MT: ");
										sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("sISIndex after adding on SMS - "+sISIndex);
										}catch (JPISException e) {
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside exception--"+e);
											final Writer result1 = new StringWriter();
											final PrintWriter printWriter = new PrintWriter(result1);
											e.printStackTrace(printWriter);
											msg=e.getMessage();
											status="error";
											e.printStackTrace();
											return status;
										}
									String query = "Select folderindex from pdbfolder with(nolock) where name = '"+ processInstanceID + "'";
									String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query,cabinetName, sessionID);
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSelectInputXML--- " + apSelectInputXML);
									String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP,jtsPort, 1);
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSelectOutXml--- " + apSelectOutXml);
									XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
									String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
									if (apSearchMaincodefolderIndex.equalsIgnoreCase("0")) 
									{
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("inside if of apSearchMaincodefolderIndex");
										String parentFolderIndex = xmlParserAPSearchfolderIndex.getValueOf("folderindex");
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("parentFolderIndex--- "+parentFolderIndex+DocType+" "+StrCreatedByAppName+" "+ISIndex+" "+lstrDocFileSize+" "+StrVolId+" "+cabinetName+" "+sessionId+" "+StrDocumentName+" "+NoOfPages);
										StringBuffer ipXMLBuffer=new StringBuffer();

										ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
										ipXMLBuffer.append("<NGOAddDocument_Input>\n");
										ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
										ipXMLBuffer.append("<CabinetName>");
										ipXMLBuffer.append(cabinetName);
										ipXMLBuffer.append("</CabinetName>\n");
										ipXMLBuffer.append("<UserDBId>");
										ipXMLBuffer.append(sessionId);
										ipXMLBuffer.append("</UserDBId>\n");
										ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
										ipXMLBuffer.append("<Document>\n");
										ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
										ipXMLBuffer.append("<ParentFolderIndex>");
										ipXMLBuffer.append(parentFolderIndex);
										ipXMLBuffer.append("</ParentFolderIndex>\n");
										ipXMLBuffer.append("<DocumentName>");
										ipXMLBuffer.append("Previous_Doc");
										ipXMLBuffer.append("</DocumentName>\n");
										ipXMLBuffer.append("<VolumeIndex>");
										ipXMLBuffer.append(volumeID);
										ipXMLBuffer.append("</VolumeIndex>\n");
										ipXMLBuffer.append("<ISIndex>");
										ipXMLBuffer.append(sISIndex);
										ipXMLBuffer.append("</ISIndex>\n");
										ipXMLBuffer.append("<NoOfPages>");
										ipXMLBuffer.append(NoOfPages);
										ipXMLBuffer.append("</NoOfPages>\n");
										ipXMLBuffer.append("<DocumentType>");
										ipXMLBuffer.append(DocType);
										ipXMLBuffer.append("</DocumentType>\n");
										ipXMLBuffer.append("<Comment>");              
								        ipXMLBuffer.append(comment);
								        ipXMLBuffer.append("</Comment>\n");
										ipXMLBuffer.append("<DocumentSize>");
										ipXMLBuffer.append(lstrDocFileSize);
										ipXMLBuffer.append("</DocumentSize>\n");
										ipXMLBuffer.append("<CreatedByAppName>");
										ipXMLBuffer.append(StrCreatedByAppName);
										ipXMLBuffer.append("</CreatedByAppName>\n");
										ipXMLBuffer.append("</Document>\n");
										ipXMLBuffer.append("</NGOAddDocument_Input>\n");
										String NGOaddDocInputXML =  ipXMLBuffer.toString();
										//
										/*String NGOaddDocInputXML = CommonMethods.getNGOAddDocumentKYC(
												parentFolderIndex, "Previous_Doc", DocType, StrCreatedByAppName,
												ISIndex, lstrDocFileSize, StrVolId, cabinetName, sessionId,StrDocumentName,NoOfPages);*/
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
										String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML,jtsIP, jtsPort, 1);
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);
										
										XMLParser xmlParserAddDoc = new XMLParser(NGOaddDocOutXml);
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("xmlParserAddDoc--- " + xmlParserAddDoc);
										String addDocMainCode = xmlParserAddDoc.getValueOf("Status");
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("addDocMainCode--- " + addDocMainCode);
										if (addDocMainCode.equalsIgnoreCase("0")) 
										{
											appendOFIndex(processInstanceID,ISIndex,indexes);
										status = "success";
										}else{
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in NGO add doc API--- ");
											status = "error";
											return status;
										}
										//WI_AddDoc_Status = "Success";
									}else{
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Ap Search maincode folderindex is not zero");
										status = "error";
										return status;
									}
								}
								else
								{
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Audit Trail not added.");
									status = "success";
								}
							}
							else
							{
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document already added");
								status = "success";
							}
						}
					}
					else
					{
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("No docs available in folder in old OD");
						status = "success";
					}
				}
				}else{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Folders not exists");
					status = "success";
				}
			}else{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Folder not exists");
				status = "success";
			}
			}
			else
			{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in search folder");
				status = "Error";
				return status;
			}
		}catch(Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in searchInFolderOF method ->" + e);
			status = "error";
			return status;
		}
		return status;
	}

	private String searchInFolder(String dataClassNameDefId, String dataFieldTypeDefId, String oFdataClassNameDefId,
			String oFdataFieldTypeDefId,String sessionId,String processInstanceID,String dataClassName) {
		String status = "";
		try{
		String searchFolderInputXML = CommonMethods.apNGOSearchFolder(cabinetName,sessionId,dataClassNameDefId,
				dataFieldTypeDefId, cifFromExtTable);
																				
		String searchFolderOutputXML = CommonMethods.WFNGExecute(searchFolderInputXML, jtsIP,
				jtsPort, 1);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("searchFolderOutputXML" + searchFolderOutputXML);
		XMLParser xmlParserAPSearch = new XMLParser(searchFolderOutputXML);
		String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
		System.out.print("Ap Search Main Code" + apSearchMaincode);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Ap Search Main Code" + apSearchMaincode);
		/*int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
		System.out.print("TotalNoOfRecords" + Record);*/
		if (apSearchMaincode.equals("0")) 
		{
			String Record = xmlParserAPSearch.getValueOf("TotalNoOfRecords");
			if(!"".equalsIgnoreCase(Record)){
			int RecordInt = Integer.parseInt(Record);
			if(RecordInt > 0){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("TotalNoOfRecords" + Record);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Folders Found");
			NGXmlList objWorkList = xmlParserAPSearch.createList("Folders","Folder");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkList " + objWorkList);
			for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
			{
				String FolderDetail = xmlParserAPSearch.getNextValueOf("Folder");
				XMLParser xmlFolderDetail = new XMLParser(FolderDetail);
				String searchedFolderIndex = xmlFolderDetail.getFirstValueOf("FolderIndex");
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("searchedFolderIndex " + searchedFolderIndex);
				
				String documentListInputXML = CommonMethods.getDocumentList(searchedFolderIndex, sessionId, cabinetName);
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("documentListInputXML " + documentListInputXML);
				String documentListOutputXML = CommonMethods.WFNGExecute(documentListInputXML, jtsIP,
						jtsPort, 1);
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("documentListOutputXML " + documentListOutputXML);
				XMLParser xmlParserDocList = new XMLParser(documentListOutputXML);
				String DocListMainCode = xmlParserDocList.getValueOf("Status");
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocListMainCode " + DocListMainCode);
				int DocListRecord = Integer.parseInt(xmlParserDocList.getValueOf("TotalNoOfRecords"));
				if (DocListMainCode.equals("0") && DocListRecord > 0) 
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Documents Found");
					NGXmlList objWorkLists = xmlParserDocList.createList("Documents","Document");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkLists " + objWorkLists);
					for (; objWorkLists.hasMoreElements(true); objWorkLists.skip(true)) 
					{
						String docDetail = xmlParserDocList.getNextValueOf("Document");
						XMLParser xmlDocDetail = new XMLParser(docDetail);
						String ISIndex = xmlDocDetail.getValueOf("ISIndex");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex" + ISIndex);
						
						String indexes = getIndexes(processInstanceID);
						if(!indexes.contains(ISIndex))
						{
							
							String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,
									xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex substring " + StrimgIndex);
							String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
							String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocumentIndex" + DocIndex);
							String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
							if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
							{
								String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
								String lstrDocFileSize = xmlDocDetail.getValueOf("DocumentSize");
								String DocType = xmlDocDetail.getValueOf("DocumentType");
								String NoOfPages = xmlDocDetail.getValueOf("NoOfPages");
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
								String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime");
								String[] splitCreationDate = CreationDateTime.split(" ");
								String creationDate = splitCreationDate[0];
								String comment = StrDocumentName+" "+creationDate;
								if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside if of special character replacement");
									StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
								}
								
								String docName = "Previous_Doc";
								if("Processed_Documents".equalsIgnoreCase(dataClassName))
								{
									comment = xmlDocDetail.getValueOf("Comment");
									String[] docFields = comment.split("\\^");
									if(docFields.length == 4){
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(" Doc Search Doc Fields Length" + docFields.length);
									    String strCcif =docFields[0].trim();
									    String strRcif =docFields[1].trim();
									    String strRpName =docFields[2].trim();//complete docName
									    String docNameID =docFields[3].trim();
									    if(!strRcif.equalsIgnoreCase(""))
									    {
									    	comment = strRcif+"_"+docNameID;
									    }
									    else if("".equalsIgnoreCase(strRcif) && "".equalsIgnoreCase(strRpName) && !"".equalsIgnoreCase(strCcif))
									    {
									    	comment = strCcif+"_"+docNameID;
									    }
									    else if("".equalsIgnoreCase(strRcif) && !"".equalsIgnoreCase(strRpName))
									    {
									    	comment = strRpName+"_"+docNameID;
									    }
									    }
									    else if(docFields.length >= 5){
									    	KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("In else Doc Fields Length" + docFields.length);
										    String doc="";
									    	String strCcif =docFields[0].trim();
										    String strRcif =docFields[1].trim();
										    String strRpName =docFields[2].trim();//complete docName
										    String DocDate =docFields[3].trim();
										    String docNameID =docFields[4].trim();
										  //to remove the extension
										    int dotIndex = docNameID.indexOf('.');
									    	if (dotIndex != -1) {
									    		doc= docNameID.substring(0, dotIndex);	
									    		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("doc"+doc);
									    	}
										    if(!strRcif.equalsIgnoreCase(""))
										    {
										    	comment = strRcif+"_"+doc+"_"+DocDate;
										    }
										    else if("".equalsIgnoreCase(strRcif) && "".equalsIgnoreCase(strRpName) && !"".equalsIgnoreCase(strCcif))
										    {
										    	comment = strCcif+"_"+doc+"_"+DocDate;
										    }
										    else if("".equalsIgnoreCase(strRcif) && !"".equalsIgnoreCase(strRpName))
										    {
										    	comment = strRpName+"_"+doc+"_"+DocDate;
										    }
										    
									    }
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside processed data function .....StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
									if(StrDocumentName.contains("^"))
									{
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside if and having ^ in document name");
										docName = StrDocumentName.substring(StrDocumentName.lastIndexOf("^")+1);
										System.out.println("docName from processed dataclass-> "+docName);
										if(!DocumentTypes.contains(docName.replaceAll(" ", "")))
										{
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document name not found in document type");
											docName = "Previous_Doc";
										}
									}
									else
									{
										docName = StrDocumentName;
										if(!DocumentTypes.contains(docName.replaceAll(" ", "")))
										{
											KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document name - "+docName+" not found in document type");
											docName = "Previous_Doc";
										}
									}
								}
								// getting parentFolderIndex of the
								// Workitem
								String query = "Select folderindex from pdbfolder with(nolock) where name = '"+ processInstanceID + "'";
								String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query,cabinetName, sessionID);
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSelectInputXML--- " + apSelectInputXML);
								String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP,jtsPort, 1);
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSelectOutXml--- " + apSelectOutXml);
								XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
								String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
								if (apSearchMaincodefolderIndex.equalsIgnoreCase("0")) 
								{
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("inside if of apSearchMaincodefolderIndex");
									String parentFolderIndex = xmlParserAPSearchfolderIndex.getValueOf("folderindex");
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("parentFolderIndex--- "+parentFolderIndex+DocType+" "+StrCreatedByAppName+" "+ISIndex+" "+lstrDocFileSize+" "+StrVolId+" "+cabinetName+" "+sessionId+" "+StrDocumentName+" "+NoOfPages);
									StringBuffer ipXMLBuffer=new StringBuffer();

									ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
									ipXMLBuffer.append("<NGOAddDocument_Input>\n");
									ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
									ipXMLBuffer.append("<CabinetName>");
									ipXMLBuffer.append(cabinetName);
									ipXMLBuffer.append("</CabinetName>\n");
									ipXMLBuffer.append("<UserDBId>");
									ipXMLBuffer.append(sessionId);
									ipXMLBuffer.append("</UserDBId>\n");
									ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
									ipXMLBuffer.append("<Document>\n");
									ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
									ipXMLBuffer.append("<ParentFolderIndex>");
									ipXMLBuffer.append(parentFolderIndex);
									ipXMLBuffer.append("</ParentFolderIndex>\n");
									ipXMLBuffer.append("<DocumentName>");
									ipXMLBuffer.append(docName);
									ipXMLBuffer.append("</DocumentName>\n");
									ipXMLBuffer.append("<VolumeIndex>");
									ipXMLBuffer.append(volumeID);
									ipXMLBuffer.append("</VolumeIndex>\n");
									ipXMLBuffer.append("<ISIndex>");
									ipXMLBuffer.append(ISIndex);
									ipXMLBuffer.append("</ISIndex>\n");
									ipXMLBuffer.append("<NoOfPages>");
									ipXMLBuffer.append(NoOfPages);
									ipXMLBuffer.append("</NoOfPages>\n");
									ipXMLBuffer.append("<DocumentType>");
									ipXMLBuffer.append(DocType);
									ipXMLBuffer.append("</DocumentType>\n");
									ipXMLBuffer.append("<Comment>");              
							        ipXMLBuffer.append(comment);
							        ipXMLBuffer.append("</Comment>\n");
									ipXMLBuffer.append("<DocumentSize>");
									ipXMLBuffer.append(lstrDocFileSize);
									ipXMLBuffer.append("</DocumentSize>\n");
									ipXMLBuffer.append("<CreatedByAppName>");
									ipXMLBuffer.append(StrCreatedByAppName);
									ipXMLBuffer.append("</CreatedByAppName>\n");
									ipXMLBuffer.append("</Document>\n");
									ipXMLBuffer.append("</NGOAddDocument_Input>\n");
									String NGOaddDocInputXML =  ipXMLBuffer.toString();
									//
									/*String NGOaddDocInputXML = CommonMethods.getNGOAddDocumentKYC(
											parentFolderIndex, "Previous_Doc", DocType, StrCreatedByAppName,
											ISIndex, lstrDocFileSize, StrVolId, cabinetName, sessionId,StrDocumentName,NoOfPages);*/
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
									String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML,jtsIP, jtsPort, 1);
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);
									
									XMLParser xmlParserAddDoc = new XMLParser(NGOaddDocOutXml);
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("xmlParserAddDoc--- " + xmlParserAddDoc);
									String addDocMainCode = xmlParserAddDoc.getValueOf("Status");
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("addDocMainCode--- " + addDocMainCode);
									if (addDocMainCode.equalsIgnoreCase("0")) 
									{
									appendIndex(processInstanceID,ISIndex,indexes);
									status = "success";
									}else{
										KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in NGO add doc API--- ");
										status = "error";
										return status;
									}
									//WI_AddDoc_Status = "Success";
								}else{
									KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Ap Search maincode folderindex is not zero");
									status = "error";
									return status;
								}
							}else{
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Documentis audit trail or conversation");
								status = "success";
							}
						}else{
							KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Documentalready added");
							status = "success";
						}
					}
				}
				else
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("No documents present in the folder");
					status = "success";
				}
			}
			}else{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Folders not exists");
				status = "success";
			}
		}else{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Folders not exists");
			status = "success";
		}
		}
		else
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in AP Search Folder");
			status = "Error";
			return status;
		}
		}catch(Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in search in folder: "+e.getMessage());
			status = "error";
			return status;
		}
		return status;
	}

	public String deleteDownloadedDocs(String nextFlePath){
		File file = new File(nextFlePath);
		if(file.exists()){
			file.delete();
		}
		return "";
	}
	
	private int readConfig(){
		Properties p = null;
		try {
			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "ConfigFiles"+ File.separator+ "KYC_Od_Download_Config.properties")));
			Enumeration<?> names = p.propertyNames();
			while (names.hasMoreElements()){
			    String name = (String) names.nextElement();
			    ODDocConfigParamMap.put(name, p.getProperty(name));
			}										
		}
		catch (Exception e){
			return -1 ;
		}
		return 0;
	}
	
	public void updateAttachDocStatus(String processinstanceID,String value){
		try{
		String columnValue = "'"+value+"'";
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Updating Add Doc Attach Status - ");
		String whereClause = "ProcessInstanceID = '"+processinstanceID+"'";
		String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"WFINSTRUMENTTABLE", "VAR_STR3",columnValue, whereClause);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
		String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
		XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
		String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
		if (apUpdateMaincode.equalsIgnoreCase("0")) 
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML for updateAttachDocStatus: "+apUpdateOutputXML);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Attach DocStatus updated to: "+value);

		}
		}catch(Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in updateAttachDocStatus - "+e.getMessage());
		}	
	}
	
	public String appendIndex(String processinstanceID,String index,String indexes){
		//indexes += "'"+index+"|'";
		indexes = "'"+indexes+index+"|'";
		try{
		String whereClause = "WINAME = '"+processinstanceID+"'";
		String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"RB_KYC_REM_EXTTABLE", "iBpsODdocAttachedIndexes",indexes, whereClause);
		
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
		String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
		XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
		String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
		if (apUpdateMaincode.equalsIgnoreCase("0")) 
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML for append index: "+apUpdateOutputXML);
		}
		}catch(Exception e){
			
		}
		return "";
	}
	
	public String appendOFIndex(String processinstanceID,String index,String indexes){
		//indexes += "'"+index+"|'";
		indexes = "'"+indexes+index+"|'";
		try{
		String whereClause = "WINAME = '"+processinstanceID+"'";
		String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"RB_KYC_REM_EXTTABLE", "OFodDocAttachedIndexes",indexes, whereClause);
		
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
		String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
		XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
		String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
		if (apUpdateMaincode.equalsIgnoreCase("0")) 
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML for append index: "+apUpdateOutputXML);
		}
		}catch(Exception e){
			
		}
		return "";
	}
	
	public String getDocAttachStatus(String processinstanceID){
		String status = "";
		try{
		
		String Query = "SELECT iBpsODdocAttachStatus FROM RB_KYC_REM_EXTTABLE with (nolock) where WINAME = '"
				+ processinstanceID + "'";
		String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
		String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
		XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
		String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
		int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
		if (apSelectMaincode.equals("0") && TotalRecords > 0) {
			status = xmlParserAPSelect.getValueOf("iBpsODdocAttachStatus");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("status---"+status);
		} else {
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("iBpsODdocAttachStatus not recieved ");
		}
		}catch(Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in getDocAttachStatus "+e );
		}
		return status;
	}
	
	public String getOFDocAttachStatus(String processinstanceID){
		String status = "";
		try{
		
		String Query = "SELECT OFodDocAttachStatus FROM RB_KYC_REM_EXTTABLE with (nolock) where WINAME = '"
				+ processinstanceID + "'";
		String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
		String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
		XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
		String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
		int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
		if (apSelectMaincode.equals("0") && TotalRecords > 0) {
			status = xmlParserAPSelect.getValueOf("iBpsODdocAttachStatus");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("status---"+status);
		} else {
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("iBpsODdocAttachStatus not recieved ");
		}
		}catch(Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in getDocAttachStatus "+e );
		}
		return status;
	}
	
	public String updateDocAttachStatus(String processinstanceID){
		try{
			String whereClause = "WINAME = '"+processinstanceID+"'";
			String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"RB_KYC_REM_EXTTABLE", "iBpsODdocAttachStatus","'Y'", whereClause);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
			String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
			XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
			String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
			if (apUpdateMaincode.equalsIgnoreCase("0")) 
			{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML for append index: "+apUpdateOutputXML);
			}
			}catch(Exception e){
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in updateDocAttachStatus ");
			}
		return "";
	}
	
	public String updateOFDocAttachStatus(String processinstanceID){
		try{
			String whereClause = "WINAME = '"+processinstanceID+"'";
			String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"RB_KYC_REM_EXTTABLE", "OFodDocAttachStatus","'Y'", whereClause);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
			String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
			XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
			String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
			if (apUpdateMaincode.equalsIgnoreCase("0")) 
			{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML for append index: "+apUpdateOutputXML);
			}
			}catch(Exception e){
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in updateDocAttachStatus ");
			}
		return "";
	}
	
	public String getIndexes(String processinstanceID){
		String index = "";
		try{
			
			String Query = "SELECT iBpsODdocAttachedIndexes FROM RB_KYC_REM_EXTTABLE with (nolock) where WINAME = '"
					+ processinstanceID + "'";
			String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
			String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
			String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
			int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (apSelectMaincode.equals("0") && TotalRecords > 0) {
				index = xmlParserAPSelect.getValueOf("iBpsODdocAttachedIndexes");
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("iBpsODdocAttachedIndexes---"+index);
			} else {
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("iBpsODdocAttachedIndexes not recieved ");
			}
			}catch(Exception e){
				
			}
		return index;
	}
	
	public String getOFIndexes(String processinstanceID){
		String index = "";
		try{
			
			String Query = "SELECT OFodDocAttachedIndexes FROM RB_KYC_REM_EXTTABLE with (nolock) where WINAME = '"
					+ processinstanceID + "'";
			String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
			String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
			String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
			int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (apSelectMaincode.equals("0") && TotalRecords > 0) {
				index = xmlParserAPSelect.getValueOf("OFodDocAttachedIndexes");
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("OFodDocAttachedIndexes---"+index);
			} else {
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("OFodDocAttachedIndexes not recieved ");
			}
			}catch(Exception e){
				
			}
		return index;
	}
	
	public String WIAttachStatus(String processinstanceID){
		String attachDocStatus = "";
		try{
		String QueryAttachDocStatus = "SELECT VAR_STR3 FROM WFINSTRUMENTTABLE with (nolock) where ProcessInstanceID = '"
				+ processinstanceID + "'";
		String InputXMLAttachDocStatus = CommonMethods.apSelectWithColumnNames(QueryAttachDocStatus, cabinetName, sessionID);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("InputXMLAttachDocStatus - "+InputXMLAttachDocStatus);
		String OutputXMLAttachDocStatus = CommonMethods.WFNGExecute(InputXMLAttachDocStatus, jtsIP, jtsPort, 1);
		KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("OutputXMLAttachDocStatus - "+OutputXMLAttachDocStatus);
		XMLParser xmlParserAPSelectAttachDocStatus = new XMLParser(OutputXMLAttachDocStatus);
		String apSelectMaincodeAttachDocStatus = xmlParserAPSelectAttachDocStatus.getValueOf("MainCode");
		int TotalRecordsAttachStatus = Integer.parseInt(xmlParserAPSelectAttachDocStatus.getValueOf("TotalRetrieved"));
		if (apSelectMaincodeAttachDocStatus.equals("0") && TotalRecordsAttachStatus > 0) {
			attachDocStatus = xmlParserAPSelectAttachDocStatus.getValueOf("VAR_STR3");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("attachDocStatus for WI "+processinstanceID+" -> "+attachDocStatus);

		}
		}catch(Exception e){
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception in  WIAttachStatus method - "+e.getMessage());
		}
		return attachDocStatus;
	}
	
	public boolean StatusUpdateQuery(String cabinetName,String sessionId,String JtsIp,String JtsPort,String processInstanceID,int rowSequence, String dataClassName, String callingEnv) throws IOException, Exception//PASS NECESSARY VALUES HERE //removed String searchValue, String searchType
	{
		boolean flag=false;
		String apUpdateInputXML="";
		//1
		String Query1 = "";
		if ("iBPS".equalsIgnoreCase(callingEnv))
			Query1 = "SELECT a=count(*) FROM KYC_0_ODDD_DOC_DTLS with (nolock) WHERE WINAME='"+processInstanceID+"' AND ID='"+rowSequence+"' AND STATUS='N' AND SERVER='iBPS' AND DATA_CLASS_NAME='"+dataClassName+"'";
		else
			Query1 = "SELECT a=count(*) FROM KYC_0_ODDD_DOC_DTLS with (nolock) WHERE WINAME='"+processInstanceID+"' AND ID='"+rowSequence+"' AND STATUS='N' AND SERVER='OmniFlow' AND DATA_CLASS_NAME='"+dataClassName+"'";
		
		try
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside StatusUpdateQuery method!");
			
			String FinalStatusInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("FinalStatusInputXML :"+FinalStatusInputXML);

			String FinalStatusOutputXML = CommonMethods.WFNGExecute(FinalStatusInputXML, JtsIp, JtsPort, 1);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("FinalStatusOutputXML :"+FinalStatusOutputXML);

			XMLParser xmlParserAPSelectFinal = new XMLParser(FinalStatusOutputXML);
			String apSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apSelectFinalMaincode :"+apSelectFinalMaincode);

			String xmlcountdtls = xmlParserAPSelectFinal.getValueOf("Record");
			XMLParser xmlParsercount = new XMLParser(xmlcountdtls);
			String recordvalue = xmlParsercount.getValueOf("a");
			int statusRecords = Integer.parseInt(recordvalue);
			
			if(apSelectFinalMaincode.equals("0") && statusRecords==0)
			{
				//String whereClause1 = "WINAME = '"+processInstanceID+"' AND ID = '"+rowSequence+"' AND SEARCH_VALUE='"+searchValue+"' AND SEARCH_TYPE='"+searchType+"' AND DATA_CLASS_NAME='"+dataClassName+"'";//ADD QUERY HERE
				
				String whereClause1 = "WINAME = '"+processInstanceID+"' AND ID = '"+rowSequence+"' AND DATA_CLASS_NAME='"+dataClassName+"'";//ADD QUERY HERE
				if ("iBPS".equalsIgnoreCase(callingEnv))
					apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionId,"KYC_0_ODDD_DATACLASS_SEARCH_DTLS", "iBPS_STATUS,iBPS_COMPLETED_DATETIME", "'Y',getdate()", whereClause1);
				else
					apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionId,"KYC_0_ODDD_DATACLASS_SEARCH_DTLS", "OFSTATUS,OFSTATUS_COMPLETED_DATETIME", "'Y',getdate()", whereClause1);
				
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
				String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, JtsIp, JtsPort, 1);
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
				XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
				String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
				if (apUpdateMaincode.equalsIgnoreCase("0")) 
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(callingEnv+" updated as Y");
					flag=false;
				}
				else
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(callingEnv+" update failed");
					flag=true;
				}
			}
			else
			{
				String whereClause1 = "WINAME = '"+processInstanceID+"' AND ID = '"+rowSequence+"' AND DATA_CLASS_NAME='"+dataClassName+"'";//ADD QUERY HERE
				if ("iBPS".equalsIgnoreCase(callingEnv))
					apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionId,"USR_0_ODDD_DATACLASS_SEARCH_DTLS", "iBPS_STATUS,iBPS_COMPLETED_DATETIME", "'I',getdate()", whereClause1);
				else
					apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionId,"USR_0_ODDD_DATACLASS_SEARCH_DTLS", "OFSTATUS,OFSTATUS_COMPLETED_DATETIME", "'I',getdate()", whereClause1);
				
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateInputXML: "+apUpdateInputXML);
				String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, JtsIp, JtsPort, 1);
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
				XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
				String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
				if (apUpdateMaincode.equalsIgnoreCase("0")) 
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(callingEnv+" updated as N");
					flag=true;
				}
				else
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug(callingEnv+" update failed");
					flag=true;
				}
			}
		}
		catch(Exception e)
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception Occurred : "+e.getMessage());
			flag=true;
		}
		return flag;
	}
	public boolean SearchDocument(String cabinetName,String sessionId,String JtsIp,String JtsPort,String tempDataDefId,String tempFieldIndexId,String searchValue, String tempFieldType,String processInstanceID,String vendorName,String tempDataClassName,String tempOFDataDefId,String tempOFFieldIndexId, int count, String callingEnv, String folderName)
	{ 
		boolean flag=false;
		
		try 
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside SearchDocument method -- for "+callingEnv);
			//String [] env=new String[] {cabinetName,CommonConnection.getOFCabinetName()};
			String env_SessionId="";
			String env_jtsIp="";
			String env_jtsPort="";
			String DataDefID="";
			String FieldIndexID ="";
			String ServerDetails="";
			String cabinetNameForEnv = cabinetName;
			
			
			
			//KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("env_chosen: "+env_chosen);
			if(callingEnv.equalsIgnoreCase("iBPS"))//if(env_chosen==0)
			{
				env_SessionId=sessionId;
				env_jtsIp=JtsIp;
				env_jtsPort=JtsPort;
				DataDefID=tempDataDefId;
				FieldIndexID=tempFieldIndexId;
				ServerDetails="iBPS";
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("rak_bpm credentials: "+env_SessionId+"\n"+env_jtsIp+"\n"+env_jtsPort+"\n"+DataDefID+"\n"+FieldIndexID);
			}
			else
			{
				env_SessionId=CommonConnection.getOFSessionID(KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger, false);
				env_jtsPort=CommonConnection.getOFJTSPort();
				env_jtsIp=CommonConnection.getOFJTSIP();
				DataDefID=tempOFDataDefId;
				FieldIndexID=tempOFFieldIndexId;
				ServerDetails="OmniFlow";
				cabinetNameForEnv = CommonConnection.getOFCabinetName();
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("rakcabinet_first credentials: "+env_SessionId+"\n"+env_jtsIp+"\n"+env_jtsPort+"\n"+DataDefID+"\n"+FieldIndexID);
			}
			String searchDocInputXML = CommonMethods.NGOSearchDocument(DataDefID,FieldIndexID,searchValue,cabinetNameForEnv,env_SessionId);//cif_no //4324343
			/*String searchDocInputXML = CommonMethods.NGOSearchDocument("19","4340",searchValue,env[i],env_SessionId);*/
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("searchDocInputXML: "+searchDocInputXML);
			String searchDocOutputXML=CommonMethods.WFNGExecute(searchDocInputXML,env_jtsIp,env_jtsPort,1);
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("searchDocOutputXML: "+searchDocOutputXML);
			XMLParser xmlParsersearchDoc = new XMLParser(searchDocOutputXML);
			String searchDocMaincode = xmlParsersearchDoc.getValueOf("Status");
			int Record = Integer.parseInt(xmlParsersearchDoc.getValueOf("TotalNoOfRecords"));
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("searchDocMaincode: "+searchDocMaincode);                			
			
			if (searchDocMaincode.equalsIgnoreCase("0"))
			{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document searched successfully");
				if(Record > 0) 
				{
					
					NGXmlList objWorkList = xmlParsersearchDoc.createList("SearchResults", "SearchResult");
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("objWorkList "+objWorkList);
					for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
					{		
						String docDetail = xmlParsersearchDoc.getNextValueOf("SearchResult");
						XMLParser xmlDocDetail = new XMLParser(docDetail);
						String ISIndex = xmlDocDetail.getValueOf("ISIndex");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex"+ISIndex);
						String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0, xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
						//String imageIndex = xmlParser.getValueOf("ISIndex").substring(0, xmlParser.getValueOf("ISIndex").indexOf("#"));
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("ISIndex substring "+StrimgIndex);
						//String StrVolId = xmlParsersearchDoc.getValueOf("ISIndex").substring(xmlParsersearchDoc.getValueOf("ISIndex").indexOf("#")+1,xmlParsersearchDoc.getValueOf("ISIndex").lastIndexOf("#"));
						String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#")+1);
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("VolId:"+StrVolId+" imgIndex :"+StrimgIndex);
						/**Same docs download issue -29122021 **/
						String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("DocumentIndex"+DocIndex);
						
						String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
						String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("StrDocumentName:"+StrDocumentName+" StrCreatedByAppName :"+StrCreatedByAppName);
						StrDocumentName+="_"+DocIndex;									
						//Download Document in server location 
						StringBuffer filePath2 = new StringBuffer(filePath1);
						filePath2.append(File.separatorChar);
						filePath2.append(StrDocumentName);
						filePath2.append(".");
						filePath2.append(StrCreatedByAppName);
						
						String columnNames1 = "ID,WINAME,DATA_CLASS_NAME,SERVER,DOC_ISINDEX,DOC_NAME,DOC_FILEPATH,STATUS";
						String columnValues1 = "'"+count+"','"+processInstanceID+"','"+tempDataClassName+"','"+ServerDetails+"','"+ISIndex+"','"+StrDocumentName+"','"+filePath2+"','N'";
						String apInsertInputXML1 = CommonMethods.apInsert(cabinetName, sessionId, columnNames1, columnValues1,"USR_0_ODDD_DOC_DTLS");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apInsertInputXML1: "+apInsertInputXML1);
						String apInsertOutputXML1 = CommonMethods.WFNGExecute(apInsertInputXML1, JtsIp, JtsPort, 1);
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apInsertOutputXML1: "+apInsertOutputXML1);
						XMLParser xmlParserAPInsert1 = new XMLParser(apInsertOutputXML1);
						String apInsertMaincode1 = xmlParserAPInsert1.getValueOf("MainCode");
						KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apInsertMaincode1: "+apInsertMaincode1);
					}
				}
				else
				{
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Document searched but no docs found");
					boolean outputStatus = StatusUpdateQuery(cabinetName,sessionId,JtsIp,JtsPort,processInstanceID,count,tempDataClassName,callingEnv);//searchValue,tempFieldType
					KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("After Setting IBPS_STATUS and OF_STATUS -- returnvalue : "+outputStatus);
				}
			}
			else
			{
				KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Error in Document Search!");                			
				flag=true;
			}
		}
		catch(Exception e)
		{
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("SearchDocument Exception occurred : "+e.getMessage());
			flag=true;
		}
		return flag;
	}
	
	
	public String DataClassInsertion(int count,String processInstanceID,String vendorName,String tempDataClassName,String tempDataDefId,String tempFieldIndexId,String searchValue,String tempFieldType,String strCurrDateTime,String cabinetName,String sessionId,String columnNames1,String JtsIp,String JtsPort,String tempOFDataDefId,String tempOFFieldIndexId) throws Exception
	{
	    String columnValues1 = "'"+count+"','"+processInstanceID+"','"+vendorName+"','"+tempDataClassName+"','"+tempDataDefId+"','"+tempFieldIndexId+"','"+searchValue+"','"+tempFieldType+"','N','','N','','"+tempOFDataDefId+"','"+tempOFFieldIndexId+"'";
	    String apInsertInputXML1 = CommonMethods.apInsert(cabinetName, sessionId, columnNames1, columnValues1,"KYC_0_ODDD_DATACLASS_SEARCH_DTLS");
	    KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apInsertInputXML1: "+apInsertInputXML1);
	    String apInsertOutputXML1 = CommonMethods.WFNGExecute(apInsertInputXML1, JtsIp, JtsPort, 1);
	    KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apInsertOutputXML1: "+apInsertOutputXML1);
	    XMLParser xmlParserAPInsert1 = new XMLParser(apInsertOutputXML1);
	    String apInsertMaincode1 = xmlParserAPInsert1.getValueOf("MainCode");
	    KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("apInsertMaincode1: "+apInsertMaincode1);
	    return apInsertMaincode1;
	}
	
	
	
	private static List<Map<String, String>> getDataFromDBMap(String query, String cabinetName, String sessionID,
			String jtsIP, String jtsPort) {
		List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
		try {
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Inside function getDataFromDB");
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("getDataFromDB query is: " + query);
			String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			OutXml = OutXml.replaceAll("&", "#andsymb#");
			Document recordDoc1 = MapXML.getDocument(OutXml);
			NodeList records1 = recordDoc1.getElementsByTagName("Record");
			if (records1.getLength() > 0) {
				for (int i = 0; i < records1.getLength(); i++) {
					Node n = records1.item(i);
					Map<String, String> t = new HashMap<String, String>();
					if (n.hasChildNodes()) {
						NodeList child = n.getChildNodes();
						for (int j = 0; j < child.getLength(); j++) {
							Node n1 = child.item(j);
							String column = n1.getNodeName();
							String value = n1.getTextContent().replaceAll("#andsymb#", "&");
							if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
										.debug("getDataFromDBMap Setting value of " + column + " as " + value);
								t.put(column, value);
							} else {
								KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger
										.debug("getDataFromDBMap Setting value of " + column + " as blank");
								t.put(column, "");
							}
						}
					}
					temp.add(t);
				}
			}

		} catch (Exception e) {
			KYCodDownloadLogBBG4.KYCodDownloadLogBBG4Logger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return temp;

	}
	
}
