package com.newgen.KYC.CelebalCIFsDocDownload;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.format.CellDateFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;

import ISPack.CImageServer;
import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;
import Jdts.DataObject.JPDBString;

public class CelebalCIFsDocDownload implements Runnable
{
	private static String nOoFtRIES = ""; ;
	private static String CIFID = "";
	private static String ID="";
	private static String Segment = "";
	private static String Cohort = "";
	private static String sessionID = "";
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	private static String CIFBatchSize = "";
	private static String FileDownloadLoc = "";
	private static StringBuffer filePath, filePath1;
	private static String DocLocation = "";
	private static int sleepIntervalInMin=0;
	private static String ofUserName = "";
	private static String ofUserPassword = "";
	private static String ofCabinetName = "";
	private static String ofjtsIP = "";
	private static String ofjtsPort = "";
	private static String volumeID = "";
	
	private static String SMSPort = "";
	Map<String,Integer>folderCount=new LinkedHashMap<String,Integer>();
	Map<String,Integer>folderPrefix=new LinkedHashMap<String,Integer>();
	Map<String,Integer>folderSuffix=new LinkedHashMap<String,Integer>();
	List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
	
	private static NGEjbClient ngEjbClientODDoc;

	static Map<String, String> CelebalExtractConfigParamMap= new HashMap<String, String>();
	
	public void run()
	{
		try
		{
			CelebalCIFsDocDownloadLog.setLogger();
			
			int configReadStatus = readConfig();

			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("configReadStatus "+configReadStatus);
			if(configReadStatus !=0)
			{
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("Could not Read Config Properties KYC_Od_Download_Config.properties");
				return;
			}
			
			volumeID = CommonConnection.getsVolumeID();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("volumeID: " + volumeID);
			
			cabinetName = CommonConnection.getCabinetName();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("JTSPORT: " + jtsPort);						
			
			SMSPort = CommonConnection.getsSMSPort();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("SMSPort: " + SMSPort);
			
			CIFBatchSize = CelebalExtractConfigParamMap.get("CIFBatchSize");
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("CIFBatchSize: " + CIFBatchSize);

			sleepIntervalInMin=Integer.parseInt(CelebalExtractConfigParamMap.get("SleepIntervalInMin"));
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("SleepIntervalInMin: "+sleepIntervalInMin);
			
			DocLocation=CelebalExtractConfigParamMap.get("DocDownloadPath");
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("DocLocation: " + DocLocation);
			
			ofUserName=CommonConnection.getOFUserName();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("ofUserName: " + ofUserName);
			
			ofUserPassword=CommonConnection.getOFPassword();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("ofUserPassword: " + ofUserPassword);
			
			ofCabinetName=CommonConnection.getOFCabinetName();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("ofCabinetName: " + ofCabinetName);
			
			ofjtsIP=CommonConnection.getOFJTSIP();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("ofjtsIP: " + ofjtsIP);
			
			ofjtsPort=CommonConnection.getOFJTSPort();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("ofjtsPort: " + ofjtsPort);
			
			
		sessionID = CommonConnection.getSessionID(CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger, false);

			if(sessionID.trim().equalsIgnoreCase("")){
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("Could Not Connect to Server!");
			}
			else{
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Session ID found: " + sessionID);
				while(true){
					sessionID = CommonConnection.getSessionID(CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger, false);
					CelebalCIFsDocDownloadLog.setLogger();
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Celebal Doc Download");				
					startCelebalDownloadDocUtility(cabinetName, jtsIP, jtsPort,sessionID,CIFBatchSize);
					System.out.println("No More CIF to Download doc for Celebal, Sleeping!");
					Thread.sleep(sleepIntervalInMin*60*1000);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception Occurred in ODDD : "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception Occurred in ODDD : "+result);
		}
	}
	
	private void startCelebalDownloadDocUtility(String cabinetName,String sJtsIp,String iJtsPort,String sessionId,String CIFBatchSize)
	{
		try{
			sessionID = CommonConnection.getSessionID(CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger, false);
			sessionId = sessionID;
			if(sessionId==null || sessionId.equalsIgnoreCase("") || sessionId.equalsIgnoreCase("null")){
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.error("Could Not Get Session ID "+sessionId);
				return;
			}
			/*
			//changed by bala
			//String Query1 = "SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with(nolock) WHERE IsActive = 'Y'";
			
			String Query1 = "SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with(nolock) WHERE IDPPACTIVE = 'Y'";
			//Ends
			String ApSelectInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName,
					sessionID);
			String ApSelectOutputXML = CommonMethods.WFNGExecute(ApSelectInputXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserAPSelectDataclass = new XMLParser(ApSelectOutputXML);
			String apSelectMaincodeDataclass = xmlParserAPSelectDataclass.getValueOf("MainCode");
			int TotalRecordsDataclassName = Integer
					.parseInt(xmlParserAPSelectDataclass.getValueOf("TotalRetrieved"));
			if (apSelectMaincodeDataclass.equals("0") && TotalRecordsDataclassName > 0) {
				DataFromDB = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
			}
			*/
			String Query = "select top "+CIFBatchSize+" ID, CIFID, IBPSODDownloadStatus, IBPSODDownloadedDocIndex, OFODDownloadStatus,"
							+"OFODDownloadedDocIndex,NoOfTries,Segment,cohort from USR_0_KYC_CELEBAL_CIFS_EXTRACT with(nolock) "
							+"where (IBPSODDownloadStatus is null or IBPSODDownloadStatus = '' or OFODDownloadStatus is null or " 
							+"OFODDownloadStatus = '' or IBPSODDownloadStatus = 'Failure' or OFODDownloadStatus = 'Failure') "
							+"AND (NoOfTries < 6 or NoOfTries is Null) order by ID";
			String FinalInputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionId);
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("InputXML to fetch from USR_0_KYC_CELEBAL_CIFS_EXTRACT :"+FinalInputXML);

			String FinalOutputXML = CommonMethods.WFNGExecute(FinalInputXML, sJtsIp, iJtsPort, 1);
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OutputXML from USR_0_KYC_CELEBAL_CIFS_EXTRACT :"+FinalOutputXML);

			XMLParser xmlParserAPSelect = new XMLParser(FinalOutputXML);
			String apSelectMaincode1 = xmlParserAPSelect.getValueOf("MainCode");
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apSelectMaincode :"+apSelectMaincode1);
			int totalCount = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
			
			String WI_AddDoc_Status = "";
			String WI_AddDoc_Status_OF = "";
			 String iBpsDocsAttached = "";
			 String OFDocsAttached = "";
			if(apSelectMaincode1.equals("0") && totalCount>0)
			{
				for(int i=0; i<totalCount; i++)
				{
					DataFromDB.clear();
					WI_AddDoc_Status = "";
					WI_AddDoc_Status_OF = "";
					iBpsDocsAttached = "";
					OFDocsAttached = "";
					String iBpsFolderResult = "";
					String OFFolderResult = "";
					String xmlDocDetails = xmlParserAPSelect.getNextValueOf("Record");
					XMLParser xmlParserChangeRecord = new XMLParser(xmlDocDetails);
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside count :");
					ID = xmlParserChangeRecord.getValueOf("ID");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ID :"+ID);
					
					CIFID = xmlParserChangeRecord.getValueOf("CIFID");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("CIFID :"+CIFID);
					
					nOoFtRIES = xmlParserChangeRecord.getValueOf("NoOfTries");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("nOoFtRIES :"+nOoFtRIES);
					
					String IBPSODDownloadStatus = xmlParserChangeRecord.getValueOf("IBPSODDownloadStatus");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("IBPSODDownloadStatus: "+IBPSODDownloadStatus);
					
					//String IBPSODDownloadedDocIndex = xmlParserChangeRecord.getValueOf("IBPSODDownloadedDocIndex");
					//CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("IBPSODDownloadedDocIndex :"+IBPSODDownloadedDocIndex);
					
					String OFODDownloadStatus = xmlParserChangeRecord.getValueOf("OFODDownloadStatus");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OFODDownloadStatus :"+OFODDownloadStatus);
					
					//String OFODDownloadedDocIndex = xmlParserChangeRecord.getValueOf("OFODDownloadedDocIndex");
					//CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OFODDownloadedDocIndex :"+OFODDownloadedDocIndex);
					// bala start
					Segment = xmlParserChangeRecord.getValueOf("Segment");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Segment :"+Segment);
					
					Cohort = xmlParserChangeRecord.getValueOf("Cohort");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Cohort :"+Cohort);
					String OFDataclassDEFID="";
					String Query1="";
					String Query2 ="";
					String DCValues="";
					StringBuilder DataClassnames = new StringBuilder();
					//changed by bala
					//String Query1 = "SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with(nolock) WHERE IsActive = 'Y'";
					if (!Segment.equalsIgnoreCase("") && !Cohort.equalsIgnoreCase(""))
					{
						Query2 ="select Dataclass from NG_KYC_REM_DC_SEGMENT_MASTER with(nolock) where Segment='"+Segment+"' and Cohort='"+Cohort+"'";
					// Query1 = "SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with(nolock) WHERE IDPPACTIVE = 'Y' and SEGMENT='"+Segment+"'";
						String ApSelectInputXML = CommonMethods.apSelectWithColumnNames(Query2, cabinetName,
								sessionID);
						String ApSelectOutputXML = CommonMethods.WFNGExecute(ApSelectInputXML, jtsIP, jtsPort, 1);
						XMLParser xmlParserAPSelectDataclass = new XMLParser(ApSelectOutputXML);
						String apSelectMaincodeDataclass = xmlParserAPSelectDataclass.getValueOf("MainCode");
						DCValues=xmlParserAPSelectDataclass.getValueOf("Dataclass");
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Dataclass :"+ApSelectOutputXML+ "  :"+DCValues);
						int TotalRecordsDataclassName = Integer
								.parseInt(xmlParserAPSelectDataclass.getValueOf("TotalRetrieved"));
						if (apSelectMaincodeDataclass.equals("0") && TotalRecordsDataclassName > 0) {
							
							String[] DC= DCValues.split(",");
							DataClassnames.append("(");
							for(int j=0;j<DC.length;j++)
							{
								DataClassnames.append("'").append(DC[j]).append("'");
								if(j<DC.length-1){
									DataClassnames.append(",");
								}
							}
							DataClassnames.append(")");
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Where COndition for  RB_KYC_REM_DATA_CLASS_MASTER :"+DataClassnames);
							Query1="SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with(nolock) WHERE IDPPActive = 'Y' and DATA_CLASS_NAME in "+DataClassnames+"";
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Query1 :"+Query1);
							DataFromDB = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
						}
					
					}
					else {
					 Query1 = "SELECT * FROM RB_KYC_REM_DATA_CLASS_MASTER with(nolock) WHERE Isactive = 'Y' ";
					}
					//Ends
					String ApSelectInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName,
							sessionID);
					String ApSelectOutputXML = CommonMethods.WFNGExecute(ApSelectInputXML, jtsIP, jtsPort, 1);
					XMLParser xmlParserAPSelectDataclass = new XMLParser(ApSelectOutputXML);
					String apSelectMaincodeDataclass = xmlParserAPSelectDataclass.getValueOf("MainCode");
					int TotalRecordsDataclassName = Integer
							.parseInt(xmlParserAPSelectDataclass.getValueOf("TotalRetrieved"));
					if (apSelectMaincodeDataclass.equals("0") && TotalRecordsDataclassName > 0) {
						DataFromDB = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
					}
					//Ends
						
						if (!"".equalsIgnoreCase(CIFID)){
							int counter = 0;
							int dataMasterSize = DataFromDB.size();
								for (Map<String,String> entry : DataFromDB){
									String dataClassName = entry.get("DATA_CLASS_NAME");
									String dataFieldType = entry.get("FIELD_TYPE");
									String dataClassNameDefId = entry.get("iBPS_DATA_DEF_ID");
									String dataFieldTypeDefId = entry.get("iBPS_FIELD_INDEX_ID");
									String OFdataClassNameDefId = entry.get("OF_DATA_DEF_ID");
									String OFdataFieldTypeDefId = entry.get("OF_FIELD_INDEX_ID");
									
									OFDataclassDEFID=OFdataClassNameDefId;
									
									if(!("".equalsIgnoreCase(dataClassNameDefId) && "".equalsIgnoreCase(dataFieldTypeDefId)))
									{
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Attaching docs from new OD for dataclass - "+dataClassName);
										
										if(!"Success".equalsIgnoreCase(IBPSODDownloadStatus))
										{
											String result = searchInFolder(dataClassNameDefId,dataFieldTypeDefId,sessionId);
											if(!"Error".equalsIgnoreCase(iBpsFolderResult)){
												iBpsFolderResult = result;
											}
											/*if("success".equalsIgnoreCase(result)){*/
											String searchDocInputXML = CommonMethods.NGOSearchDocument(dataClassNameDefId,
													dataFieldTypeDefId, CIFID, cabinetName, sessionId);
																													
											String searchDocOutputXML = CommonMethods.WFNGExecute(searchDocInputXML, jtsIP,
													jtsPort, 1);
											XMLParser xmlParserAPSearch = new XMLParser(searchDocOutputXML);
											String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Ap Search Main Code" + apSearchMaincode);
											
											int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Records found");
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("TotalNoOfRecords" + Record);
											
											if (apSearchMaincode.equals("0") && Record > 0) 
											{
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Documents Found");
												NGXmlList objWorkList = xmlParserAPSearch.createList("SearchResults",
														"SearchResult");
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("objWorkList " + objWorkList);
												for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
												{
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside Objects :");
													String docDetail = xmlParserAPSearch.getNextValueOf("SearchResult");
													XMLParser xmlDocDetail = new XMLParser(docDetail);
													String ISIndex = xmlDocDetail.getValueOf("ISIndex");
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex" + ISIndex);
													
													String indexes = getIndexes("IBPSODDownloadedDocIndex");
													if(!indexes.contains(ISIndex))
													{
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" Index not null :");
														String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex substring " + StrimgIndex);
														String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
														String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocumentIndex" + DocIndex);
														String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
														String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime").replace(":", "-");
														
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" CreationDateTime :"+CreationDateTime);
														if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
														{
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" Doc name is not AuditTrail or : Conversation");
															String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
															String lstrDocFileSize = xmlDocDetail.getValueOf("DocumentSize");
															String DocType = xmlDocDetail.getValueOf("DocumentType");
															String NoOfPages = xmlDocDetail.getValueOf("NoOfPages");
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocumentSize:"+ lstrDocFileSize + " DocumentType :" + DocType + " NoOfPages :" + NoOfPages);
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName:"
																	+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
														
															
															
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
															
															if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
																CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside if of special character replacement");
																StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
															}
															
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
															
															//String nextFlePath = DocLocation+File.separator+CIFID+File.separator+StrDocumentName+"_I"+DocIndex+"."+StrCreatedByAppName;
															String nextFlePath = "";
															String Path = DocLocation+File.separator+CIFID;
																	
															Path targetDirectory = Paths.get(Path);
															if(!Files.exists(targetDirectory)){
																	File f1 = new File(Path);
																	boolean made = f1.mkdirs();
																	CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Directory made--"+made);
															}
															//Changed by Bala
															//nextFlePath = Path+File.separator+StrDocumentName+"_I"+DocIndex+"."+StrCreatedByAppName;
															//
															nextFlePath = Path+File.separator+StrDocumentName+"~~"+CreationDateTime+"_I"+DocIndex+"."+StrCreatedByAppName;
															
															String c_Site = "1"; //Clarification
															String msg = "";
															//boolean status ;
															
															CImageServer cImageServer=null;
															try 
															{
																cImageServer = new CImageServer(null, jtsIP, Short.parseShort(jtsPort));
															}
															catch (JPISException e) 
															{
																e.printStackTrace();
																msg = e.getMessage();
																WI_AddDoc_Status = "Error";
																CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in cImageServer object initialization:" + e.getMessage());
															}
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("values passed -> "+ jtsIP+" "+SMSPort+" "+cabinetName+" "+StrVolId+" "+c_Site+" "+StrimgIndex+" "+nextFlePath.toString());
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("document name and imageindex for "+CIFID+" -- "+StrDocumentName+", "+StrimgIndex);
															JPISIsIndex ISINDEX = new JPISIsIndex();
															JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
															//String volumeIDold = StrVolId.substring(0,StrVolId.indexOf("#"));
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Fetching OD Download Code ::::::");
															int odDownloadCode;
															odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(SMSPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(StrVolId), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OD Download Code :"+odDownloadCode);
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex Downloaded :"+ISIndex);
																
															if (odDownloadCode == 1) 
															{
																appendIndex("IBPSODDownloadedDocIndex",ISIndex,indexes);
																if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
																WI_AddDoc_Status = "Success";
															}
															else if(odDownloadCode == -6012)
															{
																nextFlePath = Path+File.separator+"AppliationDoc"+"~~"+CreationDateTime+"_I"+DocIndex+"."+StrCreatedByAppName;
																odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(SMSPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(StrVolId), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
																CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ODDownloadCode after changing doc name --> "+odDownloadCode);
																if (odDownloadCode == 1) 
																{
																	appendIndex("IBPSODDownloadedDocIndex",ISIndex,indexes);
																	if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
																	WI_AddDoc_Status = "Success";
																}
																else
																{
																	CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in NGO download doc API--- ");
																	WI_AddDoc_Status = "Error";
																}
															}
															else
															{
																CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in NGO download doc API--- ");
																WI_AddDoc_Status = "Error";
															}
														}
														else
														{
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Audit Trail doc not added");
															if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
																WI_AddDoc_Status = "Success";
														}
													}
													else
													{
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Document already added");
														if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
															WI_AddDoc_Status = "Success";
													}
												}
												if ("Success".equalsIgnoreCase(WI_AddDoc_Status)) {
													iBpsDocsAttached = "Success";
												}
											}
											else{
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("No docs available in CIF for dataclass - "+dataClassName);
												if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
												{
												WI_AddDoc_Status = "Success";
												iBpsDocsAttached = "Success";
												}
											}
									}else{
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("iBps Docs already attached as status received is Success");
											WI_AddDoc_Status = "Success";
											iBpsDocsAttached = "Success";
									}
								  }
									
									///  for searching on of server adding this block/////////////////////////
									
									if(!("".equalsIgnoreCase(OFdataClassNameDefId) && "".equalsIgnoreCase(OFdataFieldTypeDefId))){
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Searchin in OmniFlow OD server");
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("attaching docs from old omnidocs for dataclass - "+dataClassName);
										
										if(!"Success".equalsIgnoreCase(OFODDownloadStatus))
										{
										try{
										String OFsessionID = CommonConnection.getOFSessionID(CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger, false);
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" Out OFsessionID" + OFsessionID);
										String result = searchInFolderOF(OFdataClassNameDefId,OFdataFieldTypeDefId,sessionId,OFsessionID);
										if(!"Error".equalsIgnoreCase(OFFolderResult)){
											OFFolderResult = result;
										}
										//if("success".equalsIgnoreCase(result)){
										String searchDocInputXML = CommonMethods.NGOSearchDocument(OFdataClassNameDefId,OFdataFieldTypeDefId, CIFID, ofCabinetName, OFsessionID);
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" searchDocInputXML OFsessionID" + searchDocInputXML);										
										String searchDocOutputXML = CommonMethods.WFNGExecute(searchDocInputXML, ofjtsIP, ofjtsPort, 1);
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" searchDocOutputXML OFsessionID" + searchDocOutputXML);
										
										XMLParser xmlParserAPSearch = new XMLParser(searchDocOutputXML);
										String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
										System.out.print("Ap Search Main Code" + apSearchMaincode);
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apSearchMaincode-- "+apSearchMaincode);
										int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Recorde-- "+Record);
										System.out.print("TotalNoOfRecords" + Record);
										if (apSearchMaincode.equals("0") && Record > 0) {
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Documents Found");
											NGXmlList objWorkList = xmlParserAPSearch.createList("SearchResults",
													"SearchResult");
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("objWorkList " + objWorkList);
											for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) {
												String docDetail = xmlParserAPSearch.getNextValueOf("SearchResult");
												XMLParser xmlDocDetail = new XMLParser(docDetail);
												String ISIndex = xmlDocDetail.getValueOf("ISIndex");
											
												String indexes = getIndexes("OFODDownloadedDocIndex");
												if(!indexes.contains(ISIndex))
												{
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex" + ISIndex);
												String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex substring " + StrimgIndex);
												String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
												String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocumentIndex" + DocIndex);
												String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrCreatedByAppName:" + StrCreatedByAppName);
												String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
												String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime").replace(":", "-");
												
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(" OF CreationDateTime "+CreationDateTime);
												if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
												{
												if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside if of special character replacement");
													StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
												}
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName: "+StrDocumentName);

												//String nextFlePath = DocLocation+File.separator+CIFID+File.separator+StrDocumentName+"_"+DocIndex+"."+StrCreatedByAppName;
												
												String nextFlePath = "";
												String Path = DocLocation+File.separator+CIFID;		
												Path targetDirectory = Paths.get(Path);
												if(!Files.exists(targetDirectory)){
														File f1 = new File(Path);
														boolean made = f1.mkdirs();
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Directory made--"+made);
												}
												nextFlePath = Path+File.separator+StrDocumentName+"~~"+CreationDateTime+"_O"+DocIndex+"."+StrCreatedByAppName;

												String c_Site = "1"; //Clarification
												String msg = "";
												boolean status ;
												try
												{
													CImageServer cImageServer=null;
													try 
													{
														cImageServer = new CImageServer(null, ofjtsIP, Short.parseShort(ofjtsPort));
													}
													catch (JPISException e) 
													{
														e.printStackTrace();
														msg = e.getMessage();
														status=false;
														WI_AddDoc_Status = "Error";
														break;
													}
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("values passed -> "+ ofjtsIP+" "+ofjtsPort+" "+ofCabinetName+" "+StrVolId+" "+c_Site+" "+StrimgIndex+" "+nextFlePath.toString());
													
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("document name and imageindex for "+CIFID+" -- "+StrDocumentName+", "+StrimgIndex);
													JPISIsIndex ISINDEX = new JPISIsIndex();
													JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
									
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Fetching OD Download Code ::::::");
													int odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,ofjtsIP, Short.parseShort(ofjtsPort), ofCabinetName, Short.parseShort(c_Site),Short.parseShort(StrVolId), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OD Download Code :"+odDownloadCode);
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex Downloaded :"+ISIndex);
													if(odDownloadCode==1)
													{
														appendIndex("OFODDownloadedDocIndex",ISIndex,indexes);
														if(!"Error".equalsIgnoreCase(WI_AddDoc_Status_OF))
															WI_AddDoc_Status_OF = "Success";
													}
													else if(odDownloadCode == -6012)
													{
														nextFlePath = Path+File.separator+"AppliationDoc"+"~~"+CreationDateTime+"_O"+DocIndex+"."+StrCreatedByAppName;
														odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(SMSPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(StrVolId), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ODDownloadCode after changing doc name --> "+odDownloadCode);
														if (odDownloadCode == 1) 
														{
															appendIndex("IBPSODDownloadedDocIndex",ISIndex,indexes);
															if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
															WI_AddDoc_Status = "Success";
														}
														else
														{
															CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in NGO download doc API--- ");
															WI_AddDoc_Status = "Error";
														}
													}
													else 
													{
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in Downloading Doc");
														WI_AddDoc_Status_OF = "Error";
													}
												}
													catch (Exception e) 
													{
														CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exsception occured in DownloadDocument method : "+e);
														System.out.println("Some exception occured while downloading the document.");
														
														final Writer result1 = new StringWriter();
														final PrintWriter printWriter = new PrintWriter(result1);
														e.printStackTrace(printWriter);
														msg=e.getMessage();
														status=false;
														WI_AddDoc_Status_OF = "Error";
													}
												}
											}
												else
												{
													CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Doc already added from ofserver");
													if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
														WI_AddDoc_Status_OF = "Success";
												}	
											}
											if ("Success".equalsIgnoreCase(WI_AddDoc_Status_OF)) {
												OFDocsAttached = "Success";
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("updating of Doc attach status after all docs added");
											}
										}
										else{
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("No docs available in CIF");
											if(!"Error".equalsIgnoreCase(WI_AddDoc_Status))
												WI_AddDoc_Status_OF = "Success";
												OFDocsAttached = "Success";
										}
											}
										catch(Exception e){
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside catch of ofServer if--->"+e.getMessage());
										}
										}
										else{
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OF Docs already attached as status received is Y");
											WI_AddDoc_Status_OF = "Success";
											OFDocsAttached = "Success";
									}
									  }
									/////OF server block end
									counter++;
								}
								if("Success".equalsIgnoreCase(iBpsDocsAttached) && "success".equalsIgnoreCase(iBpsFolderResult)){
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("1");
									if(counter==dataMasterSize)
									updateDocAttachStatus("IBPS","Success");
								}
								else{
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("2");
									if(!(IBPSODDownloadStatus.equalsIgnoreCase("Success")))
									updateDocAttachStatus("IBPS","Failure");
								}
								if("Success".equalsIgnoreCase(OFDocsAttached) && "success".equalsIgnoreCase(OFFolderResult)){
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("3");
									if(counter==dataMasterSize)
									updateDocAttachStatus("OF","Success");
								}
								else{
									if((OFDataclassDEFID.equalsIgnoreCase("")))
									{
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("5 :"+OFDataclassDEFID);
										updateDocAttachStatus("OF","No Search");
									}
									else
									{
									if(!(OFODDownloadStatus.equalsIgnoreCase("Success")))
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("4");
									updateDocAttachStatus("OF","Failure");
									}
								}
								
						}
						else {
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("CIF not found");
						}
					} 
				 
				}
				else{
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("No CIF to Download");
				}
			}
			catch (Exception e){
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception ui: "+e.getMessage());
			}
	}
	
	private String searchInFolderOF(String oFdataClassNameDefId,
			String oFdataFieldTypeDefId, String sessionId, String oFsessionID) {
		String status = "";
		CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside OFsearchInFolder ");
		
		try
		{
			String searchFolderInputXML = CommonMethods.apNGOSearchFolder(ofCabinetName,oFsessionID,oFdataClassNameDefId,
					oFdataFieldTypeDefId, CIFID);
																					
			String searchFolderOutputXML = CommonMethods.WFNGExecute(searchFolderInputXML, ofjtsIP,
					ofjtsPort, 1);
			XMLParser xmlParserAPSearch = new XMLParser(searchFolderOutputXML);
			String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
			System.out.print("Ap Search Main Code" + apSearchMaincode);
			/*int Record = Integer.parseInt(xmlParserAPSearch.getValueOf("TotalNoOfRecords"));
			System.out.print("TotalNoOfRecords" + Record);*/
			if (apSearchMaincode.equals("0")) 
			{
				String Record = xmlParserAPSearch.getValueOf("TotalNoOfRecords");
				if(!"".equalsIgnoreCase(Record))
				{
					int RecordInt = Integer.parseInt(Record);
					if(RecordInt > 0){
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Folders Found");
					NGXmlList objWorkList = xmlParserAPSearch.createList("Folders","Folder");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("objWorkList " + objWorkList);
					for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
					{
						status = "";
						String FolderDetail = xmlParserAPSearch.getNextValueOf("Folder");
						XMLParser xmlFolderDetail = new XMLParser(FolderDetail);
						String searchedFolderIndex = xmlFolderDetail.getFirstValueOf("FolderIndex");
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("searchedFolderIndex " + searchedFolderIndex);
						
						String documentListInputXML = CommonMethods.getDocumentList(searchedFolderIndex, oFsessionID, ofCabinetName);
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("documentListInputXML " + documentListInputXML);
						String documentListOutputXML = CommonMethods.WFNGExecute(documentListInputXML, ofjtsIP,ofjtsPort,1);
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("documentListOutputXML " + documentListOutputXML);
						XMLParser xmlParserDocList = new XMLParser(documentListOutputXML);
						String DocListMainCode = xmlParserDocList.getValueOf("Status");
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocListMainCode " + DocListMainCode);
						int DocListRecord = Integer.parseInt(xmlParserDocList.getValueOf("TotalNoOfRecords"));
						if (DocListMainCode.equals("0") && DocListRecord > 0) 
						{
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Documents Found");
							NGXmlList objWorkLists = xmlParserDocList.createList("Documents","Document");
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("objWorkLists " + objWorkLists);
							for (; objWorkLists.hasMoreElements(true); objWorkLists.skip(true)) 
							{
								String docDetail = xmlParserDocList.getNextValueOf("Document");
								XMLParser xmlDocDetail = new XMLParser(docDetail);
								String ISIndex = xmlDocDetail.getValueOf("ISIndex");
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex" + ISIndex);
								
								String indexes = getIndexes("OFODDownloadedDocIndex");
								if(!indexes.contains(ISIndex))
								{
									
									String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex substring " + StrimgIndex);
									String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
									String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocumentIndex" + DocIndex);
									String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
									String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime").replace(":", "-");
								
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside OFsearchInFolder CreationDateTime"+CreationDateTime);
									
									if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
									{
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside OFsearchInFolder Not AuditTrail & Conversation"+CreationDateTime);
										String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
										
										if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside if of special character replacement");
											StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
										}
										
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
										
										String nextFlePath = "";
										String Path = DocLocation+File.separator+CIFID;
												
										Path targetDirectory = Paths.get(Path);
										if(!Files.exists(targetDirectory)){
												File f1 = new File(Path);
												boolean made = f1.mkdirs();
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Directory made--"+made);
										}
										nextFlePath = Path+File.separator+StrDocumentName+"~~"+CreationDateTime+"_O"+DocIndex+"."+StrCreatedByAppName;
										
										String c_Site = "1"; //Clarification
										String msg = "";
										//boolean status ;
										
										CImageServer cImageServer=null;
										try 
										{
											cImageServer = new CImageServer(null, ofjtsIP, Short.parseShort(ofjtsPort));
										}
										catch (JPISException e) 
										{
											e.printStackTrace();
											msg = e.getMessage();
											status="error";
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in cImageServer object initialization:" + e.getMessage());
											return status;
										}
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("values passed -> "+ ofjtsIP+" "+ofjtsPort+" "+ofCabinetName+" "+StrVolId+" "+c_Site+" "+StrimgIndex+" "+nextFlePath.toString());
										
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("document name and imageindex for "+CIFID+" -- "+StrDocumentName+", "+StrimgIndex);
										JPISIsIndex ISINDEX = new JPISIsIndex();
										JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
										String volumeIDold = StrVolId.substring(0,StrVolId.indexOf("#"));
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Fetching OD Download Code ::::::");
										int odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,ofjtsIP, Short.parseShort(ofjtsPort), ofCabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OD Download Code :"+odDownloadCode);
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex Downloaded :"+ISIndex);
											
										if (odDownloadCode == 1) 
										{
											appendIndex("OFODDownloadedDocIndex",ISIndex,indexes);
											if(!(status == "error"))
												status = "success";
										}
										else if(odDownloadCode == -6012)
										{
											nextFlePath = Path+File.separator+"ApplicationDoc"+"~~"+CreationDateTime+"_O"+DocIndex+"."+StrCreatedByAppName;
											odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(SMSPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("odDownloadCode after changing docName to ApplicationDoc --> "+odDownloadCode);
											if (odDownloadCode == 1) 
											{
												appendIndex("IBPSODDownloadedDocIndex",ISIndex,indexes);
												if(!(status == "error"))
													status = "success";
											}
											else
											{
												CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in NGO download doc API in search folder method--- ");
												status = "error";
											}
										}
										else
										{
											CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in download doc API--- ");
											status = "error";
											//return status;
										}
										
									}
									else
									{
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Audit Trail not added.");
										if(!(status == "error"))
											status = "success";
									}
								}
								else
								{
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Document already added");
									if(!(status == "error"))
									status = "success";
								}
							}
						}
						else
						{
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("No docs available in folder in old OD");
							if(!(status == "error"))
								status = "success";
						}
					}
					}else{
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Folders not exists");
						status = "success";
					}
				}else{
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Folder not exists");
					status = "success";
				}
			}
			else
			{
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in search folder");
				status = "Error";
				//return status;
			}
		}catch(Exception e){
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception in searchInFolderOF method ->" + e);
			status = "error";
			return status;
		}
		return status;
	}

	private String searchInFolder(String dataClassNameDefId, String dataFieldTypeDefId, String sessionId) {
		String status = "";
		CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside searchInFolder");
		try{
		String searchFolderInputXML = CommonMethods.apNGOSearchFolder(cabinetName,sessionId,dataClassNameDefId,
				dataFieldTypeDefId, CIFID);																	
		String searchFolderOutputXML = CommonMethods.WFNGExecute(searchFolderInputXML, jtsIP,
				jtsPort, 1);
		CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("searchFolderOutputXML" + searchFolderOutputXML);
		XMLParser xmlParserAPSearch = new XMLParser(searchFolderOutputXML);
		String apSearchMaincode = xmlParserAPSearch.getValueOf("Status");
		System.out.print("Ap Search Main Code" + apSearchMaincode);
		CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Ap Search Main Code" + apSearchMaincode);
		if (apSearchMaincode.equals("0")) 
		{
			String Record = xmlParserAPSearch.getValueOf("TotalNoOfRecords");
			if(!"".equalsIgnoreCase(Record)){
			int RecordInt = Integer.parseInt(Record);
			if(RecordInt > 0){
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("TotalNoOfRecords" + Record);
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Folders Found");
			NGXmlList objWorkList = xmlParserAPSearch.createList("Folders","Folder");
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("objWorkList " + objWorkList);
			for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
			{
				String FolderDetail = xmlParserAPSearch.getNextValueOf("Folder");
				XMLParser xmlFolderDetail = new XMLParser(FolderDetail);
				String searchedFolderIndex = xmlFolderDetail.getFirstValueOf("FolderIndex");
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("searchedFolderIndex " + searchedFolderIndex);
				
				String documentListInputXML = CommonMethods.getDocumentList(searchedFolderIndex, sessionId, cabinetName);
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("documentListInputXML " + documentListInputXML);
				String documentListOutputXML = CommonMethods.WFNGExecute(documentListInputXML, jtsIP,
						jtsPort, 1);
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("documentListOutputXML " + documentListOutputXML);
				XMLParser xmlParserDocList = new XMLParser(documentListOutputXML);
				String DocListMainCode = xmlParserDocList.getValueOf("Status");
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocListMainCode " + DocListMainCode);
				int DocListRecord = Integer.parseInt(xmlParserDocList.getValueOf("TotalNoOfRecords"));
				if (DocListMainCode.equals("0") && DocListRecord > 0) 
				{
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Documents Found");
					NGXmlList objWorkLists = xmlParserDocList.createList("Documents","Document");
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("objWorkLists " + objWorkLists);
					for (; objWorkLists.hasMoreElements(true); objWorkLists.skip(true)) 
					{
						String docDetail = xmlParserDocList.getNextValueOf("Document");
						XMLParser xmlDocDetail = new XMLParser(docDetail);
						String ISIndex = xmlDocDetail.getValueOf("ISIndex");
						CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex" + ISIndex);
						
						String indexes = getIndexes("IBPSODDownloadedDocIndex");
						if(!indexes.contains(ISIndex))
						{
							String StrimgIndex = xmlDocDetail.getValueOf("ISIndex").substring(0,
									xmlDocDetail.getValueOf("ISIndex").indexOf("#"));
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex substring " + StrimgIndex);
							String StrVolId = xmlDocDetail.getValueOf("ISIndex").substring(xmlDocDetail.getValueOf("ISIndex").indexOf("#") + 1);
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("VolId:" + StrVolId + " imgIndex :" + StrimgIndex);
							String DocIndex = xmlDocDetail.getValueOf("DocumentIndex");
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("DocumentIndex" + DocIndex);
							String StrDocumentName = xmlDocDetail.getValueOf("DocumentName");
							String CreationDateTime = xmlDocDetail.getValueOf("CreationDateTime").replace(":", "-");
							
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside searchInFolder finalCreateddatetime"+CreationDateTime);
							if(!"AuditTrail".equalsIgnoreCase(StrDocumentName) && !"Conversation".equalsIgnoreCase(StrDocumentName))
							{
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside searchInFolder Not AuditTrail & Conversation"+CreationDateTime);
								String StrCreatedByAppName = xmlDocDetail.getValueOf("CreatedByAppName");
								
								
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
								
								if(StrDocumentName.contains("/") || StrDocumentName.contains("\\") || StrDocumentName.contains("<") || StrDocumentName.contains(">") || StrDocumentName.contains("|") || StrDocumentName.contains("#") || StrDocumentName.contains(":") || StrDocumentName.contains("*") || StrDocumentName.contains("?")){
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside if of special character replacement");
									StrDocumentName = StrDocumentName.replaceAll("[/\\\\<>|#:*?]", "");
								}
								
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("StrDocumentName:"+ StrDocumentName + " StrCreatedByAppName :" + StrCreatedByAppName);
								//String nextFlePath = DocLocation+File.separator+CIFID+File.separator+StrDocumentName+"_I"+DocIndex+"."+StrCreatedByAppName;
								String nextFlePath = "";
								String Path = DocLocation+File.separator+CIFID;
										
								Path targetDirectory = Paths.get(Path);
								if(!Files.exists(targetDirectory)){
										File f1 = new File(Path);
										boolean made = f1.mkdirs();
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Directory made--"+made);
								}
								nextFlePath = Path+File.separator+StrDocumentName+"~~"+CreationDateTime+"_I"+DocIndex+"."+StrCreatedByAppName;
								
								String c_Site = "1"; //Clarification
								String msg = "";
								//boolean status ;
								
								CImageServer cImageServer=null;
								try 
								{
									cImageServer = new CImageServer(null, jtsIP, Short.parseShort(jtsPort));
								}
								catch (JPISException e) 
								{
									e.printStackTrace();
									msg = e.getMessage();
									status="error";
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in cImageServer object initialization:" + e.getMessage());
									return status;
								}
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("values passed -> "+ jtsIP+" "+jtsPort+" "+cabinetName+" "+StrVolId+" "+c_Site+" "+StrimgIndex+" "+nextFlePath.toString());
								
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("document name and imageindex for "+CIFID+" -- "+StrDocumentName+", "+StrimgIndex);
								JPISIsIndex ISINDEX = new JPISIsIndex();
								JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
								String volumeIDold = StrVolId.substring(0,StrVolId.indexOf("#"));
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Fetching OD Download Code in search folder method for iBps::::::");
								//int odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(jtsPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
								int odDownloadCode;
								odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(SMSPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());

								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("OD Download Code :"+odDownloadCode);
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("ISIndex Downloaded :"+ISIndex);
									
								if (odDownloadCode == 1) 
								{
									appendIndex("IBPSODDownloadedDocIndex",ISIndex,indexes);
									if(!(status == "error"))
										status = "success";
								}
								else if(odDownloadCode == -6012)
								{
									nextFlePath = Path+File.separator+"ApplicationDoc"+"~~"+CreationDateTime+"_I"+DocIndex+"."+StrCreatedByAppName;
									odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(SMSPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(volumeIDold), Integer.parseInt(StrimgIndex),"",nextFlePath.toString(), new JPDBString());
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("odDownloadCode after changing docName to ApplicationDoc --> "+odDownloadCode);
									if (odDownloadCode == 1) 
									{
										appendIndex("IBPSODDownloadedDocIndex",ISIndex,indexes);
										if(!(status == "error"))
											status = "success";
									}
									else
									{
										CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in NGO download doc API in search folder method--- ");
										status = "error";
									}
								}
								else
								{
									CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in NGO download doc API in search folder method--- ");
									status = "error";
								}	
							}
							else
							{
								CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Document is audit trail or conversation");
								if(!(status == "error"))
									status = "success";
							}
						}
						else
						{
							CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Documentalready added");
							if(!(status == "error"))
								status = "success";
						}
					}
				}
				else
				{
					CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("No documents present in the folder");
					if(!(status == "error"))
						status = "success";
				}
			}
			}else{
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Folders not exists");
				if(!(status == "error"))
					status = "success";
			}
		}else{
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Folders not exists");
			if(!(status == "error"))
				status = "success";
		}
		}
		else
		{
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Error in AP Search Folder");
			status = "Error";
		}
		}catch(Exception e){
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception in search in folder: "+e.getMessage());
			status = "error";
			return status;
		}
		return status;
	}

	public String deleteDownloadedDocs(String nextFlePath){
		File file = new File(nextFlePath);
		if(file.exists())
		{
			file.delete();
		}
		return "";
	}
	
	private int readConfig(){
		Properties p = null;
		try {
			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "ConfigFiles"+ File.separator+ "KYC_Celebal_CIF_Extract_Config.properties")));
			Enumeration<?> names = p.propertyNames();
			while (names.hasMoreElements()){
			    String name = (String) names.nextElement();
			    CelebalExtractConfigParamMap.put(name, p.getProperty(name));
			}										
		}
		catch (Exception e){
			return -1 ;
		}
		return 0;
	}
	
	
	public String appendIndex(String EnvColName,String index,String indexes){
		//indexes += "'"+index+"|'";
		indexes = "'"+indexes+index+"|'";
		try{
		String whereClause = "CIFID = '"+CIFID+"' and ID='"+ID+"' ";
		String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"USR_0_KYC_CELEBAL_CIFS_EXTRACT", EnvColName,indexes, whereClause);
		
		CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apUpdateInputXML: "+apUpdateInputXML);
		String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
		CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
		XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
		String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
		if (apUpdateMaincode.equalsIgnoreCase("0")) 
		{
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apUpdateOutputXML for append index: "+apUpdateOutputXML);
		}
		}catch(Exception e){
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception in append Index of --"+EnvColName);
		}
		return "";
	}
	
	
	public String updateDocAttachStatus(String EnvType,String caseResult){
		try{
			String whereClause = "CIFID = '"+CIFID+"' and ID='"+ID+"' ";
			String ColName = "";
			String ColValue = "";
			int tries;
			if(!nOoFtRIES.equalsIgnoreCase(""))
			{
				tries = Integer.parseInt(nOoFtRIES);
				tries++;
			}
			else
				tries =1;
			
			String strTries = String.valueOf(tries);
			if("IBPS".equalsIgnoreCase(EnvType))
			{
				if(caseResult.equalsIgnoreCase("Success"))
				{
				ColName = "IBPSODDownloadStatus, IBPSODActCompletedDateTime, NoOfTries";
				ColValue = "'Success', getDate(),'"+strTries+"'";
				}
				else
				{
					ColName = "IBPSODDownloadStatus, NoOfTries";
					ColValue = "'Failure', '"+strTries+"'";
				}
			}
			if("OF".equalsIgnoreCase(EnvType))
			{
				if(caseResult.equalsIgnoreCase("Success"))
				{
				ColName = "OFODDownloadStatus, OFODActCompletedDateTime, NoOfTries";
				ColValue = "'Success', getDate(),'"+strTries+"'";
				}
				else if(caseResult.equalsIgnoreCase("No Search")){
					ColName = "OFODDownloadStatus, NoOfTries";
					ColValue = "'No Record', '"+strTries+"'";
				}
				
				else
				{
					ColName = "OFODDownloadStatus, NoOfTries";
					ColValue = "'Failure', '"+strTries+"'";
				}
			}
			
			String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"USR_0_KYC_CELEBAL_CIFS_EXTRACT", ColName,ColValue, whereClause);
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apUpdateInputXML: "+apUpdateInputXML);
			String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
			XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
			String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
			if (apUpdateMaincode.equalsIgnoreCase("0")) 
			{
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("apUpdateOutputXML for updateDocAttachStatus: "+apUpdateOutputXML);
			}
			}catch(Exception e){
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception in updateDocAttachStatus ");
			}
		return "";
	}
	
	
	public String getIndexes(String EnvColName){
		String index = "";
		try{
			String Query = "SELECT "+EnvColName+" FROM USR_0_KYC_CELEBAL_CIFS_EXTRACT with (nolock) where CIFID = '"+ CIFID + "' and ID='"+ID+"' ";
			String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
			String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
			String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
			int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (apSelectMaincode.equals("0") && TotalRecords > 0) {
				index = xmlParserAPSelect.getValueOf(EnvColName);
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(EnvColName+"---:"+index);
			} else {
				CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug(EnvColName+" not recieved ");
			}
			}catch(Exception e){
				
			}
		return index;
	}
		
	private static List<Map<String, String>> getDataFromDBMap(String query, String cabinetName, String sessionID,
			String jtsIP, String jtsPort) {
		List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
		try {
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Inside function getDataFromDB");
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("getDataFromDB query is: " + query);
			String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			OutXml = OutXml.replaceAll("&", "#andsymb#");
			Document recordDoc1 = MapXML.getDocument(OutXml);
			NodeList records1 = recordDoc1.getElementsByTagName("Record");
			if (records1.getLength() > 0) {
				for (int i = 0; i < records1.getLength(); i++) {
					Node n = records1.item(i);
					Map<String, String> t = new HashMap<String, String>();
					if (n.hasChildNodes()) {
						NodeList child = n.getChildNodes();
						for (int j = 0; j < child.getLength(); j++) {
							Node n1 = child.item(j);
							String column = n1.getNodeName();
							String value = n1.getTextContent().replaceAll("#andsymb#", "&");
							if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
								//CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("getDataFromDBMap Setting value of " + column + " as " + value);
								t.put(column, value);
							} else {
								//CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("getDataFromDBMap Setting value of " + column + " as blank");
								t.put(column, "");
							}
						}
					}
					temp.add(t);
				}
			}

		} catch (Exception e) {
			CelebalCIFsDocDownloadLog.CelebalCIFsDocDownloadLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return temp;

	}
	
}
