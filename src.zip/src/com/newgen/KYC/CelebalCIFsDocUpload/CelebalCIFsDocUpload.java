package com.newgen.KYC.CelebalCIFsDocUpload;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

import com.newgen.KYC.CelebalCIFsDocDownload.CelebalCIFsDocDownloadLog;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

public class CelebalCIFsDocUpload implements Runnable{
	
	static Map<String, String> DocArchivalConfigParamMap = new HashMap<String, String>();
	static String sessionID = "";
	static String cabinetName = "";
	static String jtsIP ="";
	static String jtsPort ="";
	static String SMSPort ="";
	static String volumeID ="";
	int sleepIntervalInMin = 0;
	public static int sessionCheckInt=0;
	public static int loopCount=50;
	public static int waitLoop=50;
	public static String sdate="";
	public static String SourceDiectoryPath="";
	public static String SuccessDirectorypath="";
	public static String ErrorDirectoryPath="";
	public static String DataClassName="";
	public static String deleteSuccessDataBeforeDays;
	public static String DocName="";
	public static String datadefId="";
	public static String indexId="";
	public static String rcifId="";
	public static String ccifId="";
	public static String strLookInFolder="";
	public static String newFilename=null;
	public static String TimeStamp="";
	public static long strDocFileSize=0L;
	public static String outputFolder="";
	public static String fromMailID="";
	public static String toMailID="";
	public static String BOMailID="";
	public static String FinanceMailID="";
	

	public static String updatedFolderName = "";
	
	private static NGEjbClient ngEjbClientConnection;

	static
	{
		try
		{
			ngEjbClientConnection = NGEjbClient.getSharedInstance();
		}
		catch (NGException e)
		{
			e.printStackTrace();
		}
	}

	

	@Override
	public void run() {
		// TODO Auto-generated method stub

		
		try
		{
			CelebalCIFsDocUploadLog.setLogger();

			int configReadStatus = readConfig();

			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("configReadStatus " + configReadStatus);
			if (configReadStatus != 0) 
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.error("Could not Read Config Properties [AddDocument_Config.properties]");
				return;
			}
			else 
			{
				
				SourceDiectoryPath= DocArchivalConfigParamMap.get("filePath");
			 
			   
			}
			cabinetName = CommonConnection.getCabinetName();
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("JTSPORT: " + jtsPort);
			//volumeID = CommonConnection.getsVolumeID();
			volumeID=DocArchivalConfigParamMap.get("volumeID");
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("VOLUME ID: " + volumeID);
			
			datadefId= DocArchivalConfigParamMap.get("DataDefId");
			DataClassName=DocArchivalConfigParamMap.get("DataClassName");
			rcifId=DocArchivalConfigParamMap.get("RcifIndexId");
			ccifId=DocArchivalConfigParamMap.get("CcifIndexId");
			strLookInFolder=DocArchivalConfigParamMap.get("SLookInFolder");
			deleteSuccessDataBeforeDays=DocArchivalConfigParamMap.get("DeleteSuccessDataBeforeDays");
			String strSize=DocArchivalConfigParamMap.get("Max_File_Size_MB");
			strDocFileSize=Long.parseLong(strSize);
			outputFolder=DocArchivalConfigParamMap.get("OutputFolder");
			fromMailID=DocArchivalConfigParamMap.get("FromMailId");
			toMailID=DocArchivalConfigParamMap.get("ToMailId");
			
			SMSPort = CommonConnection.getsSMSPort();
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("SMSPORT: " + SMSPort);
			

			sleepIntervalInMin = Integer.parseInt(DocArchivalConfigParamMap.get("SleepIntervalInMin"));

			sessionID = CommonConnection.getSessionID(CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger, false);

			if (sessionID.trim().equalsIgnoreCase(""))
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("Could Not Connect to Server!");
			} 
			else
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("Session ID found: " + sessionID);

				while (true) 
				{
					CelebalCIFsDocUploadLog.setLogger();
					CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("AddDocument Doc In OD..");
					sessionID = CommonConnection.getSessionID(CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger, false);
					startProcessing();
					CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("No More document to Process, Sleeping!");
					System.out.println("No More document to Process, Sleeping!");
					deleteOldFileFromSuccess();
					Thread.sleep(sleepIntervalInMin * 60 * 1000);
				}
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.error("Exception Occurred in AddDocument: " + e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.error("Exception Occurred in AddDocument..: " + result);
		}
	
		
	}
	private int readConfig() 
	{
		Properties p = null;
		try 
		{
			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir") + File.separator + "ConfigFiles"
					+ File.separator + "KYC_Clebal_DocUpload_Config.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements()) 	
			{
				String name = (String) names.nextElement();
				DocArchivalConfigParamMap.put(name, p.getProperty(name));
			}
		}
		catch (Exception e)
		{
			return -1;
		}
		return 0;
	}
	
	private void startProcessing()
	{

		try {
			Format formatter = new SimpleDateFormat("dd-MMM-yy");
			Date now = new Date();
			sdate = formatter.format(now);
			File root = new File(SourceDiectoryPath);
			String[] foldersToBeProcesed = root.list();
			String strCifType = "";
			if (root.exists()) {
				if (foldersToBeProcesed.length > 0) {
					
					for (String f : foldersToBeProcesed) {
						String currFolderPath = SourceDiectoryPath + File.separator + f;

						String[] folderComponents = currFolderPath.split("\\\\");
						if (folderComponents.length < 2) {
							
							throw new IllegalArgumentException("SourceDirectoryPath is not valid");
							
						}
						String updatedFolderName = folderComponents[folderComponents.length - 1];

						String QueryString = "select TOP 1 CIFType from USR_0_KYC_CELEBAL_CIFS_EXTRACT with (nolock) where CIFID='"
								+ updatedFolderName + "'";

						String sInputXML = CommonMethods.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger
								.debug("Input XML for Apselect from USR_0_KYC_CELEBAL_CIFS_EXTRACT Table " + sInputXML);

						String sOutputXML = CelebalCIFsDocUpload.WFNGExecute(sInputXML, jtsIP, jtsPort, 1);
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger
								.debug("Output XML for USR_0_KYC_CELEBAL_CIFS_EXTRACT Table select " + sOutputXML);

						XMLParser sXMLParser = new XMLParser(sOutputXML);
						String sMainCode = sXMLParser.getValueOf("MainCode");
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("SMainCode: " + sMainCode);

						int sTotalRecords = Integer.parseInt(sXMLParser.getValueOf("TotalRetrieved"));
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("STotalRecords: " + sTotalRecords);

						if (sMainCode.equals("0") && sTotalRecords > 0) {
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("Inside If block");
							strCifType = sXMLParser.getValueOf("CIFType");
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("updatedFolderName " + updatedFolderName);
							} 
							String indexId = "";
						if (strCifType.equalsIgnoreCase("INDIVIDUAL")) {
							indexId = rcifId;
						} else {
							indexId = ccifId;
						}
						File currFolder = new File(currFolderPath);
						String indexTag = "<Field>" + "<IndexId>" + indexId + "</IndexId>" + "<IndexValue>"
								+ updatedFolderName + "</IndexValue>" + "<IndexType>S</IndexType>" + "</Field>";
						String folderIndex = addFolderInODIfNotExist(updatedFolderName, indexTag);
						if (!"".equalsIgnoreCase(folderIndex)) {
							currFolder = new File(currFolderPath);
							String docListToadd[] = currFolder.list();
							for (String doc : docListToadd) {
								String docFullPath = currFolderPath + File.separator + doc;
								String status = addDocumentToOD(docFullPath, folderIndex, indexTag, doc,
										updatedFolderName,strCifType);
								
								 String UploadStatus="";
								 String ErrorDescription="";
									if (status.equalsIgnoreCase("0"))
									{
										UploadStatus="Success";
									}
									else{
										UploadStatus="Failure";
										ErrorDescription="Error In Add Document "+doc;
									}
								String docuploaded = getIndexes("DocsUploaded",updatedFolderName);
								String[] s1=doc.split("\\^");//dot is a regex character in java therefore need to be escaped 
							    String docNameId =s1[4].trim();
							    String StrDocumentName = docNameId.replaceAll("[/\\\\<>|#:*?_]", "");
							    String StrDocument =StrDocumentName.replaceFirst("[.][pP][dD][fF]$","");
							    CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("docName " + StrDocument);
								appendIndex("UploadStatus,ErrorDescription,DocsUploaded,UploadedDatetime",StrDocument,docuploaded,UploadStatus,ErrorDescription,updatedFolderName);
							}
						}
						deleteEmptyFolder(currFolder);
					}
				}
			}
			
			
		}

		catch (Exception e) {
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Exception in processing CelebalCIFsDocUpload" + e.toString());

		}

	
	}
	
	public static String get_timestamp()
	{
		Date present = new Date();
		Format pformatter = new SimpleDateFormat("dd-MM-yyyy-hhmmss");
		String TimeStamp=pformatter.format(present);
		return TimeStamp;
	}
	public static boolean deleteDir(File dir) throws Exception {
		if (dir.isDirectory()) {
			String[] lstrChildren = dir.list();
			for (int i = 0; i < lstrChildren.length; i++) {
				boolean success = deleteDir(new File(dir, lstrChildren[i]));
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}
	
	public String addFolderInODIfNotExist(String folderName,String indexTag)
	{	
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Inside addOrUpdateFolderIfExist..! ");
		String parentFolderIndex = "";
		String statusCode="";
		XMLParser xmlparser;
		String  strAddFolderInXML="";
		String strAddFolderOutXML="";
		
		sessionCheckInt=0;
		while(sessionCheckInt<loopCount)
		{
			try
			{
			
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("search folder lookinfolder is--"+strLookInFolder);
				String strSearchFolderInXML=getSearchFolderInput(cabinetName,sessionID,strLookInFolder,folderName);
		        String strSearchFolderOutXML = WFNGExecute(strSearchFolderInXML,jtsIP,jtsPort, 1);
		        CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("search folder output xml--"+strSearchFolderOutXML);
				xmlparser = new XMLParser(strSearchFolderOutXML);
                statusCode=xmlparser.getValueOf("Status");
				if (statusCode.equalsIgnoreCase("0"))
				{
					String error=xmlparser.getValueOf("Error");
					if(error==null)
						error="";
					if(error.length()==0 && !"0".equalsIgnoreCase(xmlparser.getValueOf("NoOfRecordsFetched"))) 
					{  
						parentFolderIndex = xmlparser.getValueOf("FolderIndex");
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("inside search folder else condition and folder is already exist with folder id--"+parentFolderIndex);
						return parentFolderIndex;
					}
					else
					{
						sessionCheckInt=0;
						while(sessionCheckInt<loopCount)
						{
							try
							{
								strAddFolderInXML = getAddFolderInputSIB(indexTag,sessionID, strLookInFolder ,folderName,cabinetName,DataClassName,datadefId);
								strAddFolderOutXML = WFNGExecute(strAddFolderInXML, jtsIP,jtsPort, 1);
								xmlparser = new XMLParser(strAddFolderOutXML);
							    CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("output xml for add folder call when executed for the first time ############# "+strAddFolderOutXML);
							    statusCode=xmlparser.getValueOf("Status");
								
								if (statusCode.equalsIgnoreCase("0"))
								{
									parentFolderIndex = xmlparser.getValueOf("FolderIndex");
									CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("value of folder index after execution of add folder call for FIRST TIME ################# "+parentFolderIndex);
									return parentFolderIndex;
								}
								else
								{
									CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error in executing add folder inxml..");
									
								}
								int mainCode=Integer.parseInt(statusCode);
								if (mainCode == -50146)
								{
									sessionID=CommonConnection.getSessionID(CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger, false);
								}
								else
								{
									sessionCheckInt++;
									break;
								}
							}
							catch(Exception e)
							{
								CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error while adding the first new folder of the hierachy--"+e.toString());
							}
						}
						
					}
				
				}
				else
				{
					CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error while searching the folder..");
					
				}
				int mainCode=Integer.parseInt(statusCode);
				if (mainCode == -50146)
				{
					sessionID=CommonConnection.getSessionID(CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger, false);
				}
				else
				{
					sessionCheckInt++;
					break;
				}
			}
			catch(Exception e)
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error while searching the first  folder of the hierachy--"+e.toString());
			}
		}

		return parentFolderIndex;
        }
	
	public String getSearchFolderInput(String sCabinetName, String sUserDBID, String sParentFolderIndex,
			String sFolderName) {
		
		String inputXml = "<?xml version=\"1.0\"?>" 
				+ "<NGOSearchFolder_Input>" 
				+ "<Option>NGOSearchFolder</Option>"
				+ "<CabinetName>" + sCabinetName + "</CabinetName>" 
				+ "<UserDBId>" + sUserDBID + "</UserDBId>"
				+ "<LookInFolder>" + sParentFolderIndex + "</LookInFolder>" 
				+ "<IncludeSubFolder>N</IncludeSubFolder>"
				+ "<Name>" + sFolderName + "</Name>" 
				+ "<StartFrom>1</StartFrom>"
				+ "<NoOfRecordsToFetch>10</NoOfRecordsToFetch>" 
				+ "</NGOSearchFolder_Input>";
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("inputXml for getSearchFolderInput:::: "+inputXml);
		return inputXml;
	}
	public String getAddFolderInputSIB(String indexTag,String sUserDBID,String sParentFolderIndex , String sFolderName,String sCabinetName,String dataClassName_Folder,String strDataclassId)
	{	
		

		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("indexTag:: "+indexTag);
		String inputXml = "<?xml version=\"1.0\"?>" 
				+ "<NGOAddFolder_Input>" 
				+ "<Option>NGOAddFolder</Option>" 
				+ "<CabinetName>" + sCabinetName + "</CabinetName>" 
				+ "<UserDBId>" + sUserDBID + "</UserDBId>" 
				+ "<Folder>"
				+ "<ParentFolderIndex>" + sParentFolderIndex + "</ParentFolderIndex>" 
				+ "<FolderName>" + sFolderName+ "</FolderName>" 
				+ "<CreationDateTime></CreationDateTime>" 
				+ "<ExpiryDateTime></ExpiryDateTime>"
				+ "<AccessType>I</AccessType>" 
				+ "<ImageVolumeIndex>1</ImageVolumeIndex>" 
				+ "<Location></Location>"
				+ "<Comment></Comment>" 
				+ "<NoOfDocuments></NoOfDocuments>" 
				+ "<NoOfSubFolders></NoOfSubFolders>"
				+ "<DataDefinition>" 
				+ "<DataDefName>"+dataClassName_Folder+"</DataDefName>" 
				+ "<DataDefIndex>" + strDataclassId+ "</DataDefIndex>"
				+ "<Fields>" 
				+ indexTag
				+ "</Fields>"
				+ "</DataDefinition>" 
				+ "</Folder>"
				+ "</NGOAddFolder_Input>";
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("inputXml for getAddFolderInputSIB:::: "+inputXml);
		return inputXml;
	}
	protected static String WFNGExecute(String ipXML, String jtsServerIP, String serverPort,
			int flag) throws IOException, Exception
	{
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("In WF NG Execute : " + serverPort);
		try
		{
			if (serverPort.startsWith("33"))
				return WFCallBroker.execute(ipXML, jtsServerIP,
						Integer.parseInt(serverPort), 1);
			else
				return ngEjbClientConnection.makeCall(jtsServerIP, serverPort,
						"WebSphere", ipXML);
		}
		catch (Exception e)
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("Exception Occured in WF NG Execute : "
					+ e.getMessage());
			e.printStackTrace();
			return "Error";
		}
	}
	
	public String addDocumentToOD(String docFullPath,String parentFolderIndex,String indexTag,String documentName,String folderName,String strCifType)
	{
		String status="";
		XMLParser xmlparser;
		int pageCount=1;
		JPISIsIndex IsIndex = new JPISIsIndex();
		JPDBRecoverDocData docDBData= new JPDBRecoverDocData();
		//docDBData.m_cDocumentType ='N';
		//docDBData.m_sVolumeId = Short.parseShort("volumeID");
		String strDocName=removeSuffixAfterLastUnderscore(documentName);
		
		String inputFolder = DocArchivalConfigParamMap.get("filePath");
		String errorFolder=DocArchivalConfigParamMap.get("ErrorFolder");
		String FullPath = inputFolder+File.separator+folderName+File.separator+documentName;
		//uploading
		try
		{
			Date now = new Date();
			Format formatter = new SimpleDateFormat("dd-MMM-yy");
			sdate = formatter.format(now);
		
			
			File file = new File(docFullPath);
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Document which going to add in OD--------->"+documentName);
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Document Path------->"+file.getAbsoluteFile());
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Is File Exist"+file.exists());
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Lengthof document---->"+file.length());
			
			if(SMSPort.startsWith("33"))
			{
				CPISDocumentTxn.AddDocument_MT(null, jtsIP , Short.parseShort(SMSPort), cabinetName, Short.parseShort(volumeID), docFullPath, docDBData, "",IsIndex);
			}
			else
			{
				CPISDocumentTxn.AddDocument_MT(null, jtsIP , Short.parseShort(SMSPort), cabinetName, Short.parseShort(volumeID), docFullPath, docDBData, null,"JNDI", IsIndex);
			}
			
			//CPISDocumentTxn.AddDocument_MT(null,CommonConnection.getJTSIP(),
					//Short.parseShort(CommonConnection.getJTSPort()),CommonConnection.getCabinetName(), Short.parseShort("volumeID"),docFullPath, docDBData, "", IsIndex);
		        
	        /*CPISDocumentTxn.AddDocument_MT(null,CommonFields.sJtsAddress,(short)(Integer.parseInt("1099")),CommonFields.sCabinetName,Short.parseShort("1"), docFullPath, docDBData, "","JNDI" ,IsIndex);*/
	        CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info(IsIndex.toString());
		}
		
		catch (NumberFormatException e) 
		{
			// TODO Auto-generated catch block
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("NumberFormatException----"+e.toString());
			e.printStackTrace();
		} catch (JPISException e) 
		{
			// TODO Auto-generated catch block
			String errorDescSourcePat="Error In SourceDirectoryPath";
			String strStatus="Failure";
			String docuploaded = getIndexes("DocsUploaded",folderName);
			appendIndex("UploadStatus,ErrorDescription,DocsUploaded,UploadedDatetime","",docuploaded,strStatus,errorDescSourcePat,folderName);
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error encountere while adding document to the server---"+e.toString());
			e.printStackTrace();
		}
		if (IsIndex.m_nDocIndex == -1) 
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info(new Date().toString() + ": Unable to add file to SMS.");
		}
		else
		{
	    CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Uploaded Document to Image Server.....");
					
		}
		
		int intISIndex = (int) IsIndex.m_nDocIndex;
		int intVolumeId = (int) IsIndex.m_sVolumeId;					
		String noOfPages = String.valueOf(pageCount);
		 	String s1[]=strDocName.split("\\.");//dot is a regex character in java therefore need to be escaped 
		    String docName=s1[0];
		    String strExtension=s1[1];
			String append=get_timestamp();
			String fileName=documentName+"_"+append;
		if(intISIndex <= 0) 
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error");
			Date d = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String strDate = dateFormat.format(d);
			strDate = strDate.replaceAll("-", "");
			String targetPath = errorFolder+File.separator+strDate+File.separator+folderName;
			moveFile(FullPath,targetPath,fileName);
			try {
				sendMail(cabinetName,sessionID,"INCORRECT FILE FORMAT",fileName,folderName);
			} catch(Exception e)
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error in sendMail ---"+e.toString());
			}
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error in adding document to SMS....."+docName);
		}
		else
		{
			try
				{
				String intISIndexVolId = Integer.toString(intISIndex) + "#" + intVolumeId + "#";
				
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Document with extension which is going to for upload in OD--"+docName);
			   
			    String DocumentType="";
			    String[] docFields = docName.split("\\^");
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("docFields--"+docFields.length);
			    if(docFields.length >= 5){
			    String strCcif =docFields[0].trim();
			    String strRcif =docFields[1].trim();
			    String strRpName =docFields[2].trim();//complete docName
			    String DocDate =docFields[3].trim();
			    String docNameId =docFields[4].trim();
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("docFields--"+strCcif+""+strRcif+""+strRpName+""+DocDate+""+docNameId);
			    //Removing characters after_
			    if (docNameId.contains("_"))
			    {
			    	CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("docNameId--"+docNameId);
			    	docNameId= docNameId.replaceAll("_[0-9]+(?=\\.[^.]+$)", "");			    			 
			    CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Doc Name Cleaned--"+docNameId);
			    }
			    
			    
			   // String strDocComment =docFields[4];
			    String strComment =documentName;
			    
			    if(strCcif.equals("") && strRcif.equals(""))
			    {
			    	if(strCifType.equalsIgnoreCase("INDIVIDUAL")){
			    		strRcif=folderName;//folder name is cif
			    	}
			    	else{
			    		strCcif=folderName;
			    	}
			    }
			        
			    String docIndexTag="<Field>" +
                        "<IndexId>" + rcifId + "</IndexId>" +
                        "<IndexValue>" + strRcif + "</IndexValue>" +
                        "<IndexType>S</IndexType>" +
                    "</Field>" +
                    "<Field>" +
                        "<IndexId>" + ccifId + "</IndexId>" +
                        "<IndexValue>" + strCcif + "</IndexValue>" +
                        "<IndexType>S</IndexType>" +
                    "</Field>";
			    
			    CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Extension of the uploaded doc--"+strExtension);
			    if(strExtension.equalsIgnoreCase("JPG") || strExtension.equalsIgnoreCase("TIF") || strExtension.equalsIgnoreCase("JPEG") || strExtension.equalsIgnoreCase("TIFF") || strExtension.equalsIgnoreCase("PNG"))
				{
					DocumentType = "I";
				}
				else
				{
					DocumentType = "N";
				}
				File file = new File(docFullPath);
				
				
				/*String strInputXml = getAddDocumentInputXML(cabinetName,sessionID,docNameId,strExtension,DocumentType,parentFolderIndex,intISIndexVolId,noOfPages,String.valueOf(file.length()),docIndexTag,datadefId,strComment);
	            CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Input Xml------------------------>"+strInputXml);
	            String strOutputXml=""; */
	            sessionCheckInt=0;
				while(sessionCheckInt<loopCount)
				{
					
					try
					{
					
						if(canUpload(file)){
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("File --"+file);
							String strInputXml = getAddDocumentInputXML(cabinetName,sessionID,docNameId,strExtension,DocumentType,parentFolderIndex,intISIndexVolId,noOfPages,String.valueOf(file.length()),docIndexTag,datadefId,strComment);
				            CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Input Xml------------------------>"+strInputXml);
				            String strOutputXml="";
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("File Size under 10 MB--");
						strOutputXml =WFNGExecute(strInputXml, jtsIP,jtsPort, 1);
						xmlparser= new XMLParser(strOutputXml);
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Output Xml------------------------>"+strOutputXml);
				        //CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info(strOutputXml);
						status= xmlparser.getValueOf("Status");
						if (!status.equalsIgnoreCase("0"))
						{
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error in Add document call");
						}
					
						if (status.equalsIgnoreCase("0")) 
						{
							
							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
							String strDate = dateFormat.format(d);
							strDate = strDate.replaceAll("-", "");
							String targetPath = outputFolder+File.separator+strDate+File.separator+folderName;
							moveFile(FullPath,targetPath,fileName);
						}
						else
						{
							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
							String strDate = dateFormat.format(d);
							strDate = strDate.replaceAll("-", "");
							String targetPath = errorFolder+File.separator+strDate+File.separator+folderName;
							moveFile(FullPath,targetPath,fileName);
							sendMail(cabinetName,sessionID,"INCORRECT FILE FORMAT",fileName,folderName);
						}	
						int mainCode=Integer.parseInt(status);
						if (mainCode == -50146)
						{
							sessionID=CommonConnection.getSessionID(CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger, false);
						}
						else
						{
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Else");
							sessionCheckInt++;
							break;
							
						}
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Ending upload for this Docuemnt");
						}
						else
						{
							CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("File Size exceeding 10 MB-- Moving to Error Folder");
							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
							String strDate = dateFormat.format(d);
							strDate = strDate.replaceAll("-", "");
							String targetPath = errorFolder+File.separator+strDate+File.separator+folderName;
							moveFile(FullPath,targetPath,fileName);
							//sendMail(cabinetName,sessionID,"INCORRECT FILE SIZE",fileName,folderName);
						}
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Ending while for this document	");
					}
					
					catch(Exception e)
					{
						CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error in adding document ---"+e.toString());
					}
				}
			    }
			    else{
			    	CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error");
					Date d = new Date();
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
					String strDate = dateFormat.format(d);
					strDate = strDate.replaceAll("-", "");
					String targetPath = errorFolder+File.separator+strDate+File.separator+folderName;
					moveFile(FullPath,targetPath,fileName);
			    }
			    CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("after 2");		
			}
			catch(Exception e)
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Error in adding document(metadata generation) ---"+e.toString());
			}
		}
		return status;         
      }
	public  String getAddDocumentInputXML(String sCabinetName,String sSessionID,String docName,String strdocExtension,String DocumentType,String parentFolderIndex,String intISIndexVolId,String nofpages,String docSize,String dataDefFieldsXml,String dataDefId,String strComment)
	{
		
		String strInputXml =
				"<?xml version=\"1.0\"?><NGOAddDocument_Input>" +
				        "<Option>NGOAddDocument</Option>" +
				        "<CabinetName>"+sCabinetName+"</CabinetName>" +
				        "<UserDBId>"+sSessionID+"</UserDBId>" +
				        "<GroupIndex>0</GroupIndex>" +
				        "<Document>" +
				        "<ParentFolderIndex>"+parentFolderIndex+"</ParentFolderIndex>" +
				        "<NoOfPages>"+nofpages+"</NoOfPages>" +
				        "<AccessType>I</AccessType>" +
				        "<DocumentName>"+docName+"</DocumentName>" +
				        "<CreationDateTime></CreationDateTime>" +
				        "<DocumentType>"+DocumentType+"</DocumentType>" +
				        "<DocumentSize>"+docSize+"</DocumentSize>" +
				        "<CreatedByAppName>"+strdocExtension+"</CreatedByAppName>" +
				        "<ISIndex>"+intISIndexVolId+"</ISIndex>" +
				        "<ODMADocumentIndex></ODMADocumentIndex>" +
				        "<Comment>"+strComment+"</Comment>" +
				        "<EnableLog>Y</EnableLog>" +
				        "<FTSFlag>PP</FTSFlag>" +
				        "<DataDefinition>"+
				        "<DataDefIndex>"+dataDefId+"</DataDefIndex>"+
				        "<Fields>"+dataDefFieldsXml+"</Fields>"+
				        "</DataDefinition>" +
				        "<Keywords></Keywords>" +
				        "</Document>" +
				        "</NGOAddDocument_Input>";
		
          return strInputXml;
	}
	
	
	public static void waiteloopExecute(long wtime) 
	{
		try 
		{
			for (int i = 0; i < 10; i++) 
			{
				Thread.yield();
				Thread.sleep(wtime / 10);
			}
		} 
		catch (InterruptedException e) 
		{
		}
	}
	
	public static boolean moveFile(String sourcePath,String targetPath,String FileName)
	{
		boolean fileMoved = true;
		Path targetDirecoty = null;
		Path targetDirectory = Paths.get(targetPath);
		if(!Files.exists(targetDirectory)){
				File f1 = new File(targetPath);
				f1.mkdirs();
		}
		try{
			Files.move(Paths.get(sourcePath),Paths.get(targetPath+File.separator+FileName), StandardCopyOption.REPLACE_EXISTING);
		}
		catch(Exception e){
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("exception in moving file"+e.getMessage());
			fileMoved = false;
		}
		return fileMoved;
	}
	public static void deleteEmptyFolder(File folder){
		File [] files = folder.listFiles();
		if(files !=null && files.length==0)
		{
			if(folder.delete())
			{
				System.out.println("deleted empty folder"+folder.getAbsolutePath());
				
			}
			else{
				System.out.println("Failed to delete the folder"+folder.getAbsolutePath());
			}
		}
		
	}
	private  void deleteOldFileFromSuccess()
	{
		try
		{
			File tobedeleted = new File(outputFolder);
			deleteFolder(tobedeleted);
		}
		catch(Exception e)
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.error("Exception Occurred in deleteOldFileFromSuccess : "+e.toString());
		}
	}
	private static void deleteFolder(File file){
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		for (File subFile : file.listFiles()) 
		{
			boolean isOld = false;
			String strModifiedDate = dateFormat.format(subFile.lastModified());
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("File Name: "+subFile.getName()+", last modified: "+strModifiedDate);
			try {
				Date parsedModifiedDate=new SimpleDateFormat("dd-MMM-yy").parse(strModifiedDate);
				isOld = olderThanDays(parsedModifiedDate, Integer.parseInt(deleteSuccessDataBeforeDays));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (isOld)
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Deleting: "+subFile.getName());	
				if(subFile.isDirectory()) 
				{
					try {
						FileUtils.deleteDirectory(subFile);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					subFile.delete();
				}
			}
		}
	}
	public static void sendMail(String cabinetName, String sessionId,String failedEvent,String FileName,String folderName )throws Exception
	{
		
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Inside sendMail");
		XMLParser objXMLParser = new XMLParser();
		String sInputXML="";
		String sOutputXML="";
		String mainCodeforAPInsert=null;
		sessionCheckInt=0;
		while(sessionCheckInt<loopCount)
		{
			try
			{
				String mailSubject = "";
				String MailStr = "";
				
				if ("INCORRECT FILE FORMAT".equalsIgnoreCase(failedEvent))
				{
					mailSubject = "Celebal Classified document not getting uploaded in OmniDocs due to file format issue.";
					MailStr = "<html><body>Dear BPM Support Team,<br><br>Celebal Classified document "+FileName+" not getting uploaded under cif "+folderName+" in OmniDocs due to file format issue.<br><br>Regards,<br>RAKBANK<br>* This is an automated email, please do not reply.</body></html>";
				} 
				/*if("INCORRECT FILE SIZE".equalsIgnoreCase(failedEvent))
				{
					mailSubject = "Celebal Classified document not getting uploaded in OmniDocs due to file size .";
					MailStr = "<html><body>Dear BPM Support Team,<br><br>Celebal Classified document "+FileName+" not getting uploaded under cif "+folderName+" in OmniDocs due to file size exceeding 10MB.<br><br>Regards,<br>RAKBANK<br>* This is an automated email, please do not reply.</body></html>";
				} */
				
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Inside sendMail"+MailStr);
				String columnName = "mailFrom,mailTo,mailSubject,mailMessage,mailContentType,mailPriority,mailStatus,mailActionType,insertedTime,noOfTrials,zipFlag";
				String strValues = "'"+fromMailID+"','"+toMailID+"','"+mailSubject+"','"+MailStr+"','text/html;charset=UTF-8','1','N','TRIGGER','"+CommonMethods.getdateCurrentDateInSQLFormat()+"','0','N'";
				
				sInputXML = "<?xml version=\"1.0\"?>" +
						"<APInsert_Input>" +
						"<Option>APInsert</Option>" +
						"<TableName>WFMAILQUEUETABLE</TableName>" +
						"<ColName>" + columnName + "</ColName>" +
						"<Values>" + strValues + "</Values>" +
						"<EngineName>" + cabinetName + "</EngineName>" +
						"<SessionId>" + sessionId + "</SessionId>" +
						"</APInsert_Input>";

				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Mail Insert InputXml::::::::::\n"+sInputXML);
				sOutputXML =WFNGExecute(sInputXML, jtsIP, jtsPort, 0);
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Mail Insert OutputXml::::::::::\n"+sOutputXML);
				objXMLParser.setInputXML(sOutputXML);
				mainCodeforAPInsert=objXMLParser.getValueOf("MainCode");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.error("Exception in Sending mail", e);
				sessionCheckInt++;
				waiteloopExecute(waitLoop);
				continue;
			}
			if (mainCodeforAPInsert.equalsIgnoreCase("11")) 
			{
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("Invalid session in Sending mail");
				sessionCheckInt++;
				sessionID=CommonConnection.getSessionID(CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger, true);
				continue;
			}
			else
			{
				sessionCheckInt++;
				break;
			}
		}
		if(mainCodeforAPInsert.equalsIgnoreCase("0"))
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("mail Insert Successful");
		}
		else
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.info("mail Insert Unsuccessful");
		}
	}
	private static boolean olderThanDays(Date givenDate, int numDays)
	{   
		final long MILLIS_PER_DAY = 24 * 60 * 60 * 1000;
		long currentMillis = new Date().getTime();
	    long millisInDays = numDays * MILLIS_PER_DAY;
	    boolean result = givenDate.getTime() < (currentMillis - millisInDays);
	    return result;
	}
	private static boolean canUpload(File file) throws IOException
	{   
		long fileSizeInMBBytes = file.length();
		double fileSizeInMB =convertBytesToMB(fileSizeInMBBytes);
	    return fileSizeInMB <= strDocFileSize;
	    
	}
	private static String removeSuffixAfterLastUnderscore(String filename)
	{
		return filename.replaceAll("(_\\d+)(\\.[^.]+)$", "$2");
	}
	public static double convertBytesToMB(long bytes)
	{
		return (double) bytes/(1024*1024);
	}
	public String appendIndex(String EnvColName,String doc,String docuploaded,String status,String errDesc,String updatedFolderName){
		//indexes += "'"+index+"|'";
		String ColValue = "";
		if(!doc.isEmpty()){
		docuploaded = "'"+docuploaded+doc+"|'";
		}
		else{
			docuploaded = "'"+docuploaded+"'";
		}
		ColValue = "'"+status+"','"+errDesc+"',"+docuploaded+",getDate()";
		try{
		String whereClause = "CIFID = '"+updatedFolderName+"'";
		String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"USR_0_KYC_CELEBAL_CIFS_EXTRACT", EnvColName,ColValue, whereClause);
		
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("apUpdateInputXML: "+apUpdateInputXML);
		String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
		CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("apUpdateOutputXML: "+apUpdateOutputXML);
		XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
		String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
		if (apUpdateMaincode.equalsIgnoreCase("0")) 
		{
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("apUpdateOutputXML for append index: "+apUpdateOutputXML);
		}
		}catch(Exception e){
			CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug("Exception in append Index of --"+EnvColName);
		}
		return "";
	}
	
	public String getIndexes(String EnvColName,String updatedFolderName ){
		String index = "";
		try{
			String Query = "SELECT "+EnvColName+" FROM USR_0_KYC_CELEBAL_CIFS_EXTRACT with (nolock) where CIFID = '"+ updatedFolderName + "'";
			String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
			String OutputXML = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
			String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
			int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (apSelectMaincode.equals("0") && TotalRecords > 0) {
				index = xmlParserAPSelect.getValueOf(EnvColName);
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug(EnvColName+"---:"+index);
			} else {
				CelebalCIFsDocUploadLog.CelebalCIFsDocUploadLogger.debug(EnvColName+" not recieved ");
			}
			}catch(Exception e){
				
			}
		return index;
	}
}
