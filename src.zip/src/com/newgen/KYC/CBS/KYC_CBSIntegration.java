/*
---------------------------------------------------------------------------------------------------------
                  NEWGEN SOFTWARE TECHNOLOGIES LIMITED

Group                   : Application - Projects
Project/Product			: RAK BPM
Application				: RAK BPM Utility
Module					: DAC CBS
File Name				: DACCBSIntegration.java
Author 					: Sivakumar P
Date (DD/MM/YYYY)		: 26/11/2019

---------------------------------------------------------------------------------------------------------
                 	CHANGE HISTORY
---------------------------------------------------------------------------------------------------------

Problem No/CR No        Change Date           Changed By             Change Description
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
*/


package com.newgen.KYC.CBS;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//import com.newgen.NBTL.Memopad.CustomerBean;
//import com.newgen.NBTL.Memopad.NBTL_Memopad;
//import com.newgen.NBTL.Memopad.NBTL_MemopadIntegration;
//import com.newgen.NBTL.Memopad.NBTL_Memopad_Log;
import com.newgen.KYC.CBS.KYC_CBS;
import com.newgen.KYC.CustOutreach.CustOutreachLog;
import com.newgen.KYC.CustOutreach.MapXML;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class KYC_CBSIntegration {

	
	private String XMLLOG_HISTORY_TABLE = "NG_KYC_Remedation_XMLLOG_HISTORY";
	private String NBTL_EXTTABLE = "RB_KYC_REM_EXTTABLE";
	
	Socket socket=null;
	String socketServerIP="";
	int socketServerPort=0;
	OutputStream out = null;
	InputStream socketInputStream = null;
	DataOutputStream dout = null;
	DataInputStream din = null;
	String outputResponse = null;
	String inputRequest = null;	
	String inputMessageID = null;
	String CustomerID="";
	
	public ResponseBean KYC_CBS_CifUpdateIntegration(String cabinetName, String sessionID,String sJtsIp, String sJtsPort , String smsPort, String wi_name,
			int socket_connection_timeout,int integrationWaitTime,String strCorporateCIF,HashMap<String, String> socketDetailsMap,
			String strWi_name,String activityName) throws Exception
	{
		String InstitutionCountryFI = "";
		String LegalEntityFI = "";
		String append = "";
		String CorpFlag = "";
		String officeAddress = "";
		String OfficeCityEmirate = "";
		String OfficeCountry = "";
		String ResidenceAddress = "";
		String ResidenceCountry = "";
		String ResidenceEmirateCity = "";
		String Mobile = "";
		String EMailID = "";
		String EmiratedIDcardNumber = "";
		String EmiratesIDexpiryDate = "";
		String PassportNumber = "";
		String PassportIssueDate = "";
		String PassportExpiryDate = "";
		String EffectiveFrom = "";
		String IndustrySegment  = "";
		String IndustrySubsegment = "";
		String caseType = "";
		String rpIntegrationresponse = "success";
		
		KYC_CBSLog.KYC_CBSLogger.debug("Testing_logger" + cabinetName+" "+ sessionID+" "+ sJtsIp+" "+ sJtsPort+" "+ smsPort+" "+ wi_name+" "+
				socket_connection_timeout+" "+ integrationWaitTime+" "+ strCorporateCIF+" "+ socketDetailsMap.toString()+" "+
				strWi_name+" "+ activityName);
		
		String query = "Select CaseType,CustomerClassification,EntityCountryOfIncorporation,LegalEntity,"
					   +"DateOfBusinessEstablishment,OwnerNationality,OwnerDOB,DNFBP_Status,IndustrySegment,IndustrySubSegment "
					   +"FROM RB_KYC_REM_EXTTABLE Where WINAME = '"+wi_name+"'";
				
		String sInputXML =CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
		KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+sInputXML);

		String sOutputXML=KYC_CBS.WFNGExecute(sInputXML, sJtsIp, sJtsPort,1);
		KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+sOutputXML);

		XMLParser XMLParser= new XMLParser(sOutputXML);
	    String sMainCode = XMLParser.getValueOf("MainCode");
	    KYC_CBSLog.KYC_CBSLogger.debug("SMainCode: "+sMainCode);

	    int sTotalRecords = Integer.parseInt(XMLParser.getValueOf("TotalRetrieved"));
	    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+sTotalRecords);

		if (sMainCode.equals("0") && sTotalRecords > 0)
		{
			caseType = XMLParser.getValueOf("CaseType");
			CorpFlag=XMLParser.getValueOf("CaseType");
			if("Individual".equalsIgnoreCase(CorpFlag)){
				 CorpFlag = "R";
				 
				 String queryRetail = "Select IndustrySegment,IndustrySubSegment,OfficeAddressLine1,OfficeAddressLine2,OfficeAddressLine3,"
				 			+ "OfficeAddressLine4,OfficeZIPCode,OfficePOBox,OfficeState,OfficeCityEmirate,OfficeCountry,"
							+ "ResidenceFlatVillaNo,Residence_Address2,Residence_Address3,ResidenceLandmark,ResidenceZIPCode,"
							+ "ResidencePOBox,ResidenceState,ResidenceCountry,ResidenceEmirateCity,Mobile,EMailID,"
							+ "EmiratedIDcardNumber,EmiratesIDexpiryDate,PassportNumber,PassportIssueDate,PassportExpiryDate,"
							+ "Title,FirstName,MiddleName,LastName,Gender,Nationality,DateOfBirth,CountryOfBirth,PlaceOfBirth,"
							+ "RiskProfile,OtherIncome,CusNonResidentIndicator,ResidentCountry,OfficeEmploymentType,OfficeEmployerNameDesc,"
							+ "OfficeEmployerCode,OfficeOccupation,MonthlyIncome,ExpectedMonthlyCreditTurnover,MonthlyCashCRturnover,"
							+ "MonthlyCashNoonCRturnover,HighestCashCRtransaction,HighestNonCashCrTransaction,PEP,"
							+ "CustomerClassification,NextReviewDate,TIN_Field,SignedDate,ExpiryDate,PreferredAddressFlag,"
							+ "USpassportHolder_GreencardHolder,FormObtained"
							+ " FROM RB_KYC_REM_EXTTABLE Where WINAME = '"+wi_name+"'";
				 String queryRetailInputXML = CommonMethods.apSelectWithColumnNames(queryRetail, cabinetName, sessionID);
				 KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect for Retail Data "+queryRetailInputXML);
					
				 String queryRetailOutputXML = KYC_CBS.WFNGExecute(queryRetailInputXML, sJtsIp, sJtsPort,1);
				 KYC_CBSLog.KYC_CBSLogger.debug("Output XML Retail Data "+queryRetailOutputXML);
				 
				 XMLParser RetailXMLParser= new XMLParser(queryRetailOutputXML);
				 String RetailMainCode = RetailXMLParser.getValueOf("MainCode");
				 KYC_CBSLog.KYC_CBSLogger.debug("RetailMainCode: "+RetailMainCode);
				 
				 int RetailTotalRecords = Integer.parseInt(RetailXMLParser.getValueOf("TotalRetrieved"));
				 KYC_CBSLog.KYC_CBSLogger.debug("RetailTotalRecords: "+RetailTotalRecords);
				 
				 IndustrySegment = RetailXMLParser.getValueOf("IndustrySegment");
				 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
				 
				 IndustrySubsegment = RetailXMLParser.getValueOf("IndustrySubSegment");
				 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
				 
				 if(!("".equalsIgnoreCase(IndustrySegment)) && !("".equalsIgnoreCase(IndustrySubsegment)))
				 	{
					 append += "\n\t<IndustryDet>";
					 if(!"".equalsIgnoreCase(IndustrySegment)) //IndustrySegment = "KYCDELETE";
					 {
						 append +="\n\t\t<IndustrySegment>"+IndustrySegment+"</IndustrySegment>";
					 }
					 if(!"".equalsIgnoreCase(IndustrySubsegment)) //IndustrySubsegment = "KYCDELETE";
					 {
						 append +="\n\t\t<IndustrySubSegment>"+IndustrySubsegment+"</IndustrySubSegment>";
					 }
					 append += "\n\t</IndustryDet>";
				 	}
				 
				 officeAddress=RetailXMLParser.getValueOf("OfficeAddressLine1");
				 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
				 
				 OfficeCityEmirate=RetailXMLParser.getValueOf("OfficeCityEmirate");
				 KYC_CBSLog.KYC_CBSLogger.debug("OfficeCityEmirate: "+OfficeCityEmirate);
				 
				 OfficeCountry=RetailXMLParser.getValueOf("OfficeCountry");
				 KYC_CBSLog.KYC_CBSLogger.debug("OfficeCountry: "+OfficeCountry);
				 
				 ResidenceAddress=RetailXMLParser.getValueOf("ResidenceFlatVillaNo");
				 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceAddress: "+ResidenceAddress);
				 
				 ResidenceEmirateCity=RetailXMLParser.getValueOf("ResidenceEmirateCity");
				 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceEmirateCity: "+ResidenceEmirateCity);
				 
				 ResidenceCountry=RetailXMLParser.getValueOf("ResidenceCountry");
				 KYC_CBSLog.KYC_CBSLogger.debug("ResidencyCountry: "+ResidenceCountry);
				 
				 String PreferredAddressFlag = RetailXMLParser.getValueOf("PreferredAddressFlag");
				 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);
				 
				 Date todayDate = new Date();
				 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
				 EffectiveFrom = outputDateFormatED.format(todayDate);
				 
				 if(!"".equalsIgnoreCase(officeAddress) && !"".equalsIgnoreCase(OfficeCityEmirate) && !"".equalsIgnoreCase(OfficeCountry))
				 {
					 String OfficeAddress2 = RetailXMLParser.getValueOf("OfficeAddressLine2");
					 KYC_CBSLog.KYC_CBSLogger.debug("OfficeAddress2: "+OfficeAddress2);
					 
					 String OfficeAddress3 = RetailXMLParser.getValueOf("OfficeAddressLine3");
					 KYC_CBSLog.KYC_CBSLogger.debug("OfficeAddress3: "+OfficeAddress3);
					 
					 String OfficeAddress4 = RetailXMLParser.getValueOf("OfficeAddressLine4");
					 KYC_CBSLog.KYC_CBSLogger.debug("OfficeAddress4: "+OfficeAddress4);
					 
					 String OfficeZIPcode = RetailXMLParser.getValueOf("OfficeZIPCode");
					 KYC_CBSLog.KYC_CBSLogger.debug("OfficeZIPcode: "+OfficeZIPcode);
					 
					 String OfficePOBox = RetailXMLParser.getValueOf("OfficePOBox");
					 KYC_CBSLog.KYC_CBSLogger.debug("OfficePOBox: "+OfficePOBox);
					 
					 String OfficeState = RetailXMLParser.getValueOf("OfficeState");
					 KYC_CBSLog.KYC_CBSLogger.debug("OfficeState: "+OfficeState);
					 
					 String prefFlag = "";
					 if("OFFICE".equalsIgnoreCase(PreferredAddressFlag) || ("".equalsIgnoreCase(ResidenceAddress)
						|| "".equalsIgnoreCase(ResidenceEmirateCity) || "".equalsIgnoreCase(ResidenceCountry) && 
						"RESIDENCE".equalsIgnoreCase(PreferredAddressFlag)))
					 {
						 prefFlag = "Y";
					 }
					 else
					 {
						 prefFlag = "N";
					 }
					 
				 append += "\n\t<AddrDet>" +
						 "\n\t\t<AddressType>OFFICE</AddressType>"+
						 "\n\t\t<AddrInd>R</AddrInd>"+
						 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
						 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
						 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
						 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
						 "\n\t\t<AddrPrefFlag>"+prefFlag+"</AddrPrefFlag>"+
						 "\n\t\t<AddrLine1>"+officeAddress+"</AddrLine1>";
				 
				 if(!"".equalsIgnoreCase(OfficeAddress2))
					 	append +="\n\t\t<AddrLine2>"+OfficeAddress2+"</AddrLine2>";
				 if(!"".equalsIgnoreCase(OfficeAddress3))
					 	append +="\n\t\t<AddrLine3>"+OfficeAddress3+"</AddrLine3>";
				 if(!"".equalsIgnoreCase(OfficeAddress4))
					 	append +="\n\t\t<AddrLine4>"+OfficeAddress4+"</AddrLine4>";
				 if(!"".equalsIgnoreCase(OfficePOBox))
					 	append +="\n\t\t<POBox>"+OfficePOBox+"</POBox>";
				 if(!"".equalsIgnoreCase(OfficeZIPcode))
					 	append +="\n\t\t<ZipCode>"+OfficeZIPcode+"</ZipCode>";
				 if(!"".equalsIgnoreCase(OfficeState))
					 	append +="\n\t\t<State>"+OfficeState+"</State>";
				 
				 append += "\n\t\t<City>"+OfficeCityEmirate+"</City>"+
						 "\n\t\t<CountryCode>"+OfficeCountry+"</CountryCode>"+
						 "\n\t</AddrDet>";
				 }
				 else
				 {
					 append += "\n\t<AddrDet>" +
							 "\n\t\t<AddressType>OFFICE</AddressType>"+
							 "\n\t\t<AddrInd>D</AddrInd>"+
							 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
							 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
							 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
							 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
							 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
							 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
							 "\n\t\t<City>KYCDELETE</City>"+
							 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
							 "\n\t</AddrDet>";
				 }
				 
				 
				 
				 if(!"".equalsIgnoreCase(ResidenceAddress) && !"".equalsIgnoreCase(ResidenceEmirateCity) && !"".equalsIgnoreCase(ResidenceCountry))
				 {
					 String ResidenceAddress2 = RetailXMLParser.getValueOf("Residence_Address2");
					 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceBuilding: "+ResidenceAddress2);
					 
					 String ResidenceAddress3 = RetailXMLParser.getValueOf("Residence_Address3");
					 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceStreet: "+ResidenceAddress3);
					 
					 String ResidenceAddress4 = RetailXMLParser.getValueOf("ResidenceLandmark");
					 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceLandmark: "+ResidenceAddress4);
					 
					 String ResidenceZIPcode = RetailXMLParser.getValueOf("ResidenceZIPCode");
					 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceZIPcode: "+ResidenceZIPcode);
					 
					 String ResidencePOBox = RetailXMLParser.getValueOf("ResidencePOBox");
					 KYC_CBSLog.KYC_CBSLogger.debug("ResidencePOBox: "+ResidencePOBox);
					 
					 String ResidenceState = RetailXMLParser.getValueOf("ResidenceState");
					 KYC_CBSLog.KYC_CBSLogger.debug("ResidenceState: "+ResidenceState);
					 
					/* String PreferredAddressFlag = RetailXMLParser.getValueOf("PreferredAddressFlag");
					 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);*/
					 String prefFlag = "";
					 if("RESIDENCE".equalsIgnoreCase(PreferredAddressFlag) || ("".equalsIgnoreCase(officeAddress)
						|| "".equalsIgnoreCase(OfficeCityEmirate) || "".equalsIgnoreCase(OfficeCountry) && "OFFICE".equalsIgnoreCase(PreferredAddressFlag)))
					 {
						 prefFlag = "Y";
					 }
					 else
					 {
						 prefFlag = "N";
					 }
				 append +="\n\t<AddrDet>" +
						 "\n\t\t\t<AddressType>RESIDENCE</AddressType>"+
						 "\n\t\t<AddrInd>R</AddrInd>"+
						 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
						 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
						 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
						 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
						 "\n\t\t<AddrPrefFlag>"+prefFlag+"</AddrPrefFlag>"+
						 "\n\t\t<AddrLine1>"+ResidenceAddress+"</AddrLine1>";
				 
				 if(!"".equalsIgnoreCase(ResidenceAddress2))
					 	append +="\n\t\t<AddrLine2>"+ResidenceAddress2+"</AddrLine2>";
				 if(!"".equalsIgnoreCase(ResidenceAddress3))
					 	append +="\n\t\t<AddrLine3>"+ResidenceAddress3+"</AddrLine3>";
				 if(!"".equalsIgnoreCase(ResidenceAddress4))
					 	append +="\n\t\t<AddrLine4>"+ResidenceAddress4+"</AddrLine4>";
				 if(!"".equalsIgnoreCase(ResidencePOBox))
					 	append +="\n\t\t<POBox>"+ResidencePOBox+"</POBox>";
				 if(!"".equalsIgnoreCase(ResidenceZIPcode))
					 	append +="\n\t\t<ZipCode>"+ResidenceZIPcode+"</ZipCode>";
				 if(!"".equalsIgnoreCase(ResidenceState))
					 	append +="\n\t\t<State>"+ResidenceState+"</State>";
				 
				 append += "\n\t\t<City>"+ResidenceEmirateCity+"</City>"+
						 "\n\t\t<CountryCode>"+ResidenceCountry+"</CountryCode>"+
						 "\n\t</AddrDet>";
				 }
				 else
				 {
					 append += "\n\t<AddrDet>" +
							 "\n\t\t<AddressType>RESIDENCE</AddressType>"+
							 "\n\t\t<AddrInd>D</AddrInd>"+
							 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
							 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
							 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
							 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
							 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
							 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
							 "\n\t\t<City>KYCDELETE</City>"+
							 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
							 "\n\t</AddrDet>";
				 }
				 
				/* Mobile=RetailXMLParser.getValueOf("Mobile");
				 KYC_CBSLog.KYC_CBSLogger.debug("Mobile: "+Mobile);
				 
				 if(!"".equalsIgnoreCase(Mobile))
				 {
					 append +="\n\t\t<PhnDetails>"+
							 "\n\t\t<PhnType>OFFCPH1</PhnType>"+
							 "\n\t\t<PhnPrefFlag>N</PhnPrefFlag>"+
							 "\n\t\t<PhnLocalCode>"+Mobile+"</PhnLocalCode>"+
							 "\n\t\t</PhnDetails>";
				 }
				 
				 EMailID=RetailXMLParser.getValueOf("EMailID");
				 KYC_CBSLog.KYC_CBSLogger.debug("EMailID: "+EMailID);
				 
				 if(!"".equalsIgnoreCase(EMailID))
				 {
					 append += "\n\t\t<EmlDet>"+
							 "\n\t\t<EmlType>ELML1</EmlType>"+
							 "\n\t\t<EmlPrefFlag>N</EmlPrefFlag>"+
							 "\n\t\t<Email>"+EMailID+"</Email>"+
							 "\n\t\t</EmlDet>";
				 }*/
				 
				 EmiratedIDcardNumber=RetailXMLParser.getValueOf("EmiratedIDcardNumber");
				 KYC_CBSLog.KYC_CBSLogger.debug("EmiratedIDcardNumber: "+EmiratedIDcardNumber);
				 
				 SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				 SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				 
				 EmiratesIDexpiryDate=RetailXMLParser.getValueOf("EmiratesIDexpiryDate");
				 KYC_CBSLog.KYC_CBSLogger.debug("EmiratesIDexpiryDate: "+EmiratesIDexpiryDate);
				 
				 try{
					 Date inputDate = inputDateFormat.parse(EmiratesIDexpiryDate);
					 EmiratesIDexpiryDate = outputDateFormat.format(inputDate);
				 }catch(Exception e)
				 {
					 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format");
				 }
				 
				 if(!"".equalsIgnoreCase(EmiratedIDcardNumber) && !"".equalsIgnoreCase(EmiratesIDexpiryDate))
				 {
					 append += "\n\t<DocDet>"+
							 "\n\t\t<DocType>EMID</DocType>"+
							 /*"\n\t\t<DocInd>R</DocInd>"+*/
							 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
							 "\n\t\t<DocNo>"+EmiratedIDcardNumber+"</DocNo>"+
							 "\n\t\t<DocExpDate>"+EmiratesIDexpiryDate+"</DocExpDate>"+
							 "\n\t</DocDet>";
				 }
				 else
				 {
					 append += "\n\t<DocDet>"+
							 "\n\t\t<DocType>EMID</DocType>"+
							 "\n\t\t<DocInd>D</DocInd>"+
							 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
							 "\n\t\t<DocNo>-1.0</DocNo>"+
							 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
							 "\n\t</DocDet>";
				 }
				 
				 PassportNumber=RetailXMLParser.getValueOf("PassportNumber");
				 KYC_CBSLog.KYC_CBSLogger.debug("PassportNumber: "+PassportNumber);
				 
				 PassportExpiryDate=RetailXMLParser.getValueOf("PassportExpiryDate");
				 KYC_CBSLog.KYC_CBSLogger.debug("PassportExpiryDate: "+PassportExpiryDate);

				 try{
					 Date inputDate = inputDateFormat.parse(PassportExpiryDate);
					 PassportExpiryDate = outputDateFormat.format(inputDate);
				 }catch(Exception e)
				 {
					 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format");
				 }
				 
				 if(!"".equalsIgnoreCase(PassportNumber) && !"".equalsIgnoreCase(PassportExpiryDate)){
				 
				 PassportIssueDate = RetailXMLParser.getValueOf("PassportIssueDate");
				 KYC_CBSLog.KYC_CBSLogger.debug("PassportIssueDate: "+PassportIssueDate);

				 try{
					 Date inputDate = inputDateFormat.parse(PassportIssueDate);
					 PassportIssueDate = outputDateFormat.format(inputDate);
				 }catch(Exception e)
				 {
					 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format");
				 }
				 
				 append += "\n\t<DocDet>"+
						 "\n\t\t<DocType>PPT</DocType>"+
						/* "\n\t\t<DocInd>R</DocInd>"+*/
						 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
						 "\n\t\t<DocNo>"+PassportNumber+"</DocNo>";
				 if(!"".equalsIgnoreCase(PassportIssueDate))
				 {
				   append += "\n\t\t<DocIssDate>"+PassportIssueDate+"</DocIssDate>";
				 }
				 append +="\n\t\t<DocExpDate>"+PassportExpiryDate+"</DocExpDate>"+
						 "\n\t</DocDet>";
						
				 }
				 else
				 {
					 append += "\n\t<DocDet>"+
							 "\n\t\t<DocType>PPT</DocType>"+
							 "\n\t\t<DocInd>D</DocInd>"+
							 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
							 "\n\t\t<DocNo>-1.0</DocNo>"+
							 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
							 "\n\t</DocDet>";
				 }
				 
				 String CusNonResidentIndicator =RetailXMLParser.getValueOf("CusNonResidentIndicator");
				 KYC_CBSLog.KYC_CBSLogger.debug("CusNonResidentIndicator: "+CusNonResidentIndicator);
				 
				 if("Y".equalsIgnoreCase(CusNonResidentIndicator) || "Yes".equalsIgnoreCase(CusNonResidentIndicator))
				 {
					 append += "\n\t<DocDet>"+
							 "\n\t\t<DocType>VISA</DocType>"+
							 "\n\t\t<DocInd>D</DocInd>"+
							 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
							 "\n\t\t<DocNo>-1.0</DocNo>"+
							 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
							 "\n\t</DocDet>";
				 }
				 
				 append +=  "\n\t<RtlAddnlDet>" ;
				 
				 String Title =RetailXMLParser.getValueOf("Title");
				 KYC_CBSLog.KYC_CBSLogger.debug("Title: "+Title);
				 
				 if(!"".equalsIgnoreCase(Title)){
					 if("Mr".equalsIgnoreCase(Title) || "MR.".equalsIgnoreCase(Title) || "MR".equalsIgnoreCase(Title))
						 Title = "MR.";
					 if("Mrs".equalsIgnoreCase(Title) || "MRS.".equalsIgnoreCase(Title) || "MRS".equalsIgnoreCase(Title))
						 Title = "MRS.";
					 if("MISS".equalsIgnoreCase(Title) || "MISS.".equalsIgnoreCase(Title))
						 Title = "MISS";
					 if("Ms".equalsIgnoreCase(Title) || "MS.".equalsIgnoreCase(Title) || "MS".equalsIgnoreCase(Title))
						 Title = "MS.";
					 
					 append +="\n\t\t<Title>"+Title+"</Title>";
				 }
				 
				 String FirstName =RetailXMLParser.getValueOf("FirstName");
				 KYC_CBSLog.KYC_CBSLogger.debug("FirstName: "+FirstName);
				 
				 if(!"".equalsIgnoreCase(FirstName)){
					 append +="\n\t\t<FirstName>"+FirstName+"</FirstName>";
				 }
				 
				 String MidName =RetailXMLParser.getValueOf("MiddleName");
				 KYC_CBSLog.KYC_CBSLogger.debug("MidName: "+MidName);
				 
				 if("".equalsIgnoreCase(MidName)) MidName = "KYCDELETE";
				 /*{*/
					 append +="\n\t\t<MidName>"+MidName+"</MidName>";
				/* }*/
				 
				 String LastName =RetailXMLParser.getValueOf("LastName");
				 KYC_CBSLog.KYC_CBSLogger.debug("LastName: "+LastName);
				 
				 if(!"".equalsIgnoreCase(LastName)){
					 append +="\n\t\t<LastName>"+LastName+"</LastName>";
				 }
				 
				 String OfficeEmployerCode =RetailXMLParser.getValueOf("OfficeEmployerCode");
				 KYC_CBSLog.KYC_CBSLogger.debug("OfficeEmployerCode: "+OfficeEmployerCode);
				 
				 if("".equalsIgnoreCase(OfficeEmployerCode)) OfficeEmployerCode = "KYCDELETE";
				 /*{*/
					 append +="\n\t\t<EmployerCode>"+OfficeEmployerCode+"</EmployerCode>";
				 /*}*/
				 
				 String EmploymentType =RetailXMLParser.getValueOf("OfficeEmploymentType");
				 KYC_CBSLog.KYC_CBSLogger.debug("EmploymentType: "+EmploymentType);
				 
				 if(!"".equalsIgnoreCase(EmploymentType)){
					 append +="\n\t\t<EmploymentType>"+EmploymentType+"</EmploymentType>";
				 }
				 
				 String Occupation =RetailXMLParser.getValueOf("OfficeOccupation");
				 KYC_CBSLog.KYC_CBSLogger.debug("Occupation: "+Occupation);
				 
				 if("".equalsIgnoreCase(Occupation)) Occupation = "KYCDELETE";
				 /*{*/
					 append +="\n\t\t<Occupation>"+Occupation+"</Occupation>";
				 /*}*/
				 
				 String MonthlyIncome =RetailXMLParser.getValueOf("MonthlyIncome");
				 KYC_CBSLog.KYC_CBSLogger.debug("MonthlyIncome: "+MonthlyIncome);
				 
				 if("".equalsIgnoreCase(MonthlyIncome)) MonthlyIncome = "-1.00";
				 /*{*/
					 append +="\n\t\t<GrossSalary>"+MonthlyIncome+"</GrossSalary>";
				/* }*/
				 
				 String OtherIncome =RetailXMLParser.getValueOf("OtherIncome");
				 KYC_CBSLog.KYC_CBSLogger.debug("OtherIncome: "+OtherIncome);
				 
				 if("".equalsIgnoreCase(OtherIncome)) OtherIncome = "-1.00";
				 /*{*/
					 append +="\n\t\t<OtherIncome>"+OtherIncome+"</OtherIncome>";
				 /*}*/
				 
				 if(!"".equalsIgnoreCase(CusNonResidentIndicator)){
					 
					 if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
						 CusNonResidentIndicator = "Y";
					 else
						 CusNonResidentIndicator = "N";
					 append +="\n\t\t<NonResidentInd>"+CusNonResidentIndicator+"</NonResidentInd>"+
							  "\n\t\t<ResidentFrom>"+EffectiveFrom+"</ResidentFrom>";
				 }
				 
				 String RiskProfile =RetailXMLParser.getValueOf("RiskProfile");
				 KYC_CBSLog.KYC_CBSLogger.debug("RiskProfile: "+RiskProfile);
				 
				 if(!"".equalsIgnoreCase(RiskProfile)){
					 append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
				 }
			
				 append += "\n\t<FatcaDetails>";
				 String FormObtained =RetailXMLParser.getValueOf("FormObtained");
				 KYC_CBSLog.KYC_CBSLogger.debug("FormObtained: "+FormObtained);
				 
				 String USpassportHolder_GreencardHolder =RetailXMLParser.getValueOf("USpassportHolder_GreencardHolder");
				 KYC_CBSLog.KYC_CBSLogger.debug("USpassportHolder_GreencardHolder: "+USpassportHolder_GreencardHolder);
				 
				 if(!"".equalsIgnoreCase(USpassportHolder_GreencardHolder)){
					 if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W9".equalsIgnoreCase(FormObtained)))
						 USpassportHolder_GreencardHolder = "R";
					 else if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W8".equalsIgnoreCase(FormObtained) || "W8 BEN".equalsIgnoreCase(FormObtained) || "Loss of Nationality Certificate".equalsIgnoreCase(FormObtained) || "LOSS OF NAT CERT".equalsIgnoreCase(FormObtained)))
						 USpassportHolder_GreencardHolder = "N";
					 else
						 USpassportHolder_GreencardHolder = "O";
					 append +="\n\t\t<USRelation>"+USpassportHolder_GreencardHolder+"</USRelation>";
				 }
				 
				 String TIN_Field =RetailXMLParser.getValueOf("TIN_Field");
				 KYC_CBSLog.KYC_CBSLogger.debug("TIN_Field: "+TIN_Field);
				 
				 if("".equalsIgnoreCase(TIN_Field)) TIN_Field = "KYCDELETE";
				 /*{*/
					 append +="\n\t\t<TIN>"+TIN_Field+"</TIN>";
				/*}*/
				 
				 if("".equalsIgnoreCase(FormObtained) || "N/A".equalsIgnoreCase(FormObtained)) FormObtained = "KYCDELETE";
				 /*{*/
					 if("W8 BEN".equalsIgnoreCase(FormObtained) || "W8".equalsIgnoreCase(FormObtained))
						 FormObtained = "W8";
					 else if("Loss of Nationality Certificate".equalsIgnoreCase(FormObtained) || "LOSS OF NAT CERT".equalsIgnoreCase(FormObtained))
						 FormObtained = "LOSS OF NAT CERT";
					 
					 append +="\n\t\t<DocumentsCollected>"+FormObtained+"</DocumentsCollected>";
				 /*}*/
				 
				 String SignedDate =RetailXMLParser.getValueOf("SignedDate");
				 KYC_CBSLog.KYC_CBSLogger.debug("SignedDate: "+SignedDate);
				 
				 if(!"".equalsIgnoreCase(SignedDate)){
					 try{
						 Date inputDate = inputDateFormat.parse(SignedDate);
						 SignedDate = outputDateFormat.format(inputDate);
					 }catch(Exception e)
					 {
						 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format Next Review Date");
					 }
					 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
				 }
				 else
				 {
					 SignedDate = "1900-01-01";
					 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
				 }
				 
				 String ExpiryDate =RetailXMLParser.getValueOf("ExpiryDate");
				 KYC_CBSLog.KYC_CBSLogger.debug("ExpiryDate: "+ExpiryDate);
				 
				 if(!"".equalsIgnoreCase(ExpiryDate)){
					 try{
						 Date inputDate = inputDateFormat.parse(ExpiryDate);
						 ExpiryDate = outputDateFormat.format(inputDate);
					 }catch(Exception e)
					 {
						 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format Next Review Date");
					 }
					 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
				 }
				 else
				 {
					 ExpiryDate = "1900-01-01";
					 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
				 }
				
				 append +="\n\t</FatcaDetails>"+
						 "\n\t<KYCDetails>";
				 
				 String NextReviewDate =RetailXMLParser.getValueOf("NextReviewDate");
				 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
				 
				 if(!"".equalsIgnoreCase(NextReviewDate)){
					 try{
						 Date inputDate = inputDateFormat.parse(NextReviewDate);
						 NextReviewDate = outputDateFormat.format(inputDate);
					 }catch(Exception e)
					 {
						 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format Next Review Date");
					 }
					 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
					 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
				 }
				 else
				 {
					 NextReviewDate = "1900-01-01";
					 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
					 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
				 }
				 
				 String ExpectedMonthlyCreditTurnover =RetailXMLParser.getValueOf("ExpectedMonthlyCreditTurnover");
				 KYC_CBSLog.KYC_CBSLogger.debug("ExpectedMonthlyCreditTurnover: "+ExpectedMonthlyCreditTurnover);
				 
				 if("".equalsIgnoreCase(ExpectedMonthlyCreditTurnover)) ExpectedMonthlyCreditTurnover = "-1.00";
				 /*{*/
					 append +="\n\t\t<MthlyCrdtTurnOvrAmt>"+ExpectedMonthlyCreditTurnover+"</MthlyCrdtTurnOvrAmt>";
				 /*}*/
				 
				 String HighestCashCRtransaction =RetailXMLParser.getValueOf("HighestCashCRtransaction");
				 KYC_CBSLog.KYC_CBSLogger.debug("HighestCashCRtransaction: "+HighestCashCRtransaction);
				 
				 if("".equalsIgnoreCase(HighestCashCRtransaction)) HighestCashCRtransaction = "-1.00";
				 /*{*/
					 append +="\n\t\t<ExpdCashCrTransAmt>"+HighestCashCRtransaction+"</ExpdCashCrTransAmt>";
				 /*}*/
				 
				 String HighestNonCashCrTransaction =RetailXMLParser.getValueOf("HighestNonCashCrTransaction");
				 KYC_CBSLog.KYC_CBSLogger.debug("HighestNonCashCrTransaction: "+HighestNonCashCrTransaction);
				 
				 if("".equalsIgnoreCase(HighestNonCashCrTransaction)) HighestNonCashCrTransaction = "-1.00";
				 {
					 append +="\n\t\t<ExpdNCashCrTransAmt>"+HighestNonCashCrTransaction+"</ExpdNCashCrTransAmt>";
				 }
				 
				 String MonthlyCashNoonCRturnover =RetailXMLParser.getValueOf("MonthlyCashNoonCRturnover");
				 KYC_CBSLog.KYC_CBSLogger.debug("MonthlyCashNoonCRturnover: "+MonthlyCashNoonCRturnover);
				 
				 if("".equalsIgnoreCase(MonthlyCashNoonCRturnover)) MonthlyCashNoonCRturnover = "-1.00";
				 /*{*/
					 append +="\n\t\t<MnthNCashCrTurnOvrPer>"+MonthlyCashNoonCRturnover+"</MnthNCashCrTurnOvrPer>";
				 /*}*/
				 
				 String MonthlyCashCRturnover =RetailXMLParser.getValueOf("MonthlyCashCRturnover");
				 KYC_CBSLog.KYC_CBSLogger.debug("MonthlyCashCRturnover: "+MonthlyCashCRturnover);
				 
				 if("".equalsIgnoreCase(MonthlyCashCRturnover)) MonthlyCashCRturnover = "-1.00";
				 {
					 append +="\n\t\t<MnthCashCrTurnOvrPer>"+MonthlyCashCRturnover+"</MnthCashCrTurnOvrPer>";
				 }
				 
				 String PEP =RetailXMLParser.getValueOf("PEP");
				 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
				 
				 if(!"".equalsIgnoreCase(PEP)){
					 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
							PEP = "FPEP";
					 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
						 PEP = "LPEP";
					 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
						 PEP = "NPEP";
					 
					 append +="\n\t\t<PEP>"+PEP+"</PEP>";
				 }
				 
				 append +="\n\t</KYCDetails>"+
						 "\n\t<OECDDet>";
				 
				 String PlaceOfBirth =RetailXMLParser.getValueOf("PlaceOfBirth");
				 KYC_CBSLog.KYC_CBSLogger.debug("PlaceOfBirth: "+PlaceOfBirth);
				 
				 if("".equalsIgnoreCase(PlaceOfBirth)) PlaceOfBirth = "KYCDELETE";
				 /*{*/
					 append +="\n\t\t<CityOfBirth>"+PlaceOfBirth+"</CityOfBirth>";
				 /*}*/
				 
				 String CountryOfBirth =RetailXMLParser.getValueOf("CountryOfBirth");
				 KYC_CBSLog.KYC_CBSLogger.debug("CountryOfBirth: "+CountryOfBirth);
				 
				 if(!"".equalsIgnoreCase(CountryOfBirth)){
					 append +="\n\t\t<CountryOfBirth>"+CountryOfBirth+"</CountryOfBirth>";
				 }
				 
				 append +="\n\t</OECDDet>";
				 
				/* String EmployerName =RetailXMLParser.getValueOf("OfficeEmployerName");
				 KYC_CBSLog.KYC_CBSLogger.debug("EmployerName: "+EmployerName);
				 
				 if(!"".equalsIgnoreCase(EmployerName)){
					 append +="\n\t\t<EmployerNm>"+EmployerName+"</EmployerNm>";
				 }*/
				 
				 String Gender =RetailXMLParser.getValueOf("Gender");
				 KYC_CBSLog.KYC_CBSLogger.debug("Gender: "+Gender);
				 
				 if(!"".equalsIgnoreCase(Gender))
				 {
					 if("Male".equalsIgnoreCase(Gender) || "M".equalsIgnoreCase(Gender))
						 Gender = "M";
					 if("Female".equalsIgnoreCase(Gender) || "F".equalsIgnoreCase(Gender))
						 Gender = "F";
					 else if("Not Available".equalsIgnoreCase(Gender) || "O".equalsIgnoreCase(Gender))
						 Gender = "O";
					 append +="\n\t\t<Gender>"+Gender+"</Gender>";
				 }
				 
				 String Nationality =RetailXMLParser.getValueOf("Nationality");
				 KYC_CBSLog.KYC_CBSLogger.debug("Nationality: "+Nationality);
				 
				 if(!"".equalsIgnoreCase(Nationality)){
					 append +="\n\t\t<Nationality>"+Nationality+"</Nationality>";
				 }
				 
				 String DateOfBirth =RetailXMLParser.getValueOf("DateOfBirth");
				 KYC_CBSLog.KYC_CBSLogger.debug("DateOfBirth: "+DateOfBirth);
				 
				 if(!"".equalsIgnoreCase(DateOfBirth)){
					 try{
						 Date inputDate = inputDateFormat.parse(DateOfBirth);
						 DateOfBirth = outputDateFormat.format(inputDate);
					 }catch(Exception e)
					 {
						 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format");
					 }
					 append +="\n\t\t<DOB>"+DateOfBirth+"</DOB>";
				 }
				 
				 String ResidentCountry =RetailXMLParser.getValueOf("ResidentCountry");
				 KYC_CBSLog.KYC_CBSLogger.debug("ResidentCountry: "+ResidentCountry);
				 
				 if(!"".equalsIgnoreCase(ResidentCountry)){
					 append +="\n\t\t<ResCntry>"+ResidentCountry+"</ResCntry>";
				 }
				 
				 append +="\n\t</RtlAddnlDet>";
				 
				}
				else if("Corporate".equalsIgnoreCase(CorpFlag))
				{
					CorpFlag = "C";
					String TLNumber = "";
					String TLIssueDate = "";
					String TLExpiryDate = "";
					
					
					rpIntegrationresponse = integrateRelatedPartyWI(cabinetName,  sessionID, sJtsIp, sJtsPort, smsPort, wi_name,socket_connection_timeout,integrationWaitTime,strCorporateCIF,socketDetailsMap,strWi_name,activityName);
					
					String query1 = "Select EntityTLNumber,TradeLicenseDate,TradeLicenseExpiryDate,IndustrySegment,"
							+ "IndustrySubSegment,EntityRiskProfile,CompanyPreferredAddress,CompanyofficeShopNo,CompanyEmirateCity,CompanyCountry,"
							+ "CompanyBuilding,CompanyStreet,CompanyLandmark,CompanyPOBox,PreferredAddressFlag,EntityRiskProfile,"
							+ "EntityOrganisedInUSA,CorporateTax,FinancialInstitution,GIIN,NextReviewDate,ExpectedMonthlyCreditTurnover,"
							+ "HighestCashCRtransaction,HighestNonCashCrTransaction,MonthlyCashNoonCRturnover,MonthlyCashCRturnover,PEP,"
							+ "CommercialRegNo,CompanyMobileOffice,CompanyEmailID,AnnualTurnover,AECBBureauReferenceNo,CustomerWebsite,VAT_RegistrationNo"
							+ " FROM RB_KYC_REM_EXTTABLE Where WINAME = '"+wi_name+"'";
	
					String InputXML =CommonMethods.apSelectWithColumnNames(query1, cabinetName, sessionID);
					KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+InputXML);
	
					String OutputXML=KYC_CBS.WFNGExecute(InputXML, sJtsIp, sJtsPort,1);
					KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+OutputXML);
	
					XMLParser XMLParsr= new XMLParser(OutputXML);
				    String MainCode = XMLParsr.getValueOf("MainCode");
				    KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);
	
				    int TotalRecords = Integer.parseInt(XMLParsr.getValueOf("TotalRetrieved"));
				    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+TotalRecords);
				    
				    if (sMainCode.equals("0") && sTotalRecords > 0)
					{
				    	 IndustrySegment = XMLParsr.getValueOf("IndustrySegment");
						 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
						 
						 IndustrySubsegment = XMLParsr.getValueOf("IndustrySubSegment");
						 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
						 
						 if(!("".equalsIgnoreCase(IndustrySegment)) && !("".equalsIgnoreCase(IndustrySubsegment)))
						 	{
							 append += "\n\t<IndustryDet>";
							 if(!"".equalsIgnoreCase(IndustrySegment)) //IndustrySegment = "KYCDELETE";
							 {
								 append +="\n\t\t<IndustrySegment>"+IndustrySegment+"</IndustrySegment>";
							 }
							 if(!"".equalsIgnoreCase(IndustrySubsegment)) //IndustrySubsegment = "KYCDELETE";
							 {
								 append +="\n\t\t<IndustrySubSegment>"+IndustrySubsegment+"</IndustrySubSegment>";
							 }
							 append += "\n\t</IndustryDet>";
						 	}
				    	
						 officeAddress=XMLParsr.getValueOf("CompanyofficeShopNo");
						 KYC_CBSLog.KYC_CBSLogger.debug("CompanyofficeShopNo: "+officeAddress);
						 
						 OfficeCityEmirate=XMLParsr.getValueOf("CompanyEmirateCity");
						 KYC_CBSLog.KYC_CBSLogger.debug("CompanyEmirateCity: "+OfficeCityEmirate);
						 
						 OfficeCountry=XMLParsr.getValueOf("CompanyCountry");
						 KYC_CBSLog.KYC_CBSLogger.debug("CompanyCountry: "+OfficeCountry);
						 
						 String CompanyPreferredAddress = XMLParsr.getValueOf("CompanyPreferredAddress");
						 KYC_CBSLog.KYC_CBSLogger.debug("CompanyPreferredAddress: "+CompanyPreferredAddress);
						 
						 Date todayDate = new Date();
						 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
						 EffectiveFrom = outputDateFormatED.format(todayDate);
						 
						 if(!"".equalsIgnoreCase(officeAddress) && !"".equalsIgnoreCase(OfficeCityEmirate) && !"".equalsIgnoreCase(OfficeCountry) && !"".equalsIgnoreCase(CompanyPreferredAddress))
						 {
							 String OfficeAddress2 = XMLParsr.getValueOf("CompanyBuilding");
							 KYC_CBSLog.KYC_CBSLogger.debug("CompanyBuilding: "+OfficeAddress2);
							 
							 String OfficeAddress3 = XMLParsr.getValueOf("CompanyStreet");
							 KYC_CBSLog.KYC_CBSLogger.debug("CompanyStreet: "+OfficeAddress3);
							 
							 String OfficeAddress4 = XMLParsr.getValueOf("CompanyLandmark");
							 KYC_CBSLog.KYC_CBSLogger.debug("CompanyLandmark: "+OfficeAddress4);
							 
							 String OfficePOBox = XMLParsr.getValueOf("CompanyPOBox");
							 KYC_CBSLog.KYC_CBSLogger.debug("CompanyPOBox: "+OfficePOBox);
							 
							/* String PreferredAddressFlag = XMLParsr.getValueOf("PreferredAddressFlag");
							 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);*/
							 
							 if("Head Office".equalsIgnoreCase(CompanyPreferredAddress))
							 {
								 CompanyPreferredAddress = "Head Office";
							 }
							 else if ("Registered Office".equalsIgnoreCase(CompanyPreferredAddress))
							 {
								 CompanyPreferredAddress = "Registered";
							 }
							 /*else
							 {
								 CompanyPreferredAddress = "OFFICE";
							 }*/
							 
							/* String prefFlag = "";
							 if(CompanyPreferredAddress.equalsIgnoreCase(PreferredAddressFlag))
							 {
								 prefFlag = "Y";
							 }
							 else
							 {
								 prefFlag = "N";
							 }*/
							 
							
						 append += "\n\t<AddrDet>" +
								 "\n\t\t<AddressType>"+CompanyPreferredAddress+"</AddressType>"+
								 "\n\t\t<AddrInd>R</AddrInd>"+
								 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
								 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
								 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
								 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
								 "\n\t\t<AddrPrefFlag>Y</AddrPrefFlag>"+
								 "\n\t\t<AddrLine1>"+officeAddress+"</AddrLine1>";
						 
						 if(!"".equalsIgnoreCase(OfficeAddress2))
							 	append +="\n\t\t<AddrLine2>"+OfficeAddress2+"</AddrLine2>";
						 if(!"".equalsIgnoreCase(OfficeAddress3))
							 	append +="\n\t\t<AddrLine3>"+OfficeAddress3+"</AddrLine3>";
						 if(!"".equalsIgnoreCase(OfficeAddress4))
							 	append +="\n\t\t<AddrLine4>"+OfficeAddress4+"</AddrLine4>";
						 if(!"".equalsIgnoreCase(OfficePOBox))
							 	append +="\n\t\t<POBox>"+OfficePOBox+"</POBox>";
						 
						 append += "\n\t\t<City>"+OfficeCityEmirate+"</City>"+
								 "\n\t\t<CountryCode>"+OfficeCountry+"</CountryCode>"+
								 "\n\t</AddrDet>";
						 }
						/* else
						 {
							 append += "\n\t<AddrDet>" +
									 "\n\t\t<AddressType>OFFICE</AddressType>"+
									 "\n\t\t<AddrInd>D</AddrInd>"+
									 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
									 "\n\t\t<EffectiveTo>1900-01-01</EffectiveTo>"+
									 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
									 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
									 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
									 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
									 "\n\t\t<City>KYCDELETE</City>"+
									 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
									 "\n\t</AddrDet>";
						 }*/
						 
						/* Mobile=XMLParsr.getValueOf("CompanyMobileOffice");
						 KYC_CBSLog.KYC_CBSLogger.debug("Mobile: "+Mobile);
						 
						 if(!"".equalsIgnoreCase(Mobile))
						 {
							 append +="\n\t<PhnDetails>"+
									 "\n\t\t<PhnType>CELLPH1</PhnType>"+
									 "\n\t\t<PhnPrefFlag>N</PhnPrefFlag>"+
									 "\n\t\t<PhnLocalCode>"+Mobile+"</PhnLocalCode>"+
									 "\n\t</PhnDetails>";
						 }
						 
						 EMailID=XMLParsr.getValueOf("CompanyEmailID");
						 KYC_CBSLog.KYC_CBSLogger.debug("EMailID: "+EMailID);
						 
						 if(!"".equalsIgnoreCase(EMailID))
						 {
							 append += "\n\t<EmlDet>"+
									 "\n\t\t<EmlType>HOMEEML</EmlType>"+
									 "\n\t\t<EmlPrefFlag>N</EmlPrefFlag>"+
									 "\n\t\t<Email>"+EMailID+"</Email>"+
									 "\n\t</EmlDet>";
						 }*/
						 
				    	 TLNumber=XMLParsr.getValueOf("EntityTLNumber");
						 KYC_CBSLog.KYC_CBSLogger.debug("TLNumber: "+TLNumber);
						 
						 TLIssueDate=XMLParsr.getValueOf("TradeLicenseDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("TLIssueDate: "+TLIssueDate);
						 if(!"".equalsIgnoreCase(TLIssueDate))
							 TLIssueDate = formatDate(TLIssueDate);
						 
						 TLExpiryDate=XMLParsr.getValueOf("TradeLicenseExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("TLExpiryDate: "+TLExpiryDate);
						 if(!"".equalsIgnoreCase(TLExpiryDate))
							 TLExpiryDate = formatDate(TLExpiryDate);
						 
						 if(!"".equalsIgnoreCase(TLNumber) && !"".equalsIgnoreCase(TLExpiryDate))
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>TDLIC</DocType>"+
									/* "\n\t\t<DocInd>R</DocInd>"+*/
									 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
									 "\n\t\t<DocNo>"+TLNumber+"</DocNo>";
							 
							 if(!"".equalsIgnoreCase(TLIssueDate))
								 append +=	 "\n\t\t<DocIssDate>"+TLIssueDate+"</DocIssDate>";
							 	
							 	 append += "\n\t\t<DocExpDate>"+TLExpiryDate+"</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
						 else
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>TDLIC</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
						 
						 
						 String VAT_RegistrationNo = XMLParsr.getValueOf("VAT_RegistrationNo");
						 KYC_CBSLog.KYC_CBSLogger.debug("VAT Registration No: "+VAT_RegistrationNo);
						 if(!"".equalsIgnoreCase(VAT_RegistrationNo))
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>VRN</DocType>"+
									 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
									 "\n\t\t<DocNo>"+VAT_RegistrationNo+"</DocNo>"+
									 "\n\t</DocDet>";
						 }
						/* else
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>VRN</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }*/
						 
						 String CommercialRegNo =XMLParsr.getValueOf("CommercialRegNo");
						 KYC_CBSLog.KYC_CBSLogger.debug("Commercial Registration No: "+CommercialRegNo);
						 if("".equalsIgnoreCase(CommercialRegNo))
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>CMREG</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
						 append +=  "\n\t<RtlAddnlDet>" ;
					      
					      String Querysupplier = "SELECT Country from NG_KYC_REM_SuppliersName WHERE WINAME = '"+wi_name+"'";
									List<Map<String, String>> DataFromDBsupplier = new ArrayList<Map<String, String>>();
									DataFromDBsupplier = getDataFromDBMap(Querysupplier, cabinetName, sessionID, sJtsIp, sJtsPort);
									KYC_CBSLog.KYC_CBSLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDBsupplier);
									String dealwithCntries = "";
									for (Map<String, String> entry : DataFromDBsupplier) 
									{
										if("".equalsIgnoreCase(dealwithCntries))
											dealwithCntries = entry.get("Country");
										else
											dealwithCntries += "|"+entry.get("Country");
										//<DealWithCntries></DealWithCntries>
									}
						 String Querybuyer = "SELECT Country from NG_KYC_REM_BuyerName WHERE WINAME = '"+wi_name+"'";
									List<Map<String, String>> DataFromDBbuyer = new ArrayList<Map<String, String>>();
									DataFromDBbuyer = getDataFromDBMap(Querybuyer, cabinetName, sessionID, sJtsIp, sJtsPort);
									KYC_CBSLog.KYC_CBSLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDBbuyer);
									for (Map<String, String> entry : DataFromDBbuyer) 
									{
										if("".equalsIgnoreCase(dealwithCntries))
											dealwithCntries = entry.get("Country");
										else
											dealwithCntries += "|"+entry.get("Country");
										//<DealWithCntries></DealWithCntries>
									}		
						if(!"".equalsIgnoreCase(dealwithCntries))
						{
							append +="\n\t\t<DealWithCntries>"+dealwithCntries+"</DealWithCntries>";
						}
					     
						String AnnualTurnover =XMLParsr.getValueOf("AnnualTurnover");
						 KYC_CBSLog.KYC_CBSLogger.debug("AnnualTurnover: "+AnnualTurnover);
						 
						 if(!"".equalsIgnoreCase(AnnualTurnover))
						 {
							 append +="\n\t\t<AvgAnnInc>"+AnnualTurnover+"</AvgAnnInc>";
						 }
						 
						String RiskBureauCdNum =XMLParsr.getValueOf("AECBBureauReferenceNo");
						KYC_CBSLog.KYC_CBSLogger.debug("AECBBureauReferenceNo: "+RiskBureauCdNum);
							 
						if(!"".equalsIgnoreCase(RiskBureauCdNum))
						{
							append +="\n\t\t<RiskBureauCdNum>"+RiskBureauCdNum+"</RiskBureauCdNum>";
						}
						
						String Website =XMLParsr.getValueOf("CustomerWebsite");
						KYC_CBSLog.KYC_CBSLogger.debug("Website: "+Website);
							 
						if(!"".equalsIgnoreCase(Website))
						{
							append +="\n\t\t<Website>"+Website+"</Website>";
						}
						
						 String RiskProfile =XMLParsr.getValueOf("EntityRiskProfile");
						 KYC_CBSLog.KYC_CBSLogger.debug("EntityRiskProfile: "+RiskProfile);
						 
						 if(!"".equalsIgnoreCase(RiskProfile))
						 {
							 append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
						 } 
						 
						 append +=  "\n\t<FatcaDetails>";
						 
						 String USRelation =XMLParsr.getValueOf("EntityOrganisedInUSA");
						 KYC_CBSLog.KYC_CBSLogger.debug("USpassportHolder_GreencardHolder: "+USRelation);
						 
						 if(!"".equalsIgnoreCase(USRelation))
						 {
							 if(("Yes".equalsIgnoreCase(USRelation) || "Y".equalsIgnoreCase(USRelation)))
								 USRelation = "1";
							 else
								 USRelation = "3";
							 append +="\n\t\t<USRelation>"+USRelation+"</USRelation>";
						 }
						 
						/* String TIN_Field =XMLParsr.getValueOf("CorporateTax");
						 KYC_CBSLog.KYC_CBSLogger.debug("TIN_Field: "+TIN_Field);
						 
						 if("".equalsIgnoreCase(TIN_Field)) TIN_Field = "KYCDELETE";
						 {
							 append +="\n\t\t<TIN>"+TIN_Field+"</TIN>";
						 }*/
						 
						 /*String FinancialInstitution =XMLParsr.getValueOf("FinancialInstitution");
						 KYC_CBSLog.KYC_CBSLogger.debug("FinancialInstitution: "+FinancialInstitution);
						 
						 if(!"".equalsIgnoreCase(FinancialInstitution))
						 {
							 append +="\n\t\t<FinancialEntity>"+FinancialInstitution+"</FinancialEntity>";
						 }*/
						 
						 String GIIN =XMLParsr.getValueOf("GIIN");
						 KYC_CBSLog.KYC_CBSLogger.debug("GIIN: "+GIIN);
						 
						 if(!"".equalsIgnoreCase(GIIN))
						 {
							 append +="\n\t\t<GIINNumber>"+GIIN+"</GIINNumber>";
						 }
						 append +=  "\n\t</FatcaDetails>"
								 + "\n\t<KYCDetails>";
						 
						 String NextReviewDate =XMLParsr.getValueOf("NextReviewDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
						 
						 if(!"".equalsIgnoreCase(NextReviewDate)){
							 NextReviewDate = formatDate(NextReviewDate);
							 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
							 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
						 }
						 else
						 {
							 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
							 append +="\n\t\t<KYCReviewdate>1900-01-01</KYCReviewdate>";
						 }
						 
						 String ExpectedMonthlyCreditTurnover =XMLParsr.getValueOf("ExpectedMonthlyCreditTurnover");
						 KYC_CBSLog.KYC_CBSLogger.debug("ExpectedMonthlyCreditTurnover: "+ExpectedMonthlyCreditTurnover);
						 
						 if("".equalsIgnoreCase(ExpectedMonthlyCreditTurnover)) ExpectedMonthlyCreditTurnover = "-1.00";
						 /*{*/
							 append +="\n\t\t<MthlyCrdtTurnOvrAmt>"+ExpectedMonthlyCreditTurnover+"</MthlyCrdtTurnOvrAmt>";
						 /*}*/
						 
						 String HighestCashCRtransaction =XMLParsr.getValueOf("HighestCashCRtransaction");
						 KYC_CBSLog.KYC_CBSLogger.debug("HighestCashCRtransaction: "+HighestCashCRtransaction);
						 
						 if("".equalsIgnoreCase(HighestCashCRtransaction)) HighestCashCRtransaction = "-1.00";
						 /*{*/
							 append +="\n\t\t<ExpdCashCrTransAmt>"+HighestCashCRtransaction+"</ExpdCashCrTransAmt>";
						 /*}*/
						 
						 String HighestNonCashCrTransaction =XMLParsr.getValueOf("HighestNonCashCrTransaction");
						 KYC_CBSLog.KYC_CBSLogger.debug("HighestNonCashCrTransaction: "+HighestNonCashCrTransaction);
						 
						 if("".equalsIgnoreCase(HighestNonCashCrTransaction)) HighestNonCashCrTransaction = "-1.00";
						 /*{*/
							 append +="\n\t\t<ExpdNCashCrTransAmt>"+HighestNonCashCrTransaction+"</ExpdNCashCrTransAmt>";
						 /*}*/
						 
						 String MonthlyCashNoonCRturnover =XMLParsr.getValueOf("MonthlyCashNoonCRturnover");
						 KYC_CBSLog.KYC_CBSLogger.debug("MonthlyCashNoonCRturnover: "+MonthlyCashNoonCRturnover);
						 
						 if("".equalsIgnoreCase(MonthlyCashNoonCRturnover)) MonthlyCashNoonCRturnover = "-1.00";
						 /*{*/
							 append +="\n\t\t<MnthNCashCrTurnOvrPer>"+MonthlyCashNoonCRturnover+"</MnthNCashCrTurnOvrPer>";
						 /*}*/
						 
						 String MonthlyCashCRturnover =XMLParsr.getValueOf("MonthlyCashCRturnover");
						 KYC_CBSLog.KYC_CBSLogger.debug("MonthlyCashCRturnover: "+MonthlyCashCRturnover);
						 
						 if("".equalsIgnoreCase(MonthlyCashCRturnover)) MonthlyCashCRturnover = "-1.00";
						 /*{*/
							 append +="\n\t\t<MnthCashCrTurnOvrPer>"+MonthlyCashCRturnover+"</MnthCashCrTurnOvrPer>";
						 /*}*/
						 
						 String PEP =XMLParsr.getValueOf("PEP");
						 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
						 
						 if(!"".equalsIgnoreCase(PEP)){
							 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
									PEP = "FPEP";
							 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
								 PEP = "LPEP";
							 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
								 PEP = "NPEP";
							 
							 append +="\n\t\t<PEP>"+PEP+"</PEP>";
						 }
						 
						 append +="\n\t</KYCDetails>"
								 +"\n\t</RtlAddnlDet>";
						 
						/* String Query = "Select RCIF,FinacleDetID,RelationshipType,UBO,ShareholdingPer,ResidenceCountry,EntityType,IBenabledFlag from NG_KYC_REM_Shareholder_GRID with (nolock) "
									+"where WINAME = '"+wi_name+"'";
									List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
									DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, sJtsIp, sJtsPort);
									KYC_CBSLog.KYC_CBSLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
									String append1 = "";
									for (Map<String, String> entry : DataFromDB) 
									{
										String RCIF = entry.get("RCIF");
										String FinacleDetID = entry.get("FinacleDetID");
										String RelationshipType = entry.get("RelationshipType");
										String UBO = entry.get("UBO");
										String ShareholdingPer = entry.get("ShareholdingPer");
										String ResCountry = entry.get("ResidenceCountry");
										String entityType = entry.get("EntityType");
										String IBenabledFlag = entry.get("IBenabledFlag");
										
										KYC_CBSLog.KYC_CBSLogger.debug("RCIF FETCHED-->"+RCIF+" FinacleDetID-->"+FinacleDetID+" RelationshipType-->"+RelationshipType+" UBO-->"+UBO+" ShareholdingPer-->"+ShareholdingPer+" ResCountry-->"+ResCountry);
										if(!"".equalsIgnoreCase(RCIF) && !"".equalsIgnoreCase(entityType) && !"".equalsIgnoreCase(RelationshipType) && !"".equalsIgnoreCase(IBenabledFlag))
										{
											append +="\n\t<CorpRelCIFDet>"+
													 "\n\t\t<RCIFID>"+RCIF+"</RCIFID>"+
													 "\n\t\t<EntityType>"+entityType+"</EntityType>"+
													 "\n\t\t<RelationshipType>"+RelationshipType+"</RelationshipType>"+
													 "\n\t\t<IBEnabledFlag>"+IBenabledFlag+"</IBEnabledFlag>"+
													 "\n\t\t<TotalEquityPcnt>"+UBO+"</TotalEquityPcnt>"+
													 "\n\t\t<ShareholdingPcnt>"+ShareholdingPer+"</ShareholdingPcnt>"+
													 "\n\t</CorpRelCIFDet>";		 
										}
										else if ("".equalsIgnoreCase(RCIF) && !"".equalsIgnoreCase(FinacleDetID))
										{
											append1 +="\n\t<CorpRelNonCIFDet>"+
													 "\n\t\t<FinancialDetID>"+FinacleDetID+"</FinancialDetID>";
											if(!"".equalsIgnoreCase(ResCountry))
											{
												append1 +="\n\t\t<CountryOfResidence>"+ResCountry+"</CountryOfResidence>";
											}
											append1 +="\n\t</CorpRelNonCIFDet>";
										}
									}
									append += append1;*/
								}	
						}
				else if("FI".equalsIgnoreCase(CorpFlag))
				{
					CorpFlag = "C";
					String id_No = "";
					String idIssueDate = "";
					String idExpiryDate = "";
					String InstitutionIDType = "";
					
					String query1 = "SELECT InstitutionCountry,OfficeShopNo,Building,Street,Landmark,POBox,CityEmirate,Country,"
							+ "InstitutionIDType,InstitutionLicenseNo,InstitutionLicenseIssueDate,InstitutionLicenseExpiryDate,RiskProfile,"
							+ "LegalStatus,NextKYCReviewDate,CustomerWebsite,PEPStatus,GIINNumber,USRelationFlag,SignedDate,ExpiryDate,"
							+ "IndustrySegment,IndustrySubSegment "
							+ "FROM NG_KYC_REM_FI_TR_TABLE Where WINAME = '"+wi_name+"'";
					
	
					String InputXML =CommonMethods.apSelectWithColumnNames(query1, cabinetName, sessionID);
					KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+InputXML);
	
					String OutputXML=KYC_CBS.WFNGExecute(InputXML, sJtsIp, sJtsPort,1);
					KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+OutputXML);
	
					XMLParser XMLParsr= new XMLParser(OutputXML);
				    String MainCode = XMLParsr.getValueOf("MainCode");
				    KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);
	
				    int TotalRecords = Integer.parseInt(XMLParsr.getValueOf("TotalRetrieved"));
				    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+TotalRecords);
				    
				    if (sMainCode.equals("0") && sTotalRecords > 0)
					{
				    	
				    	 InstitutionCountryFI = XMLParsr.getValueOf("InstitutionCountry");
						 KYC_CBSLog.KYC_CBSLogger.debug("InstitutionCountryFI: "+InstitutionCountryFI);
						 
						 LegalEntityFI = XMLParsr.getValueOf("LegalStatus");
						 KYC_CBSLog.KYC_CBSLogger.debug("LegalEntityFI: "+LegalEntityFI);
						 
				    	 IndustrySegment = XMLParser.getValueOf("IndustrySegment");
						 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
						 
						 IndustrySubsegment = XMLParser.getValueOf("IndustrySubSegment");
						 KYC_CBSLog.KYC_CBSLogger.debug("officeAddress: "+officeAddress);
						 if(!"".equalsIgnoreCase(IndustrySegment) && !"".equalsIgnoreCase(IndustrySubsegment))
						 {
							 append += "\n\t<IndustryDet>";
							 if(!"".equalsIgnoreCase(IndustrySegment)) //IndustrySegment = "KYCDELETE";
								 append +="\n\t\t<IndustrySegment>"+IndustrySegment+"</IndustrySegment>";
							 if(!"".equalsIgnoreCase(IndustrySubsegment)) //IndustrySubsegment = "KYCDELETE";
								 append +="\n\t\t<IndustrySubSegment>"+IndustrySubsegment+"</IndustrySubSegment>";
							 append += "\n\t</IndustryDet>";
						 }
							 
							 officeAddress=XMLParsr.getValueOf("OfficeShopNo");
							 KYC_CBSLog.KYC_CBSLogger.debug("OfficeShopNo: "+officeAddress);
							 
							 OfficeCityEmirate=XMLParsr.getValueOf("CityEmirate");
							 KYC_CBSLog.KYC_CBSLogger.debug("CityEmirate: "+OfficeCityEmirate);
							 
							 OfficeCountry=XMLParsr.getValueOf("Country");
							 KYC_CBSLog.KYC_CBSLogger.debug("Country: "+OfficeCountry);
							 
							 Date todayDate = new Date();
							 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
							 EffectiveFrom = outputDateFormatED.format(todayDate);
							 
							 if(!"".equalsIgnoreCase(officeAddress) && !"".equalsIgnoreCase(OfficeCityEmirate) && !"".equalsIgnoreCase(OfficeCountry))
							 {
								 String OfficeAddress2 = XMLParsr.getValueOf("Building");
								 KYC_CBSLog.KYC_CBSLogger.debug("Building: "+OfficeAddress2);
								 
								 String OfficeAddress3 = XMLParsr.getValueOf("Street");
								 KYC_CBSLog.KYC_CBSLogger.debug("Street: "+OfficeAddress3);
								 
								 String OfficeAddress4 = XMLParsr.getValueOf("Landmark");
								 KYC_CBSLog.KYC_CBSLogger.debug("Landmark: "+OfficeAddress4);
								 
								 String OfficePOBox = XMLParsr.getValueOf("POBox");
								 KYC_CBSLog.KYC_CBSLogger.debug("POBox: "+OfficePOBox);
								 
								 String CompanyPreferredAddress = "Registered";
								 
								 append += "\n\t<AddrDet>" +
										 "\n\t\t<AddressType>"+CompanyPreferredAddress+"</AddressType>"+
										 "\n\t\t<AddrInd>R</AddrInd>"+
										 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
										 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
										 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
										 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
										 "\n\t\t<AddrPrefFlag>Y</AddrPrefFlag>"+
										 "\n\t\t<AddrLine1>"+officeAddress+"</AddrLine1>";
							 
								 if(!"".equalsIgnoreCase(OfficeAddress2))
									 	append +="\n\t\t<AddrLine2>"+OfficeAddress2+"</AddrLine2>";
								 if(!"".equalsIgnoreCase(OfficeAddress3))
									 	append +="\n\t\t<AddrLine3>"+OfficeAddress3+"</AddrLine3>";
								 if(!"".equalsIgnoreCase(OfficeAddress4))
									 	append +="\n\t\t<AddrLine4>"+OfficeAddress4+"</AddrLine4>";
								 if(!"".equalsIgnoreCase(OfficePOBox))
									 	append +="\n\t\t<POBox>"+OfficePOBox+"</POBox>";
								 
								 append += "\n\t\t<City>"+OfficeCityEmirate+"</City>"+
										 "\n\t\t<CountryCode>"+OfficeCountry+"</CountryCode>"+
										 "\n\t</AddrDet>"; 
							 }
							 
							 InstitutionIDType=XMLParsr.getValueOf("InstitutionIDType");
							 KYC_CBSLog.KYC_CBSLogger.debug("InstitutionIDType: "+InstitutionIDType);
							 
							 id_No=XMLParsr.getValueOf("InstitutionLicenseNo");
							 KYC_CBSLog.KYC_CBSLogger.debug("id_No: "+id_No);
							 
							 idIssueDate=XMLParsr.getValueOf("InstitutionLicenseIssueDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("idIssueDate: "+idIssueDate);
							 if(!"".equalsIgnoreCase(idIssueDate))
								 idIssueDate = formatDate(idIssueDate);
							 
							 idExpiryDate=XMLParsr.getValueOf("InstitutionLicenseExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("InstitutionLicenseExpiryDate: "+idExpiryDate);
							 if(!"".equalsIgnoreCase(idExpiryDate))
								 idExpiryDate = formatDate(idExpiryDate);
							 
							 if(!"".equalsIgnoreCase(id_No) && !"".equalsIgnoreCase(idExpiryDate))
							 {
								 if("BKLIC".equalsIgnoreCase(InstitutionIDType)) InstitutionIDType = "TDLIC";
								 append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>"+InstitutionIDType+"</DocType>"+
										/* "\n\t\t<DocInd>R</DocInd>"+*/
										 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
										 "\n\t\t<DocNo>"+id_No+"</DocNo>";
								 
								 if(!"".equalsIgnoreCase(idIssueDate))
									 append +=	 "\n\t\t<DocIssDate>"+idIssueDate+"</DocIssDate>";
								 	
								 	 append += "\n\t\t<DocExpDate>"+idExpiryDate+"</DocExpDate>"+
										 "\n\t</DocDet>";
							 }
							 else
							 {
								 append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>"+InstitutionIDType+"</DocType>"+
										 "\n\t\t<DocInd>D</DocInd>"+
										 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
										 "\n\t\t<DocNo>-1.0</DocNo>"+
										 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
										 "\n\t</DocDet>";
							 }
							 
							 if("AMIRI".equalsIgnoreCase(InstitutionIDType) || "CMREG".equalsIgnoreCase(InstitutionIDType))
							 {
								 if(!"".equalsIgnoreCase(id_No) && !"".equalsIgnoreCase(idExpiryDate))
								 {
									 append += "\n\t<DocDet>"+
											 "\n\t\t<DocType>TDLIC</DocType>"+
											 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
											 "\n\t\t<DocNo>"+id_No+"</DocNo>";
									 if(!"".equalsIgnoreCase(idIssueDate))
										 append +=	 "\n\t\t<DocIssDate>"+idIssueDate+"</DocIssDate>";
									 	
									 	 append += "\n\t\t<DocExpDate>"+idExpiryDate+"</DocExpDate>"+
											 "\n\t</DocDet>";
								 }
							 }
							 
							 append +=  "\n\t<RtlAddnlDet>" ;
							 String Website =XMLParsr.getValueOf("CustomerWebsite");
							 KYC_CBSLog.KYC_CBSLogger.debug("Website: "+Website);
									 
								if(!"".equalsIgnoreCase(Website))
								{
									append +="\n\t\t<Website>"+Website+"</Website>";
								}
								 String RiskProfile =XMLParsr.getValueOf("RiskProfile");
								 KYC_CBSLog.KYC_CBSLogger.debug("RiskProfile: "+RiskProfile);
								 
								 if(!"".equalsIgnoreCase(RiskProfile))
								 {
									 append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
								 } 
								 
								 append +=  "\n\t<FatcaDetails>";
								 
								 String USRelation =XMLParsr.getValueOf("USRelationFlag");
								 KYC_CBSLog.KYC_CBSLogger.debug("USRelation: "+USRelation);
								 
								 if(!"".equalsIgnoreCase(USRelation))
								 {
									 if(("Yes".equalsIgnoreCase(USRelation) || "Y".equalsIgnoreCase(USRelation)))
										 USRelation = "1";
									 else
										 USRelation = "3";
									 append +="\n\t\t<USRelation>"+USRelation+"</USRelation>";
								 }
								 
								 String SignedDate =XMLParsr.getValueOf("SignedDate");
								 KYC_CBSLog.KYC_CBSLogger.debug("SignedDate: "+SignedDate);
								
								 if(!"".equalsIgnoreCase(SignedDate))
								 {
									 SignedDate = formatDate(SignedDate);
									 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
								 }
								 else
								 {
									 SignedDate = "1900-01-01";
									 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
								 }
								 String ExpiryDate =XMLParsr.getValueOf("ExpiryDate");
								 KYC_CBSLog.KYC_CBSLogger.debug("ExpiryDate: "+ExpiryDate);
								 
								 if(!"".equalsIgnoreCase(ExpiryDate))
								 {
									 ExpiryDate = formatDate(ExpiryDate);
									 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
								 }
								 else
								 {
									 ExpiryDate = "1900-01-01";
									 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
								 }
								 
								 String GIIN =XMLParsr.getValueOf("GIINNumber");
								 KYC_CBSLog.KYC_CBSLogger.debug("GIIN: "+GIIN);
								 
								 if(!"".equalsIgnoreCase(GIIN))
								 {
									 append +="\n\t\t<GIINNumber>"+GIIN+"</GIINNumber>";
								 }
								 append +=  "\n\t</FatcaDetails>"
										 + "\n\t<KYCDetails>";
								 
								 String NextReviewDate =XMLParsr.getValueOf("NextKYCReviewDate");
								 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
								 
								 if(!"".equalsIgnoreCase(NextReviewDate)){
									 NextReviewDate = formatDate(NextReviewDate);
									 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
									 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
								 }
								 else
								 {
									 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
									 append +="\n\t\t<KYCReviewdate>1900-01-01</KYCReviewdate>";
								 }
								 
								 String PEP =XMLParsr.getValueOf("PEPStatus");
								 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
								 
								 if(!"".equalsIgnoreCase(PEP)){
									 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
											PEP = "FPEP";
									 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
										 PEP = "LPEP";
									 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
										 PEP = "NPEP";
									 
									 append +="\n\t\t<PEP>"+PEP+"</PEP>";
								 }
								 
								 append +="\n\t</KYCDetails>"
										 +"\n\t</RtlAddnlDet>";
					}	
				}
					/*else if("RelatedParty".equalsIgnoreCase(CorpFlag)){
					CorpFlag = "R";
					String subSegment = "";
					String OwnerPassportNo = "";
					String OwnerPassportIssueDate = "";
					String OwnerPassportExpiryDate = "";
					String OwnerEmiratesID = "";
					String OwnerEmiratesIDExpiryDate = "";
					
					String query2 = "Select " 
							+ "OwnerPassportNo,OwnerPassportIssueDate,OwnerPassportExpiryDate,OwnerEmiratesID,OwnerEmiratesIDExpiryDate"
							+ " FROM RB_KYC_REM_EXTTABLE Where WINAME = '"+wi_name+"'";
					
					String query2 = "Select EXT.OwnerPassportNo,EXT.OwnerPassportIssueDate,EXT.OwnerPassportExpiryDate,EXT.OwnerEmiratesID,EXT.OwnerEmiratesIDExpiryDate,WF.VAR_STR8,"
							+"EXT.OwnerResidentialAddress,EXT.OwnerBuilding,EXT.OwnerStreet,EXT.OwnerLandmark,EXT.OwnerZIPCode,EXT.OwnerPOBox,EXT.OwnerState,OwnerCity,"
							+"EXT.OwnerCountry,EXT.PreferredAddressFlag,OwnerTitle,OwnerName,OwnerConnectedParty,OwnerRiskProfile,FormObtained,USpassportHolder_GreencardHolder,"
							+"TIN_Field,SignedDate,ExpiryDate,NextReviewDate,PEP,OwnerPlaceOfBirth,OwnerCountryOfBirth,OwnerGender,OwnerNationality,OwnerDOB,OwnerResidentCountry,Customer_Subsegment,OwnerPrefAddress "
							+"FROM RB_KYC_REM_EXTTABLE EXT JOIN WFINSTRUMENTTABLE WF ON EXT.WINAME = WF.ProcessInstanceID "
							+"WHERE EXT.WINAME = '"+wi_name+"'";	
					
					String InputXML =CommonMethods.apSelectWithColumnNames(query2, cabinetName, sessionID);
					KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+InputXML);

					String OutputXML=KYC_CBS.WFNGExecute(InputXML, sJtsIp, sJtsPort,1);
					KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+OutputXML);

					XMLParser XMLParsr= new XMLParser(OutputXML);
				    String MainCode = XMLParsr.getValueOf("MainCode");
				    KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);

				    int TotalRecords = Integer.parseInt(XMLParsr.getValueOf("TotalRetrieved"));
				    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+TotalRecords);
				    
				    if (MainCode.equals("0") && sTotalRecords > 0)
					{
				    	 subSegment = XMLParsr.getValueOf("Customer_Subsegment");
						 KYC_CBSLog.KYC_CBSLogger.debug("subSegment: "+subSegment);
					}
				    if(!"SME".equalsIgnoreCase(subSegment) && !"PSL".equalsIgnoreCase(subSegment) && !"CBD".equalsIgnoreCase(subSegment)){
				    	CorpFlag = "R";
				    	
				    	 ResidenceAddress=XMLParsr.getValueOf("OwnerResidentialAddress");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerResidentialAddress: "+ResidenceAddress);
						 
						 ResidenceEmirateCity=XMLParsr.getValueOf("OwnerCity");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCity: "+ResidenceEmirateCity);
						 
						 ResidenceCountry=XMLParsr.getValueOf("OwnerCountry");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCountry: "+ResidenceCountry);
						 
						 String PreferredAddressFlag = XMLParsr.getValueOf("OwnerPrefAddress");
						 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);
						 
						 Date todayDate = new Date();
						 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
						 EffectiveFrom = outputDateFormatED.format(todayDate);
						 
						 if(!"".equalsIgnoreCase(ResidenceAddress) && !"".equalsIgnoreCase(ResidenceEmirateCity) && !"".equalsIgnoreCase(ResidenceCountry) && !"".equalsIgnoreCase(PreferredAddressFlag))
						 {
							 String ResidenceAddress2 = XMLParsr.getValueOf("OwnerBuilding");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerBuilding: "+ResidenceAddress2);
							 
							 String ResidenceAddress3 = XMLParsr.getValueOf("OwnerStreet");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerStreet: "+ResidenceAddress3);
							 
							 String ResidenceAddress4 = XMLParsr.getValueOf("OwnerLandmark");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerLandmark: "+ResidenceAddress4);
							 
							 String ResidenceZIPcode = XMLParsr.getValueOf("OwnerZIPCode");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerZIPCode: "+ResidenceZIPcode);
							 
							 String ResidencePOBox = XMLParsr.getValueOf("OwnerPOBox");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPOBox: "+ResidencePOBox);
							 
							 String ResidenceState = XMLParsr.getValueOf("OwnerState");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerState: "+ResidenceState);
							 
							
							 String prefFlag = "";
							 if("RESIDENCE".equalsIgnoreCase(PreferredAddressFlag))
							 {
								 prefFlag = "Y";
							 }
							 else
							 {
								 prefFlag = "N";
							 }
						 append +="\n\t<AddrDet>" +
								 "\n\t\t\t<AddressType>"+PreferredAddressFlag+"</AddressType>"+
								 "\n\t\t<AddrInd>R</AddrInd>"+
								 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
								 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
								 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
								 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
								 "\n\t\t<AddrPrefFlag>Y</AddrPrefFlag>"+
								 "\n\t\t<AddrLine1>"+ResidenceAddress+"</AddrLine1>";
						 
						 if(!"".equalsIgnoreCase(ResidenceAddress2))
							 	append +="\n\t\t<AddrLine2>"+ResidenceAddress2+"</AddrLine2>";
						 if(!"".equalsIgnoreCase(ResidenceAddress3))
							 	append +="\n\t\t<AddrLine3>"+ResidenceAddress3+"</AddrLine3>";
						 if(!"".equalsIgnoreCase(ResidenceAddress4))
							 	append +="\n\t\t<AddrLine4>"+ResidenceAddress4+"</AddrLine4>";
						 if(!"".equalsIgnoreCase(ResidencePOBox))
							 	append +="\n\t\t<POBox>"+ResidencePOBox+"</POBox>";
						 if(!"".equalsIgnoreCase(ResidenceZIPcode))
							 	append +="\n\t\t<ZipCode>"+ResidenceZIPcode+"</ZipCode>";
						 if(!"".equalsIgnoreCase(ResidenceState))
							 	append +="\n\t\t<State>"+ResidenceState+"</State>";
						 
						 append += "\n\t\t<City>"+ResidenceEmirateCity+"</City>"+
								 "\n\t\t<CountryCode>"+ResidenceCountry+"</CountryCode>"+
								 "\n\t</AddrDet>";
						 }
						 else
						 {
							 append += "\n\t<AddrDet>" +
									 "\n\t\t<AddressType>RESIDENCE</AddressType>"+
									 "\n\t\t<AddrInd>D</AddrInd>"+
									 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
									 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
									 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
									 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
									 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
									 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
									 "\n\t\t<City>KYCDELETE</City>"+
									 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
									 "\n\t</AddrDet>";
						 }
				    	
				    	 OwnerEmiratesID=XMLParsr.getValueOf("OwnerEmiratesID");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesID: "+OwnerEmiratesID);
						 
						 OwnerEmiratesIDExpiryDate=XMLParsr.getValueOf("OwnerEmiratesIDExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesIDExpiryDate: "+OwnerEmiratesIDExpiryDate);
				    	
						 OwnerEmiratesIDExpiryDate = formatDate(OwnerEmiratesIDExpiryDate);
						 
						 OwnerPassportNo=XMLParsr.getValueOf("OwnerPassportNo");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportNo: "+OwnerPassportNo);
						 
						 OwnerPassportIssueDate=XMLParsr.getValueOf("OwnerPassportIssueDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportIssueDate: "+OwnerPassportIssueDate);
						 
						 OwnerPassportIssueDate = formatDate(OwnerPassportIssueDate);
						 
						 OwnerPassportExpiryDate=XMLParsr.getValueOf("OwnerPassportExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportExpiryDate: "+OwnerPassportExpiryDate);
						 
						 OwnerPassportExpiryDate = formatDate(OwnerPassportExpiryDate);
				    	 if(!"".equalsIgnoreCase(OwnerEmiratesID) || !"".equalsIgnoreCase(OwnerEmiratesIDExpiryDate))
				    	 {
						 append += "\n\t\t<DocDet>"+
								 "\n\t\t<DocType>EMID</DocType>"+
								 "\n\t\t<DocInd>R</DocInd>"+
								 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
								 "\n\t\t<DocNo>"+OwnerEmiratesID+"</DocNo>"+
								 "\n\t\t<DocExpDate>"+OwnerEmiratesIDExpiryDate+"</DocExpDate>"+
								 "\n\t\t</DocDet>";
				    	 }
				    	 else
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>EMID</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
						 
				    	if(!"".equalsIgnoreCase(OwnerPassportNo) || !"".equalsIgnoreCase(OwnerPassportExpiryDate))
				    	{
				    		append +="\n\t\t<DocDet>"+
				    				"\n\t\t<DocType>PPT</DocType>"+
				    				"\n\t\t<DocInd>R</DocInd>"+
				    				"\n\t\t<DocIsVerified>Y</DocIsVerified>"+
				    				"\n\t\t<DocNo>"+OwnerPassportNo+"</DocNo>";
				    		if(!"".equalsIgnoreCase(OwnerPassportIssueDate))
				    		{
				    			append +="\n\t\t<DocIssDate>"+OwnerPassportIssueDate+"</DocIssDate>";
				    		}
							append += "\n\t\t<DocExpDate>"+OwnerPassportExpiryDate+"</DocExpDate>"+
									  "\n\t\t</DocDet>";
				    	}
				    	 else
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>PPT</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
						
				    	String CusNonResidentIndicator =XMLParsr.getValueOf("OwnerConnectedParty");
						KYC_CBSLog.KYC_CBSLogger.debug("CusNonResidentIndicator: "+CusNonResidentIndicator);
						
						if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
						{
							append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>VISA</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						}
						
						append += "\n\t<RtlAddnlDet>";
						
						 String Title = XMLParsr.getValueOf("OwnerTitle");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerTitle: "+Title);
						 
						 if(!"".equalsIgnoreCase(Title))
						 {
							 if("Mr".equalsIgnoreCase(Title) || "MR.".equalsIgnoreCase(Title) || "MR".equalsIgnoreCase(Title))
								 Title = "MR.";
							 if("Mrs".equalsIgnoreCase(Title) || "MRS.".equalsIgnoreCase(Title) || "MRS".equalsIgnoreCase(Title))
								 Title = "MRS.";
							 if("MISS".equalsIgnoreCase(Title) || "MISS.".equalsIgnoreCase(Title))
								 Title = "MISS";
							 if("Ms".equalsIgnoreCase(Title) || "MS.".equalsIgnoreCase(Title) || "MS".equalsIgnoreCase(Title))
								 Title = "MS.";
							 
							 append +="\n\t\t<Title>"+Title+"</Title>";
						 }
					   
						 String fullName = XMLParsr.getValueOf("OwnerName");
					     KYC_CBSLog.KYC_CBSLogger.debug("OwnerName: "+fullName);
					     
					     if(!"".equalsIgnoreCase(fullName))
					     {
					    	 String firstName = "";
					    	 String middleName = "";
					    	 String lastName = "";
					    	 String[] name = fullName.split(" ");
					    	 if(name.length == 2)
					    	 {
					    		 firstName = name[0];
					    		 lastName = name[1];
					    		 append +="\n\t\t<FirstName>"+firstName+"</FirstName>"+
					    				  "\n\t\t<LastName>"+lastName+"</LastName>";
					    	 }
					    	 if(name.length == 1)
					    	 {
					    		 firstName = name[0];
					    		 append +="\n\t\t<FirstName>"+firstName+"</FirstName>";
					    	 }
					    	 if(name.length >= 3)
					    	 {
					    		 firstName = name[0];
					    		 middleName = name[1];
					    		 for(int i=2;i<name.length;i++)
					    		 {
					    			 lastName = lastName+" "+name[i];
					    		 }
					    		 append +="\n\t\t<FirstName>"+firstName+"</FirstName>"+
					    				  "\n\t\t<MidName>"+middleName+"</MidName>"+
					    				  "\n\t\t<LastName>"+lastName+"</LastName>";
					    	 }
					    	 append +="\n\t\t<FullName>"+fullName+"</FullName>";
					     }
						 
						 if(!"".equalsIgnoreCase(CusNonResidentIndicator)){
							 
							 if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
								 CusNonResidentIndicator = "Y";
							 else
								 CusNonResidentIndicator = "N";
							 append +="\n\t\t<NonResidentInd>"+CusNonResidentIndicator+"</NonResidentInd>"+
									  "\n\t\t<ResidentFrom>"+EffectiveFrom+"</ResidentFrom>";
						 }
					     
					     String RiskProfile = XMLParsr.getValueOf("OwnerRiskProfile");
					     KYC_CBSLog.KYC_CBSLogger.debug("RiskProfile: "+RiskProfile);
					     
					     if(!"".equalsIgnoreCase(RiskProfile))
					     append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
					     
					     append +="\n\t<FatcaDetails>";
					     
					     String FormObtained =XMLParsr.getValueOf("FormObtained");
						 KYC_CBSLog.KYC_CBSLogger.debug("FormObtained: "+FormObtained);
						 
						 String USpassportHolder_GreencardHolder =XMLParsr.getValueOf("USpassportHolder_GreencardHolder");
						 KYC_CBSLog.KYC_CBSLogger.debug("USpassportHolder_GreencardHolder: "+USpassportHolder_GreencardHolder);
						
						 R - YES - REPORTABLE
						 N - YES - NOT REPORTABLE
						 O - NO
						 C -  RECALCITRANT CUSTOMER
						 if(!"".equalsIgnoreCase(USpassportHolder_GreencardHolder)){
							 if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W9".equalsIgnoreCase(FormObtained)))
								 USpassportHolder_GreencardHolder = "R";
							 else if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W8 BEN".equalsIgnoreCase(FormObtained) || "Loss of Nationality Certificate".equalsIgnoreCase(FormObtained)))
								 USpassportHolder_GreencardHolder = "N";
							 else
								 USpassportHolder_GreencardHolder = "O";
							 append +="\n\t\t<USRelation>"+USpassportHolder_GreencardHolder+"</USRelation>";
						 }
						 
						 String TIN_Field =XMLParsr.getValueOf("TIN_Field");
						 KYC_CBSLog.KYC_CBSLogger.debug("TIN_Field: "+TIN_Field);
						 
						 if("".equalsIgnoreCase(TIN_Field)) TIN_Field = "KYCDELETE";
						 //{
							 append +="\n\t\t<TIN>"+TIN_Field+"</TIN>";
						 //}
						 
						 if("".equalsIgnoreCase(FormObtained)) FormObtained = "KYCDELETE";
						 //{
							 append +="\n\t\t<DocumentsCollected>"+FormObtained+"</DocumentsCollected>";
						 //}
							
						 String SignedDate =XMLParsr.getValueOf("SignedDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("SignedDate: "+SignedDate);
						 
						 if(!"".equalsIgnoreCase(SignedDate))
						 {
							 SignedDate = formatDate(SignedDate);
							 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
						 }
						 else
						 {
							 SignedDate = "1900-01-01";
							 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
						 }
						 
						 String ExpiryDate =XMLParsr.getValueOf("ExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("ExpiryDate: "+ExpiryDate);
						 
						 if(!"".equalsIgnoreCase(ExpiryDate))
						 {
							 ExpiryDate = formatDate(ExpiryDate);
							 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
						 }
						 else
						 {
							 ExpiryDate = "1900-01-01";
							 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
						 }
						 append +="\n\t</FatcaDetails>"+
								 "\n\t<KYCDetails>";
						
						 String NextReviewDate =XMLParsr.getValueOf("NextReviewDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
						 
						 if(!"".equalsIgnoreCase(NextReviewDate))
						 {
							 NextReviewDate = formatDate(NextReviewDate);
							 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
							 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
						 }
						 else
						 {
							 NextReviewDate = "1900-01-01";
							 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
							 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
						 }
						 
						 String PEP =XMLParsr.getValueOf("PEP");
						 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
						 
						 if(!"".equalsIgnoreCase(PEP)){
							 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
									PEP = "FPEP";
							 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
								 PEP = "LPEP";
							 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
								 PEP = "NPEP";
							 
							 append +="\n\t\t<PEP>"+PEP+"</PEP>";
						 }
						 
						 append +="\n\t</KYCDetails>"+
								 "\n\t<OECDDet>";
						 
						 String OwnerPlaceOfBirth = XMLParsr.getValueOf("OwnerPlaceOfBirth");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPlaceOfBirth: "+OwnerPlaceOfBirth);
						 
						 if("".equalsIgnoreCase(OwnerPlaceOfBirth)) OwnerPlaceOfBirth = "KYCDELETE";
						 //{
							 append +="\n\t\t<CityOfBirth>"+OwnerPlaceOfBirth+"</CityOfBirth>";
						 //}
						 
						 String OwnerCountryOfBirth = XMLParsr.getValueOf("OwnerCountryOfBirth");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCountryOfBirth: "+OwnerCountryOfBirth);
						 
						 if(!"".equalsIgnoreCase(OwnerCountryOfBirth)){
							 append +="\n\t\t<CountryOfBirth>"+OwnerCountryOfBirth+"</CountryOfBirth>";
						 }
						 append +="\n\t</OECDDet>";
						 
						 String Gender =XMLParsr.getValueOf("OwnerGender");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerGender: "+Gender);
						 
						 if(!"".equalsIgnoreCase(Gender)){
							 if("Male".equalsIgnoreCase(Gender) || "M".equalsIgnoreCase(Gender))
								 Gender = "M";
							 if("Female".equalsIgnoreCase(Gender) || "F".equalsIgnoreCase(Gender))
								 Gender = "F";
							 else if("NA - Entity".equalsIgnoreCase(Gender) || "O".equalsIgnoreCase(Gender))
								 Gender = "O";
							 append +="\n\t\t<Gender>"+Gender+"</Gender>";
						 }
						 
						 String OwnerNationality = XMLParsr.getValueOf("OwnerNationality");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerNationality: "+OwnerNationality);
						 
						 if(!"".equalsIgnoreCase(OwnerNationality)){
							 append +="\n\t\t<Nationality>"+OwnerNationality+"</Nationality>";
						 }
						 
						 String OwnerDOB = XMLParsr.getValueOf("OwnerDOB");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerDOB: "+OwnerDOB);
						 
						 OwnerDOB = formatDate(OwnerDOB);
						 
						 if(!"".equalsIgnoreCase(OwnerDOB)){
							 append +="\n\t\t<DOB>"+OwnerDOB+"</DOB>";
						 }
						 
						 String ResidentCountry = XMLParsr.getValueOf("OwnerResidentCountry");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerResidentCountry: "+ResidentCountry);
						 
						 if(!"".equalsIgnoreCase(ResidentCountry)){
							 append +="\n\t\t<ResCntry>"+ResidentCountry+"</ResCntry>";
						 }
						 append +="\n\t</RtlAddnlDet>";
				    }
				    else
				    {
				    	CorpFlag = "C";
				    	
				    	 Date todayDate = new Date();
						 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
						 EffectiveFrom = outputDateFormatED.format(todayDate);
				    	
				    	 ResidenceAddress=XMLParsr.getValueOf("OwnerResidentialAddress");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerResidentialAddress: "+ResidenceAddress);
						 
						 ResidenceEmirateCity=XMLParsr.getValueOf("OwnerCity");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCity: "+ResidenceEmirateCity);
						 
						 ResidenceCountry=XMLParsr.getValueOf("OwnerCountry");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCountry: "+ResidenceCountry);
						 
						 String PreferredAddressFlag = XMLParsr.getValueOf("OwnerPrefAddress");
						 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);
						 
						 if(!"".equalsIgnoreCase(ResidenceAddress) && !"".equalsIgnoreCase(ResidenceEmirateCity) && !"".equalsIgnoreCase(ResidenceCountry) && !"".equalsIgnoreCase(PreferredAddressFlag))
						 {
							 String ResidenceAddress2 = XMLParsr.getValueOf("OwnerBuilding");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerBuilding: "+ResidenceAddress2);
							 
							 String ResidenceAddress3 = XMLParsr.getValueOf("OwnerStreet");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerStreet: "+ResidenceAddress3);
							 
							 String ResidenceAddress4 = XMLParsr.getValueOf("OwnerLandmark");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerLandmark: "+ResidenceAddress4);
							 
							 String ResidenceZIPcode = XMLParsr.getValueOf("OwnerZIPCode");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerZIPCode: "+ResidenceZIPcode);
							 
							 String ResidencePOBox = XMLParsr.getValueOf("OwnerPOBox");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPOBox: "+ResidencePOBox);
							 
							 String ResidenceState = XMLParsr.getValueOf("OwnerState");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerState: "+ResidenceState);
							 
							
							 String prefFlag = "";
							 if("RESIDENCE".equalsIgnoreCase(PreferredAddressFlag))
							 {
								 prefFlag = "Y";
							 }
							 else
							 {
								 prefFlag = "N";
							 }
						 append +="\n\t<AddrDet>" +
								 "\n\t\t\t<AddressType>"+PreferredAddressFlag+"</AddressType>"+
								 "\n\t\t<AddrInd>R</AddrInd>"+
								 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
								 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
								 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
								 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
								 "\n\t\t<AddrPrefFlag>Y</AddrPrefFlag>"+
								 "\n\t\t<AddrLine1>"+ResidenceAddress+"</AddrLine1>";
						 
						 if(!"".equalsIgnoreCase(ResidenceAddress2))
							 	append +="\n\t\t<AddrLine2>"+ResidenceAddress2+"</AddrLine2>";
						 if(!"".equalsIgnoreCase(ResidenceAddress3))
							 	append +="\n\t\t<AddrLine3>"+ResidenceAddress3+"</AddrLine3>";
						 if(!"".equalsIgnoreCase(ResidenceAddress4))
							 	append +="\n\t\t<AddrLine4>"+ResidenceAddress4+"</AddrLine4>";
						 if(!"".equalsIgnoreCase(ResidencePOBox))
							 	append +="\n\t\t<POBox>"+ResidencePOBox+"</POBox>";
						 if(!"".equalsIgnoreCase(ResidenceZIPcode))
							 	append +="\n\t\t<ZipCode>"+ResidenceZIPcode+"</ZipCode>";
						 if(!"".equalsIgnoreCase(ResidenceState))
							 	append +="\n\t\t<State>"+ResidenceState+"</State>";
						 
						 append += "\n\t\t<City>"+ResidenceEmirateCity+"</City>"+
								 "\n\t\t<CountryCode>"+ResidenceCountry+"</CountryCode>"+
								 "\n\t</AddrDet>";
						 }
						 else
						 {
							 append += "\n\t<AddrDet>" +
									 "\n\t\t<AddressType>OFFICE</AddressType>"+
									 "\n\t\t<AddrInd>D</AddrInd>"+
									 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
									 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
									 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
									 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
									 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
									 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
									 "\n\t\t<City>KYCDELETE</City>"+
									 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
									 "\n\t</AddrDet>";
						 }
				    	 OwnerEmiratesID=XMLParsr.getValueOf("OwnerEmiratesID");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesID: "+OwnerEmiratesID);
						 
						 OwnerEmiratesIDExpiryDate=XMLParsr.getValueOf("OwnerEmiratesIDExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesIDExpiryDate: "+OwnerEmiratesIDExpiryDate);
				    	
						 OwnerEmiratesIDExpiryDate = formatDate(OwnerEmiratesIDExpiryDate);
						 
						 OwnerPassportNo=XMLParsr.getValueOf("OwnerPassportNo");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportNo: "+OwnerPassportNo);
						 
						 OwnerPassportIssueDate=XMLParsr.getValueOf("OwnerPassportIssueDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportIssueDate: "+OwnerPassportIssueDate);
						 
						 OwnerPassportIssueDate = formatDate(OwnerPassportIssueDate);
						 
						 OwnerPassportExpiryDate=XMLParsr.getValueOf("OwnerPassportExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportExpiryDate: "+OwnerPassportExpiryDate);
						 
						 OwnerPassportExpiryDate = formatDate(OwnerPassportExpiryDate);
				    	
					    if(!"".equalsIgnoreCase(OwnerEmiratesID) || !"".equalsIgnoreCase(OwnerEmiratesIDExpiryDate))
						 append += "\n\t\t<DocDet>"+
								 "\n\t\t<DocType>TDLIC</DocType>"+
								 "\n\t\t<DocInd>R</DocInd>"+
								 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
								 "\n\t\t<DocNo>"+OwnerEmiratesID+"</DocNo>"+
								 "\n\t\t<DocExpDate>"+OwnerEmiratesIDExpiryDate+"</DocExpDate>"+
								 "\n\t\t</DocDet>";
					    else
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>TDLIC</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
				    	if(!"".equalsIgnoreCase(OwnerPassportNo) || !"".equalsIgnoreCase(OwnerPassportExpiryDate))
				    	{
				    		append += "\n\t\t<DocDet>"+
				    				"\n\t\t<DocType>TDLIC</DocType>"+
				    				"\n\t\t<DocInd>R</DocInd>"+
				    				"\n\t\t<DocIsVerified>Y</DocIsVerified>"+
				    				"\n\t\t<DocNo>"+OwnerPassportNo+"</DocNo>";
				    		if(!"".equalsIgnoreCase(OwnerPassportIssueDate))
				    		{
				    			append +="\n\t\t<DocIssDate>"+OwnerPassportIssueDate+"</DocIssDate>";
				    		}
				    	append += "\n\t\t<DocExpDate>"+OwnerPassportExpiryDate+"</DocExpDate>"+
								 "\n\t\t</DocDet>";
				    	}
				    	 else
						 {
							 append += "\n\t<DocDet>"+
									 "\n\t\t<DocType>TDLIC</DocType>"+
									 "\n\t\t<DocInd>D</DocInd>"+
									 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
									 "\n\t\t<DocNo>-1.0</DocNo>"+
									 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
									 "\n\t</DocDet>";
						 }
				    	append += "\n\t<RtlAddnlDet>";
				    	
				    	String Title = XMLParsr.getValueOf("OwnerTitle");
						 KYC_CBSLog.KYC_CBSLogger.debug("OwnerTitle: "+Title);
						 
						 if(!"".equalsIgnoreCase(Title)){
							 if("Mr".equalsIgnoreCase(Title) || "MR.".equalsIgnoreCase(Title) || "MR".equalsIgnoreCase(Title))
								 Title = "MR.";
							 if("Mrs".equalsIgnoreCase(Title) || "MRS.".equalsIgnoreCase(Title) || "MRS".equalsIgnoreCase(Title))
								 Title = "MRS.";
							 if("MISS".equalsIgnoreCase(Title) || "MISS.".equalsIgnoreCase(Title))
								 Title = "MISS";
							 if("Ms".equalsIgnoreCase(Title) || "MS.".equalsIgnoreCase(Title) || "MS".equalsIgnoreCase(Title))
								 Title = "MS.";
							 
							 append +="\n\t\t<Title>"+Title+"</Title>";
						 }
					   
						 String fullName = XMLParsr.getValueOf("OwnerName");
					     KYC_CBSLog.KYC_CBSLogger.debug("OwnerName: "+fullName);
					     
					     if(!"".equalsIgnoreCase(fullName))
					     append +="\n\t\t<FullName>"+fullName+"</FullName>";
					     
					     String CusNonResidentIndicator =XMLParsr.getValueOf("OwnerConnectedParty");
						 KYC_CBSLog.KYC_CBSLogger.debug("CusNonResidentIndicator: "+CusNonResidentIndicator);
						 
						 if(!"".equalsIgnoreCase(CusNonResidentIndicator)){
							 
							 if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
								 CusNonResidentIndicator = "Y";
							 else
								 CusNonResidentIndicator = "N";
							 append +="\n\t\t<NonResidentInd>"+CusNonResidentIndicator+"</NonResidentInd>"+
									  "\n\t\t<ResidentFrom>"+EffectiveFrom+"</ResidentFrom>";
						 }
					     
					     String RiskProfile = XMLParsr.getValueOf("OwnerRiskProfile");
					     KYC_CBSLog.KYC_CBSLogger.debug("RiskProfile: "+RiskProfile);
					     
					     if(!"".equalsIgnoreCase(RiskProfile))
					     append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
					     
					     append +="\n\t<FatcaDetails>";
					     
					     String FormObtained =XMLParsr.getValueOf("FormObtained");
						 KYC_CBSLog.KYC_CBSLogger.debug("FormObtained: "+FormObtained);
						 
						 String USpassportHolder_GreencardHolder =XMLParsr.getValueOf("USpassportHolder_GreencardHolder");
						 KYC_CBSLog.KYC_CBSLogger.debug("USpassportHolder_GreencardHolder: "+USpassportHolder_GreencardHolder);
						 
						 if(!"".equalsIgnoreCase(USpassportHolder_GreencardHolder)){
							 if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W9".equalsIgnoreCase(FormObtained)))
								 USpassportHolder_GreencardHolder = "1";
							 else if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W8 BEN".equalsIgnoreCase(FormObtained) || "W8".equalsIgnoreCase(FormObtained) || "Loss of Nationality Certificate".equalsIgnoreCase(FormObtained) || "LOSS OF NAT CERT".equalsIgnoreCase(FormObtained)))
								 USpassportHolder_GreencardHolder = "2";
							 else
								 USpassportHolder_GreencardHolder = "3";
							 append +="\n\t\t<USRelation>"+USpassportHolder_GreencardHolder+"</USRelation>";
						 }
						 
						 String TIN_Field =XMLParsr.getValueOf("TIN_Field");
						 KYC_CBSLog.KYC_CBSLogger.debug("TIN_Field: "+TIN_Field);
						 
						 if("".equalsIgnoreCase(TIN_Field)) TIN_Field = "KYCDELETE";
						 //{
							 append +="\n\t\t<TIN>"+TIN_Field+"</TIN>";
						 //}
						 
						 if(!"".equalsIgnoreCase(FormObtained)) FormObtained = "KYCDELETE";
						 //{
							 append +="\n\t\t<DocumentsCollected>"+FormObtained+"</DocumentsCollected>";
						 //}
						
						 String SignedDate =XMLParsr.getValueOf("SignedDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("SignedDate: "+SignedDate);
						
						 if(!"".equalsIgnoreCase(SignedDate))
						 {
							 SignedDate = formatDate(SignedDate);
							 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
						 }
						 else
						 {
							 SignedDate = "1900-01-01";
							 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
						 }
						 String ExpiryDate =XMLParsr.getValueOf("ExpiryDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("ExpiryDate: "+ExpiryDate);
						 
						 if(!"".equalsIgnoreCase(ExpiryDate))
						 {
							 ExpiryDate = formatDate(ExpiryDate);
							 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
						 }
						 else
						 {
							 ExpiryDate = "1900-01-01";
							 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
						 }
						 append +="\n\t</FatcaDetails>"+
								 "\n\t<KYCDetails>";
						 
						 String NextReviewDate =XMLParsr.getValueOf("NextReviewDate");
						 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
						 
						 if(!"".equalsIgnoreCase(NextReviewDate))
						 {
							 NextReviewDate = formatDate(NextReviewDate);
							 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
							 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
						 }
						 
						 String PEP =XMLParsr.getValueOf("PEP");
						 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
						 
						 if(!"".equalsIgnoreCase(PEP))
						 {
							 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
								 PEP = "FPEP";
							 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
								 PEP = "LPEP";
							 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
								 PEP = "NPEP";
							 
							 append +="\n\t\t<PEP>"+PEP+"</PEP>";
						 }
						 append +="\n\t</KYCDetails>"+
								 "\n\t</RtlAddnlDet>";
				    }
				}*/
			}

				Date todayDate = new Date();
				SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				EffectiveFrom = outputDateFormat.format(todayDate);
		
				ResponseBean objResponseBean=new ResponseBean();
				String CIFUpdateinputXML = "<EE_EAI_MESSAGE>" +
								"\n\t<EE_EAI_HEADER>"+
								"\n\t\t<MsgFormat>CUSTOMER_UPDATE_REQ</MsgFormat>"+
								"\n\t\t<MsgVersion>001</MsgVersion>"+
								"\n\t\t<RequestorChannelId>BPM</RequestorChannelId>"+
								"\n\t\t<RequestorUserId>RAKUSER</RequestorUserId>" +
								"\n\t\t<RequestorLanguage>E</RequestorLanguage>" +
								"\n\t\t<RequestorSecurityInfo>secure</RequestorSecurityInfo>" +
								"\n\t\t<ReturnCode>911</ReturnCode>" +
								"\n\t\t<ReturnDesc>Issuer Timed Out</ReturnDesc>" +
								"\n\t\t<MessageId>Test_CU_0031</MessageId>" +
								"\n\t\t<Extra1>REQ||SHELL.dfgJOHN</Extra1>" +
								"\n\t\t<Extra2>YYYY-MM-DDThh:mm:ss.mmm+hh:mm</Extra2>" +
								"\n\t</EE_EAI_HEADER>" +
								"\n\t<CustomerDetailsUpdateReq>" +
								"\n\t\t<BankId>RAK</BankId>" + 
								"\n\t\t<CIFId>"+strCorporateCIF+"</CIFId>" +
								"\n\t\t<RetCorpFlag>"+CorpFlag+"</RetCorpFlag>";
								if("C".equalsIgnoreCase(CorpFlag) && "Corporate".equalsIgnoreCase(caseType))
								{
									String EntityCountryOfIncorporation =  XMLParser.getValueOf("EntityCountryOfIncorporation");
									 if(!"".equalsIgnoreCase(EntityCountryOfIncorporation)){
										 CIFUpdateinputXML += "\n\t\t<CountryOfIncorp>"+ EntityCountryOfIncorporation+"</CountryOfIncorp>";
									 }
									 String DateOfBusinessEstablishment =  XMLParser.getValueOf("DateOfBusinessEstablishment");
									 if(!"".equalsIgnoreCase(DateOfBusinessEstablishment)){
										 DateOfBusinessEstablishment = formatDate(DateOfBusinessEstablishment);
										 CIFUpdateinputXML += "\n\t\t<DateOfIncorp>"+DateOfBusinessEstablishment+"</DateOfIncorp>";
									 }
									 String LegalEntity =  XMLParser.getValueOf("LegalEntity");
									 String query2 = "SELECT Code from NG_KYC_REM_LegalEntity_MASTER with (nolock) WHERE Entity = '"+LegalEntity+"'";	
										
										String InputXML =CommonMethods.apSelectWithColumnNames(query2, cabinetName, sessionID);
										KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+InputXML);

										String OutputXML=KYC_CBS.WFNGExecute(InputXML, sJtsIp, sJtsPort,1);
										KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+OutputXML);

										XMLParser XMLParsr= new XMLParser(OutputXML);
									    String MainCode = XMLParsr.getValueOf("MainCode");
									    KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);

									    int TotalRecords = Integer.parseInt(XMLParsr.getValueOf("TotalRetrieved"));
									    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+TotalRecords);
									    
									    if (MainCode.equals("0") && sTotalRecords > 0)
										{
									    	 LegalEntity = XMLParsr.getValueOf("Code");
											 KYC_CBSLog.KYC_CBSLogger.debug("LegalEntity: "+LegalEntity);
										}
									 if(!"".equalsIgnoreCase(LegalEntity))
									 {
										 CIFUpdateinputXML += "\n\t\t<LegalEntityType>"+LegalEntity+"</LegalEntityType>";
									 }	
									 
									 String DNFBPDeclarationStatus =  XMLParser.getValueOf("DNFBP_Status");
									 if(!"".equalsIgnoreCase(DNFBPDeclarationStatus))
									 {
										 if("CONDUCT".equalsIgnoreCase(DNFBPDeclarationStatus) || "Conduct".equalsIgnoreCase(DNFBPDeclarationStatus)) DNFBPDeclarationStatus = "C";
										 else if("DOESNOT CONDUCT".equalsIgnoreCase(DNFBPDeclarationStatus) || "DOES NOT CONDUCT".equalsIgnoreCase(DNFBPDeclarationStatus)) DNFBPDeclarationStatus = "NC"; 
										 else if("NOT APPLICABLE".equalsIgnoreCase(DNFBPDeclarationStatus)) DNFBPDeclarationStatus = "NA";

										 CIFUpdateinputXML += "\n\t\t<DNFBPDeclarationStatus>"+DNFBPDeclarationStatus+"</DNFBPDeclarationStatus>";
									 }
									 
								}
								if("C".equalsIgnoreCase(CorpFlag) && "RelatedParty".equalsIgnoreCase(caseType))
								{
									String OwnerCountryOfIncorporation =  XMLParser.getValueOf("OwnerNationality");
									 if(!"".equalsIgnoreCase(OwnerCountryOfIncorporation)){
										 CIFUpdateinputXML += "\n\t\t<CountryOfIncorp>"+ OwnerCountryOfIncorporation+"</CountryOfIncorp>";
									 }
									 String DateOfBusinessEstablishment =  XMLParser.getValueOf("OwnerDOB");
									 if(!"".equalsIgnoreCase(DateOfBusinessEstablishment)){
										 DateOfBusinessEstablishment = formatDate(DateOfBusinessEstablishment);
										 CIFUpdateinputXML += "\n\t\t<DateOfIncorp>"+DateOfBusinessEstablishment+"</DateOfIncorp>";
									 }
								}
								if("C".equalsIgnoreCase(CorpFlag) && "FI".equalsIgnoreCase(caseType))
								{
									if(!"".equalsIgnoreCase(InstitutionCountryFI))
										 CIFUpdateinputXML += "\n\t\t<CountryOfIncorp>"+ InstitutionCountryFI+"</CountryOfIncorp>";
											
										String query2 = "SELECT Code from NG_KYC_REM_LegalEntity_MASTER with (nolock) WHERE Entity = '"+LegalEntityFI+"'";	
										
										String InputXML =CommonMethods.apSelectWithColumnNames(query2, cabinetName, sessionID);
										KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+InputXML);

										String OutputXML=KYC_CBS.WFNGExecute(InputXML, sJtsIp, sJtsPort,1);
										KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+OutputXML);

										XMLParser XMLParsr= new XMLParser(OutputXML);
									    String MainCode = XMLParsr.getValueOf("MainCode");
									    KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);

									    int TotalRecords = Integer.parseInt(XMLParsr.getValueOf("TotalRetrieved"));
									    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+TotalRecords);
									    
									    if (MainCode.equals("0") && sTotalRecords > 0)
										{
									    	 LegalEntityFI = XMLParsr.getValueOf("Code");
											 KYC_CBSLog.KYC_CBSLogger.debug("LegalEntity: "+LegalEntityFI);
										}
									 if(!"".equalsIgnoreCase(LegalEntityFI))
									 {
										 CIFUpdateinputXML += "\n\t\t<LegalEntityType>"+LegalEntityFI+"</LegalEntityType>";
									 }
								}
								/*if("R".equalsIgnoreCase(CorpFlag))
								{
									 String CustomerClassification =XMLParser.getValueOf("CustomerClassification");
									 KYC_CBSLog.KYC_CBSLogger.debug("CustomerClassification: "+CustomerClassification);
									 
									 if(!"".equalsIgnoreCase(CustomerClassification)){
										 if("ISLAMIC".equalsIgnoreCase(CustomerClassification) || "I".equalsIgnoreCase(CustomerClassification))
											 CustomerClassification = "I";
										 else if("CONVENTIONAL".equalsIgnoreCase(CustomerClassification) || "C".equalsIgnoreCase(CustomerClassification))
											 CustomerClassification = "C";
										 else
											 CustomerClassification = "B";
											 
										 CIFUpdateinputXML +="\n\t\t<CustClassification>"+CustomerClassification+"</CustClassification>";
									 }
								}*/ 
								CIFUpdateinputXML += "\n\t\t<NTBStatus>K</NTBStatus>"
												    +"\n\t\t<ActionRequired>U</ActionRequired>";
						 
					append +="\n\t</CustomerDetailsUpdateReq>" +
							"\n</EE_EAI_MESSAGE>";
				
				CIFUpdateinputXML += append;
				KYC_CBSLog.KYC_CBSLogger.debug("Input XML for KYC CIF Update is "+CIFUpdateinputXML);

				try
				{
					KYC_CBSLog.KYC_CBSLogger.debug("Session Id is "+sessionID);

					socketServerIP=socketDetailsMap.get("SocketServerIP");
					KYC_CBSLog.KYC_CBSLogger.debug("Socket server IP is "+socketServerIP);

					socketServerPort=Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
					KYC_CBSLog.KYC_CBSLogger.debug("Socket server port is "+socketServerPort);

					if(!("".equals(socketServerIP)) && socketServerIP!=null && !(socketServerPort==0))
					{
						socket=new Socket(socketServerIP,socketServerPort);
						socket.setSoTimeout(socket_connection_timeout*1000);
						out = socket.getOutputStream();
						socketInputStream = socket.getInputStream();
						dout = new DataOutputStream(out);
						din = new DataInputStream(socketInputStream);

						KYC_CBSLog.KYC_CBSLogger.debug("Data output stream is "+dout);
						KYC_CBSLog.KYC_CBSLogger.debug("Data input stream is "+din);
						outputResponse="";
						inputRequest=getRequestXML(cabinetName, sessionID, wi_name, activityName, CommonConnection.getUsername(), new StringBuilder(CIFUpdateinputXML));

						KYC_CBSLog.KYC_CBSLogger.debug("Input MQ XML for Customer creation is "+inputRequest);

						if (inputRequest != null && inputRequest.length() > 0)
						{
							int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
							KYC_CBSLog.KYC_CBSLogger.debug("RequestLen: "+inputRequestLen + "");
							inputRequest = inputRequestLen + "##8##;" + inputRequest;
							KYC_CBSLog.KYC_CBSLogger.debug("InputRequest"+"Input Request Bytes : "+ inputRequest.getBytes("UTF-16LE"));
							dout.write(inputRequest.getBytes("UTF-16LE"));dout.flush();
						}
						byte[] readBuffer = new byte[500];
						int num = din.read(readBuffer);

						if (num > 0)
						{

							byte[] arrayBytes = new byte[num];
							System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
							outputResponse = outputResponse+ new String(arrayBytes, "UTF-16LE");
							inputMessageID = outputResponse;
							KYC_CBSLog.KYC_CBSLogger.debug("OutputResponse: "+outputResponse);

							if(!"".equalsIgnoreCase(outputResponse))
								outputResponse = getResponseXML(cabinetName,sJtsIp,sJtsPort,sessionID,
										wi_name,outputResponse,integrationWaitTime );
							if(outputResponse.contains("&lt;"))
							{
								outputResponse=outputResponse.replaceAll("&lt;", "<");
								outputResponse=outputResponse.replaceAll("&gt;", ">");
							}
							KYC_CBSLog.KYC_CBSLogger.debug("OutputResponse: "+outputResponse);
						}
						socket.close();

						outputResponse = outputResponse.replaceAll("</MessageId>","</MessageId>/n<InputMessageId>"+inputMessageID+"</InputMessageId>");
						XMLParser sXMLParser= new XMLParser(outputResponse);
						System.out.println("outputResponse--"+outputResponse);
						String return_code = sXMLParser.getValueOf("ReturnCode");
						String return_desc = sXMLParser.getValueOf("ReturnDesc");
						if (return_desc.trim().equalsIgnoreCase(""))
						{
							return_desc = sXMLParser.getValueOf("Description");
						}
						KYC_CBSLog.KYC_CBSLogger.debug("return_code: "+return_code);
						
						if("0000".equalsIgnoreCase(return_code))
						{
							if ("success".equalsIgnoreCase(rpIntegrationresponse))
							{
								objResponseBean.setCifUpdateReturnCode("Success");
								objResponseBean.setIntegrationDecision("Success");
								objResponseBean.setMWErrorCode(return_code);
								objResponseBean.setMWErrorDesc(return_desc);
								objResponseBean.setNBTLRequestId(sXMLParser.getValueOf("RequestId"));
								objResponseBean.setMessageId(sXMLParser.getValueOf("MessageId"));
							}
							else
							{
								objResponseBean.setCifUpdateReturnCode("Failure");
								objResponseBean.setIntegrationDecision("Failure");
								objResponseBean.setMWErrorCode(return_code);
								objResponseBean.setMWErrorDesc(rpIntegrationresponse);
								objResponseBean.setNBTLRequestId(sXMLParser.getValueOf("MessageId"));
								objResponseBean.setMessageId(sXMLParser.getValueOf("MessageId"));
							}
						}
						else
						{
							if ("success".equalsIgnoreCase(rpIntegrationresponse))
								return_desc = wi_name+"-"+return_desc;
							else
								return_desc = wi_name+"-"+return_desc+"\n"+rpIntegrationresponse;
								objResponseBean.setCifUpdateReturnCode("Failure");
								objResponseBean.setIntegrationDecision("Failure");
								objResponseBean.setMWErrorCode(return_code);
								objResponseBean.setMWErrorDesc(return_desc);
								objResponseBean.setMessageId(sXMLParser.getValueOf("MessageId"));
						}
						KYC_CBSLog.KYC_CBSLogger.debug("Response XML for Cif Update is "+outputResponse);
					}
				}
				catch(Exception e)
				{
					KYC_CBSLog.KYC_CBSLogger.error("The Exception in Cif Update is "+e.getMessage());
					System.out.println("The Exception in Cif Update is "+e.getMessage());
				}
		return objResponseBean;	
	}
		
	private String integrateRelatedPartyWI(String cabinetName, String sessionID, String jtsIP, String jtsPort,
			String smsPort, String wi_name, int socket_connection_timeout, int integrationWaitTime,
			String strCorporateCIF, HashMap<String, String> socketDetailsMap, String strWi_name, String activityName) 
	{
		String status = "success";
		try{
			String Query = "SELECT RP_WI_Number FROM NG_KYC_REM_RP_GRID WHERE WI_Name = '"+wi_name+"'";
					List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
					DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
					KYC_CBSLog.KYC_CBSLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
					
					for (Map<String, String> entry : DataFromDB) 
					{		
						String rpWIName = entry.get("RP_WI_Number");

						String CorpFlag = "R";
						String append = "";
						String subSegment = "";
						String OwnerPassportNo = "";
						String OwnerPassportIssueDate = "";
						String OwnerPassportExpiryDate = "";
						String OwnerEmiratesID = "";
						String OwnerEmiratesIDExpiryDate = "";
						String cifID = "";
						
						/*String query2 = "Select " 
								+ "OwnerPassportNo,OwnerPassportIssueDate,OwnerPassportExpiryDate,OwnerEmiratesID,OwnerEmiratesIDExpiryDate"
								+ " FROM RB_KYC_REM_EXTTABLE Where WINAME = '"+wi_name+"'";*/
						
						String query2 = "Select EXT.CIF_ID,EXT.OwnerPassportNo,EXT.OwnerPassportIssueDate,EXT.OwnerPassportExpiryDate,EXT.OwnerEmiratesID,EXT.OwnerEmiratesIDExpiryDate,WF.VAR_STR8,"
								+"EXT.OwnerResidentialAddress,EXT.OwnerBuilding,EXT.OwnerStreet,EXT.OwnerLandmark,EXT.OwnerZIPCode,EXT.OwnerPOBox,EXT.OwnerState,OwnerCity,"
								+"EXT.OwnerCountry,EXT.PreferredAddressFlag,OwnerTitle,OwnerName,OwnerConnectedParty,OwnerRiskProfile,FormObtained,USpassportHolder_GreencardHolder,"
								+"TIN_Field,SignedDate,ExpiryDate,NextReviewDate,PEP,OwnerPlaceOfBirth,OwnerCountryOfBirth,OwnerGender,OwnerNationality,OwnerDOB,OwnerResidentCountry,Customer_Subsegment,OwnerPrefAddress "
								+"FROM RB_KYC_REM_EXTTABLE EXT JOIN WFINSTRUMENTTABLE WF ON EXT.WINAME = WF.ProcessInstanceID "
								+"WHERE EXT.WINAME = '"+rpWIName+"'";	
						
						String InputXML =CommonMethods.apSelectWithColumnNames(query2, cabinetName, sessionID);
						KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+InputXML);

						String OutputXML=KYC_CBS.WFNGExecute(InputXML, jtsIP, jtsPort,1);
						KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+OutputXML);

						XMLParser XMLParsr= new XMLParser(OutputXML);
					    String MainCode = XMLParsr.getValueOf("MainCode");
					    KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);

					    int TotalRecords = Integer.parseInt(XMLParsr.getValueOf("TotalRetrieved"));
					    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+TotalRecords);
					    
					    if (MainCode.equals("0") && TotalRecords > 0)
						{
					    	 subSegment = XMLParsr.getValueOf("Customer_Subsegment");
							 KYC_CBSLog.KYC_CBSLogger.debug("subSegment: "+subSegment);
							 
							 cifID = XMLParsr.getValueOf("CIF_ID");
							 KYC_CBSLog.KYC_CBSLogger.debug("RP cifID: "+cifID);
						}
					    if(!"SME".equalsIgnoreCase(subSegment) && !"PSL".equalsIgnoreCase(subSegment) && !"CBD".equalsIgnoreCase(subSegment))
					    {
					    	CorpFlag = "R";
					    	
					    	 String ResidenceAddress=XMLParsr.getValueOf("OwnerResidentialAddress");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerResidentialAddress: "+ResidenceAddress);
							 
							 String ResidenceEmirateCity=XMLParsr.getValueOf("OwnerCity");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCity: "+ResidenceEmirateCity);
							 
							 String ResidenceCountry=XMLParsr.getValueOf("OwnerCountry");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCountry: "+ResidenceCountry);
							 
							 String PreferredAddressFlag = XMLParsr.getValueOf("OwnerPrefAddress");
							 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);
							 
							 Date todayDate = new Date();
							 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
							 String EffectiveFrom = outputDateFormatED.format(todayDate);
							 
							 if(!"".equalsIgnoreCase(ResidenceAddress) && !"".equalsIgnoreCase(ResidenceEmirateCity) && !"".equalsIgnoreCase(ResidenceCountry) && !"".equalsIgnoreCase(PreferredAddressFlag))
							 {
								 String ResidenceAddress2 = XMLParsr.getValueOf("OwnerBuilding");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerBuilding: "+ResidenceAddress2);
								 
								 String ResidenceAddress3 = XMLParsr.getValueOf("OwnerStreet");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerStreet: "+ResidenceAddress3);
								 
								 String ResidenceAddress4 = XMLParsr.getValueOf("OwnerLandmark");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerLandmark: "+ResidenceAddress4);
								 
								 String ResidenceZIPcode = XMLParsr.getValueOf("OwnerZIPCode");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerZIPCode: "+ResidenceZIPcode);
								 
								 String ResidencePOBox = XMLParsr.getValueOf("OwnerPOBox");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPOBox: "+ResidencePOBox);
								 
								 String ResidenceState = XMLParsr.getValueOf("OwnerState");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerState: "+ResidenceState);
								 
								
								/* String prefFlag = "";
								 if("RESIDENCE".equalsIgnoreCase(PreferredAddressFlag))
								 {
									 prefFlag = "Y";
								 }
								 else
								 {
									 prefFlag = "N";
								 }*/
							 append +="\n\t<AddrDet>" +
									 "\n\t\t\t<AddressType>"+PreferredAddressFlag+"</AddressType>"+
									 "\n\t\t<AddrInd>R</AddrInd>"+
									 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
									 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
									 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
									 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
									 "\n\t\t<AddrPrefFlag>Y</AddrPrefFlag>"+
									 "\n\t\t<AddrLine1>"+ResidenceAddress+"</AddrLine1>";
							 
							 if(!"".equalsIgnoreCase(ResidenceAddress2))
								 	append +="\n\t\t<AddrLine2>"+ResidenceAddress2+"</AddrLine2>";
							 if(!"".equalsIgnoreCase(ResidenceAddress3))
								 	append +="\n\t\t<AddrLine3>"+ResidenceAddress3+"</AddrLine3>";
							 if(!"".equalsIgnoreCase(ResidenceAddress4))
								 	append +="\n\t\t<AddrLine4>"+ResidenceAddress4+"</AddrLine4>";
							 if(!"".equalsIgnoreCase(ResidencePOBox))
								 	append +="\n\t\t<POBox>"+ResidencePOBox+"</POBox>";
							 if(!"".equalsIgnoreCase(ResidenceZIPcode))
								 	append +="\n\t\t<ZipCode>"+ResidenceZIPcode+"</ZipCode>";
							 if(!"".equalsIgnoreCase(ResidenceState))
								 	append +="\n\t\t<State>"+ResidenceState+"</State>";
							 
							 append += "\n\t\t<City>"+ResidenceEmirateCity+"</City>"+
									 "\n\t\t<CountryCode>"+ResidenceCountry+"</CountryCode>"+
									 "\n\t</AddrDet>";
							 }
							 /*else
							 {
								 append += "\n\t<AddrDet>" +
										 "\n\t\t<AddressType>RESIDENCE</AddressType>"+
										 "\n\t\t<AddrInd>D</AddrInd>"+
										 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
										 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
										 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
										 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
										 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
										 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
										 "\n\t\t<City>KYCDELETE</City>"+
										 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
										 "\n\t</AddrDet>";
							 }*/
					    	
					    	 OwnerEmiratesID=XMLParsr.getValueOf("OwnerEmiratesID");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesID: "+OwnerEmiratesID);
							 
							 OwnerEmiratesIDExpiryDate=XMLParsr.getValueOf("OwnerEmiratesIDExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesIDExpiryDate: "+OwnerEmiratesIDExpiryDate);
					    	
							 OwnerEmiratesIDExpiryDate = formatDate(OwnerEmiratesIDExpiryDate);
							 
							 OwnerPassportNo=XMLParsr.getValueOf("OwnerPassportNo");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportNo: "+OwnerPassportNo);
							 
							 OwnerPassportIssueDate=XMLParsr.getValueOf("OwnerPassportIssueDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportIssueDate: "+OwnerPassportIssueDate);
							 
							 OwnerPassportIssueDate = formatDate(OwnerPassportIssueDate);
							 
							 OwnerPassportExpiryDate=XMLParsr.getValueOf("OwnerPassportExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportExpiryDate: "+OwnerPassportExpiryDate);
							 
							 OwnerPassportExpiryDate = formatDate(OwnerPassportExpiryDate);
					    	 if(!"".equalsIgnoreCase(OwnerEmiratesID) && !"".equalsIgnoreCase(OwnerEmiratesIDExpiryDate))
					    	 {
							 append += "\n\t\t<DocDet>"+
									 "\n\t\t<DocType>EMID</DocType>"+
									 /*"\n\t\t<DocInd>R</DocInd>"+*/
									 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
									 "\n\t\t<DocNo>"+OwnerEmiratesID+"</DocNo>"+
									 "\n\t\t<DocExpDate>"+OwnerEmiratesIDExpiryDate+"</DocExpDate>"+
									 "\n\t\t</DocDet>";
					    	 }
					    	 else
							 {
								 append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>EMID</DocType>"+
										 "\n\t\t<DocInd>D</DocInd>"+
										 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
										 "\n\t\t<DocNo>-1.0</DocNo>"+
										 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
										 "\n\t</DocDet>";
							 }
							 
					    	if(!"".equalsIgnoreCase(OwnerPassportNo) && !"".equalsIgnoreCase(OwnerPassportExpiryDate))
					    	{
					    		append +="\n\t\t<DocDet>"+
					    				"\n\t\t<DocType>PPT</DocType>"+
					    				/*"\n\t\t<DocInd>R</DocInd>"+*/
					    				"\n\t\t<DocIsVerified>Y</DocIsVerified>"+
					    				"\n\t\t<DocNo>"+OwnerPassportNo+"</DocNo>";
					    		if(!"".equalsIgnoreCase(OwnerPassportIssueDate))
					    		{
					    			append +="\n\t\t<DocIssDate>"+OwnerPassportIssueDate+"</DocIssDate>";
					    		}
								append += "\n\t\t<DocExpDate>"+OwnerPassportExpiryDate+"</DocExpDate>"+
										  "\n\t\t</DocDet>";
					    	}
					    	 else
							 {
								 append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>PPT</DocType>"+
										 "\n\t\t<DocInd>D</DocInd>"+
										 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
										 "\n\t\t<DocNo>-1.0</DocNo>"+
										 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
										 "\n\t</DocDet>";
							 }
							
					    	String CusNonResidentIndicator =XMLParsr.getValueOf("OwnerConnectedParty");
							KYC_CBSLog.KYC_CBSLogger.debug("CusNonResidentIndicator: "+CusNonResidentIndicator);
							
							if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
							{
								append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>VISA</DocType>"+
										 "\n\t\t<DocInd>D</DocInd>"+
										 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
										 "\n\t\t<DocNo>-1.0</DocNo>"+
										 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
										 "\n\t</DocDet>";
							}
							
							append += "\n\t<RtlAddnlDet>";
							
							 String Title = XMLParsr.getValueOf("OwnerTitle");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerTitle: "+Title);
							 
							 if(!"".equalsIgnoreCase(Title))
							 {
								 if("Mr".equalsIgnoreCase(Title) || "MR.".equalsIgnoreCase(Title) || "MR".equalsIgnoreCase(Title))
									 Title = "MR.";
								 if("Mrs".equalsIgnoreCase(Title) || "MRS.".equalsIgnoreCase(Title) || "MRS".equalsIgnoreCase(Title))
									 Title = "MRS.";
								 if("MISS".equalsIgnoreCase(Title) || "MISS.".equalsIgnoreCase(Title))
									 Title = "MISS";
								 if("Ms".equalsIgnoreCase(Title) || "MS.".equalsIgnoreCase(Title) || "MS".equalsIgnoreCase(Title))
									 Title = "MS.";
								 
								 append +="\n\t\t<Title>"+Title+"</Title>";
							 }
						   
							 String fullName = XMLParsr.getValueOf("OwnerName");
						     KYC_CBSLog.KYC_CBSLogger.debug("OwnerName: "+fullName);
						     
						     if(!"".equalsIgnoreCase(fullName))
						     {
						    	 String firstName = "";
						    	 String middleName = "";
						    	 String lastName = "";
						    	 String[] name = fullName.split(" ");
						    	 if(name.length == 2)
						    	 {
						    		 firstName = name[0];
						    		 lastName = name[1];
						    		 append +="\n\t\t<FirstName>"+firstName+"</FirstName>"+
						    				  "\n\t\t<LastName>"+lastName+"</LastName>";
						    	 }
						    	 if(name.length == 1)
						    	 {
						    		 firstName = name[0];
						    		 append +="\n\t\t<FirstName>"+firstName+"</FirstName>";
						    	 }
						    	 if(name.length >= 3)
						    	 {
						    		 firstName = name[0];
						    		 middleName = name[1];
						    		 for(int i=2;i<name.length;i++)
						    		 {
						    			 lastName = lastName+" "+name[i];
						    		 }
						    		 append +="\n\t\t<FirstName>"+firstName+"</FirstName>"+
						    				  "\n\t\t<MidName>"+middleName+"</MidName>"+
						    				  "\n\t\t<LastName>"+lastName+"</LastName>";
						    	 }
						    	 append +="\n\t\t<FullName>"+fullName+"</FullName>";
						     }
							 
							 if(!"".equalsIgnoreCase(CusNonResidentIndicator)){
								 
								 if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
									 CusNonResidentIndicator = "Y";
								 else
									 CusNonResidentIndicator = "N";
								 append +="\n\t\t<NonResidentInd>"+CusNonResidentIndicator+"</NonResidentInd>"+
										  "\n\t\t<ResidentFrom>"+EffectiveFrom+"</ResidentFrom>";
							 }
						     
						     String RiskProfile = XMLParsr.getValueOf("OwnerRiskProfile");
						     KYC_CBSLog.KYC_CBSLogger.debug("RiskProfile: "+RiskProfile);
						     
						     if(!"".equalsIgnoreCase(RiskProfile))
						     append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
						     
						     append +="\n\t<FatcaDetails>";
						     
						     String FormObtained =XMLParsr.getValueOf("FormObtained");
							 KYC_CBSLog.KYC_CBSLogger.debug("FormObtained: "+FormObtained);
							 
							 String USpassportHolder_GreencardHolder =XMLParsr.getValueOf("USpassportHolder_GreencardHolder");
							 KYC_CBSLog.KYC_CBSLogger.debug("USpassportHolder_GreencardHolder: "+USpassportHolder_GreencardHolder);
							
							/* R - YES - REPORTABLE
							 N - YES - NOT REPORTABLE
							 O - NO
							 C -  RECALCITRANT CUSTOMER*/
							 if(!"".equalsIgnoreCase(USpassportHolder_GreencardHolder)){
								 if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W9".equalsIgnoreCase(FormObtained)))
									 USpassportHolder_GreencardHolder = "R";
								 else if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W8 BEN".equalsIgnoreCase(FormObtained) || "Loss of Nationality Certificate".equalsIgnoreCase(FormObtained)))
									 USpassportHolder_GreencardHolder = "N";
								 else
									 USpassportHolder_GreencardHolder = "O";
								 append +="\n\t\t<USRelation>"+USpassportHolder_GreencardHolder+"</USRelation>";
							 }
							 
							 String TIN_Field =XMLParsr.getValueOf("TIN_Field");
							 KYC_CBSLog.KYC_CBSLogger.debug("TIN_Field: "+TIN_Field);
							 
							 if("".equalsIgnoreCase(TIN_Field)) TIN_Field = "KYCDELETE";
							 //{
								 append +="\n\t\t<TIN>"+TIN_Field+"</TIN>";
							 //}
							 
							 if("".equalsIgnoreCase(FormObtained)) FormObtained = "KYCDELETE";
							 //{
								 append +="\n\t\t<DocumentsCollected>"+FormObtained+"</DocumentsCollected>";
							 //}
								
							 String SignedDate =XMLParsr.getValueOf("SignedDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("SignedDate: "+SignedDate);
							 
							 if(!"".equalsIgnoreCase(SignedDate))
							 {
								 SignedDate = formatDate(SignedDate);
								 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
							 }
							 else
							 {
								 SignedDate = "1900-01-01";
								 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
							 }
							 
							 String ExpiryDate =XMLParsr.getValueOf("ExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("ExpiryDate: "+ExpiryDate);
							 
							 if(!"".equalsIgnoreCase(ExpiryDate))
							 {
								 ExpiryDate = formatDate(ExpiryDate);
								 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
							 }
							 else
							 {
								 ExpiryDate = "1900-01-01";
								 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
							 }
							 append +="\n\t</FatcaDetails>"+
									 "\n\t<KYCDetails>";
							
							 String NextReviewDate =XMLParsr.getValueOf("NextReviewDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
							 
							 if(!"".equalsIgnoreCase(NextReviewDate))
							 {
								 NextReviewDate = formatDate(NextReviewDate);
								 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
								 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
							 }
							 else
							 {
								 NextReviewDate = "1900-01-01";
								 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
								 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
							 }
							 
							 String PEP =XMLParsr.getValueOf("PEP");
							 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
							 
							 if(!"".equalsIgnoreCase(PEP)){
								 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
										PEP = "FPEP";
								 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
									 PEP = "LPEP";
								 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
									 PEP = "NPEP";
								 
								 append +="\n\t\t<PEP>"+PEP+"</PEP>";
							 }
							 
							 append +="\n\t</KYCDetails>"+
									 "\n\t<OECDDet>";
							 
							 String OwnerPlaceOfBirth = XMLParsr.getValueOf("OwnerPlaceOfBirth");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPlaceOfBirth: "+OwnerPlaceOfBirth);
							 
							 if("".equalsIgnoreCase(OwnerPlaceOfBirth)) OwnerPlaceOfBirth = "KYCDELETE";
							 //{
								 append +="\n\t\t<CityOfBirth>"+OwnerPlaceOfBirth+"</CityOfBirth>";
							 //}
							 
							 String OwnerCountryOfBirth = XMLParsr.getValueOf("OwnerCountryOfBirth");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCountryOfBirth: "+OwnerCountryOfBirth);
							 
							 if(!"".equalsIgnoreCase(OwnerCountryOfBirth)){
								 append +="\n\t\t<CountryOfBirth>"+OwnerCountryOfBirth+"</CountryOfBirth>";
							 }
							 append +="\n\t</OECDDet>";
							 
							 String Gender =XMLParsr.getValueOf("OwnerGender");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerGender: "+Gender);
							 
							 if(!"".equalsIgnoreCase(Gender)){
								 if("Male".equalsIgnoreCase(Gender) || "M".equalsIgnoreCase(Gender))
									 Gender = "M";
								 if("Female".equalsIgnoreCase(Gender) || "F".equalsIgnoreCase(Gender))
									 Gender = "F";
								 else if("NA - Entity".equalsIgnoreCase(Gender) || "O".equalsIgnoreCase(Gender))
									 Gender = "O";
								 append +="\n\t\t<Gender>"+Gender+"</Gender>";
							 }
							 
							 String OwnerNationality = XMLParsr.getValueOf("OwnerNationality");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerNationality: "+OwnerNationality);
							 
							 if(!"".equalsIgnoreCase(OwnerNationality)){
								 append +="\n\t\t<Nationality>"+OwnerNationality+"</Nationality>";
							 }
							 
							 String OwnerDOB = XMLParsr.getValueOf("OwnerDOB");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerDOB: "+OwnerDOB);
							 
							 OwnerDOB = formatDate(OwnerDOB);
							 
							 if(!"".equalsIgnoreCase(OwnerDOB)){
								 append +="\n\t\t<DOB>"+OwnerDOB+"</DOB>";
							 }
							 
							 String ResidentCountry = XMLParsr.getValueOf("OwnerResidentCountry");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerResidentCountry: "+ResidentCountry);
							 
							 if(!"".equalsIgnoreCase(ResidentCountry)){
								 append +="\n\t\t<ResCntry>"+ResidentCountry+"</ResCntry>";
							 }
							 append +="\n\t</RtlAddnlDet>";
					    }
					    else
					    {
					    	CorpFlag = "C";
					    	
					    	 Date todayDate = new Date();
							 SimpleDateFormat outputDateFormatED = new SimpleDateFormat("yyyy-MM-dd");
							 String EffectiveFrom = outputDateFormatED.format(todayDate);
					    	
					    	 String ResidenceAddress=XMLParsr.getValueOf("OwnerResidentialAddress");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerResidentialAddress: "+ResidenceAddress);
							 
							 String ResidenceEmirateCity=XMLParsr.getValueOf("OwnerCity");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCity: "+ResidenceEmirateCity);
							 
							 String ResidenceCountry=XMLParsr.getValueOf("OwnerCountry");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerCountry: "+ResidenceCountry);
							 
							 String PreferredAddressFlag = XMLParsr.getValueOf("OwnerPrefAddress");
							 KYC_CBSLog.KYC_CBSLogger.debug("PreferredAddressFlag: "+PreferredAddressFlag);
							 
							 if(!"".equalsIgnoreCase(ResidenceAddress) && !"".equalsIgnoreCase(ResidenceEmirateCity) && !"".equalsIgnoreCase(ResidenceCountry) && !"".equalsIgnoreCase(PreferredAddressFlag))
							 {
								 String ResidenceAddress2 = XMLParsr.getValueOf("OwnerBuilding");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerBuilding: "+ResidenceAddress2);
								 
								 String ResidenceAddress3 = XMLParsr.getValueOf("OwnerStreet");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerStreet: "+ResidenceAddress3);
								 
								 String ResidenceAddress4 = XMLParsr.getValueOf("OwnerLandmark");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerLandmark: "+ResidenceAddress4);
								 
								 String ResidenceZIPcode = XMLParsr.getValueOf("OwnerZIPCode");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerZIPCode: "+ResidenceZIPcode);
								 
								 String ResidencePOBox = XMLParsr.getValueOf("OwnerPOBox");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPOBox: "+ResidencePOBox);
								 
								 String ResidenceState = XMLParsr.getValueOf("OwnerState");
								 KYC_CBSLog.KYC_CBSLogger.debug("OwnerState: "+ResidenceState);
								 
								
								/* String prefFlag = "";
								 if("RESIDENCE".equalsIgnoreCase(PreferredAddressFlag))
								 {
									 prefFlag = "Y";
								 }
								 else
								 {
									 prefFlag = "N";
								 }*/
							 append +="\n\t<AddrDet>" +
									 "\n\t\t\t<AddressType>"+PreferredAddressFlag+"</AddressType>"+
									 "\n\t\t<AddrInd>R</AddrInd>"+
									 "\n\t\t<EffectiveFrom>"+EffectiveFrom+"</EffectiveFrom>"+
									 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
									 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
									 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
									 "\n\t\t<AddrPrefFlag>Y</AddrPrefFlag>"+
									 "\n\t\t<AddrLine1>"+ResidenceAddress+"</AddrLine1>";
							 
							 if(!"".equalsIgnoreCase(ResidenceAddress2))
								 	append +="\n\t\t<AddrLine2>"+ResidenceAddress2+"</AddrLine2>";
							 if(!"".equalsIgnoreCase(ResidenceAddress3))
								 	append +="\n\t\t<AddrLine3>"+ResidenceAddress3+"</AddrLine3>";
							 if(!"".equalsIgnoreCase(ResidenceAddress4))
								 	append +="\n\t\t<AddrLine4>"+ResidenceAddress4+"</AddrLine4>";
							 if(!"".equalsIgnoreCase(ResidencePOBox))
								 	append +="\n\t\t<POBox>"+ResidencePOBox+"</POBox>";
							 if(!"".equalsIgnoreCase(ResidenceZIPcode))
								 	append +="\n\t\t<ZipCode>"+ResidenceZIPcode+"</ZipCode>";
							 if(!"".equalsIgnoreCase(ResidenceState))
								 	append +="\n\t\t<State>"+ResidenceState+"</State>";
							 
							 append += "\n\t\t<City>"+ResidenceEmirateCity+"</City>"+
									 "\n\t\t<CountryCode>"+ResidenceCountry+"</CountryCode>"+
									 "\n\t</AddrDet>";
							 }
							 /*else
							 {
								 append += "\n\t<AddrDet>" +
										 "\n\t\t<AddressType>OFFICE</AddressType>"+
										 "\n\t\t<AddrInd>D</AddrInd>"+
										 "\n\t\t<EffectiveFrom>1900-01-01</EffectiveFrom>"+
										 "\n\t\t<EffectiveTo>2099-12-31</EffectiveTo>"+
										 "\n\t\t<HoldMailFlag>N</HoldMailFlag>"+
										 "\n\t\t<ReturnFlag>N</ReturnFlag>"+
										 "\n\t\t<AddrPrefFlag>N</AddrPrefFlag>"+
										 "\n\t\t<AddrLine1>KYCDELETE</AddrLine1>"+
										 "\n\t\t<City>KYCDELETE</City>"+
										 "\n\t\t<CountryCode>KYCDELETE</CountryCode>"+
										 "\n\t</AddrDet>";
							 }*/
					    	 OwnerEmiratesID=XMLParsr.getValueOf("OwnerEmiratesID");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesID: "+OwnerEmiratesID);
							 
							 OwnerEmiratesIDExpiryDate=XMLParsr.getValueOf("OwnerEmiratesIDExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerEmiratesIDExpiryDate: "+OwnerEmiratesIDExpiryDate);
					    	
							 OwnerEmiratesIDExpiryDate = formatDate(OwnerEmiratesIDExpiryDate);
							 
							 OwnerPassportNo=XMLParsr.getValueOf("OwnerPassportNo");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportNo: "+OwnerPassportNo);
							 
							 OwnerPassportIssueDate=XMLParsr.getValueOf("OwnerPassportIssueDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportIssueDate: "+OwnerPassportIssueDate);
							 
							 OwnerPassportIssueDate = formatDate(OwnerPassportIssueDate);
							 
							 OwnerPassportExpiryDate=XMLParsr.getValueOf("OwnerPassportExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerPassportExpiryDate: "+OwnerPassportExpiryDate);
							 
							 OwnerPassportExpiryDate = formatDate(OwnerPassportExpiryDate);
					    	
						   /* if(!"".equalsIgnoreCase(OwnerEmiratesID) || !"".equalsIgnoreCase(OwnerEmiratesIDExpiryDate))
							 append += "\n\t\t<DocDet>"+
									 "\n\t\t<DocType>TDLIC</DocType>"+
									 "\n\t\t<DocInd>R</DocInd>"+
									 "\n\t\t<DocIsVerified>Y</DocIsVerified>"+
									 "\n\t\t<DocNo>"+OwnerEmiratesID+"</DocNo>"+
									 "\n\t\t<DocExpDate>"+OwnerEmiratesIDExpiryDate+"</DocExpDate>"+
									 "\n\t\t</DocDet>";
						    else
							 {
								 append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>TDLIC</DocType>"+
										 "\n\t\t<DocInd>D</DocInd>"+
										 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
										 "\n\t\t<DocNo>-1.0</DocNo>"+
										 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
										 "\n\t</DocDet>";
							 }*/
					    	if(!"".equalsIgnoreCase(OwnerPassportNo) && !"".equalsIgnoreCase(OwnerPassportExpiryDate))
					    	{
					    		append += "\n\t\t<DocDet>"+
					    				"\n\t\t<DocType>TDLIC</DocType>"+
					    				/*"\n\t\t<DocInd>R</DocInd>"+*/
					    				"\n\t\t<DocIsVerified>Y</DocIsVerified>"+
					    				"\n\t\t<DocNo>"+OwnerPassportNo+"</DocNo>";
					    		if(!"".equalsIgnoreCase(OwnerPassportIssueDate))
					    		{
					    			append +="\n\t\t<DocIssDate>"+OwnerPassportIssueDate+"</DocIssDate>";
					    		}
					    	append += "\n\t\t<DocExpDate>"+OwnerPassportExpiryDate+"</DocExpDate>"+
									 "\n\t\t</DocDet>";
					    	}
					    	 else
							 {
								 append += "\n\t<DocDet>"+
										 "\n\t\t<DocType>TDLIC</DocType>"+
										 "\n\t\t<DocInd>D</DocInd>"+
										 "\n\t\t<DocIsVerified>N</DocIsVerified>"+
										 "\n\t\t<DocNo>-1.0</DocNo>"+
										 "\n\t\t<DocExpDate>1900-01-01</DocExpDate>"+
										 "\n\t</DocDet>";
							 }
					    	append += "\n\t<RtlAddnlDet>";
					    	
					    	String Title = XMLParsr.getValueOf("OwnerTitle");
							 KYC_CBSLog.KYC_CBSLogger.debug("OwnerTitle: "+Title);
							 
							 if(!"".equalsIgnoreCase(Title)){
								 if("Mr".equalsIgnoreCase(Title) || "MR.".equalsIgnoreCase(Title) || "MR".equalsIgnoreCase(Title))
									 Title = "MR.";
								 if("Mrs".equalsIgnoreCase(Title) || "MRS.".equalsIgnoreCase(Title) || "MRS".equalsIgnoreCase(Title))
									 Title = "MRS.";
								 if("MISS".equalsIgnoreCase(Title) || "MISS.".equalsIgnoreCase(Title))
									 Title = "MISS";
								 if("Ms".equalsIgnoreCase(Title) || "MS.".equalsIgnoreCase(Title) || "MS".equalsIgnoreCase(Title))
									 Title = "MS.";
								 
								 append +="\n\t\t<Title>"+Title+"</Title>";
							 }
						   
							 String fullName = XMLParsr.getValueOf("OwnerName");
						     KYC_CBSLog.KYC_CBSLogger.debug("OwnerName: "+fullName);
						     
						     if(!"".equalsIgnoreCase(fullName))
						     append +="\n\t\t<FullName>"+fullName+"</FullName>";
						     
						     String CusNonResidentIndicator =XMLParsr.getValueOf("OwnerConnectedParty");
							 KYC_CBSLog.KYC_CBSLogger.debug("CusNonResidentIndicator: "+CusNonResidentIndicator);
							 
							 if(!"".equalsIgnoreCase(CusNonResidentIndicator)){
								 
								 if("Yes".equalsIgnoreCase(CusNonResidentIndicator) || "Y".equalsIgnoreCase(CusNonResidentIndicator))
									 CusNonResidentIndicator = "Y";
								 else
									 CusNonResidentIndicator = "N";
								 append +="\n\t\t<NonResidentInd>"+CusNonResidentIndicator+"</NonResidentInd>"+
										  "\n\t\t<ResidentFrom>"+EffectiveFrom+"</ResidentFrom>";
							 }
						     
						     String RiskProfile = XMLParsr.getValueOf("OwnerRiskProfile");
						     KYC_CBSLog.KYC_CBSLogger.debug("RiskProfile: "+RiskProfile);
						     
						     if(!"".equalsIgnoreCase(RiskProfile))
						     append +="\n\t\t<RiskProfile>"+RiskProfile+"</RiskProfile>";
						     
						     append +="\n\t<FatcaDetails>";
						     
						     String FormObtained =XMLParsr.getValueOf("FormObtained");
							 KYC_CBSLog.KYC_CBSLogger.debug("FormObtained: "+FormObtained);
							 
							 String USpassportHolder_GreencardHolder =XMLParsr.getValueOf("USpassportHolder_GreencardHolder");
							 KYC_CBSLog.KYC_CBSLogger.debug("USpassportHolder_GreencardHolder: "+USpassportHolder_GreencardHolder);
							 
							 if(!"".equalsIgnoreCase(USpassportHolder_GreencardHolder)){
								 if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W9".equalsIgnoreCase(FormObtained)))
									 USpassportHolder_GreencardHolder = "1";
								 else if(("Yes".equalsIgnoreCase(USpassportHolder_GreencardHolder) || "Y".equalsIgnoreCase(USpassportHolder_GreencardHolder)) && ("W8 BEN".equalsIgnoreCase(FormObtained) || "W8".equalsIgnoreCase(FormObtained) || "Loss of Nationality Certificate".equalsIgnoreCase(FormObtained) || "LOSS OF NAT CERT".equalsIgnoreCase(FormObtained)))
									 USpassportHolder_GreencardHolder = "2";
								 else
									 USpassportHolder_GreencardHolder = "3";
								 append +="\n\t\t<USRelation>"+USpassportHolder_GreencardHolder+"</USRelation>";
							 }
							 
							 String TIN_Field =XMLParsr.getValueOf("TIN_Field");
							 KYC_CBSLog.KYC_CBSLogger.debug("TIN_Field: "+TIN_Field);
							 
							 if("".equalsIgnoreCase(TIN_Field)) TIN_Field = "KYCDELETE";
							 //{
								 append +="\n\t\t<TIN>"+TIN_Field+"</TIN>";
							 //}
							 
							 if(!"".equalsIgnoreCase(FormObtained)) FormObtained = "KYCDELETE";
							 //{
								 append +="\n\t\t<DocumentsCollected>"+FormObtained+"</DocumentsCollected>";
							 //}
							
							 String SignedDate =XMLParsr.getValueOf("SignedDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("SignedDate: "+SignedDate);
							
							 if(!"".equalsIgnoreCase(SignedDate))
							 {
								 SignedDate = formatDate(SignedDate);
								 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
							 }
							 else
							 {
								 SignedDate = "1900-01-01";
								 append +="\n\t\t<SignedDate>"+SignedDate+"</SignedDate>";
							 }
							 String ExpiryDate =XMLParsr.getValueOf("ExpiryDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("ExpiryDate: "+ExpiryDate);
							 
							 if(!"".equalsIgnoreCase(ExpiryDate))
							 {
								 ExpiryDate = formatDate(ExpiryDate);
								 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
							 }
							 else
							 {
								 ExpiryDate = "1900-01-01";
								 append +="\n\t\t<SignedExpiryDate>"+ExpiryDate+"</SignedExpiryDate>";
							 }
							 append +="\n\t</FatcaDetails>"+
									 "\n\t<KYCDetails>";
							 
							 String NextReviewDate =XMLParsr.getValueOf("NextReviewDate");
							 KYC_CBSLog.KYC_CBSLogger.debug("NextReviewDate: "+NextReviewDate);
							 
							 if(!"".equalsIgnoreCase(NextReviewDate))
							 {
								 NextReviewDate = formatDate(NextReviewDate);
								 append +="\n\t\t<KYCHeld>Y</KYCHeld>";
								 append +="\n\t\t<KYCReviewdate>"+NextReviewDate+"</KYCReviewdate>";
							 }
							 
							 String PEP =XMLParsr.getValueOf("PEP");
							 KYC_CBSLog.KYC_CBSLogger.debug("PEP: "+PEP);
							 
							 if(!"".equalsIgnoreCase(PEP))
							 {
								 if("FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP))
									 PEP = "FPEP";
								 else if("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP))
									 PEP = "LPEP";
								 else if("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP))
									 PEP = "NPEP";
								 
								 append +="\n\t\t<PEP>"+PEP+"</PEP>";
							 }
							 append +="\n\t</KYCDetails>"+
									 "\n\t</RtlAddnlDet>";
					    }
					    
					    Date todayDate = new Date();
						SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
						String EffectiveFrom = outputDateFormat.format(todayDate);
				
						ResponseBean objResponseBean=new ResponseBean();
						String CIFUpdateinputXML = "<EE_EAI_MESSAGE>" +
										"\n\t<EE_EAI_HEADER>"+
										"\n\t\t<MsgFormat>CUSTOMER_UPDATE_REQ</MsgFormat>"+
										"\n\t\t<MsgVersion>001</MsgVersion>"+
										"\n\t\t<RequestorChannelId>BPM</RequestorChannelId>"+
										"\n\t\t<RequestorUserId>RAKUSER</RequestorUserId>" +
										"\n\t\t<RequestorLanguage>E</RequestorLanguage>" +
										"\n\t\t<RequestorSecurityInfo>secure</RequestorSecurityInfo>" +
										"\n\t\t<ReturnCode>911</ReturnCode>" +
										"\n\t\t<ReturnDesc>Issuer Timed Out</ReturnDesc>" +
										"\n\t\t<MessageId>Test_CU_0031</MessageId>" +
										"\n\t\t<Extra1>REQ||SHELL.dfgJOHN</Extra1>" +
										"\n\t\t<Extra2>YYYY-MM-DDThh:mm:ss.mmm+hh:mm</Extra2>" +
										"\n\t</EE_EAI_HEADER>" +
										"\n\t<CustomerDetailsUpdateReq>" +
										"\n\t\t<BankId>RAK</BankId>" + 
										"\n\t\t<CIFId>"+cifID+"</CIFId>" +
										"\n\t\t<RetCorpFlag>"+CorpFlag+"</RetCorpFlag>";
						if("C".equalsIgnoreCase(CorpFlag))
						{
							String OwnerCountryOfIncorporation =  XMLParsr.getValueOf("OwnerNationality");
							 if(!"".equalsIgnoreCase(OwnerCountryOfIncorporation)){
								 CIFUpdateinputXML += "\n\t\t<CountryOfIncorp>"+ OwnerCountryOfIncorporation+"</CountryOfIncorp>";
							 }
							 String DateOfBusinessEstablishment =  XMLParsr.getValueOf("OwnerDOB");
							 if(!"".equalsIgnoreCase(DateOfBusinessEstablishment)){
								 DateOfBusinessEstablishment = formatDate(DateOfBusinessEstablishment);
								 CIFUpdateinputXML += "\n\t\t<DateOfIncorp>"+DateOfBusinessEstablishment+"</DateOfIncorp>";
							 }
						}
										
						CIFUpdateinputXML += "\n\t\t<NTBStatus>K</NTBStatus>"
								  +"\n\t\t<ActionRequired>U</ActionRequired>";
					 
				append +="\n\t</CustomerDetailsUpdateReq>" +
						"\n</EE_EAI_MESSAGE>";
			
				CIFUpdateinputXML += append;
				KYC_CBSLog.KYC_CBSLogger.debug("Input XML for KYC CIF Update is "+CIFUpdateinputXML);

				KYC_CBSLog.KYC_CBSLogger.debug("Session Id is "+sessionID);

				socketServerIP=socketDetailsMap.get("SocketServerIP");
				KYC_CBSLog.KYC_CBSLogger.debug("Socket server IP is "+socketServerIP);

				socketServerPort=Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
				KYC_CBSLog.KYC_CBSLogger.debug("Socket server port is "+socketServerPort);

				if(!("".equals(socketServerIP)) && socketServerIP!=null && !(socketServerPort==0))
				{
					socket=new Socket(socketServerIP,socketServerPort);
					socket.setSoTimeout(socket_connection_timeout*1000);
					out = socket.getOutputStream();
					socketInputStream = socket.getInputStream();
					dout = new DataOutputStream(out);
					din = new DataInputStream(socketInputStream);

					KYC_CBSLog.KYC_CBSLogger.debug("Data output stream is "+dout);
					KYC_CBSLog.KYC_CBSLogger.debug("Data input stream is "+din);
					outputResponse="";
					inputRequest=getRequestXML(cabinetName, sessionID, rpWIName, activityName, CommonConnection.getUsername(), new StringBuilder(CIFUpdateinputXML));

					KYC_CBSLog.KYC_CBSLogger.debug("Input MQ XML for Customer creation is "+inputRequest);

					if (inputRequest != null && inputRequest.length() > 0)
					{
						int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
						KYC_CBSLog.KYC_CBSLogger.debug("RequestLen: "+inputRequestLen + "");
						inputRequest = inputRequestLen + "##8##;" + inputRequest;
						KYC_CBSLog.KYC_CBSLogger.debug("InputRequest"+"Input Request Bytes : "+ inputRequest.getBytes("UTF-16LE"));
						dout.write(inputRequest.getBytes("UTF-16LE"));dout.flush();
					}
					byte[] readBuffer = new byte[500];
					int num = din.read(readBuffer);

					if (num > 0)
					{

						byte[] arrayBytes = new byte[num];
						System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
						outputResponse = outputResponse+ new String(arrayBytes, "UTF-16LE");
						inputMessageID = outputResponse;
						KYC_CBSLog.KYC_CBSLogger.debug("OutputResponse: "+outputResponse);

						if(!"".equalsIgnoreCase(outputResponse))
							outputResponse = getResponseXML(cabinetName,jtsIP,jtsPort,sessionID,
									rpWIName,outputResponse,integrationWaitTime );
						if(outputResponse.contains("&lt;"))
						{
							outputResponse=outputResponse.replaceAll("&lt;", "<");
							outputResponse=outputResponse.replaceAll("&gt;", ">");
						}
						KYC_CBSLog.KYC_CBSLogger.debug("OutputResponse: "+outputResponse);
					}
					socket.close();

					outputResponse = outputResponse.replaceAll("</MessageId>","</MessageId>/n<InputMessageId>"+inputMessageID+"</InputMessageId>");
					XMLParser sXMLParser= new XMLParser(outputResponse);
					System.out.println("outputResponse--"+outputResponse);
					String return_code = sXMLParser.getValueOf("ReturnCode");
					String return_desc = sXMLParser.getValueOf("ReturnDesc");
					if (return_desc.trim().equalsIgnoreCase(""))
					{
						return_desc = sXMLParser.getValueOf("Description");
					}
					KYC_CBSLog.KYC_CBSLogger.debug("return_code: "+return_code);
					
					if("0000".equalsIgnoreCase(return_code))
					{
						KYC_CBSLog.KYC_CBSLogger.debug("Related Party integrated successfully - "+rpWIName);
					}
					else
					{
						if("success".equalsIgnoreCase(status))
							status = rpWIName+"-"+return_desc;
						else if(!"success".equalsIgnoreCase(status))
							status += "\n"+rpWIName+"-"+return_desc;
					}
					KYC_CBSLog.KYC_CBSLogger.debug("Response XML for Cif Update is "+outputResponse);
				}
		     }
	    }
		catch(Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.error("The Exception in integrating related party is "+e.getMessage());
		}
		return status;
	}

	private String getRequestXML(String cabinetName, String sessionID,
			String wi_name, String ws_name, String userName, StringBuilder final_XML)
	{
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>"+XMLLOG_HISTORY_TABLE+"</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(final_XML);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		KYC_CBSLog.KYC_CBSLogger.debug("GetRequestXML: "+ strBuff.toString());
		return strBuff.toString();
	}
	

	private String getResponseXML(String cabinetName,String sJtsIp,String iJtsPort, String
			sessionID, String wi_name,String message_ID, int integrationWaitTime)
	{

		String outputResponseXML="";
		try
		{
			String QueryString = "select OUTPUT_XML from "+XMLLOG_HISTORY_TABLE+" with (nolock) where " +
					"MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+wi_name+"'";

			String responseInputXML =CommonMethods.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
			KYC_CBSLog.KYC_CBSLogger.debug("Response APSelect InputXML: "+responseInputXML);

			int Loop_count=0;
			do
			{
				String responseOutputXML=KYC_CBS.WFNGExecute(responseInputXML,sJtsIp,iJtsPort,1);
				KYC_CBSLog.KYC_CBSLogger.debug("Response APSelect OutputXML: "+responseOutputXML);

			    XMLParser xmlParserSocketDetails= new XMLParser(responseOutputXML);
			    String responseMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			    KYC_CBSLog.KYC_CBSLogger.debug("ResponseMainCode: "+responseMainCode);

			    int responseTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			    KYC_CBSLog.KYC_CBSLogger.debug("ResponseTotalRecords: "+responseTotalRecords);
			    if (responseMainCode.equals("0") && responseTotalRecords > 0)
				{
					String responseXMLData=xmlParserSocketDetails.getNextValueOf("Record");
					responseXMLData =responseXMLData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

	        		XMLParser xmlParserResponseXMLData = new XMLParser(responseXMLData);

	        		outputResponseXML=xmlParserResponseXMLData.getValueOf("OUTPUT_XML");
	        		KYC_CBSLog.KYC_CBSLogger.debug("OutputResponseXML: "+outputResponseXML);

	        		if("".equalsIgnoreCase(outputResponseXML)){
	        			outputResponseXML="Error";
	    			}
	        		break;
				}
			    Loop_count++;
			    Thread.sleep(1000);
			}
			while(Loop_count<integrationWaitTime);

		}
		catch(Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.error("Exception occurred in outputResponseXML" + e.getMessage());
			KYC_CBSLog.KYC_CBSLogger.error("Exception occurred in outputResponseXML" + e.getStackTrace());
			outputResponseXML="Error";
		}
		return outputResponseXML;
	}

	public String formatDate(String inDate) {
		 SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		 SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		 try{
			 Date inputDate = inputDateFormat.parse(inDate);
			 inDate = outputDateFormat.format(inputDate);
		 }catch(Exception e)
		 {
			 KYC_CBSLog.KYC_CBSLogger.debug("Exception in converting date format");
		 }
		return inDate;
  }
	
	private static List<Map<String, String>> getDataFromDBMap(String query, String cabinetName, String sessionID,
			String jtsIP, String jtsPort) {
		List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
		try {
			KYC_CBSLog.KYC_CBSLogger.debug("Inside function getDataFromDB");
			KYC_CBSLog.KYC_CBSLogger.debug("getDataFromDB query is: " + query);
			String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			OutXml = OutXml.replaceAll("&", "#andsymb#");
			Document recordDoc1 = MapXML.getDocument(OutXml);
			NodeList records1 = recordDoc1.getElementsByTagName("Record");
			if (records1.getLength() > 0) {
				for (int i = 0; i < records1.getLength(); i++) {
					Node n = records1.item(i);
					Map<String, String> t = new HashMap<String, String>();
					if (n.hasChildNodes()) {
						NodeList child = n.getChildNodes();
						for (int j = 0; j < child.getLength(); j++) {
							Node n1 = child.item(j);
							String column = n1.getNodeName();
							String value = n1.getTextContent().replaceAll("#andsymb#", "&");
							if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
								//CustOutreachLog.KYCcustOutreachLogger.debug("getDataFromDBMap Setting value of " + column + " as " + value);
								t.put(column, value);
							} else {
								//CustOutreachLog.KYCcustOutreachLogger.debug("getDataFromDBMap Setting value of " + column + " as blank");
								t.put(column, "");
							}
						}
					}
					temp.add(t);
				}
			}

		} catch (Exception e) {
			KYC_CBSLog.KYC_CBSLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return temp;
	}
	
	
}
