/*
---------------------------------------------------------------------------------------------------------
                  NEWGEN SOFTWARE TECHNOLOGIES LIMITED

Group                   : Application - Projects
Project/Product			: RAK BPM
Application				: RAK BPM Utility
Module					: DAC CBS
File Name				: DACCBS.java
Author 					: Sivakumar P
Date (DD/MM/YYYY)		: 26/07/2019

---------------------------------------------------------------------------------------------------------
                 	CHANGE HISTORY
---------------------------------------------------------------------------------------------------------

Problem No/CR No        Change Date           Changed By             Change Description
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
*/


package com.newgen.KYC.CBS;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.newgen.KYC.CustOutreach.CustOutreachLog;
import com.newgen.KYC.CustOutreach.MapXML;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class KYC_CBS implements Runnable
{
	private String NBTL_WIHISTORY="USR_0_NBTL_WIHISTORY";
	
	private static NGEjbClient ngEjbClientKYC_CBS;
	static Map<String, String> KYC_CBSConfigParamMap= new HashMap<String, String>();
	private String KYC_EXTTABLE = "RB_KYC_REM_EXTTABLE";
	private final String ws_name="System_Integration";
	private String entryDateTime="";
	private String strIntegrationErrCode="";
	private String strIntegrationErrRemarks="";
	private String attributesTag = "";
	private String getWorkItemInputXML = "";
	private String getWorkItemOutputXml = "";
	private XMLParser xmlParserGetWorkItem = new XMLParser();
	private String getWorkItemMainCode = "";
	private String emailBody = "";
	private String mailFrom = "";
	private String mailSubject = "";
	private String activityName = "";
	KYC_CBSIntegration objKYC_CBSIntegration=new KYC_CBSIntegration();
	public void run()
	{
		String sessionID = "";
		String cabinetName = "";
		String jtsIP = "";
		String jtsPort = "";
		String smsPort = "";
		String queueID = "";
		int integrationWaitTime=0;
		int sleepIntervalInMin=0;

		try
		{
			KYC_CBSLog.setLogger();
			ngEjbClientKYC_CBS = NGEjbClient.getSharedInstance();

			KYC_CBSLog.KYC_CBSLogger.debug("Connecting to Cabinet.");

			int configReadStatus = readConfig();

			KYC_CBSLog.KYC_CBSLogger.debug("configReadStatus "+configReadStatus);
			if(configReadStatus !=0)
			{
				KYC_CBSLog.KYC_CBSLogger.error("Could not Read Config Properties [NBTL CBS]");
				return;
			}

			cabinetName = CommonConnection.getCabinetName();
			KYC_CBSLog.KYC_CBSLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			KYC_CBSLog.KYC_CBSLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			KYC_CBSLog.KYC_CBSLogger.debug("JTSPORT: " + jtsPort);
			
			smsPort = CommonConnection.getsSMSPort();
			KYC_CBSLog.KYC_CBSLogger.debug("SMSPort: " + smsPort);
			

			queueID = KYC_CBSConfigParamMap.get("queueID");
			KYC_CBSLog.KYC_CBSLogger.debug("QueueID: " + queueID);

			integrationWaitTime=Integer.parseInt(KYC_CBSConfigParamMap.get("INTEGRATION_WAIT_TIME"));
			KYC_CBSLog.KYC_CBSLogger.debug("IntegrationWaitTime: "+integrationWaitTime);

			sleepIntervalInMin=Integer.parseInt(KYC_CBSConfigParamMap.get("SleepIntervalInMin"));
			KYC_CBSLog.KYC_CBSLogger.debug("SleepIntervalInMin: "+sleepIntervalInMin);
			
			sessionID = CommonConnection.getSessionID(KYC_CBSLog.KYC_CBSLogger, false);
			if(sessionID.trim().equalsIgnoreCase(""))
			{
				KYC_CBSLog.KYC_CBSLogger.debug("Could Not Connect to Server!");
			}
			else
			{
				HashMap<String, String> socketDetailsMap= socketConnectionDetails(cabinetName, jtsIP, jtsPort,
						sessionID);
				while (true)
				{
					sessionID = CommonConnection.getSessionID(KYC_CBSLog.KYC_CBSLogger, false);
					KYC_CBSLog.setLogger();
					KYC_CBSLog.KYC_CBSLogger.debug("KYC CBS....");
					startKYC_CBSUtility(cabinetName,jtsIP,jtsPort,smsPort,queueID,sleepIntervalInMin,integrationWaitTime,sessionID,socketDetailsMap,"","","");
					Thread.sleep(sleepIntervalInMin*60*1000);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			KYC_CBSLog.KYC_CBSLogger.error("Exception Occurred in KYC CBS : "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			KYC_CBSLog.KYC_CBSLogger.error("Exception Occurred in KYC CBS : "+result);
		}
	}
	
	
	private int readConfig()
	{
		Properties p = null;
		try {

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "ConfigFiles"+ File.separator+ "KYC_CBS_Config.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements())
			{
			    String name = (String) names.nextElement();
			    KYC_CBSConfigParamMap.put(name, p.getProperty(name));
			}
		}
		catch (Exception e)
		{

			return -1 ;
		}
		return 0;
	}
	
	
	
	private void startKYC_CBSUtility(String cabinetName,String jtsIP,String jtsPort, String smsPort, String queueId,int sleepIntervalTime,int integrationWaitTime,String sessionID,HashMap<String, String> socketDetailsMap, String lastProcessInstance, String lastWorkitemID, String lastValue)
	{
		try
		{
			sessionID  = CommonConnection.getSessionID(KYC_CBSLog.KYC_CBSLogger, false);

			if(sessionID==null || sessionID.equalsIgnoreCase("") || sessionID.equalsIgnoreCase("null"))
			{
				KYC_CBSLog.KYC_CBSLogger.error("Could Not Get Session ID "+sessionID);
				return;
			}

			KYC_CBSLog.KYC_CBSLogger.debug("Fetching all Workitems at system Integration queue");
			System.out.println("Fetching all WIs at system Integration");

			String fetchWorkitemListInputXML=fetchWIInput_XML(cabinetName, sessionID, queueId, lastProcessInstance, lastWorkitemID, lastValue);
			KYC_CBSLog.KYC_CBSLogger.debug("Input XML for fetch WIs "+fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML=WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);
			KYC_CBSLog.KYC_CBSLogger.debug("Fetch WIs output XML is "+fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			KYC_CBSLog.KYC_CBSLogger.debug("Fetch WIs list main code is "+fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));

			KYC_CBSLog.KYC_CBSLogger.debug("No of records retreived in fetchWI "+fetchWorkitemListCount);

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0)
			{
				for(int i=0; i<fetchWorkitemListCount; i++)
				{
					String fetchWorkItemlistData=xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData =fetchWorkItemlistData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

					KYC_CBSLog.KYC_CBSLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: "+fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);


					String processInstanceID=xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					KYC_CBSLog.KYC_CBSLogger.debug("Current ProcessInstanceID: "+processInstanceID);

					KYC_CBSLog.KYC_CBSLogger.debug("Processing Workitem: "+processInstanceID);
					System.out.println("\nProcessing Workitem: "+processInstanceID);

					String WorkItemID=xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					KYC_CBSLog.KYC_CBSLogger.debug("Current WorkItemID: "+WorkItemID);
					
					activityName=xmlParserfetchWorkItemData.getValueOf("ActivityName");
					KYC_CBSLog.KYC_CBSLogger.debug("Current ActivityName: "+activityName);

					entryDateTime=xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					KYC_CBSLog.KYC_CBSLogger.debug("Current EntryDateTime: "+entryDateTime);
					if(i==99){
						lastProcessInstance = processInstanceID;
						lastWorkitemID = WorkItemID;
					}
					
					String QueryString="SELECT WINAME,CIF_ID,FirstName,LastName,Nationality,CIFPersona,CusType,ProductCurrency,NextReviewDate,CaseType"
							+ " FROM "+KYC_EXTTABLE+" with (nolock) where WINAME='"+processInstanceID+"'";

					String sInputXML =CommonMethods.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
					KYC_CBSLog.KYC_CBSLogger.debug("Input XML for Apselect from External Table "+sInputXML);

					String sOutputXML=KYC_CBS.WFNGExecute(sInputXML, jtsIP, jtsPort,1);
					KYC_CBSLog.KYC_CBSLogger.debug("Output XML for external Table select "+sOutputXML);

					XMLParser sXMLParser= new XMLParser(sOutputXML);
				    String sMainCode = sXMLParser.getValueOf("MainCode");
				    KYC_CBSLog.KYC_CBSLogger.debug("SMainCode: "+sMainCode);

				    int sTotalRecords = Integer.parseInt(sXMLParser.getValueOf("TotalRetrieved"));
				    KYC_CBSLog.KYC_CBSLogger.debug("STotalRecords: "+sTotalRecords);

					if (sMainCode.equals("0") && sTotalRecords > 0)
					{
						KYC_CBSLog.KYC_CBSLogger.debug("Inside If block");
						CustomerBean objCustBean=new CustomerBean();
						
						String caseType=sXMLParser.getValueOf("CaseType");
						if(!"RelatedParty".equalsIgnoreCase(caseType))
						{
						String strWi_name=sXMLParser.getValueOf("WINAME");
						objCustBean.setWiName(strWi_name);
						KYC_CBSLog.KYC_CBSLogger.debug("strWi_name "+strWi_name);
						
						
						String CIF_ID=sXMLParser.getValueOf("CIF_ID");
						objCustBean.setCorporateCIF(CIF_ID);
						KYC_CBSLog.KYC_CBSLogger.debug("CIF_ID "+CIF_ID);
						
						
						String FirstName=sXMLParser.getValueOf("FirstName");
						objCustBean.setToBeTLNo(FirstName);
						KYC_CBSLog.KYC_CBSLogger.debug("FirstName "+FirstName);
						
						String LastName=sXMLParser.getValueOf("LastName");
						objCustBean.setCorporateCIF(LastName);
						KYC_CBSLog.KYC_CBSLogger.debug("LastName "+LastName);
						
						String Nationality=sXMLParser.getValueOf("Nationality");
						objCustBean.setEmail(Nationality);
						KYC_CBSLog.KYC_CBSLogger.debug("Nationality "+Nationality);
						
						String CIFPersona=sXMLParser.getValueOf("CIFPersona");
						objCustBean.setMemoPadText(CIFPersona);
						KYC_CBSLog.KYC_CBSLogger.debug("CIFPersona "+CIFPersona);
						
						String CusType=sXMLParser.getValueOf("CusType");
						objCustBean.setRequestType(CusType);
						KYC_CBSLog.KYC_CBSLogger.debug("CusType "+CusType);
						
							ResponseBean objResponseBean=objKYC_CBSIntegration.KYC_CBS_CifUpdateIntegration(cabinetName,  sessionID, jtsIP, jtsPort, smsPort, processInstanceID,sleepIntervalTime,integrationWaitTime,CIF_ID,socketDetailsMap,strWi_name,activityName);
							KYC_CBSLog.KYC_CBSLogger.error("objResponseBean.getCifUpdateReturnCode() "+objResponseBean.getCifUpdateReturnCode());
							String messageID = objResponseBean.getMessageId();
							KYC_CBSLog.KYC_CBSLogger.debug("messageID = "+messageID);	
							if("Success".equals(objResponseBean.getCifUpdateReturnCode()))
								{
									strIntegrationErrCode="Success";
									strIntegrationErrRemarks="Cif Update Successfull";
									
								}	
								else
								{
									strIntegrationErrCode="Failure";
									//strIntegrationErrRemarks="Error in Cif Update";
									String Rermarks = objResponseBean.getMWErrorDesc();
									strIntegrationErrRemarks=Rermarks;
									
								}
								KYC_CBSLog.KYC_CBSLogger.debug("objResponseBean.getIntegrationDecision() "+objResponseBean.getIntegrationDecision());
								KYC_CBSLog.KYC_CBSLogger.debug("strIntegrationErrCode "+strIntegrationErrCode);
								
								attributesTag="<DECISION>"+strIntegrationErrCode+"</DECISION>"
										+ "<REMARKS>"+strIntegrationErrRemarks+"</REMARKS>";
								
								removeDocs(cabinetName, jtsIP, jtsPort, smsPort,sessionID,processInstanceID);
			
								DoneWI(cabinetName, jtsIP, jtsPort, smsPort, queueId, sleepIntervalTime, integrationWaitTime, sessionID,  processInstanceID,
										 WorkItemID,  strIntegrationErrCode,  strIntegrationErrRemarks ,attributesTag);
								
								if("Failure".equalsIgnoreCase(strIntegrationErrCode))
								sendEmail(cabinetName, sessionID, jtsIP, jtsPort, processInstanceID, messageID, strIntegrationErrRemarks);
						}
					}
				}

			}
			if(fetchWorkitemListCount>99){
				KYC_CBSLog.KYC_CBSLogger.debug("Again calling startKYC_CBSUtility recursively to get next set of WI's--");
				startKYC_CBSUtility(cabinetName,jtsIP,jtsPort,smsPort,queueId,sleepIntervalTime,integrationWaitTime,sessionID,socketDetailsMap,lastProcessInstance,lastWorkitemID,entryDateTime);
			}
		}
		catch(Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.error("Exception "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			KYC_CBSLog.KYC_CBSLogger.error("Exception Occurred in NBTL CBS Thread : "+result);
			System.out.println("Exception "+e);
			
		}
	}
	
	private static String fetchWIInput_XML(String cabinetName, String sessionID, String queueId, String lastProcessInstance, String lastWorkItemID, String lastValue){
		String FilterString = "VAR_STR1 IN ('Individual','Corporate')";
		StringBuffer ipXMLBuffer=new StringBuffer();
		ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
		ipXMLBuffer.append("<WMFetchWorkItems_Input>\n");
		ipXMLBuffer.append("<Option>WMFetchWorkItem</Option>\n");
		ipXMLBuffer.append("<EngineName>");
		ipXMLBuffer.append(cabinetName);
		ipXMLBuffer.append("</EngineName>\n");
		ipXMLBuffer.append("<SessionID>");
		ipXMLBuffer.append(sessionID);
		ipXMLBuffer.append("</SessionID>\n");
		ipXMLBuffer.append("<QueueId>");
		ipXMLBuffer.append(queueId);
		ipXMLBuffer.append("</QueueId>\n");
		ipXMLBuffer.append("<Filter>\n");
		ipXMLBuffer.append("<Type>");
		ipXMLBuffer.append("256");
		ipXMLBuffer.append("</Type>\n");
		ipXMLBuffer.append("<FilterString>");
		ipXMLBuffer.append(FilterString);
		ipXMLBuffer.append("</FilterString>\n");
		ipXMLBuffer.append("</Filter>\n");
		ipXMLBuffer.append("<BatchInfo>\n");
		ipXMLBuffer.append("<NoOfRecordsToFetch>100</NoOfRecordsToFetch>\n");
		ipXMLBuffer.append("<LastWorkItem>");
		ipXMLBuffer.append(lastWorkItemID);
		ipXMLBuffer.append("</LastWorkItem>\n");
		ipXMLBuffer.append("<LastValue>");
		ipXMLBuffer.append(lastValue);
		ipXMLBuffer.append("</LastValue>\n");
		ipXMLBuffer.append("<LastProcessInstance>");
		ipXMLBuffer.append(lastProcessInstance);
		ipXMLBuffer.append("</LastProcessInstance>\n");
		ipXMLBuffer.append("</BatchInfo>\n");
		ipXMLBuffer.append("</WMFetchWorkItems_Input>\n");
		return ipXMLBuffer.toString();
	}
	private static String sendEmail(String cabinetName, String sessionID, String jtsIP, String jtsPort, String wiName, String messageID, String strIntegrationErrRemarks) {
		try {
			int mailPriority = 1;
			String mailStatus = "N";
			String UserNAme = "rakbpm";
			String mailActionType = "TRIGGER";
			String mailContentType = "text/html;charset=UTF-8";
			// String wiName = processInstanceID;
			int workitemid = 1;
			int activityID = 3;
			int noOfTrials = 0;
			String Query1 = "SELECT Subject,Content,FomEmail,CCEmail FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'System Alert'";
			/*String mailFrom = "test4@rakbanktst.ae";
			  String mailTo = "test2@rakbanktst.ae";
			String mailSubject = "Workitem("+wiName+") moved to integration error queue";
			String emailBody = "<!DOCTYPE html><html><head>  <meta charset=\"UTF-8\">  <title>Integration Error Notification</title>  <style>    body {      font-family: Arial, sans-serif;      background-color: #f8f9fa;      padding: 20px;    }    .email-container {      background-color: #ffffff;      border: 1px solid #dee2e6;      padding: 20px;      max-width: 600px;      margin: auto;    }    .email-header {      font-size: 18px;      font-weight: bold;      margin-bottom: 20px;    }    .email-body {      font-size: 14px;      line-height: 1.6;    }    .email-footer {      margin-top: 30px;      font-size: 14px;    }    .details-table {      width: 100%;      border-collapse: collapse;      margin-top: 10px;    }    .details-table th,    .details-table td {      border: 1px solid #ced4da;      padding: 8px;      text-align: left;    }    .details-table th {      background-color: #e9ecef;    }  </style></head><body>  <div class=\"email-container\">    <div class=\"email-header\">Dear Concerned,</div>    <div class=\"email-body\">      <p>WI has moved to the integration error queue. Please find below the details:</p>      <table class=\"details-table\">        <tr>          <th>WINAME</th>          <td>"+wiName+"</td>        </tr>        <tr>          <th>Message ID</th>          <td>"+messageID+"</td>        </tr>        <tr>          <th>Remarks</th>          <td>"+strIntegrationErrRemarks+"</td>        </tr>      </table>    </div>    <div class=\"email-footer\">      Regards,<br>      RAKBANK    </div>  </div></body></html>";
			*/
			
			String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			KYC_CBSLog.KYC_CBSLogger.debug("dataInputXML " + dataInputXML);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			KYC_CBSLog.KYC_CBSLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				String mailFrom = dataxmlParserAPSelect.getValueOf("FomEmail");
				String mailMessage = dataxmlParserAPSelect.getValueOf("Content");
				String mailSubject = dataxmlParserAPSelect.getValueOf("Subject");
				String mailTo = dataxmlParserAPSelect.getValueOf("CCEmail");
				mailSubject = mailSubject.replaceAll("#wiName#", wiName);
				mailMessage = mailMessage.replaceAll("'", "''");
				mailMessage = mailMessage.replaceAll("#wiName#", wiName);
				mailMessage = mailMessage.replaceAll("#messageID#", messageID);
				mailMessage = mailMessage.replaceAll("#strIntegrationErrRemarks#", strIntegrationErrRemarks);
				
			String tableName = "WFMAILQUEUETABLE";
			String columnName = "mailFrom,mailTo,mailSubject,mailMessage,mailContentType,mailPriority,mailStatus,insertedBy,"
					+ "mailActionType,workitemId,activityId,noOfTrials,processinstanceID,insertedTime";
			String values = "'" + mailFrom + "','" + mailTo + "','" + mailSubject + "',N'" + mailMessage + "','"
					+ mailContentType + "','" + mailPriority + "','" + mailStatus + "','" + UserNAme + "','"
					+ mailActionType + "','" + workitemid + "','" + activityID + "','" + noOfTrials + "','"+wiName+"',getdate()";
			// String mailInsertQuery = "Insert into " +tableName+"
			// "+columnName+" values "+values;

			String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
			KYC_CBSLog.KYC_CBSLogger.debug("APInsertInputXML: " + apInsertInputXML);

			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
			KYC_CBSLog.KYC_CBSLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			KYC_CBSLog.KYC_CBSLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
			if (apInsertMaincode.equalsIgnoreCase("0")) {
				KYC_CBSLog.KYC_CBSLogger.debug("ApInsert successful: " + apInsertMaincode);
				KYC_CBSLog.KYC_CBSLogger.debug("Mail sent successfully.");
				return "true";
			 }
			}
		} catch (Exception e) {
			KYC_CBSLog.KYC_CBSLogger.debug("Exception in sending mail----" + e);
		}
		return "false";
	}
	
	public static String WFNGExecute(String ipXML, String jtsServerIP, String serverPort,
			int flag) throws IOException, Exception
	{
		KYC_CBSLog.KYC_CBSLogger.debug("In WF NG Execute : " + serverPort);
		try
		{
			if (serverPort.startsWith("33"))
				return WFCallBroker.execute(ipXML, jtsServerIP,
						Integer.parseInt(serverPort), 1);
			else
				return ngEjbClientKYC_CBS.makeCall(jtsServerIP, serverPort,
						"WebSphere", ipXML);
		}
		catch (Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.error("Exception Occured in WF NG Execute : "
					+ e.getMessage());
			e.printStackTrace();
			return "Error";
		}
	}

	public static String removeDocs(String cabinetName, String jtsIP, String jtsPort, String smsPort,String sessionID, String processInstanceID)
	{
		try{
		String query = "select FolderIndex from PDBFolder where name = '"+processInstanceID+"'";
		
		String apSelectInputXMLFolderIndex =CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
		KYC_CBSLog.KYC_CBSLogger.debug("apSelectInputXMLFolderIndex: "+apSelectInputXMLFolderIndex);

		String apSelectOutputXML=WFNGExecute(apSelectInputXMLFolderIndex,jtsIP,jtsPort,1);
		KYC_CBSLog.KYC_CBSLogger.debug("APSelect OutputXML: "+apSelectOutputXML);

		XMLParser xmlParserFolderIndex= new XMLParser(apSelectOutputXML);
		String MainCodeFolderIndex = xmlParserFolderIndex.getValueOf("MainCode");
		KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCodeFolderIndex);

		int TotalRecordsRetrieved = Integer.parseInt(xmlParserFolderIndex.getValueOf("TotalRetrieved"));
		KYC_CBSLog.KYC_CBSLogger.debug("TotalRecords: "+TotalRecordsRetrieved);

		String FolderIndex = "";
		if(MainCodeFolderIndex.equalsIgnoreCase("0")&& TotalRecordsRetrieved>0)
		{
			String xmlData=xmlParserFolderIndex.getNextValueOf("Record");
			xmlData =xmlData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

			XMLParser xmlParserRecord = new XMLParser(xmlData);

			FolderIndex=xmlParserRecord.getValueOf("FolderIndex");
			KYC_CBSLog.KYC_CBSLogger.debug("FolderIndex: "+FolderIndex);
		
		}
		
		
		String query1 = "Select PDBDocument.DocumentIndex "
				+"from PDBDocument "
				+"INNER JOIN PDBDocumentContent ON PDBDocument.DocumentIndex = PDBDocumentContent.DocumentIndex "
				+"INNER JOIN PDBFolder ON PDBDocumentContent.ParentFolderIndex = PDBFolder.FolderIndex "
				+"WHERE PDBDocument.Name = 'Previous_Doc' and PDBFolder.Name = '"+processInstanceID+"'";
		
		String apSelectInputXML =CommonMethods.apSelectWithColumnNames(query1, cabinetName, sessionID);
		KYC_CBSLog.KYC_CBSLogger.debug("APSelect InputXML: "+apSelectInputXML);

		String OutputXML=WFNGExecute(apSelectInputXML,jtsIP,jtsPort,1);
		KYC_CBSLog.KYC_CBSLogger.debug("APSelect OutputXML: "+OutputXML);

		XMLParser xmlParser= new XMLParser(OutputXML);
		String MainCode = xmlParser.getValueOf("MainCode");
		KYC_CBSLog.KYC_CBSLogger.debug("MainCode: "+MainCode);

		int TotalRecords = Integer.parseInt(xmlParser.getValueOf("TotalRetrieved"));
		KYC_CBSLog.KYC_CBSLogger.debug("TotalRecords: "+TotalRecords);

		
		if(MainCode.equalsIgnoreCase("0")&& TotalRecords>0)
		{
			for(int i=0;i<TotalRecords;i++)
			{
			String xmlData=xmlParser.getNextValueOf("Record");
			xmlData =xmlData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

			XMLParser xmlParserRecord = new XMLParser(xmlData);

			String DocumentIndex=xmlParserRecord.getValueOf("DocumentIndex");
			KYC_CBSLog.KYC_CBSLogger.debug("FolderIndex: "+DocumentIndex);
			System.out.println("FolderIndex: "+DocumentIndex);

			KYC_CBSLog.KYC_CBSLogger.debug("ParentFolderIndex found.");
			System.out.println("ParentFolderIndex found.");
			
			String DocumentsTag = "<Documents>";
			
			DocumentsTag = DocumentsTag+
					"\n\t\t<Document>"
					+"\n\t\t\t<DocumentIndex>"+DocumentIndex+"</DocumentIndex>"
					+"\n\t\t\t<ParentFolderIndex>"+FolderIndex+"</ParentFolderIndex>"
					+"\n\t\t\t<ReferenceFlag>Y</ReferenceFlag>"
					+"\n\t\t</Document>";
			DocumentsTag = DocumentsTag
					+"\n</Documents>\n";
			
			StringBuffer ipXMLBuffer=new StringBuffer();

			ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
			ipXMLBuffer.append("<NGODeleteDocumentExt_Input>\n");
			ipXMLBuffer.append("<Option>NGODeleteDocumentExt</Option>\n");
			ipXMLBuffer.append("<CabinetName>");
			ipXMLBuffer.append(cabinetName);
			ipXMLBuffer.append("</CabinetName>\n");
			ipXMLBuffer.append("<UserDBId>");
			ipXMLBuffer.append(sessionID);
			ipXMLBuffer.append("</UserDBId>\n");
			ipXMLBuffer.append(DocumentsTag);
			ipXMLBuffer.append("</NGODeleteDocument_Input>");
			
			String NGODeleteDocumentInput = ipXMLBuffer.toString();
			KYC_CBSLog.KYC_CBSLogger.debug("NGODeleteDocumentInput----"+NGODeleteDocumentInput);
			
			String NGODeleteDocumentInputOutput=WFNGExecute(NGODeleteDocumentInput,jtsIP,jtsPort,1);
			KYC_CBSLog.KYC_CBSLogger.debug("NGODeleteDocumentInputOutput OutputXML: "+NGODeleteDocumentInputOutput);
			}
		}
		
		}catch (Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.error("Exception Occured in removeDocs() ---"+ e.getMessage());
			e.printStackTrace();
			return "Error";
		}
		return "";
	}
	
	public static HashMap<String,String> socketConnectionDetails(String cabinetName, String sJtsIp, String iJtsPort,
			String sessionID )
	{
		HashMap<String, String> socketDetailsMap = new HashMap<String, String>();

		try
		{
			ngEjbClientKYC_CBS = NGEjbClient.getSharedInstance();
			KYC_CBSLog.KYC_CBSLogger.debug("Fetching Socket Connection Details.");
			System.out.println("Fetching Socket Connection Details.");

			String socketDetailsQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'KYC_Remediation' and CallingSource = 'Utility'";

			String socketDetailsInputXML =CommonMethods.apSelectWithColumnNames(socketDetailsQuery, cabinetName, sessionID);
			KYC_CBSLog.KYC_CBSLogger.debug("Socket Details APSelect InputXML: "+socketDetailsInputXML);

			String socketDetailsOutputXML=WFNGExecute(socketDetailsInputXML,sJtsIp,iJtsPort,1);
			KYC_CBSLog.KYC_CBSLogger.debug("Socket Details APSelect OutputXML: "+socketDetailsOutputXML);

			XMLParser xmlParserSocketDetails= new XMLParser(socketDetailsOutputXML);
			String socketDetailsMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			KYC_CBSLog.KYC_CBSLogger.debug("SocketDetailsMainCode: "+socketDetailsMainCode);

			int socketDetailsTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			KYC_CBSLog.KYC_CBSLogger.debug("SocketDetailsTotalRecords: "+socketDetailsTotalRecords);

			if(socketDetailsMainCode.equalsIgnoreCase("0")&& socketDetailsTotalRecords>0)
			{
				String xmlDataSocketDetails=xmlParserSocketDetails.getNextValueOf("Record");
				xmlDataSocketDetails =xmlDataSocketDetails.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

				XMLParser xmlParserSocketDetailsRecord = new XMLParser(xmlDataSocketDetails);

				String socketServerIP=xmlParserSocketDetailsRecord.getValueOf("SocketServerIP");
				KYC_CBSLog.KYC_CBSLogger.debug("SocketServerIP: "+socketServerIP);
				socketDetailsMap.put("SocketServerIP", socketServerIP);

				String socketServerPort=xmlParserSocketDetailsRecord.getValueOf("SocketServerPort");
				KYC_CBSLog.KYC_CBSLogger.debug("SocketServerPort " + socketServerPort);
				socketDetailsMap.put("SocketServerPort", socketServerPort);

				KYC_CBSLog.KYC_CBSLogger.debug("SocketServer Details found.");
				System.out.println("SocketServer Details found.");

			}
		}
		catch (Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.error("Exception in getting Socket Connection Details: "+e.getMessage());
			System.out.println("Exception in getting Socket Connection Details: "+e.getMessage());
		}

		return socketDetailsMap;
	}
	
	private void DoneWI(String cabinetName,String jtsIP,String jtsPort, String smsPort, String queueId,int sleepIntervalTime,int integrationWaitTime,String sessionID, String processInstanceID,
			String WorkItemID, String Decision, String Remarks, String attributesTag) throws IOException, Exception{
		RouteRelatedPartyWI(processInstanceID,Decision,cabinetName,sessionID,jtsIP,jtsPort);
		getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, processInstanceID,WorkItemID);
		KYC_CBSLog.KYC_CBSLogger.debug("Input XML for getWorkItem is "+getWorkItemInputXML);
		getWorkItemOutputXml = WFNGExecute(getWorkItemInputXML,jtsIP,jtsPort,1);

		KYC_CBSLog.KYC_CBSLogger.debug("Output XML for getWorkItem is "+getWorkItemOutputXml);

		xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
		getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");

		if("0".equals(getWorkItemMainCode))
		{
			KYC_CBSLog.KYC_CBSLogger.info("get Workitem call successfull for "+processInstanceID);

			String assignWorkitemAttributeInputXML=CommonMethods.assignWorkitemAttributeInput(cabinetName, sessionID,
					processInstanceID,WorkItemID,attributesTag);
			KYC_CBSLog.KYC_CBSLogger.debug("Input XML for assign Attribute is "+assignWorkitemAttributeInputXML);

			String assignWorkitemAttributeOutputXML=WFNGExecute(assignWorkitemAttributeInputXML,jtsIP,
					jtsPort,1);
			KYC_CBSLog.KYC_CBSLogger.debug("Output XML for assign Attribues is "+assignWorkitemAttributeOutputXML);

			XMLParser xmlParserAssignAtt=new XMLParser(assignWorkitemAttributeOutputXML);

			String mainCodeAssignAtt=xmlParserAssignAtt.getValueOf("MainCode");
			if("0".equals(mainCodeAssignAtt.trim()))
			{
				String completeWorkItemInputXML = CommonMethods.completeWorkItemInput(cabinetName, sessionID,
						processInstanceID,WorkItemID);

				KYC_CBSLog.KYC_CBSLogger.debug("Input XML for complete WI is "+completeWorkItemInputXML);

				KYC_CBSLog.KYC_CBSLogger.debug("Input XML for wmcompleteWorkItem: "+ completeWorkItemInputXML);

				String completeWorkItemOutputXML = WFNGExecute(completeWorkItemInputXML,jtsIP,jtsPort,1);
				KYC_CBSLog.KYC_CBSLogger.debug("Output XML for wmcompleteWorkItem: "+ completeWorkItemOutputXML);

				XMLParser xmlParserCompleteWorkitem = new XMLParser(completeWorkItemOutputXML);
				String completeWorkitemMaincode = xmlParserCompleteWorkitem.getValueOf("MainCode");
				KYC_CBSLog.KYC_CBSLogger.debug("Status of wmcompleteWorkItem  "+ completeWorkitemMaincode);

				if("0".equals(completeWorkitemMaincode))
				{
					//inserting into history table
					KYC_CBSLog.KYC_CBSLogger.debug("WmCompleteWorkItem successful: "+completeWorkitemMaincode);
					System.out.println(processInstanceID + "Complete Succesfully with status ");

					KYC_CBSLog.KYC_CBSLogger.debug("WorkItem moved to next Workstep.");

					SimpleDateFormat inputDateformat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					SimpleDateFormat outputDateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

					Date entryDatetimeFormat = inputDateformat.parse(entryDateTime);
					String formattedEntryDatetime=outputDateFormat.format(entryDatetimeFormat);
					KYC_CBSLog.KYC_CBSLogger.debug("FormattedEntryDatetime: "+formattedEntryDatetime);

					Date d = new Date();
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String strDate = dateFormat.format(d);
					
					String tableName = "NG_KYC_REM_GR_HISTORY";
					String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
					String values = "'"+strDate+"','System_Integration','"+Decision+"','rakBPMutility','"+Remarks+"','"+processInstanceID+"','"+formattedEntryDatetime+"'";
					

					String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnName, values,tableName);
					KYC_CBSLog.KYC_CBSLogger.debug("APInsertInputXML: "+apInsertInputXML);

					String apInsertOutputXML = WFNGExecute(apInsertInputXML,jtsIP,
							jtsPort,1);
					KYC_CBSLog.KYC_CBSLogger.debug("APInsertOutputXML: "+ apInsertOutputXML);

					XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
					String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
					KYC_CBSLog.KYC_CBSLogger.debug("Status of apInsertMaincode  "+ apInsertMaincode);
					if(apInsertMaincode.equalsIgnoreCase("0"))
					{
						KYC_CBSLog.KYC_CBSLogger.debug("ApInsert successful: "+apInsertMaincode);
						KYC_CBSLog.KYC_CBSLogger.debug("Inserted in WiHistory table successfully.");
						
					}
					else
					{
						KYC_CBSLog.KYC_CBSLogger.error("ApInsert failed: "+apInsertMaincode);
					}
				}
				else
				{
					KYC_CBSLog.KYC_CBSLogger.error("Error in completeWI call for "+processInstanceID);
				}
			}
			else
			{
				KYC_CBSLog.KYC_CBSLogger.error("Error in Assign Attribute call for WI "+processInstanceID);
			}


		}
		else
		{
			KYC_CBSLog.KYC_CBSLogger.error("Error in getWI call for WI "+processInstanceID);
		}
	}
	
	private String RouteRelatedPartyWI(String MainWI,String decision,String cabinetName,String sessionID,String jtsIP,String jtsPort) {
		try{
			KYC_CBSLog.KYC_CBSLogger.debug("Inside RouteRelatedPartyWI for main WI - "+MainWI);
			String Query = "SELECT RP_WI_Number FROM NG_KYC_REM_RP_GRID with (nolock) WHERE WI_Name = '"+MainWI+"'";
					List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
					DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
					KYC_CBSLog.KYC_CBSLogger.debug("DataFromDB : OF_DATA_DEF_ID "+DataFromDB);
					
					for (Map<String, String> entry : DataFromDB) 
					{
						String WINAME = entry.get("RP_WI_Number");
						
						String WorkItemID = "";
						String ActivityID = "";
						String ProcessDefID = "";
						String EntryDateTime = "";
						String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE where ProcessInstanceID = '"+WINAME+"'";
						String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
						String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
						XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
						String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
						int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
						if (dataMainCode.equals("0") && dataTotalRecords > 0) {
							WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
							ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
							ProcessDefID =  dataxmlParserAPSelect.getValueOf("ProcessDefID");
							EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");
							
							StringBuffer ipXMLBuffer=new StringBuffer();

							ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
							ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
							ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
							ipXMLBuffer.append("<EngineName>");
							ipXMLBuffer.append(cabinetName);
							ipXMLBuffer.append("</EngineName>\n");
							ipXMLBuffer.append("<SessionID>");
							ipXMLBuffer.append(sessionID);
							ipXMLBuffer.append("</SessionID>\n");
							ipXMLBuffer.append("<ProcessInstanceID>");
							ipXMLBuffer.append(WINAME);
							ipXMLBuffer.append("</ProcessInstanceID>\n");
							ipXMLBuffer.append("<WorkItemID>");
							ipXMLBuffer.append(WorkItemID);
							ipXMLBuffer.append("</WorkItemID>\n");
							ipXMLBuffer.append("<SourceUser>");
							//ipXMLBuffer.append(WorkItemID);
							ipXMLBuffer.append("</SourceUser>\n");
							ipXMLBuffer.append("<TargetUser>");
							ipXMLBuffer.append("rakbpmutility");
							ipXMLBuffer.append("</TargetUser>\n");
							ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
							String WMUnlockWIInput = ipXMLBuffer.toString();
							KYC_CBSLog.KYC_CBSLogger.debug("Input XML For WMUnlockWIInput: "+ WMUnlockWIInput);
							String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput,jtsIP,jtsPort,1);
							KYC_CBSLog.KYC_CBSLogger.debug("Output XML For WMUnlockWIInput: "+ WMUnlockWIOutputXml);

							XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
							String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
							KYC_CBSLog.KYC_CBSLogger.debug("WMUnlockWICall Maincode:  "+ WMUnlockWIMainCode);
							
						if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")){	
							
						String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,WorkItemID);
						KYC_CBSLog.KYC_CBSLogger.debug("Input XML For WmgetWorkItemCall: "+ getWorkItemInputXML);
						String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML,jtsIP,jtsPort,1);
						KYC_CBSLog.KYC_CBSLogger.debug("Output XML For WmgetWorkItemCall: "+ getWorkItemOutputXml);
						
						XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
						String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
						KYC_CBSLog.KYC_CBSLogger.debug("WmgetWorkItemCall Maincode:  "+ getWorkItemMainCode);
						if (getWorkItemMainCode.trim().equals("0")){
							String attTag = "<DECISION>"+decision+"</DECISION>";
							String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
				                    + "<Option>WMAssignWorkItemAttributes</Option>"
				                    + "<EngineName>"+cabinetName+"</EngineName>"
				                    + "<SessionId>"+sessionID+"</SessionId>"
				                    + "<ProcessInstanceId>"+WINAME+"</ProcessInstanceId>"
				                    + "<WorkItemId>"+WorkItemID+"</WorkItemId>"
				                    + "<ActivityId>"+ActivityID+"</ActivityId>"
				                    + "<ProcessDefId>"+ProcessDefID+"</ProcessDefId>"
				                    + "<LastModifiedTime></LastModifiedTime>"
				                    + "<ActivityType></ActivityType>"
				                    + "<complete>D</complete>"
				                    + "<AuditStatus></AuditStatus>"
				                    + "<Comments></Comments>"
				                    + "<UserDefVarFlag>Y</UserDefVarFlag>"
				                    + "<Attributes>"+attTag+"</Attributes>"
				                    + "</WMAssignWorkItemAttributes_Input>";


							KYC_CBSLog.KYC_CBSLogger.debug("assignInputXML--- "+assignInputXML);
							String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
							KYC_CBSLog.KYC_CBSLogger.debug("assignOutXml--- "+assignOutXml);
							XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
							String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
							if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0"))
							{
								KYC_CBSLog.KYC_CBSLogger.debug("Related Party WI routed--- "+WINAME);
							}
							else{
								KYC_CBSLog.KYC_CBSLogger.debug("Error in assignWICall--- "+WINAME);
								return "Error";
							}
						}
						else{
							KYC_CBSLog.KYC_CBSLogger.debug("Error in getWICall--- "+WINAME);
							return "Error";
						}
						}
						else{
							KYC_CBSLog.KYC_CBSLogger.debug("Error in reassigning--- "+WINAME);
							return "Error";
						}
						}
						else{
							KYC_CBSLog.KYC_CBSLogger.debug("Error in getting Activity ID--- "+WINAME);
							return "Error";
						}
					}
			
		}catch(Exception e)
		{
			KYC_CBSLog.KYC_CBSLogger.debug("Exception in RouteRelatedPartyWI method-"+e.getMessage());
			return "Error";
		}
		return "Success";
	}
	
	private static List<Map<String, String>> getDataFromDBMap(String query, String cabinetName, String sessionID,
			String jtsIP, String jtsPort) {
		List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
		try {
			KYC_CBSLog.KYC_CBSLogger.debug("Inside function getDataFromDB");
			KYC_CBSLog.KYC_CBSLogger.debug("getDataFromDB query is: " + query);
			String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			OutXml = OutXml.replaceAll("&", "#andsymb#");
			Document recordDoc1 = MapXML.getDocument(OutXml);
			NodeList records1 = recordDoc1.getElementsByTagName("Record");
			if (records1.getLength() > 0) {
				for (int i = 0; i < records1.getLength(); i++) {
					Node n = records1.item(i);
					Map<String, String> t = new HashMap<String, String>();
					if (n.hasChildNodes()) {
						NodeList child = n.getChildNodes();
						for (int j = 0; j < child.getLength(); j++) {
							Node n1 = child.item(j);
							String column = n1.getNodeName();
							String value = n1.getTextContent().replaceAll("#andsymb#", "&");
							if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
								//KYC_CBSLog.KYC_CBSLogger.debug("getDataFromDBMap Setting value of " + column + " as " + value);
								t.put(column, value);
							} else {
								//KYC_CBSLog.KYC_CBSLogger.debug("getDataFromDBMap Setting value of " + column + " as blank");
								t.put(column, "");
							}
						}
					}
					temp.add(t);
				}
			}

		} catch (Exception e) {
			KYC_CBSLog.KYC_CBSLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return temp;
	}
}
