package com.newgen.KYC.CustOutreach;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.newgen.KYC.CBS.KYC_CBS;
import com.newgen.KYC.CBS.KYC_CBSLog;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

public class CustOutreach implements Runnable {

	private static NGEjbClient ngEjbClientOutreach;
	private static String sessionID = "";
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	private static String queueID = "";
	private static String OutreachDocPath = "";
	private static String SMSPort = "";
	private static String volumeID = "";
	private static String DocTypes = "";
	private static String SuccessPath = "";
	private static String ErrorPath = "";
	private static String KYCformPath = "";
	private static String completedCasesPendingForHours = "";
	private static int integrationWaitTime = 0;
	private static int sleepIntervalInMin = 0;
	private static int DaysToDelete;
	private static int ConsequenceEmailDays;
	private static int AvgAnnInc;
	private static String autoConsequenceDays;
	String XMLLOG_HISTORY_TABLE = "NG_KYC_Remedation_XMLLOG_HISTORY";
	Socket socket = null;
	String socketServerIP = "";
	int socketServerPort = 0;
	OutputStream out = null;
	InputStream socketInputStream = null;
	DataOutputStream dout = null;
	DataInputStream din = null;
	String outputResponse = null;
	String inputRequest = null;
	String inputMessageID = null;
	static Map<String, String> KYCcustOutreachParaMap = new HashMap<String, String>();
	List<String> DocsList = new ArrayList<>();

	@Override
	public void run() {
		try {
			CustOutreachLog.setLogger();
			ngEjbClientOutreach = NGEjbClient.getSharedInstance();

			CustOutreachLog.KYCcustOutreachLogger.debug("Connecting to Cabinet.");

			int configReadStatus = readConfig();

			CustOutreachLog.KYCcustOutreachLogger.debug("configReadStatus " + configReadStatus);
			if (configReadStatus != 0) {
				CustOutreachLog.KYCcustOutreachLogger.error("Could not Read Config Properties [ODDDStatus]");
				return;
			}

			volumeID = CommonConnection.getsVolumeID();
			CustOutreachLog.KYCcustOutreachLogger.debug("volumeID: " + volumeID);

			cabinetName = CommonConnection.getCabinetName();
			CustOutreachLog.KYCcustOutreachLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			CustOutreachLog.KYCcustOutreachLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			CustOutreachLog.KYCcustOutreachLogger.debug("JTSPORT: " + jtsPort);

			queueID = KYCcustOutreachParaMap.get("queueID");
			CustOutreachLog.KYCcustOutreachLogger.debug("QueueID: " + queueID);

			SMSPort = CommonConnection.getsSMSPort();
			CustOutreachLog.KYCcustOutreachLogger.debug("SMSPort: " + SMSPort);

			OutreachDocPath = KYCcustOutreachParaMap.get("OutreachDocPath");
			CustOutreachLog.KYCcustOutreachLogger.debug("OutreachDocPath: " + OutreachDocPath);

			SuccessPath = KYCcustOutreachParaMap.get("SuccessPath");
			CustOutreachLog.KYCcustOutreachLogger.debug("SuccessPath: " + SuccessPath);

			ErrorPath = KYCcustOutreachParaMap.get("ErrorPath");
			CustOutreachLog.KYCcustOutreachLogger.debug("ErrorPath: " + ErrorPath);

			DocTypes = KYCcustOutreachParaMap.get("DocTypes");
			CustOutreachLog.KYCcustOutreachLogger.debug("DocTypes from config files: " + DocTypes);

			DaysToDelete = Integer.parseInt(KYCcustOutreachParaMap.get("DaysToDelete"));
			CustOutreachLog.KYCcustOutreachLogger.debug("DaysToDelete: " + DaysToDelete);

			KYCformPath = KYCcustOutreachParaMap.get("KYCFormPath");
			CustOutreachLog.KYCcustOutreachLogger.debug("KYCformPath: " + KYCformPath);

			integrationWaitTime = Integer.parseInt(KYCcustOutreachParaMap.get("INTEGRATION_WAIT_TIME"));
			CustOutreachLog.KYCcustOutreachLogger.debug("IntegrationWaitTime: " + integrationWaitTime);

			sleepIntervalInMin = Integer.parseInt(KYCcustOutreachParaMap.get("SleepIntervalInMin"));
			CustOutreachLog.KYCcustOutreachLogger.debug("SleepIntervalInMin: " + sleepIntervalInMin);

			ConsequenceEmailDays = Integer.parseInt(KYCcustOutreachParaMap.get("ConsequenceEmailDays"));
			CustOutreachLog.KYCcustOutreachLogger.debug("ConsequenceEmailDays: " + ConsequenceEmailDays);

			AvgAnnInc = Integer.parseInt(KYCcustOutreachParaMap.get("AvgAnnInc"));
			CustOutreachLog.KYCcustOutreachLogger.debug("AvgAnnInc: " + AvgAnnInc);
			
			autoConsequenceDays = KYCcustOutreachParaMap.get("autoConsequenceDays");
			CustOutreachLog.KYCcustOutreachLogger.debug("autoConsequenceDays: " + autoConsequenceDays);
			completedCasesPendingForHours = KYCcustOutreachParaMap.get("completedCasesPendingForHours");
			CustOutreachLog.KYCcustOutreachLogger.debug("completedCasesPendingForHours: " + completedCasesPendingForHours);

			sessionID = CommonConnection.getSessionID(CustOutreachLog.KYCcustOutreachLogger, false);

			if (sessionID.trim().equalsIgnoreCase("")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("Could Not Connect to Server!");
			} else {
				CustOutreachLog.KYCcustOutreachLogger.debug("Session ID found: " + sessionID);
				HashMap<String, String> socketDetailsMap = socketConnectionDetails(cabinetName, jtsIP, jtsPort,
						sessionID);
				while (true) {
					sessionID = CommonConnection.getSessionID(CustOutreachLog.KYCcustOutreachLogger, false);
					CustOutreachLog.setLogger();
					CustOutreachLog.KYCcustOutreachLogger.debug("Customer Outreach Utility start...123");
					startUtilityCustOutreach(cabinetName, sessionID, jtsIP, jtsPort, socketDetailsMap);
					System.out.println("No More workitems to Process, Sleeping!");
					Thread.sleep(sleepIntervalInMin * 60 * 1000);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			CustOutreachLog.KYCcustOutreachLogger.error("Exception Occurred in outreach : " + e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			CustOutreachLog.KYCcustOutreachLogger.error("Exception Occurred in outreach : " + result);
		}
	}

	private int readConfig() {
		Properties p = null;
		try {

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir") + File.separator + "ConfigFiles"
					+ File.separator + "KYC_CustOutreach_Config.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();
				KYCcustOutreachParaMap.put(name, p.getProperty(name));
			}
		} catch (Exception e) {
			return -1;
		}
		return 0;
	}

	// WICategory and NoOfDocsForOutreach via SELECT , change to
	// OutreachDocumentFlag
	// If files.length < NoOfDocsForOutreach, nothing to do almost.
	// On line 198 If NoOfDocsForOutreach != 0 then for loop(pre-existing)
	// NoOfDocsForOutreach = 0 or null complete WI.
	//

	private void startUtilityCustOutreach(String cabinetName, String sessionID, String jtsIP, String jtsPort,
			HashMap<String, String> socketDetailsMap) {
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside startUtilityCustOutreach");
			RouteConsequenceWI();
			RouteAutoConsequenceWI();
			ExpireEmailHoldWI();
			processEmailResponseWI();
			BBGConsequenceEligibleWI();
			RouteConsequenceHeldTillWI();
			sendBBGReminderEmail();
			ProcessBBGPortalReturnCases(socketDetailsMap);
			sendMailConsequenceFailedCases();

			// byVar
			sendMailPendingCases(); // post Outreach
			//to do varun
			/*
			 * String Query =
			 * "Select CIF_ID,WINAME,OutreachStatusUpdateDateTime,CURRENT_WS,CaseType,OutreachDocumentFlag,WICategory from RB_KYC_REM_EXTTABLE with (nolock) "
			 * +
			 * "where CustomerOutreachFlag = 'Completed' AND (CURRENT_WS = 'RM_Vendor' OR CURRENT_WS = 'Consequence') AND (Prev_Dec = 'Customer Outreach' OR Prev_Dec = 'Re-Integrate' OR Prev_Dec = 'Send to KYC Consequence' OR Prev_Dec = 'Submit to RM Vendor' OR Prev_Dec = 'Success')"
			 * ;
			 */
			/*
			 * String Query =
			 * "Select CIF_ID,WINAME,OutreachStatusUpdateDateTime,CURRENT_WS,CaseType,OutreachDocumentFlag,WICategory,"
			 * +
			 * "CustomerOutreachFlag,FqiN6495+
			 * ,OfficeAddressLine1,OfficeCountry,OfficeCityEmirate,ResidenceFlatVillaNo,"
			 * +
			 * "ResidenceCountry,ResidenceEmirateCity,RiskProfile from RB_KYC_REM_EXTTABLE e with (nolock) JOIN WFINSTRUMENTTABLE WF ON e.WINAME = WF.processInstanceID "
			 * +
			 * "WHERE WF.Statename != 'SUSPENDED' AND ((CustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND "
			 * +
			 * "(Prev_Dec = 'Customer Outreach' OR Prev_Dec = 'Re-Integrate') AND (Prev_WS = 'Maker' OR Prev_WS = 'Maker2' OR "
			 * +
			 * "Prev_WS = 'RM_Vendor' OR Prev_WS = 'Doc_Error_Handling')) OR (CustomerOutreachFlag = 'Completed' AND "
			 * +
			 * "CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Action Taken' AND Prev_WS = 'Consequence_Manual') OR "
			 * +
			 * "(CustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Send to RM Vendor' AND "
			 * +
			 * "Prev_WS = 'Consequence_Hold') OR (CustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND "
			 * +
			 * "Prev_Dec = 'Submit to RM Vendor' AND Prev_WS = 'Consequence') OR (CustomerOutreachFlag = 'Completed' AND "
			 * +
			 * "CURRENT_WS = 'Consequence' AND Prev_Dec = 'Send to KYC Consequence' AND Prev_WS = 'RM_Vendor') OR "
			 * +
			 * "(CustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Success' "
			 * + "AND Prev_WS = 'Attach_Document'))";
			 */

			String Query = "Select CIF_ID,WINAME,OutreachStatusUpdateDateTime,CURRENT_WS,CaseType,OutreachDocumentFlag,WICategory,"
					+ "CustomerOutreachFlag,PreferredAddressFlag,OfficeAddressLine1,OfficeCountry,OfficeCityEmirate,ResidenceFlatVillaNo,"
					+ "ResidenceCountry,ResidenceEmirateCity,RiskProfile,ProfileChange,DocumentUpload,OfficeEmployerNameDesc,AutoRRCStatus,EMPLOYER_CHANGE from RB_KYC_REM_EXTTABLE e with (nolock) JOIN WFINSTRUMENTTABLE WF ON e.WINAME = WF.processInstanceID "
					+ "WHERE WF.Statename != 'SUSPENDED' AND (((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND "
					+ "(Prev_Dec = 'Customer Outreach' OR Prev_Dec = 'Re-Integrate') AND (Prev_WS = 'Maker' OR Prev_WS = 'Maker2' OR "
					+ "Prev_WS = 'RM_Vendor' OR Prev_WS = 'Doc_Error_Handling')) OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND "
					+ "CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Action Taken' AND Prev_WS = 'Consequence_Manual') OR "
					+ "((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Send to RM Vendor' AND "
					+ "Prev_WS = 'Consequence_Hold') OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND "
					+ "Prev_Dec = 'Submit to RM Vendor' AND Prev_WS = 'Consequence') OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND "
					+ "CURRENT_WS = 'Consequence' AND Prev_Dec = 'Send to KYC Consequence' AND Prev_WS = 'RM_Vendor') OR "
					+ "((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Success' "
					+ "AND Prev_WS = 'Attach_Document')) OR (CustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'Consequence_Hold' AND caseType = 'Individual' AND AUTO_CONSEQUENCE_STATUS = 'PENDING' AND Consequence_Status IN ('Fully Applied','Partial Applied'))";

			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {

				String cif = entry.get("CIF_ID");
				String WINAME = entry.get("WINAME");
				CustOutreachLog.KYCcustOutreachLogger.debug("WINAME FETCHED-->" + WINAME);
				String CURRENT_WS = entry.get("CURRENT_WS");
				String OutreachupdateDateTime = entry.get("OutreachStatusUpdateDateTime");
				String CaseType = entry.get("CaseType");
				String OutreachDocFlag = entry.get("OutreachDocumentFlag");
				String outreachFlag = entry.get("CustomerOutreachFlag");
				CustOutreachLog.KYCcustOutreachLogger.debug("outreachFlag-->" + outreachFlag);
				String prefAddress = entry.get("PreferredAddressFlag");
				String OfficeAddressLine1 = entry.get("OfficeAddressLine1");
				String OfficeCountry = entry.get("OfficeCountry");
				String OfficeCityEmirate = entry.get("OfficeCityEmirate");
				String ResidenceFlatVillaNo = entry.get("ResidenceFlatVillaNo");
				String ResidenceCountry = entry.get("ResidenceCountry");
				String ResidenceEmirateCity = entry.get("ResidenceEmirateCity");
				String RiskProfile = entry.get("RiskProfile");
				String WICategory = entry.get("WICategory");
				String ProfileChange = entry.get("ProfileChange");
				String DocumentUpload = entry.get("DocumentUpload");
				String OfficeEmployerNameDesc = entry.get("OfficeEmployerNameDesc");
				CustOutreachLog.KYCcustOutreachLogger.debug("OfficeEmployerNameDesc-->" + OfficeEmployerNameDesc);
				String AutoRRCStatus = entry.get("AutoRRCStatus");
				String Path = OutreachDocPath + File.separator + WINAME;
				Path targetDirectory = Paths.get(Path);
				String EMPLOYER_CHANGE = entry.get("EMPLOYER_CHANGE");

				if (!"0".equalsIgnoreCase(OutreachDocFlag) && !"".equalsIgnoreCase(OutreachDocFlag)) {
					if (Files.exists(targetDirectory)) {
						File directory = new File(Path);
						File[] files = directory.listFiles();
						int length = files.length;
						CustOutreachLog.KYCcustOutreachLogger.debug("Length - " + length);
						CustOutreachLog.KYCcustOutreachLogger.debug("files - " + files);
						if (length != 0) {
							for (File file : files) {
								if (file.isFile()) {
									String fileName = file.getName();
									String fileNameWithoutExt = fileName.substring(0, fileName.lastIndexOf("."));
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Document processing-->" + file.getName());
									String size = String.valueOf(file.length());
									String ext = fileName.substring(fileName.lastIndexOf("."), fileName.length());
									String createdByAppName = ext.replaceFirst(".", "");
									//-------08/06/2026---------start
									//String DocumentType = "Additional Documents";
									String DocumentType = "";
									//-------08/06/2026---------end
									if (fileName.startsWith("Others")) {
										DocumentType = "Others";
									} else if (fileName.startsWith("Additional Documents")) {
										DocumentType = "Additional Documents";
									}
									if (DocTypes.contains(fileName.substring(0, fileName.lastIndexOf(".")))) {
										DocumentType = fileName.substring(0, fileName.lastIndexOf("."));
									}
									//-------08/06/2026---------start
									if("".equalsIgnoreCase(DocumentType)) {
										CustOutreachLog.KYCcustOutreachLogger.debug("skipping document "+fileName+" as it is not as per agreed naming convention.....");
										continue;
									}
									//-------08/06/2026---------end
									String FullPath = Path + File.separator + fileName;
									JPISIsIndex ISINDEX = new JPISIsIndex();
									JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
									CustOutreachLog.KYCcustOutreachLogger.debug("trying to add doc on image server");
									try {
										CustOutreachLog.KYCcustOutreachLogger.debug("Values passed -- >jtsip-" + jtsIP
												+ " , jtsPort->" + jtsPort + ",cabinetName->" + cabinetName
												+ ",volumeID->" + volumeID + ", File path-->" + FullPath);
										CPISDocumentTxn.AddDocument_MT(null, jtsIP, Short.parseShort(SMSPort),
												cabinetName, Short.parseShort(volumeID), FullPath.toString(), JPISDEC,
												"", ISINDEX);

										CustOutreachLog.KYCcustOutreachLogger
												.debug("after CPISDocumentTxn AddDocument MT: ");
										String sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
										CustOutreachLog.KYCcustOutreachLogger
												.debug("sISIndex after adding on SMS - " + sISIndex);
										String parentFolderIndex = getFolderIndex(WINAME);
										String comment = cif + "_" + fileNameWithoutExt;
										if("KYC Form".equalsIgnoreCase(DocumentType))
											comment = cif + "_KYC Form Updated";
										StringBuffer ipXMLBuffer = new StringBuffer();

										ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
										ipXMLBuffer.append("<NGOAddDocument_Input>\n");
										ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
										ipXMLBuffer.append("<CabinetName>");
										ipXMLBuffer.append(cabinetName);
										ipXMLBuffer.append("</CabinetName>\n");
										ipXMLBuffer.append("<UserDBId>");
										ipXMLBuffer.append(sessionID);
										ipXMLBuffer.append("</UserDBId>\n");
										ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
										ipXMLBuffer.append("<Document>\n");
										ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
										ipXMLBuffer.append("<ParentFolderIndex>");
										ipXMLBuffer.append(parentFolderIndex);
										ipXMLBuffer.append("</ParentFolderIndex>\n");
										ipXMLBuffer.append("<DocumentName>");
										ipXMLBuffer.append(DocumentType);
										ipXMLBuffer.append("</DocumentName>\n");
										ipXMLBuffer.append("<VolumeIndex>");
										ipXMLBuffer.append(volumeID);
										ipXMLBuffer.append("</VolumeIndex>\n");
										ipXMLBuffer.append("<ISIndex>");
										ipXMLBuffer.append(sISIndex);
										ipXMLBuffer.append("</ISIndex>\n");
										/*
										 * ipXMLBuffer.append("<NoOfPages>");
										 * ipXMLBuffer.append(NoOfPages);
										 * ipXMLBuffer.append("</NoOfPages>\n");
										 */
										ipXMLBuffer.append("<DocumentType>");
										ipXMLBuffer.append("N");
										ipXMLBuffer.append("</DocumentType>\n");
										ipXMLBuffer.append("<Comment>");
										ipXMLBuffer.append(comment);
										ipXMLBuffer.append("</Comment>\n");
										ipXMLBuffer.append("<DocumentSize>");
										ipXMLBuffer.append(size);
										ipXMLBuffer.append("</DocumentSize>\n");
										ipXMLBuffer.append("<CreatedByAppName>");
										ipXMLBuffer.append(createdByAppName);
										ipXMLBuffer.append("</CreatedByAppName>\n");
										ipXMLBuffer.append("</Document>\n");
										ipXMLBuffer.append("</NGOAddDocument_Input>\n");
										String NGOaddDocInputXML = ipXMLBuffer.toString();
										CustOutreachLog.KYCcustOutreachLogger
												.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
										String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML, jtsIP,
												jtsPort, 1);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);

										XMLParser xmlParserAddDoc = new XMLParser(NGOaddDocOutXml);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("xmlParserAddDoc--- " + xmlParserAddDoc);
										String addDocMainCode = xmlParserAddDoc.getValueOf("Status");
										CustOutreachLog.KYCcustOutreachLogger
												.debug("addDocMainCode--- " + addDocMainCode);
										if (addDocMainCode.equalsIgnoreCase("0")) {
											String DocName = "";
											CustOutreachLog.KYCcustOutreachLogger
													.debug("Document " + fileName + " added successfully");
											if (DocumentType.equalsIgnoreCase("Others")) {
												DocName = fileNameWithoutExt.substring(7);
											} else if (DocumentType.equalsIgnoreCase("Additional Documents")) {
												DocName = fileNameWithoutExt.substring(21);
											} else {
												DocName = fileNameWithoutExt;
											}
											updateUploadFlag(WINAME, "Y", DocName);
											Date d = new Date();
											SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
											String strDate = dateFormat.format(d);
											strDate = strDate.replaceAll("-", "");
											String targetPath = SuccessPath + File.separator + WINAME + strDate;
											moveFile(FullPath, targetPath, fileName);
										} else {
											String DocName = "";
											if (DocumentType.equalsIgnoreCase("Others")) {
												DocName = fileNameWithoutExt.substring(7);
											} else if (DocumentType.equalsIgnoreCase("Additional Documents")) {
												DocName = fileNameWithoutExt.substring(21);
											} else {
												DocName = fileNameWithoutExt;
											}
											CustOutreachLog.KYCcustOutreachLogger.debug("Error in adding Document--> "
													+ fileName + " in AddDocument Call.");
											updateUploadFlag(WINAME, "N", fileNameWithoutExt);
											Date d = new Date();
											SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
											String strDate = dateFormat.format(d);
											strDate = strDate.replaceAll("-", "");
											String targetPath = ErrorPath + File.separator + WINAME + strDate;
											moveFile(FullPath, targetPath, fileName);
										}
									} catch (JPISException e) {
										CustOutreachLog.KYCcustOutreachLogger.debug("Inside exception--" + e);
										final Writer result1 = new StringWriter();
										final PrintWriter printWriter = new PrintWriter(result1);
										e.printStackTrace(printWriter);
										String msg = e.getMessage();
										boolean status = false;
										e.printStackTrace();
									}
								}
							}
							DoneWI(WINAME, "DocsAttached", OutreachupdateDateTime, CURRENT_WS, CaseType, cif, socketDetailsMap,
									OutreachDocFlag, outreachFlag, prefAddress, OfficeAddressLine1, OfficeCountry,
									OfficeCityEmirate, ResidenceFlatVillaNo, ResidenceCountry, ResidenceEmirateCity,
									RiskProfile,WICategory,ProfileChange,DocumentUpload,OfficeEmployerNameDesc,AutoRRCStatus,EMPLOYER_CHANGE,"","");
							DocsList.clear();
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Documents not found in " + WINAME + "folder");
							boolean status = HoursPassed(OutreachupdateDateTime);
							if (status)
								DoneWI(WINAME, "NoDocument", OutreachupdateDateTime, CURRENT_WS, CaseType, cif,
										socketDetailsMap, OutreachDocFlag, outreachFlag, prefAddress,
										OfficeAddressLine1, OfficeCountry, OfficeCityEmirate, ResidenceFlatVillaNo,
										ResidenceCountry, ResidenceEmirateCity, RiskProfile,WICategory,ProfileChange,DocumentUpload,OfficeEmployerNameDesc,AutoRRCStatus,EMPLOYER_CHANGE,"","");
							DocsList.clear();
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Directory does not exist for --" + WINAME);
						boolean status = HoursPassed(OutreachupdateDateTime);
						if (status)
							DoneWI(WINAME, "FolderNotPresent", OutreachupdateDateTime, CURRENT_WS, CaseType, cif,
									socketDetailsMap, OutreachDocFlag, outreachFlag, prefAddress, OfficeAddressLine1,
									OfficeCountry, OfficeCityEmirate, ResidenceFlatVillaNo, ResidenceCountry,
									ResidenceEmirateCity, RiskProfile,WICategory,ProfileChange,DocumentUpload,OfficeEmployerNameDesc,AutoRRCStatus,EMPLOYER_CHANGE,"","");
						DocsList.clear();
					}

				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("OutreachDocumentFlag is 0:" + OutreachDocFlag);
					DoneWI(WINAME, "NoFilesUploadedByBO", OutreachupdateDateTime, CURRENT_WS, CaseType, cif,
							socketDetailsMap, OutreachDocFlag, outreachFlag, prefAddress, OfficeAddressLine1,
							OfficeCountry, OfficeCityEmirate, ResidenceFlatVillaNo, ResidenceCountry,
							ResidenceEmirateCity, RiskProfile,WICategory,ProfileChange,DocumentUpload,OfficeEmployerNameDesc,AutoRRCStatus,EMPLOYER_CHANGE,"","");
					DocsList.clear();
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in startUtilityCustOutreach --" + e.getMessage());
		}
		File parentFolderSuccess = new File(SuccessPath);
		File parentfolderInput = new File(OutreachDocPath);
		try {
			checkAndDelete(parentFolderSuccess);
			checkAndDelete(parentfolderInput);
		} catch (IOException e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkAndDelete method.");
			e.printStackTrace();
		}
	}

	private String safe(String value) {
	    return value == null ? "" : value;
	}

	private String getWIList(){
		StringBuilder htmlTable = new StringBuilder();
		try {
			htmlTable.append("<table border='1' cellpadding='6' cellspacing='0' ")
			         .append("style='border-collapse: collapse; margin-top: 10px;'>")
			         .append("<tr>")
			         .append("<th>Entry Date Time</th>")
			         .append("<th>WI No</th>")
			         .append("<th>CIF No</th>")
			         .append("<th>Type</th>")
			         .append("<th>Reason for failure</th>")
			         .append("<th>Ageing</th>")
			         .append("<th>Customer Segment</th>")
			         .append("<th>Customer Sub Segment</th>")
			         .append("</tr>");

			String query = "SELECT EntryAt, WINAME, CIF_ID, caseType, FAILURE_REASON, "
			              + "DATEDIFF(DAY, EntryAt, GETDATE()) AS Aging,Segment,Sub_Segment "
			              + "FROM RB_KYC_REM_EXTTABLE WITH (NOLOCK) "
			              + "WHERE CURRENT_WS = 'Consequence_Manual' "
			              + "AND CaseType NOT IN ('RelatedParty')";

			List<Map<String, String>> dataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);

			for (Map<String, String> entry : dataFromDB) {
			    String entryAt = safe(entry.get("EntryAt"));
			    String wiName = safe(entry.get("WINAME"));
			    String cifId = safe(entry.get("CIF_ID"));
			    String caseType = safe(entry.get("caseType"));
			    String failureReason = safe(entry.get("FAILURE_REASON"));
			    String aging = safe(entry.get("Aging"));
			    String segment = safe(entry.get("Segment"));
			    String subSegment = safe(entry.get("Sub_Segment"));
			    
			    htmlTable.append("<tr>")
			             .append("<td>").append(entryAt).append("</td>")
			             .append("<td>").append(wiName).append("</td>")
			             .append("<td>").append(cifId).append("</td>")
			             .append("<td>").append(caseType).append("</td>")
			             .append("<td>").append(failureReason).append("</td>")
			             .append("<td>").append(aging).append("</td>")
			             .append("<td>").append(segment).append("</td>")
			             .append("<td>").append(subSegment).append("</td>")
			             .append("</tr>");
			}
			htmlTable.append("</table>");
			return htmlTable.toString();
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendreminder method---" + e.getMessage());
		}
		return htmlTable.toString();
	}
	
	private String getWIListPostOutreachPending(){ // byVar
		StringBuilder htmlTable = new StringBuilder();
		try {
			htmlTable.append("<table border='1' cellpadding='6' cellspacing='0' ")
			         .append("style='border-collapse: collapse; margin-top: 10px;'>")
			         .append("<tr>")
					 .append("<th>WI number</th>")					 
			         .append("<th>Completion timestamp</th>")
			         .append("<th>Segment</th>")			         
			         .append("</tr>");

			String query1 = "Select WINAME,OutreachStatusUpdateDateTime from RB_KYC_REM_EXTTABLE e with (nolock) JOIN WFINSTRUMENTTABLE WF ON e.WINAME = WF.processInstanceID WHERE WF.Statename != 'SUSPENDED' AND (((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND (Prev_Dec = 'Customer Outreach' OR Prev_Dec = 'Re-Integrate') AND (Prev_WS = 'Maker' OR Prev_WS = 'Maker2' OR Prev_WS = 'RM_Vendor' OR Prev_WS = 'Doc_Error_Handling')) OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Action Taken' AND Prev_WS = 'Consequence_Manual') OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Send to RM Vendor' AND Prev_WS = 'Consequence_Hold') OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Submit to RM Vendor' AND Prev_WS = 'Consequence') OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'Consequence' AND Prev_Dec = 'Send to KYC Consequence' AND Prev_WS = 'RM_Vendor') OR ((CustomerOutreachFlag = 'Completed' OR CustomerOutreachFlag = 'Negative Processed') AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Success' AND Prev_WS = 'Attach_Document') OR (CustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'Consequence_Hold' AND caseType = 'Individual' AND AUTO_CONSEQUENCE_STATUS = 'PENDING' AND Consequence_Status IN ('Fully Applied','Partial Applied'))) AND DATEADD(HOUR, "+completedCasesPendingForHours+", OutreachStatusUpdateDateTime) <= GETDATE()";
			
			String query2 = "Select WINAME,OutreachStatusUpdateDateTime from RB_KYC_REM_EXTTABLE e with (nolock) JOIN WFINSTRUMENTTABLE WF ON e.WINAME = WF.processInstanceID WHERE WF.Statename != 'SUSPENDED' AND caseType = 'Corporate 'AND ((BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Outreach to Portal' AND Prev_WS IN ('Maker','Maker2','RM_Vendor')) OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Success' AND Prev_WS = 'Attach_Document') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Re-Integrate' AND Prev_WS = 'Doc_Error_Handling') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Send to RM Vendor' AND Prev_WS = 'Consequence_Hold') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Action Taken' AND Prev_WS = 'Consequence_Manual') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'Consequence' AND Prev_Dec = 'Send to KYC Consequence' AND Prev_WS = 'RM_Vendor') OR (BBGCustomerOutreachFlag = 'Completed' AND Current_Ws = 'Consequence_Hold' AND CaseType = 'Corporate' AND OutreachStatusUpdateDateTime > '2026-04-19' AND AUTO_CONSEQUENCE_STATUS = 'PENDING' AND Consequence_Status IN ('Fully Applied','Partial Applied'))) AND DATEADD(HOUR, "+completedCasesPendingForHours+", OutreachStatusUpdateDateTime) <= GETDATE()";
			

			List<Map<String, String>> dataFromDB1 = getDataFromDBMap(query1, cabinetName, sessionID, jtsIP, jtsPort);
			List<Map<String, String>> dataFromDB2 = getDataFromDBMap(query2, cabinetName, sessionID, jtsIP, jtsPort);

			for (Map<String, String> entry : dataFromDB1) {
			    String OutreachStatusUpdateDateTime = safe(entry.get("OutreachStatusUpdateDateTime"));
			    String wiName = safe(entry.get("WINAME"));
			    String segment = "PBG";			    
			    
			    htmlTable.append("<tr>")
			             .append("<td>").append(wiName).append("</td>")
			             .append("<td>").append(OutreachStatusUpdateDateTime).append("</td>")
						 .append("<td>").append(segment).append("</td>")
			             .append("</tr>");
			}
			
			for (Map<String, String> entry : dataFromDB2) {
			    String OutreachStatusUpdateDateTime = safe(entry.get("OutreachStatusUpdateDateTime"));
			    String wiName = safe(entry.get("WINAME"));
			    String segment = "BBG";			    
			    
			    htmlTable.append("<tr>")
			             .append("<td>").append(wiName).append("</td>")
			             .append("<td>").append(OutreachStatusUpdateDateTime).append("</td>")
						 .append("<td>").append(segment).append("</td>")
			             .append("</tr>");
			}
			
			htmlTable.append("</table>");
			return htmlTable.toString();

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendreminder method---" + e.getMessage());
		}
		
		return htmlTable.toString();
	}
	

	private void sendMailConsequenceFailedCases() {
		try {
			LocalTime now = LocalTime.now(); 
			LocalTime sixPm = LocalTime.of(18, 0); // 9:00 PM
			if(now.isAfter(sixPm)){
				if(!checkMailSentToday())
				{
					String wiList = getWIList();
					String Query1 = "SELECT Type,Subject,Content,FomEmail,CCEmail FROM NG_KYC_REM_EMAIL_TEMPLATE WITH (NOLOCK) WHERE Type = 'Consequence_Manual'";
					String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
					String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
					XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
					String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
					int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
					if (dataMainCode.equals("0") && dataTotalRecords > 0) {
						String mailFrom = dataxmlParserAPSelect.getValueOf("FomEmail");
						String mailTo = dataxmlParserAPSelect.getValueOf("CCEmail");
						//String mailCC = dataxmlParserAPSelect.getValueOf("mailCC");
						String mailSubject = dataxmlParserAPSelect.getValueOf("Subject");
						String mailMessage = dataxmlParserAPSelect.getValueOf("Content");
						mailMessage = mailMessage.replaceAll("#WIList#", wiList);
						mailMessage = mailMessage.replaceAll("'", "''");
						String mailContentType = "text/html;charset=UTF-8";
						String workItemID = "1";
						//String activityID = dataxmlParserAPSelect.getValueOf("activityID");
						String mailPriority = "1";
						String mailStatus = "N";
						String insertedBy = "system";
						String mailActionType = "Trigger";
						//String processinstanceID = WINAME;
						String noOfTrials = "0";
		
						String tableName = "WFMAILQUEUETABLE";
						String columnName = "mailFrom,mailTo,mailSubject,mailMessage,"
								+ "mailContentType,mailPriority,mailStatus,insertedBy,mailActionType,"
								+ "noOfTrials,insertedTime";
		
						String values = "'" + mailFrom + "','" + mailTo + "','" + mailSubject + "',N'"
								+ mailMessage + "','" + mailContentType + "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','" + mailActionType
								+ "','" + noOfTrials + "',getDate()";
		
						String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
						CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);
		
						String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);
		
						XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
						CustOutreachLog.KYCcustOutreachLogger.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
						String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
						if (apInsertMaincode.equalsIgnoreCase("0")) {
							CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
							CustOutreachLog.KYCcustOutreachLogger.debug("Data Inserted in wfmailqueue table successfully for sending consequence manual mail.");
							String columnNameNG_KYC_REM_Variable_TABLE = "Value";
							String today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
							String value = "'"+today+"'";
							String whereClause = "Variable = 'ConsequenceManualMailSentOn'";
							String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"NG_KYC_REM_Variable_TABLE", columnNameNG_KYC_REM_Variable_TABLE, value, whereClause);
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
							String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
							XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
							String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
							if (apUpdateMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("ConsequenceManualMailSentOn updated");
								CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML for updating ConsequenceManualMailSentOn: " + apUpdateOutputXML);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert not successful: " + apInsertMaincode);
						}
					}
				}
			}
			else{
				CustOutreachLog.KYCcustOutreachLogger.debug("Time is not after six pm");
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendMailConsequenceFailedCases method---" + e.getMessage());
		}
		
	}

	private void sendMailPendingCases(){ // byVar

		try {
			LocalTime now = LocalTime.now(); 
			LocalTime eigthAM = LocalTime.of(8, 0);
			LocalTime threePM = LocalTime.of(15, 0);
			if( (now.isAfter(eigthAM) && !checkMailSentAfterTime("8")) || (now.isAfter(threePM) && !checkMailSentAfterTime("3")) ){
				{
					String wiList = getWIListPostOutreachPending();
					String Query1 = "SELECT Type,Subject,Content,FomEmail,CCEmail FROM NG_KYC_REM_EMAIL_TEMPLATE WITH (NOLOCK) WHERE Type = 'PostOutreachPending'";
					String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
					String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : " + dataOutputXML);
					XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
					String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
					int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
					if (dataMainCode.equals("0") && dataTotalRecords > 0) {
						String mailFrom = dataxmlParserAPSelect.getValueOf("FomEmail");
						String mailTo = dataxmlParserAPSelect.getValueOf("CCEmail").split("~")[0].substring(3);
						String mailCC = dataxmlParserAPSelect.getValueOf("CCEmail").split("~")[1].substring(3);
						String mailSubject = dataxmlParserAPSelect.getValueOf("Subject");
						String mailMessage = dataxmlParserAPSelect.getValueOf("Content");
						mailMessage = mailMessage.replaceAll("#WIList#", wiList);
						mailMessage = mailMessage.replaceAll("'", "''");
						String mailContentType = "text/html;charset=UTF-8";
						String workItemID = "1";
						String mailPriority = "1";
						String mailStatus = "N";
						String insertedBy = "system";
						String mailActionType = "Trigger";
						String noOfTrials = "0";
		
						String tableName = "WFMAILQUEUETABLE";
						String columnName = "mailFrom,mailTo,mailCC,mailSubject,mailMessage,"
								+ "mailContentType,mailPriority,mailStatus,insertedBy,mailActionType,"
								+ "noOfTrials,insertedTime";
		
						String values = "'" + mailFrom + "','" + mailTo + "','" +mailCC + "','"+ mailSubject + "',N'"
								+ mailMessage + "','" + mailContentType + "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','" + mailActionType
								+ "','" + noOfTrials + "',getDate()";
		
						String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
						CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);
		
						String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);
		
						XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
						CustOutreachLog.KYCcustOutreachLogger.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
						String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
						if (apInsertMaincode.equalsIgnoreCase("0")) {
							CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
							CustOutreachLog.KYCcustOutreachLogger.debug("Data Inserted in wfmailqueue table successfully for sending consequence manual mail.");
							String columnNameNG_KYC_REM_Variable_TABLE = "Value";
							String currentDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
							String value = "'" + currentDateTime + "'";
							
							String whereClause = "Variable = 'PostOutreachPendingMailSentOn'";
							String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,"NG_KYC_REM_Variable_TABLE", columnNameNG_KYC_REM_Variable_TABLE, value, whereClause);
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
							String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
							XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
							String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
							if (apUpdateMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("PostOutreachPendingMailSentOn updated");
								CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML for updating PostOutreachPendingMailSentOn: " + apUpdateOutputXML);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert not successful: " + apInsertMaincode);
						}
					}
				}
			}
			else{
				CustOutreachLog.KYCcustOutreachLogger.debug("Time is not after six pm");
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendMailConsequenceFailedCases method---" + e.getMessage());
		}

	}

	/*private boolean checkMailSentToday() {
		try{
			String query = "SELECT Value from NG_KYC_REM_Variable_TABLE WITH (NOLOCK) WHERE Variable = 'ConsequenceManualMailSentOn'";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				String sentOn = dataxmlParserAPSelect.getValueOf("Value");
				if(!"".equalsIgnoreCase(sentOn))
				{
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDateTime entryDateTime = LocalDateTime.parse(sentOn, formatter);
					// Convert to date only
					LocalDate entryDate = entryDateTime.toLocalDate();
					LocalDate today = LocalDate.now();
					return entryDate.isEqual(today);
				}
			}
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkMailSentToday method---" + e.getMessage());
		}
		return false;
	}*/
	
	private boolean checkMailSentToday() {
	    try {
	        CustOutreachLog.KYCcustOutreachLogger.debug("Inside checkMailSentToday method......");
	        String query = "SELECT Value FROM NG_KYC_REM_Variable_TABLE WITH (NOLOCK) WHERE Variable = 'ConsequenceManualMailSentOn'";
	        String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
	        String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);

	        CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB: " + dataOutputXML);

	        XMLParser parser = new XMLParser(dataOutputXML);
	        String mainCode = parser.getValueOf("MainCode");
	        int totalRecords = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

	        if ("0".equals(mainCode) && totalRecords > 0) {
	            String sentOn = parser.getValueOf("Value");
		        CustOutreachLog.KYCcustOutreachLogger.debug("sentOn - "+sentOn);
	            if (sentOn != null && !sentOn.isEmpty()) {
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	                LocalDate entryDate = LocalDate.parse(sentOn, formatter);
	                LocalDate today = LocalDate.now();

	                return entryDate.isEqual(today);
	            }
	        }
	    } catch (Exception e) {
	        CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkMailSentToday: " + e.getMessage());
	    }

	    return false;
	}
	
	private boolean checkMailSentAfterTime(String time) {
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside checkMailSentAfterTime method......");

			String query = "SELECT Value FROM NG_KYC_REM_Variable_TABLE WITH (NOLOCK) WHERE Variable = 'PostOutreachPendingMailSentOn'";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);

			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB: " + dataOutputXML);

			XMLParser parser = new XMLParser(dataOutputXML);
			String mainCode = parser.getValueOf("MainCode");
			int totalRecords = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

			if ("0".equals(mainCode) && totalRecords > 0) {
				String sentOn = parser.getValueOf("Value");
				CustOutreachLog.KYCcustOutreachLogger.debug("sentOn - " + sentOn);

				if (sentOn != null && !sentOn.isEmpty()) {

					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
					LocalDateTime entryDateTime = LocalDateTime.parse(sentOn, formatter);

					LocalDate today = LocalDate.now();

					LocalDateTime thresholdDateTime;

					if ("8".equals(time)) {
						thresholdDateTime = today.atTime(8, 0);   // 8 AM today
					} else if ("3".equals(time)) {
						thresholdDateTime = today.atTime(15, 0);  // 3 PM today
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Invalid time parameter: " + time);
						return false;
					}

					return entryDateTime.isAfter(thresholdDateTime);
				}
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkMailSentAfter: " + e.getMessage());
		}

		return false;
	}


	private void ProcessBBGPortalReturnCases(HashMap<String, String> socketDetailsMap) {
		try {
			String Query = "Select CIF_ID,WINAME,OutreachStatusUpdateDateTime,CURRENT_WS,CaseType,OutreachDocumentFlag,"
					+ "BBGCustomerOutreachFlag,CompanyPreferredAddress,CompanyofficeShopNo,CompanyEmirateCity,CompanyCountry,"
					+ "EntityRiskProfile,ProfileChange,DocumentUpload,AutoRRCStatus,DeclineFlag,BBG_NSTP_Remark from RB_KYC_REM_EXTTABLE e "
					+ "with (nolock) JOIN WFINSTRUMENTTABLE WF ON e.WINAME = WF.processInstanceID WHERE WF.Statename != 'SUSPENDED' "
					+ "AND caseType = 'Corporate 'AND (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Outreach to Portal' "
					+ "AND Prev_WS IN ('Maker','Maker2','RM_Vendor')) OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Success' "
					+ "AND Prev_WS = 'Attach_Document') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Re-Integrate' "
					+ "AND Prev_WS = 'Doc_Error_Handling') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Send to RM Vendor' "
					+ "AND Prev_WS = 'Consequence_Hold') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'RM_Vendor' AND Prev_Dec = 'Action Taken' "
					+ "AND Prev_WS = 'Consequence_Manual') OR (BBGCustomerOutreachFlag = 'Completed' AND CURRENT_WS = 'Consequence' AND Prev_Dec = 'Send to KYC Consequence' "
					+ "AND Prev_WS = 'RM_Vendor') OR (BBGCustomerOutreachFlag = 'Completed' AND Current_Ws = 'Consequence_Hold' AND CaseType = 'Corporate' "
					+ "AND OutreachStatusUpdateDateTime > '2026-04-19' AND AUTO_CONSEQUENCE_STATUS = 'PENDING' AND Consequence_Status IN ('Fully Applied','Partial Applied'))";

			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				String cif = entry.get("CIF_ID");
				String WINAME = entry.get("WINAME");
				CustOutreachLog.KYCcustOutreachLogger.debug("WINAME FETCHED-->" + WINAME);
				String CURRENT_WS = entry.get("CURRENT_WS");
				String OutreachupdateDateTime = entry.get("OutreachStatusUpdateDateTime");
				String CaseType = entry.get("CaseType");
				String OutreachDocFlag = entry.get("OutreachDocumentFlag");
				String outreachFlag = entry.get("CustomerOutreachFlag");
				String prefAddress = entry.get("CompanyPreferredAddress");
				String CompanyofficeShopNo = entry.get("CompanyofficeShopNo");
				String CompanyEmirateCity = entry.get("CompanyEmirateCity");
				String CompanyCountry = entry.get("CompanyCountry");
				String EntityRiskProfile = entry.get("EntityRiskProfile");
				String ProfileChange = entry.get("ProfileChange");
				String DocumentUpload = entry.get("DocumentUpload");
				String AutoRRCStatus = entry.get("AutoRRCStatus");
				String DeclineFlag = entry.get("DeclineFlag");
				String Path = OutreachDocPath + File.separator + WINAME;
				Path targetDirectory = Paths.get(Path);
				String BBG_NSTP_Remark = entry.get("BBG_NSTP_Remark");
				CustOutreachLog.KYCcustOutreachLogger.debug("targetDirectory - " + targetDirectory);
				if (!"0".equalsIgnoreCase(OutreachDocFlag) && !"".equalsIgnoreCase(OutreachDocFlag)) {
					if (Files.exists(targetDirectory)) {
						File directory = new File(Path);
						File[] files = directory.listFiles();
						int length = files.length;
						if("".equalsIgnoreCase(OutreachDocFlag)) OutreachDocFlag = "0";
						CustOutreachLog.KYCcustOutreachLogger.debug("Length - " + length);
						CustOutreachLog.KYCcustOutreachLogger.debug("OutreachDocFlag - " + OutreachDocFlag);
						if (length >= Integer.parseInt(OutreachDocFlag)) {
							for (File file : files) {
								if (file.isFile()) {
									String fileName = file.getName();
									//String fileNameWithoutExt = fileName.substring(0, fileName.lastIndexOf("."));
									CustOutreachLog.KYCcustOutreachLogger.debug("Document processing-->" + file.getName());
									String size = String.valueOf(file.length());
									String ext = fileName.substring(fileName.lastIndexOf("."), fileName.length());
									String createdByAppName = ext.replaceFirst(".", "");
									String comment = "";
									String parentFolderIndex = "";
									boolean isCIF = false;
									String RP_WInumber = "";
									//----18/06/2026---start
									//String DocumentType = "Additional Documents";
									String DocumentType = "";
									//----18/06/2026---end
									if(fileName.contains("^")){
										String splitDocType[] = fileName.split("\\^");
										if(splitDocType.length==2){
											if (DocTypes.contains(splitDocType[1].substring(0, splitDocType[1].lastIndexOf(".")))) {
												DocumentType = splitDocType[1].substring(0, splitDocType[1].lastIndexOf("."));
												comment = splitDocType[0]+"_"+splitDocType[1];
												if("KYC Form".equalsIgnoreCase(DocumentType))
													comment = splitDocType[0] + "_KYC Form Updated";
											}
											//parentFolderIndex = getFolderIndex(WINAME);
										}
										else if(splitDocType.length==3){
											if (DocTypes.contains(splitDocType[2].substring(0, splitDocType[2].lastIndexOf(".")))) {
												DocumentType = splitDocType[2].substring(0, splitDocType[2].lastIndexOf("."));
												comment = splitDocType[1]+"_"+splitDocType[2];
												if("KYC Form".equalsIgnoreCase(DocumentType))
													comment = splitDocType[1] + "_KYC Form Updated";
											}
											isCIF = isCIF(splitDocType[1]);
											//now find out its related party WI
											if(isCIF){
												RP_WInumber = findRPWINumber(splitDocType[1],WINAME);
												//parentFolderIndex = getFolderIndex(RP_WInumber);
											}
											//if not cif
											//else parentFolderIndex = getFolderIndex(WINAME);
										}
									}
									else{
										CustOutreachLog.KYCcustOutreachLogger.debug("skipping doc "+fileName+" as it is not as per agreed naming convention....");
										continue;
									}
									String FullPath = Path + File.separator + fileName;
									parentFolderIndex = getFolderIndex(WINAME);
									JPISIsIndex ISINDEX = new JPISIsIndex();
									JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
									CustOutreachLog.KYCcustOutreachLogger.debug("trying to add doc on image server");
									try{
										CustOutreachLog.KYCcustOutreachLogger.debug("Values passed -- >jtsip-" + jtsIP
												+ " , jtsPort->" + jtsPort + ",cabinetName->" + cabinetName
												+ ",volumeID->" + volumeID + ", File path-->" + FullPath);
										CPISDocumentTxn.AddDocument_MT(null, jtsIP, Short.parseShort(SMSPort),
												cabinetName, Short.parseShort(volumeID), FullPath.toString(), JPISDEC,
												"", ISINDEX);

										CustOutreachLog.KYCcustOutreachLogger
												.debug("after CPISDocumentTxn AddDocument MT: ");
										String sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
										CustOutreachLog.KYCcustOutreachLogger
												.debug("sISIndex after adding on SMS - " + sISIndex);
										
										
										//String parentFolderIndex = getFolderIndex(WINAME);
										
										StringBuffer ipXMLBuffer = new StringBuffer();

										ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
										ipXMLBuffer.append("<NGOAddDocument_Input>\n");
										ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
										ipXMLBuffer.append("<CabinetName>");
										ipXMLBuffer.append(cabinetName);
										ipXMLBuffer.append("</CabinetName>\n");
										ipXMLBuffer.append("<UserDBId>");
										ipXMLBuffer.append(sessionID);
										ipXMLBuffer.append("</UserDBId>\n");
										ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
										ipXMLBuffer.append("<Document>\n");
										ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
										ipXMLBuffer.append("<ParentFolderIndex>");
										ipXMLBuffer.append(parentFolderIndex);
										ipXMLBuffer.append("</ParentFolderIndex>\n");
										ipXMLBuffer.append("<DocumentName>");
										ipXMLBuffer.append(DocumentType);
										ipXMLBuffer.append("</DocumentName>\n");
										ipXMLBuffer.append("<VolumeIndex>");
										ipXMLBuffer.append(volumeID);
										ipXMLBuffer.append("</VolumeIndex>\n");
										ipXMLBuffer.append("<ISIndex>");
										ipXMLBuffer.append(sISIndex);
										ipXMLBuffer.append("</ISIndex>\n");
										ipXMLBuffer.append("<DocumentType>");
										ipXMLBuffer.append("N");
										ipXMLBuffer.append("</DocumentType>\n");
										ipXMLBuffer.append("<Comment>");
										ipXMLBuffer.append(comment);
										ipXMLBuffer.append("</Comment>\n");
										ipXMLBuffer.append("<DocumentSize>");
										ipXMLBuffer.append(size);
										ipXMLBuffer.append("</DocumentSize>\n");
										ipXMLBuffer.append("<CreatedByAppName>");
										ipXMLBuffer.append(createdByAppName);
										ipXMLBuffer.append("</CreatedByAppName>\n");
										ipXMLBuffer.append("</Document>\n");
										ipXMLBuffer.append("</NGOAddDocument_Input>\n");
										String NGOaddDocInputXML = ipXMLBuffer.toString();
										CustOutreachLog.KYCcustOutreachLogger
												.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
										String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML, jtsIP,
												jtsPort, 1);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);

										XMLParser xmlParserAddDoc = new XMLParser(NGOaddDocOutXml);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("xmlParserAddDoc--- " + xmlParserAddDoc);
										String addDocMainCode = xmlParserAddDoc.getValueOf("Status");
										CustOutreachLog.KYCcustOutreachLogger
												.debug("addDocMainCode--- " + addDocMainCode);
										if (addDocMainCode.equalsIgnoreCase("0")) 
										{
											CustOutreachLog.KYCcustOutreachLogger.debug("Document " + fileName + " added successfully");
											if(isCIF) updateUploadFlag(RP_WInumber, "Y", DocumentType);
											else updateUploadFlag(WINAME, "Y", DocumentType);
											Date d = new Date();
											SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
											String strDate = dateFormat.format(d);
											strDate = strDate.replaceAll("-", "");
											String targetPath = SuccessPath + File.separator + WINAME + strDate;
											moveFile(FullPath, targetPath, fileName);
										} else {
											Date d = new Date();
											SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
											String strDate = dateFormat.format(d);
											strDate = strDate.replaceAll("-", "");
											String targetPath = ErrorPath + File.separator + WINAME + strDate;
											moveFile(FullPath, targetPath, fileName);
										}
										
									}catch (JPISException e) {
										CustOutreachLog.KYCcustOutreachLogger.debug("Inside exception--" + e);
										final Writer result1 = new StringWriter();
										final PrintWriter printWriter = new PrintWriter(result1);
										e.printStackTrace(printWriter);
										String msg = e.getMessage();
										boolean status = false;
										e.printStackTrace();
									}
								}
							}
							//done WI to be done after for loop
							DoneWI(WINAME, "DocsAttached", OutreachupdateDateTime, CURRENT_WS, CaseType, cif, socketDetailsMap,
									OutreachDocFlag, outreachFlag, prefAddress, CompanyofficeShopNo, CompanyCountry,
									CompanyEmirateCity, "", "", "",EntityRiskProfile,"",ProfileChange,DocumentUpload,
									"",AutoRRCStatus,"",DeclineFlag,BBG_NSTP_Remark);
							DocsList.clear();
						}else
						{
							CustOutreachLog.KYCcustOutreachLogger.debug("outreach Doc flag value and doc received is not same");
							boolean status = HoursPassed(OutreachupdateDateTime);
							if (status)
							{
								//change for doc count 5 feb 2026
								for (File file : files) {
									if (file.isFile()) {
										String fileName = file.getName();
										//String fileNameWithoutExt = fileName.substring(0, fileName.lastIndexOf("."));
										CustOutreachLog.KYCcustOutreachLogger.debug("Document processing-->" + file.getName());
										String size = String.valueOf(file.length());
										String ext = fileName.substring(fileName.lastIndexOf("."), fileName.length());
										String createdByAppName = ext.replaceFirst(".", "");
										String comment = "";
										String parentFolderIndex = "";
										boolean isCIF = false;
										String RP_WInumber = "";
										//String DocumentType = "Additional Documents";
										String DocumentType = "";
										if(fileName.contains("^")){
											String splitDocType[] = fileName.split("\\^");
											if(splitDocType.length==2){
												if (DocTypes.contains(splitDocType[1].substring(0, splitDocType[1].lastIndexOf(".")))) {
													DocumentType = splitDocType[1].substring(0, splitDocType[1].lastIndexOf("."));
													comment = splitDocType[0]+"_"+splitDocType[1];
													if("KYC Form".equalsIgnoreCase(DocumentType))
														comment = splitDocType[0] + "_KYC Form Updated";
												}
												//parentFolderIndex = getFolderIndex(WINAME);
											}
											else if(splitDocType.length==3){
												if (DocTypes.contains(splitDocType[2].substring(0, splitDocType[2].lastIndexOf(".")))) {
													DocumentType = splitDocType[2].substring(0, splitDocType[2].lastIndexOf("."));
													comment = splitDocType[1]+"_"+splitDocType[2];
													if("KYC Form".equalsIgnoreCase(DocumentType))
														comment = splitDocType[1] + "_KYC Form Updated";
												}
												isCIF = isCIF(splitDocType[1]);
												//now find out its related party WI
												if(isCIF){
													RP_WInumber = findRPWINumber(splitDocType[1],WINAME);
													//parentFolderIndex = getFolderIndex(RP_WInumber);
												}
												//if not cif
												//else parentFolderIndex = getFolderIndex(WINAME);
											}
										}
										else{
											CustOutreachLog.KYCcustOutreachLogger.debug("skipping doc "+fileName+" as it is not as per agreed naming convention....");
											continue;
										}
										String FullPath = Path + File.separator + fileName;
										parentFolderIndex = getFolderIndex(WINAME);
										JPISIsIndex ISINDEX = new JPISIsIndex();
										JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
										CustOutreachLog.KYCcustOutreachLogger.debug("trying to add doc on image server");
										try{
											CustOutreachLog.KYCcustOutreachLogger.debug("Values passed -- >jtsip-" + jtsIP
													+ " , jtsPort->" + jtsPort + ",cabinetName->" + cabinetName
													+ ",volumeID->" + volumeID + ", File path-->" + FullPath);
											CPISDocumentTxn.AddDocument_MT(null, jtsIP, Short.parseShort(SMSPort),
													cabinetName, Short.parseShort(volumeID), FullPath.toString(), JPISDEC,
													"", ISINDEX);

											CustOutreachLog.KYCcustOutreachLogger
													.debug("after CPISDocumentTxn AddDocument MT: ");
											String sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
											CustOutreachLog.KYCcustOutreachLogger
													.debug("sISIndex after adding on SMS - " + sISIndex);
											
											
											//String parentFolderIndex = getFolderIndex(WINAME);
											
											StringBuffer ipXMLBuffer = new StringBuffer();

											ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
											ipXMLBuffer.append("<NGOAddDocument_Input>\n");
											ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
											ipXMLBuffer.append("<CabinetName>");
											ipXMLBuffer.append(cabinetName);
											ipXMLBuffer.append("</CabinetName>\n");
											ipXMLBuffer.append("<UserDBId>");
											ipXMLBuffer.append(sessionID);
											ipXMLBuffer.append("</UserDBId>\n");
											ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
											ipXMLBuffer.append("<Document>\n");
											ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
											ipXMLBuffer.append("<ParentFolderIndex>");
											ipXMLBuffer.append(parentFolderIndex);
											ipXMLBuffer.append("</ParentFolderIndex>\n");
											ipXMLBuffer.append("<DocumentName>");
											ipXMLBuffer.append(DocumentType);
											ipXMLBuffer.append("</DocumentName>\n");
											ipXMLBuffer.append("<VolumeIndex>");
											ipXMLBuffer.append(volumeID);
											ipXMLBuffer.append("</VolumeIndex>\n");
											ipXMLBuffer.append("<ISIndex>");
											ipXMLBuffer.append(sISIndex);
											ipXMLBuffer.append("</ISIndex>\n");
											ipXMLBuffer.append("<DocumentType>");
											ipXMLBuffer.append("N");
											ipXMLBuffer.append("</DocumentType>\n");
											ipXMLBuffer.append("<Comment>");
											ipXMLBuffer.append(comment);
											ipXMLBuffer.append("</Comment>\n");
											ipXMLBuffer.append("<DocumentSize>");
											ipXMLBuffer.append(size);
											ipXMLBuffer.append("</DocumentSize>\n");
											ipXMLBuffer.append("<CreatedByAppName>");
											ipXMLBuffer.append(createdByAppName);
											ipXMLBuffer.append("</CreatedByAppName>\n");
											ipXMLBuffer.append("</Document>\n");
											ipXMLBuffer.append("</NGOAddDocument_Input>\n");
											String NGOaddDocInputXML = ipXMLBuffer.toString();
											CustOutreachLog.KYCcustOutreachLogger
													.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
											String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML, jtsIP,
													jtsPort, 1);
											CustOutreachLog.KYCcustOutreachLogger
													.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);

											XMLParser xmlParserAddDoc = new XMLParser(NGOaddDocOutXml);
											CustOutreachLog.KYCcustOutreachLogger
													.debug("xmlParserAddDoc--- " + xmlParserAddDoc);
											String addDocMainCode = xmlParserAddDoc.getValueOf("Status");
											CustOutreachLog.KYCcustOutreachLogger
													.debug("addDocMainCode--- " + addDocMainCode);
											if (addDocMainCode.equalsIgnoreCase("0")) 
											{
												CustOutreachLog.KYCcustOutreachLogger.debug("Document " + fileName + " added successfully");
												if(isCIF) updateUploadFlag(RP_WInumber, "Y", DocumentType);
												else updateUploadFlag(WINAME, "Y", DocumentType);
												Date d = new Date();
												SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
												String strDate = dateFormat.format(d);
												strDate = strDate.replaceAll("-", "");
												String targetPath = SuccessPath + File.separator + WINAME + strDate;
												moveFile(FullPath, targetPath, fileName);
											} else {
												Date d = new Date();
												SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
												String strDate = dateFormat.format(d);
												strDate = strDate.replaceAll("-", "");
												String targetPath = ErrorPath + File.separator + WINAME + strDate;
												moveFile(FullPath, targetPath, fileName);
											}
											
										}catch (JPISException e) {
											CustOutreachLog.KYCcustOutreachLogger.debug("Inside exception--" + e);
											final Writer result1 = new StringWriter();
											final PrintWriter printWriter = new PrintWriter(result1);
											e.printStackTrace(printWriter);
											String msg = e.getMessage();
											boolean status1 = false;
											e.printStackTrace();
										}
									}
								}
								//done WI to be done after for loop
								DoneWI(WINAME, "Not all Docs received.", OutreachupdateDateTime, CURRENT_WS, CaseType, cif, socketDetailsMap,
										OutreachDocFlag, outreachFlag, prefAddress, CompanyofficeShopNo, CompanyCountry,
										CompanyEmirateCity, "", "", "",EntityRiskProfile,"",ProfileChange,DocumentUpload,
										"",AutoRRCStatus,"",DeclineFlag,BBG_NSTP_Remark);
								DocsList.clear();
						}
								//Doc count change END
								/*DoneWI(WINAME, "NoDocument", OutreachupdateDateTime, CURRENT_WS, CaseType, cif, socketDetailsMap,
										OutreachDocFlag, outreachFlag, prefAddress, CompanyofficeShopNo, CompanyCountry,
										CompanyEmirateCity, "", "", "",EntityRiskProfile,"",ProfileChange,DocumentUpload,
										"",AutoRRCStatus,"",DeclineFlag,BBG_NSTP_Remark);
							DocsList.clear();*/
						}
					}else{
						CustOutreachLog.KYCcustOutreachLogger.debug("Directory does not exists for  " + WINAME);
						boolean status = HoursPassed(OutreachupdateDateTime);
						if (status)
							DoneWI(WINAME, "FolderNotPresent", OutreachupdateDateTime, CURRENT_WS, CaseType, cif, socketDetailsMap,
									OutreachDocFlag, outreachFlag, prefAddress, CompanyofficeShopNo, CompanyCountry,
									CompanyEmirateCity, "", "", "",EntityRiskProfile,"",ProfileChange,DocumentUpload,
									"",AutoRRCStatus,"",DeclineFlag,BBG_NSTP_Remark);
						DocsList.clear();
					}
				}else{
					//outreach doc flag is 0
					CustOutreachLog.KYCcustOutreachLogger.debug("OutreachDocumentFlag is 0:" + OutreachDocFlag);
					DoneWI(WINAME, "NoFilesUploadedByBO", OutreachupdateDateTime, CURRENT_WS, CaseType, cif, socketDetailsMap,
							OutreachDocFlag, outreachFlag, prefAddress, CompanyofficeShopNo, CompanyCountry,
							CompanyEmirateCity, "", "", "",EntityRiskProfile,"",ProfileChange,DocumentUpload,
							"",AutoRRCStatus,"",DeclineFlag,BBG_NSTP_Remark);
					DocsList.clear();
				}
			}
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkAndDelete method.");
			e.printStackTrace();
		}
	}

	private String findRPWINumber(String cif, String wINAME) {
		String wiNumber = "";
		try{
			String Query = "SELECT RP_WI_Number FROM NG_KYC_REM_RP_GRID WHERE CIF = '"+cif+"' AND WI_Name = '"+wINAME+"'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				wiNumber = entry.get("RP_WI_Number");
			}
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkAndDelete method.");
			e.printStackTrace();
		}
		return wiNumber;
	}

	public static boolean isCIF(String str) {
	    return str != null && str.matches("\\d+");
	}
	
	private String processEmailResponseWI() {
		String WINAME = "";
		String Current_WS = "";
		try {
			String Query1 = "SELECT WINAME FROM RB_KYC_REM_EXTTABLE  with(nolock) WHERE FirstResponse = 'Y' AND Current_WS = 'Email_Hold'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				WINAME = entry.get("WINAME");
				RouteRelatedPartyWI(WINAME, "Send to Maker2", "");
				String WorkItemID = "";
				String ActivityID = "";
				String ProcessDefID = "";
				String EntryDateTime = "";
				String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE with (nolock) where ProcessInstanceID = '"
						+ WINAME + "' AND Workitemid = '1'";
				String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
				XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
				String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
				int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
				if (dataMainCode.equals("0") && dataTotalRecords > 0) {
					WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
					ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
					ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
					EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

					StringBuffer ipXMLBuffer = new StringBuffer();

					ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
					ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
					ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
					ipXMLBuffer.append("<EngineName>");
					ipXMLBuffer.append(cabinetName);
					ipXMLBuffer.append("</EngineName>\n");
					ipXMLBuffer.append("<SessionID>");
					ipXMLBuffer.append(sessionID);
					ipXMLBuffer.append("</SessionID>\n");
					ipXMLBuffer.append("<ProcessInstanceID>");
					ipXMLBuffer.append(WINAME);
					ipXMLBuffer.append("</ProcessInstanceID>\n");
					ipXMLBuffer.append("<WorkItemID>");
					ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</WorkItemID>\n");
					ipXMLBuffer.append("<SourceUser>");
					// ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</SourceUser>\n");
					ipXMLBuffer.append("<TargetUser>");
					ipXMLBuffer.append("rakbpmutility");
					ipXMLBuffer.append("</TargetUser>\n");
					ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
					String WMUnlockWIInput = ipXMLBuffer.toString();
					CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
					String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

					XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
					String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

					if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

						String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,
								WorkItemID);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
						String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

						XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
						String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger
								.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

						if (getWorkItemMainCode.trim().equals("0")) {

							String attributeTAg = "<DECISION>Send to Maker2</DECISION>";
							String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
									+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
									+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
									+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
									+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID + "</ActivityId>"
									+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
									+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
									+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
									+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributeTAg
									+ "</Attributes>" + "</WMAssignWorkItemAttributes_Input>";

							CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
							String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
							XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
							String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
							if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {
								sendcustomEmail(WINAME, "customerResponse", "", "");
								CustOutreachLog.KYCcustOutreachLogger.debug("WI routed--- " + WINAME);
								Date d = new Date();
								SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								String strDate = dateFormat.format(d);
								String remarks = "Response Received.";
								String tableName = "NG_KYC_REM_GR_HISTORY";
								String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
								String values = "'" + strDate + "','Email_Hold','Send to Maker2','rakBPMutility','"
										+ remarks + "','" + WINAME + "','" + EntryDateTime + "'";
								String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName,
										values, tableName);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

								String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort,
										1);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

								XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of aapInsertOutputXML for insertion in history grid - "
												+ apInsertOutputXML);
								String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of apInsertMaincode  " + apInsertMaincode);
								if (apInsertMaincode.equalsIgnoreCase("0")) {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("ApInsert successful: " + apInsertMaincode);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Inserted in history table successfully.");
								} else {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Insertion in history table failed.");
								}
							} else {
								CustOutreachLog.KYCcustOutreachLogger.debug("Error in assignWICall--- " + WINAME);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Error in getWICall--- " + WINAME);
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Error in reassigning--- " + WINAME);
					}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Error in getting Activity ID--- " + WINAME);
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in processEmailResponseWI method.");
		}
		return "true";
	}

	private void sendcustomEmail(String WINAME, String type, String consequenceAction, String mailToID) {
		try {
			String mailFrom = "";
			String mailTo = "";
			String userNAme = getUSerEmailID(WINAME).split("~~")[1];
			String mailSubject = "";
			String mailMessage = "";
			String mailContentType = "text/html;charset=UTF-8";
			String mailPriority = "1";
			String mailStatus = "N";
			String insertedBy = "system";
			String mailActionType = "TRIGGER";
			String processInstanceID = WINAME;
			String workItemID = "1";
			String ActivityID = getActivityID(WINAME);
			String noOfTrials = "0";
			String tableName = "WFMAILQUEUETABLE";
			String Query1 = "";
			CustOutreachLog.KYCcustOutreachLogger.debug("type " + type);
			CustOutreachLog.KYCcustOutreachLogger.debug("consequenceAction " + consequenceAction);
			if ("customerResponse".equalsIgnoreCase(type)) {
				Query1 = "SELECT Subject,Content,FomEmail FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'Customer Response'";
				mailTo = getUSerEmailID(WINAME).split("~~")[0];
			} else if ("consequenceEmail".equalsIgnoreCase(type)) {
				mailTo = mailToID;
				if ("Block Cheque Book Facility".equalsIgnoreCase(consequenceAction))
					CustOutreachLog.KYCcustOutreachLogger.debug("No email for block cheque Book facility");
				else if ((consequenceAction.contains("Block Debit Cards")
						|| consequenceAction.contains("Block Credit Cards"))
						&& consequenceAction.contains("Block Digital Banking"))
					Query1 = "SELECT Subject,Content,FomEmail FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'All_Blocked'";
				else if ("Block Digital Banking".equalsIgnoreCase(consequenceAction))
					Query1 = "SELECT Subject,Content,FomEmail FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'DB_Blocked'";
				else if ((consequenceAction.contains("Block Debit Cards")
						|| consequenceAction.contains("Block Credit Cards"))
						&& !consequenceAction.contains("Block Digital Banking"))
					Query1 = "SELECT Subject,Content,FomEmail FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'Cards_Blocked'";
			}
			CustOutreachLog.KYCcustOutreachLogger.debug("Query to get email template " + Query1);

			String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("dataInputXML " + dataInputXML);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				mailFrom = dataxmlParserAPSelect.getValueOf("FomEmail");
				mailMessage = dataxmlParserAPSelect.getValueOf("Content");
				mailSubject = dataxmlParserAPSelect.getValueOf("Subject") + " " + WINAME;

				mailMessage = mailMessage.replaceAll("'", "''");
				mailMessage = mailMessage.replaceAll("#WI_No#", WINAME);
				mailMessage = mailMessage.replaceAll("#user#", userNAme);
				mailMessage = mailMessage.replaceAll("DD/MM/YYYY", getDate());
				String columnName = "mailFrom,mailTo,mailSubject,mailMessage,"
						+ "mailContentType,mailPriority,mailStatus,insertedBy,mailActionType,"
						+ "processInstanceID,workItemID,ActivityID,noOfTrials,insertedTime";

				String values = "'" + mailFrom + "','" + mailTo + "','" + mailSubject + "',N'" + mailMessage + "','"
						+ mailContentType + "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','"
						+ mailActionType + "','" + processInstanceID + "','" + workItemID + "','" + ActivityID + "','"
						+ noOfTrials + "',getDate()";

				String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
				CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

				String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

				XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
				CustOutreachLog.KYCcustOutreachLogger
						.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
				String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
				CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
				if (apInsertMaincode.equalsIgnoreCase("0")) {
					CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Data Inserted in wfmailqueue table successfully for sending custom email.");
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert not successful: " + apInsertMaincode);
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception in sendUserCustomerResponseEmail method." + e.getMessage());
		}
	}

	private String getDate() {
		String dt = "";
		try {
			LocalDate currentDate = LocalDate.now();
			int daysToAdd = 14; // Two weeks
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

			LocalDate futureDate = currentDate.plusDays(daysToAdd);
			if (futureDate.getDayOfWeek() == DayOfWeek.SATURDAY)
				futureDate = futureDate.plusDays(2);
			else if (futureDate.getDayOfWeek() == DayOfWeek.SUNDAY)
				futureDate = futureDate.plusDays(1);
			/*
			 * int weekdaysCount = 0;
			 * 
			 * while (weekdaysCount < daysToAdd) { futureDate =
			 * futureDate.plusDays(1); if (futureDate.getDayOfWeek() !=
			 * DayOfWeek.SATURDAY && futureDate.getDayOfWeek() !=
			 * DayOfWeek.SUNDAY) { weekdaysCount++; } }
			 */
			return dt = futureDate.format(formatter);

		} catch (Exception e) {
			e.printStackTrace();
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getDate method." + e.getMessage());
		}
		return dt;
	}

	private String getUSerEmailID(String wINAME) {
		String emailID = "";
		String user = "";
		try {
			String Query1 = "SELECT MailID,UserName FROM PDBUser with(nolock) where UserName = (SELECT TOP 1 UserName "
					+ "from NG_KYC_REM_GR_HISTORY with(nolock) WHERE WI_NAME = '" + wINAME
					+ "' order by DateTime desc)";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				emailID = dataxmlParserAPSelect.getValueOf("MailID");
				user = dataxmlParserAPSelect.getValueOf("UserName");
				return emailID + "~~" + user;
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception in sendUserCustomerResponseEmail method." + e.getMessage());
			return emailID;
		}
		return emailID;
	}

	private String getActivityID(String wINAME) {
		String activityID = "";
		try {
			String Query1 = "SELECT ActivityId FROM WFINSTRUMENTTABLE with(nolock) WHERE ProcessInstanceID = '" + wINAME
					+ "' AND WorkItemId = '1'";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				activityID = dataxmlParserAPSelect.getValueOf("ActivityId");
				return activityID;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getActivityID method." + e.getMessage());
		}
		return activityID;
	}

	private void sendBBGReminderEmail() {
		try {
			String Query = "SELECT WINAME,outreachInitialDateTime,CompanyMobileOffice,CIF_ID FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE Current_WS = 'EMAIL_HOLD' AND CaseType = 'Corporate'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				String WINAME = entry.get("WINAME");
				String CompanyMobileOffice = entry.get("CompanyMobileOffice");
				String CIF_ID = entry.get("CIF_ID");
				String Query1 = "SELECT TOP 1 SNO,SendDateTime FROM NG_KYC_REM_CUST_COMMUNICATION with(nolock) "
						+ "WHERE WINAME = '" + WINAME + "' ORDER BY SendDateTime desc";
				List<Map<String, String>> DataFromDB1 = new ArrayList<Map<String, String>>();
				DataFromDB1 = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
				CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB1);
				if (!DataFromDB1.isEmpty()) {
					for (Map<String, String> entry1 : DataFromDB1) {
						String SNO = entry1.get("SNO");
						String SendDateTime = entry1.get("SendDateTime");
						String majorSNO = "";
						String minorSNO = "";
						if (SNO.contains(".")) {
							String[] arrSNO = SNO.split("\\.");
							CustOutreachLog.KYCcustOutreachLogger.debug("arrSNO " + arrSNO);
							majorSNO = arrSNO[0];
							CustOutreachLog.KYCcustOutreachLogger.debug("majorSNO " + majorSNO);
							minorSNO = arrSNO[1];
							CustOutreachLog.KYCcustOutreachLogger.debug("minorSNO " + minorSNO);
							if (1 == Integer.parseInt(minorSNO)) {
								sendreminder(2, majorSNO, WINAME, minorSNO, CompanyMobileOffice,CIF_ID);
							} else if (2 == Integer.parseInt(minorSNO)) {
								sendreminder(3, majorSNO, WINAME, minorSNO, CompanyMobileOffice,CIF_ID);
							}
						} else {
							sendreminder(1, SNO, WINAME, minorSNO, CompanyMobileOffice,CIF_ID);
						}
					}
				}

			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendBBGReminderEmail method---" + e.getMessage());
		}
	}

	private void sendreminder(int ReminderNo, String majorSNO, String WINAME, String minorSNO,
			String CompanyMobileOffice, String CIF_ID) {
		try {
			String Query = "SELECT SendDateTime,EmailFinal from NG_KYC_REM_CUST_COMMUNICATION with(nolock) WHERE Sno = '"
					+ majorSNO + "' AND WINAME = '" + WINAME + "'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				String SendDateTime = entry.get("SendDateTime");
				String EmailFinal = entry.get("EmailFinal");
				SendDateTime = normalizeTimestampString(SendDateTime);
				/*if (SendDateTime.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{1,2}")) {
					//SendDateTime = SendDateTime + "0"; // Pad with a zero to
														// make it .SSS
					 int dotIndex = SendDateTime.lastIndexOf('.');
				        String prefix = SendDateTime.substring(0, dotIndex + 1);
				        String millis = SendDateTime.substring(dotIndex + 1);
				        while (millis.length() < 3) {
				            millis += "0";
				        }
				        SendDateTime = prefix + millis;
				}*/
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
				LocalDateTime originalDate = LocalDateTime.parse(SendDateTime, formatter);
				String day = "";
				String Query1 = "SELECT Value FROM NG_KYC_REM_VARIABLE_TABLE with(nolock) "
						+ "WHERE Variable = 'Reminder" + ReminderNo + "'";
				List<Map<String, String>> DataFromDB1 = new ArrayList<Map<String, String>>();
				DataFromDB1 = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
				CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB1);
				for (Map<String, String> entry1 : DataFromDB1) {
					day = entry1.get("Value");
				}
				LocalDateTime newDate = originalDate.plusDays(Integer.parseInt(day));
				LocalDateTime currentDate = LocalDateTime.now();
				if (newDate.toLocalDate().equals(currentDate.toLocalDate()) || newDate.isBefore(currentDate)) {
					CustOutreachLog.KYCcustOutreachLogger.debug("The new date is equal to the current date!");
					DayOfWeek dayOfWeek = currentDate.getDayOfWeek();
					if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
						CustOutreachLog.KYCcustOutreachLogger.debug("Its weekend chilll!!!!!!.");
					} else {
						sendEmail(ReminderNo, majorSNO, WINAME, EmailFinal);
						sendSMS(ReminderNo, majorSNO, WINAME, minorSNO, CompanyMobileOffice,CIF_ID);
					}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Reminder date is not reached yet....");
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendreminder method---" + e.getMessage());
		}
	}

	public static String normalizeTimestampString(String timestamp) {
	    if (timestamp == null) {
	        throw new IllegalArgumentException("Timestamp is null");
	    }
	    if (timestamp.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{1,3}")) {
	        int dotIndex = timestamp.lastIndexOf('.');
	        String prefix = timestamp.substring(0, dotIndex + 1);
	        String millis = timestamp.substring(dotIndex + 1);
	        while (millis.length() < 3) {
	            millis += "0";
	        }
	        return prefix + millis;
	    }
	    if (timestamp.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}")) {
	        return timestamp + ".000";
	    }
	    throw new IllegalArgumentException("Unrecognized timestamp format: " + timestamp);
	}

	
	private void sendSMS(int reminderNo, String majorSNO, String wINAME, String minorSNO, String CompanyMobileOffice, String CIF_ID) {
		try {
			String query = "SELECT COUNT(*) AS totalCommunication from NG_KYC_REM_CUST_COMMUNICATION WHERE WINAME = '"
					+ wINAME + "'";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				String SMS_no = "";
				String totalCommunication = dataxmlParserAPSelect.getValueOf("totalCommunication");
				if (Integer.parseInt(totalCommunication) <= 3) {
					if (Integer.parseInt(totalCommunication) == 2)
						SMS_no = "SMS2";
					else if (Integer.parseInt(totalCommunication) == 3)
						SMS_no = "SMS3";
				}
				/*String query1 = "SELECT SMSContent FROM NG_KYC_REM_SMS_TEMPLATE with(nolock) WHERE SMSNumber = '"
						+ SMS_no + "'";*/
				String query1 = "SELECT SMSContent,INFOBIP_ALERT_ID FROM NG_KYC_REM_SMS_TEMPLATE with(nolock) WHERE SMSNumber = '"
						+ SMS_no + "'";
				String dataInputXML1 = CommonMethods.apSelectWithColumnNames(query1, cabinetName, sessionID);
				String dataOutputXML1 = CommonMethods.WFNGExecute(dataInputXML1, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML1);
				XMLParser dataxmlParserAPSelect1 = new XMLParser(dataOutputXML1);
				String dataMainCode1 = dataxmlParserAPSelect1.getValueOf("MainCode");
				int dataTotalRecords1 = Integer.parseInt(dataxmlParserAPSelect1.getValueOf("TotalRetrieved"));
				if (dataMainCode1.equals("0") && dataTotalRecords1 > 0) {
					String alertTExt = dataxmlParserAPSelect1.getValueOf("SMSContent");
					String infobipAlertID = dataxmlParserAPSelect1.getValueOf("INFOBIP_ALERT_ID");
					//String tablename = "NG_RLOS_SMSQUEUETABLE";
					String tablename = "USR_0_INFOBIP_SMS_QUEUETABLE";
					String alertName = "KYC_SMS";
					String alertStatus = "P";
					String mobileNo = CompanyMobileOffice;
					// String AlertSubject = "Important : KYC Update";
					String Workstep = "Email_Hold";
					String processinstanceID = wINAME;
					/*String columnNAme = "(Alert_Name,Alert_Code,Alert_Status,Mobile_No,Alert_Text,"
							+ "WI_Name,Workstep_Name,inserted_Date_time)";*/
					
					String columnNAme = "Processname, WI_NAME, AlertID, InsertedDateTime, CIF, "
							+ "Alert_Status, Infobip_No_Of_Retry, MobileNumber, SMS_Content";				
					/*String values = "'" + alertName + "','" + SMS_no + "','" + alertStatus + "','" + mobileNo + "','"
							+ alertTExt + "','" + processinstanceID + "','" + Workstep + "',getDate()";*/
					String values = "'KYC_Remediation','" + processinstanceID + "','" + infobipAlertID + "',format(getdate(),'yyyy-MM-dd HH:mm:ss.fff'),'" + CIF_ID + "','P','0','" + mobileNo+ "','" + alertTExt + "'";
					String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnNAme, values,
							tablename);
					CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);
					String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);
					XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
					CustOutreachLog.KYCcustOutreachLogger.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
					String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
					if (apInsertMaincode.equalsIgnoreCase("0")) {
						CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Data Inserted in SMS table successfully for sending reminder mail.");
						String SNO = majorSNO + "." + reminderNo;
						String columnName = "SMSContent";
						String value = "'" + alertTExt + "'";
						String whereClause = "WINAME = '" + processinstanceID + "' AND SNO = '" + SNO + "'";
						String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,
								"NG_KYC_REM_CUST_Communication", columnName, value, whereClause);
						CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
						String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
						XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
						String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
						if (apUpdateMaincode.equalsIgnoreCase("0")) {
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML for Upload Flag: " + apUpdateOutputXML);
						}
						// insertInCustCommunicationGrid(majorSNO,ReminderNo,mailTo,mailSubject,EmailFinal,WINAME);
					}
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendSMS method---" + e.getMessage());
		}
	}

	private void sendEmail(int ReminderNo, String majorSNO, String WINAME, String EmailFinal) {
		try {
			String Query1 = "SELECT TOP 1 mailFrom,mailTo,mailCC,mailSubject,mailMessage,mailContentType,attachmentISINDEX,attachmentNames,workItemID"
					+ ",activityID FROM NG_KYC_REM_EMAIL_HISTORY_TABLE with(nolock) WHERE mailType = 'Outreach' AND processinstanceID = '"
					+ WINAME + "' order by insertedTime desc";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + dataOutputXML);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				String mailFrom = dataxmlParserAPSelect.getValueOf("mailFrom");
				String mailTo = dataxmlParserAPSelect.getValueOf("mailTo");
				String mailCC = dataxmlParserAPSelect.getValueOf("mailCC");
				String mailSubject = dataxmlParserAPSelect.getValueOf("mailSubject");
				if (ReminderNo == 1) {
					mailSubject = "First Reminder " + mailSubject;
				}
				if (ReminderNo == 2) {
					mailSubject = "Second Reminder " + mailSubject;
				}
				if (ReminderNo == 3) {
					mailSubject = "Last Reminder " + mailSubject;
				}
				String mailMessage = dataxmlParserAPSelect.getValueOf("mailMessage");
				String mailContentType = dataxmlParserAPSelect.getValueOf("mailContentType");
				String attachmentISINDEX = dataxmlParserAPSelect.getValueOf("attachmentISINDEX");
				String attachmentNames = dataxmlParserAPSelect.getValueOf("attachmentNames");
				String workItemID = dataxmlParserAPSelect.getValueOf("workItemID");
				String activityID = dataxmlParserAPSelect.getValueOf("activityID");
				String mailPriority = "1";
				String mailStatus = "N";
				String insertedBy = "system";
				String mailActionType = "Trigger";
				String processinstanceID = WINAME;
				String noOfTrials = "0";

				String tableName = "WFMAILQUEUETABLE";
				String columnName = "mailFrom,mailTo,mailCC,mailSubject,mailMessage,attachmentISINDEX,"
						+ "attachmentNames,mailContentType,mailPriority,mailStatus,insertedBy,mailActionType,"
						+ "processInstanceID,workItemID,ActivityID,noOfTrials,insertedTime";

				String values = "'" + mailFrom + "','" + mailTo + "','" + mailCC + "','" + mailSubject + "',N'"
						+ mailMessage + "','" + attachmentISINDEX + "','" + attachmentNames + "','" + mailContentType
						+ "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','" + mailActionType
						+ "','" + processinstanceID + "','" + workItemID + "','" + activityID + "','" + noOfTrials
						+ "',getDate()";

				String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
				CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

				String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

				XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
				CustOutreachLog.KYCcustOutreachLogger
						.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
				String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
				CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
				if (apInsertMaincode.equalsIgnoreCase("0")) {
					CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Data Inserted in wfmailqueue table successfully for sending reminder mail.");
					insertInCustCommunicationGrid(majorSNO, ReminderNo, mailTo, mailSubject, EmailFinal, WINAME);
					insertInMailHistoryTable(columnName, values, ReminderNo);
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert not successful: " + apInsertMaincode);
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in sendreminder method---" + e.getMessage());
		}
	}

	private void insertInCustCommunicationGrid(String majorSNO, int reminderNo, String mailTo, String mailSubject,
			String emailFinal, String WINAME) {
		try {
			String wiNAme = WINAME;
			String SNO = majorSNO + "." + String.valueOf(reminderNo);
			String ToEmail = mailTo;
			String Subject = mailSubject;
			String EmailFinal = emailFinal;

			String tableName = "NG_KYC_REM_CUST_COMMUNICATION";
			String columnName = "WINAME,SNO,ToEmail,Subject,SendDateTime,EmailFinal";
			String values = "'" + wiNAme + "','" + SNO + "','" + ToEmail + "','" + Subject + "',getDate(),N'"
					+ EmailFinal + "'";
			String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
			CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
			if (apInsertMaincode.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
				CustOutreachLog.KYCcustOutreachLogger.debug(
						"Data Inserted in Customer Communication grid table successfully for sending reminder mail.");
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception in insertInCustCommunicationGrid method---" + e.getMessage());
		}
	}

	private void insertInMailHistoryTable(String columnName, String values, int ReminderNo) {
		try {
			String tableName = "NG_KYC_REM_EMAIL_HISTORY_TABLE";
			columnName += ",mailType";
			values += ",'Reminder" + String.valueOf(ReminderNo) + "'";
			String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values, tableName);
			CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);
			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);
			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Status of aapInsertOutputXML for insertion in history grid - " + apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
			if (apInsertMaincode.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger
						.debug("inserted in mail history successfully " + apInsertMaincode);
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception in insertInMailHistoryTable method---" + e.getMessage());
		}
	}

	private String BBGConsequenceEligibleWI() {
		String WINAME = "";
		String Current_WS = "";
		String avgAnnInc = "";
		String firstConsequenceDate = "";
		try {
			String Query1 = "SELECT f.WINAME,f.BBGOutreachInitialDateTime,f.Current_WS,f.AverageAnnualIncome,f.FIRST_CONSEQUENCE_DATE "
					+ "FROM RB_KYC_REM_EXTTABLE f with(nolock) "
					+ "WHERE DATEDIFF(DAY, f.BBGOutreachInitialDateTime, GETDATE()) >= 91 "
					+ "AND (SELECT MAX(TRY_CAST(s.SNO AS FLOAT)) " + "FROM NG_KYC_REM_CUST_COMMUNICATION s with(nolock)"
					+ "WHERE s.WINAME = f.WINAME ) <= 1.3 AND f.CURRENT_WS = 'Email_Hold' AND f.AUTO_CONSEQUENCE_STATUS IS NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query1",firstConsequenceDate);
			}
			DataFromDB.clear();
			String Query2 = "SELECT t1.WINAME, t1.BBGOutreachInitialDateTime, t1.CURRENT_WS, t2.SendDateTime, t2.SNO, t1.AverageAnnualIncome,t1.FIRST_CONSEQUENCE_DATE "
					+ "FROM RB_KYC_REM_EXTTABLE t1 with(nolock)" + "JOIN NG_KYC_REM_CUST_COMMUNICATION t2 with(nolock)"
					+ "ON t1.WINAME = t2.WINAME " + "WHERE t1.BBGOutreachInitialDateTime <= DATEADD(DAY, -91, GETDATE()) "
					+ "AND t1.EntryAt <= DATEADD(DAY, -15, GETDATE()) " + "AND (t2.SNO LIKE '2%' OR t2.SNO LIKE '3%') "
					+ "AND t2.SendDateTime = (" + "SELECT MAX(SendDateTime) "
					+ "FROM NG_KYC_REM_CUST_COMMUNICATION t2_sub with(nolock)" + "WHERE t2_sub.WINAME = t2.WINAME) "
					+ "AND t1.CURRENT_WS = 'Email_Hold' AND t1.AUTO_CONSEQUENCE_STATUS IS NULL";
			List<Map<String, String>> DataFromDB2 = new ArrayList<Map<String, String>>();
			DataFromDB2 = getDataFromDBMap(Query2, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB2);

			for (Map<String, String> entry : DataFromDB2) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query2",firstConsequenceDate);
			}
			DataFromDB2.clear();
			String Query3 = "SELECT t1.WINAME, t1.BBGOutreachInitialDateTime, t1.CURRENT_WS, t2.SendDateTime, t2.SNO, t1.AverageAnnualIncome,t1.FIRST_CONSEQUENCE_DATE "
					+ "FROM RB_KYC_REM_EXTTABLE t1 with(nolock)" + "JOIN NG_KYC_REM_CUST_COMMUNICATION t2 with(nolock)"
					+ "ON t1.WINAME = t2.WINAME " + "WHERE t1.BBGOutreachInitialDateTime <= DATEADD(DAY, -91, GETDATE()) "
					+ "AND TRY_CAST(t2.SNO AS FLOAT) >= 4 " + "AND t1.CURRENT_WS = 'Email_Hold' AND t1.AUTO_CONSEQUENCE_STATUS IS NULL";
			List<Map<String, String>> DataFromDB3 = new ArrayList<Map<String, String>>();
			DataFromDB3 = getDataFromDBMap(Query3, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB3);

			for (Map<String, String> entry : DataFromDB3) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query3",firstConsequenceDate);
			}
			DataFromDB3.clear();

			String Query4 = "SELECT f.WINAME,f.BBGOutreachInitialDateTime,f.Current_WS,f.AverageAnnualIncome,f.FIRST_CONSEQUENCE_DATE "
					+ "FROM RB_KYC_REM_EXTTABLE f with(nolock) JOIN WFINSTRUMENTTABLE WF with(nolock) ON f.WINAME = WF.processinstanceID "
					+ "WHERE DATEDIFF(DAY, f.BBGOutreachInitialDateTime, GETDATE()) >= "+autoConsequenceDays+" AND f.CURRENT_WS IN ('Maker2','RM_Vendor','Controls','Compliance','Email_Hold') "
					+ "AND f.caseType = 'Corporate' AND f.ConsequenceEntryFlag IS NULL AND WF.VAR_STR8 = 'BBG' AND f.AUTO_CONSEQUENCE_STATUS IS NULL";
			List<Map<String, String>> DataFromDB4 = new ArrayList<Map<String, String>>();
			DataFromDB4 = getDataFromDBMap(Query4, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB4);

			for (Map<String, String> entry : DataFromDB4) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query4",firstConsequenceDate);
			}
			DataFromDB4.clear();
			
			//String Query5 = "SELECT WINAME,Current_WS,AverageAnnualIncome,FIRST_CONSEQUENCE_DATE FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE Current_WS = 'RM_Vendor' AND AUTO_CONSEQUENCE_STATUS IS NULL AND BBGCustomerOutreachFlag = 'In Progress' AND BBGOutreachInitialDateTime <= DATEADD(DAY, -91, GETDATE()) AND (ConsequenceEntryFlag IS NULL OR ConsequenceEntryFlag = '')";
			String Query5 = 
				    "SELECT A.WINAME, " +
				    "       A.Current_WS, " +
				    "       A.AverageAnnualIncome, " +
				    "       A.FIRST_CONSEQUENCE_DATE " +
				    "FROM RB_KYC_REM_EXTTABLE A WITH (NOLOCK) " +
				    "WHERE A.Current_WS = 'RM_Vendor' " +
				    "  AND A.AUTO_CONSEQUENCE_STATUS IS NULL " +
				    "  AND A.BBGCustomerOutreachFlag = 'In Progress' " +
				    "  AND A.BBGOutreachInitialDateTime <= DATEADD(DAY, -91, GETDATE()) " +
				    "  AND (A.ConsequenceEntryFlag IS NULL OR A.ConsequenceEntryFlag = '') " +
				    "  AND ( " +
				    "        /* Scenario 1: BBG_OUTREACH_CASE = 'Y' AND history count = 2 */ " +
				    "        ( " +
				    "            EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_BO_IBPS_TABLE B WITH (NOLOCK) " +
				    "                WHERE B.WI_NAME = A.WINAME " +
				    "                  AND B.BBG_OUTREACH_CASE = 'Y' " +
				    "            ) " +
				    "            AND EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_GR_HISTORY H WITH (NOLOCK) " +
				    "                WHERE H.WI_NAME = A.WINAME " +
				    "                GROUP BY H.WI_NAME " +
				    "                HAVING COUNT(*) = 2 " +
				    "            ) " +
				    "        ) " +
				    "        OR " +
				    "        /* Scenario 2: BBG_OUTREACH_CASE NOT 'Y' OR NULL AND Outreach to Portal = 1 */ " +
				    "        ( " +
				    "            EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_BO_IBPS_TABLE B2 WITH (NOLOCK) " +
				    "                WHERE B2.WI_NAME = A.WINAME " +
				    "                  AND (B2.BBG_OUTREACH_CASE IS NULL OR B2.BBG_OUTREACH_CASE <> 'Y') " +
				    "            ) " +
				    "            AND EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_GR_HISTORY H2 WITH (NOLOCK) " +
				    "                WHERE H2.WI_NAME = A.WINAME " +
				    "                  AND H2.Decision = 'Outreach to Portal' " +
				    "                GROUP BY H2.WI_NAME " +
				    "                HAVING COUNT(*) = 1 " +
				    "            ) " +
				    "        ) " +
				    "      );";

			
			List<Map<String, String>> DataFromDB5 = new ArrayList<Map<String, String>>();
			DataFromDB5 = getDataFromDBMap(Query5, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB5);

			for (Map<String, String> entry : DataFromDB5) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query5",firstConsequenceDate);
			}
			DataFromDB5.clear();
			
			/*String Query6 = "SELECT r.WINAME,r.Current_WS,r.AverageAnnualIncome,r.FIRST_CONSEQUENCE_DATE FROM RB_KYC_REM_EXTTABLE r WITH (NOLOCK) "
					+ "WHERE r.Current_WS = 'RM_Vendor' AND r.AUTO_CONSEQUENCE_STATUS IS NULL AND r.BBGCustomerOutreachFlag = 'In Progress' AND r.BBGOutreachInitialDateTime <= "
					+ "DATEADD(DAY, -90, GETDATE()) AND (r.ConsequenceEntryFlag != 'C6')AND EXISTS (SELECT 1 FROM NG_KYC_REM_GR_HISTORY h "
					+ "WHERE h.WI_NAME = r.WINAME AND h.Decision = 'Outreach to Portal' GROUP BY h.WI_NAME HAVING COUNT(*) = 2 AND MAX(h.DateTime) <= DATEADD(DAY, -15, GETDATE()))";*/
			String Query6 = 
				    "SELECT r.WINAME, " +
				    "       r.Current_WS, " +
				    "       r.AverageAnnualIncome, " +
				    "       r.FIRST_CONSEQUENCE_DATE " +
				    "FROM RB_KYC_REM_EXTTABLE r WITH (NOLOCK) " +
				    "WHERE r.Current_WS = 'RM_Vendor' " +
				    "  AND r.AUTO_CONSEQUENCE_STATUS IS NULL " +
				    "  AND r.BBGCustomerOutreachFlag = 'In Progress' " +
				    "  AND r.BBGOutreachInitialDateTime <= DATEADD(DAY, -90, GETDATE()) " +
				    "  AND (r.ConsequenceEntryFlag IS NULL OR r.ConsequenceEntryFlag = '') " +
				    "  AND ( " +
				    "        ( " +
				    "            EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_BO_IBPS_TABLE b WITH (NOLOCK) " +
				    "                WHERE b.WI_NAME = r.WINAME " +
				    "                  AND b.BBG_OUTREACH_CASE = 'Y' " +
				    "            ) " +
				    "            AND EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_GR_HISTORY h WITH (NOLOCK) " +
				    "                WHERE h.WI_NAME = r.WINAME " +
				    "                  AND h.Decision = 'Outreach to Portal' " +
				    "                GROUP BY h.WI_NAME " +
				    "                HAVING COUNT(*) = 1 " +
				    "                   AND MAX(h.DateTime) <= DATEADD(DAY, -15, GETDATE()) " +
				    "            ) " +
				    "        ) " +
				    "        OR " +
				    "        ( " +
				    "            EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_BO_IBPS_TABLE b2 WITH (NOLOCK) " +
				    "                WHERE b2.WI_NAME = r.WINAME " +
				    "                  AND (b2.BBG_OUTREACH_CASE IS NULL OR b2.BBG_OUTREACH_CASE <> 'Y') " +
				    "            ) " +
				    "            AND EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_GR_HISTORY h2 WITH (NOLOCK) " +
				    "                WHERE h2.WI_NAME = r.WINAME " +
				    "                  AND h2.Decision = 'Outreach to Portal' " +
				    "                GROUP BY h2.WI_NAME " +
				    "                HAVING COUNT(*) = 2 " +
				    "                   AND MAX(h2.DateTime) <= DATEADD(DAY, -15, GETDATE()) " +
				    "            ) " +
				    "        ) " +
				    "      )";

			List<Map<String, String>> DataFromDB6 = new ArrayList<Map<String, String>>();
			DataFromDB6 = getDataFromDBMap(Query6, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : " + DataFromDB6);

			for (Map<String, String> entry : DataFromDB6) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query6",firstConsequenceDate);
			}
			DataFromDB6.clear();
			
			/*String Query7 = "SELECT r.WINAME,r.Current_WS,r.AverageAnnualIncome,r.FIRST_CONSEQUENCE_DATE FROM RB_KYC_REM_EXTTABLE r WITH (NOLOCK) "
					+ "WHERE r.Current_WS = 'RM_Vendor' AND r.AUTO_CONSEQUENCE_STATUS IS NULL AND r.BBGCustomerOutreachFlag = 'In Progress' AND r.BBGOutreachInitialDateTime <= "
					+ "DATEADD(DAY, -90, GETDATE()) AND (r.ConsequenceEntryFlag != 'C6')AND EXISTS (SELECT 1 FROM NG_KYC_REM_GR_HISTORY h "
					+ "WHERE h.WI_NAME = r.WINAME AND h.Decision = 'Outreach to Portal' GROUP BY h.WI_NAME HAVING COUNT(*) >= 3)";*/
			
			String Query7 = 
				    "SELECT r.WINAME, " +
				    "       r.Current_WS, " +
				    "       r.AverageAnnualIncome, " +
				    "       r.FIRST_CONSEQUENCE_DATE " +
				    "FROM RB_KYC_REM_EXTTABLE r WITH (NOLOCK) " +
				    "WHERE r.Current_WS = 'RM_Vendor' " +
				    "  AND r.AUTO_CONSEQUENCE_STATUS IS NULL " +
				    "  AND r.BBGCustomerOutreachFlag = 'In Progress' " +
				    "  AND r.BBGOutreachInitialDateTime <= DATEADD(DAY, -90, GETDATE()) " +
				    "  AND (r.ConsequenceEntryFlag IS NULL OR r.ConsequenceEntryFlag = '') " +
				    "  AND ( " +
				    "        ( " +
				    "            EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_BO_IBPS_TABLE b WITH (NOLOCK) " +
				    "                WHERE b.WI_NAME = r.WINAME " +
				    "                  AND b.BBG_OUTREACH_CASE = 'Y' " +
				    "            ) " +
				    "            AND EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_GR_HISTORY h WITH (NOLOCK) " +
				    "                WHERE h.WI_NAME = r.WINAME " +
				    "                  AND h.Decision = 'Outreach to Portal' " +
				    "                GROUP BY h.WI_NAME " +
				    "                HAVING COUNT(*) = 2 " +
				    "            ) " +
				    "        ) " +
				    "        OR " +
				    "        ( " +
				    "            EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_BO_IBPS_TABLE b2 WITH (NOLOCK) " +
				    "                WHERE b2.WI_NAME = r.WINAME " +
				    "                  AND (b2.BBG_OUTREACH_CASE IS NULL OR b2.BBG_OUTREACH_CASE <> 'Y') " +
				    "            ) " +
				    "            AND EXISTS ( " +
				    "                SELECT 1 " +
				    "                FROM NG_KYC_REM_GR_HISTORY h2 WITH (NOLOCK) " +
				    "                WHERE h2.WI_NAME = r.WINAME " +
				    "                  AND h2.Decision = 'Outreach to Portal' " +
				    "                GROUP BY h2.WI_NAME " +
				    "                HAVING COUNT(*) = 3 " +
				    "            ) " +
				    "        ) " +
				    "      );";

			List<Map<String, String>> DataFromDB7 = new ArrayList<Map<String, String>>();
			DataFromDB7 = getDataFromDBMap(Query7, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : " + DataFromDB7);

			for (Map<String, String> entry : DataFromDB7) {
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				avgAnnInc = entry.get("AverageAnnualIncome");
				firstConsequenceDate =  entry.get("FIRST_CONSEQUENCE_DATE");
				String res = checkExclusionCriteria(WINAME, avgAnnInc);
				if ("true".equalsIgnoreCase(res))
					RouteBBGConsequenceEligibleWI(WINAME, Current_WS, "Query7",firstConsequenceDate);
			}
			DataFromDB7.clear();
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception happened for BBGConsequenceEligibleWI-- " + WINAME + "----" + e.getMessage());
			return "Error";
		}
		return "success";
	}

	private String checkExclusionCriteria(String WINAME, String avgAnnInc) {
		try {
			String RP_WI_Number = "";
			String relatioshipType = "";
			// String avgAnnInc = "";
			String PEP = "";
			String getRPWIquery = "SELECT RP_WI_NUMBER FROM NG_KYC_REM_RP_GRID with(nolock) WHERE WI_Name = '" + WINAME
					+ "'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(getRPWIquery, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				RP_WI_Number = entry.get("RP_WI_NUMBER");
				String getExclusionDataquery = "SELECT OwnerRelationshipType,PEP FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE WINAME = '"
						+ RP_WI_Number + "'";
				List<Map<String, String>> DataFromDB1 = new ArrayList<Map<String, String>>();
				DataFromDB1 = getDataFromDBMap(getExclusionDataquery, cabinetName, sessionID, jtsIP, jtsPort);
				CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB1);
				for (Map<String, String> entry1 : DataFromDB1) {
					relatioshipType = entry1.get("OwnerRelationshipType");
					PEP = entry1.get("PEP");
					if (("Signatory".equalsIgnoreCase(relatioshipType)
							|| "POA Holder".equalsIgnoreCase(relatioshipType))
							&& ("LPEP".equalsIgnoreCase(PEP) || "Local PEP".equalsIgnoreCase(PEP))) {
						CustOutreachLog.KYCcustOutreachLogger
								.debug("RP is signatory or POA Holder and PEP is Local PEP - " + RP_WI_Number);
						return "RP is signatory or POA Holder and PEP is Local PEP";
					}
					if (!"".equalsIgnoreCase(avgAnnInc)) {
						if (Double.parseDouble(avgAnnInc) > (double) AvgAnnInc) {
							CustOutreachLog.KYCcustOutreachLogger.debug("Average Annual Income more than 1 Million.");
							return "Average Annual Income more than 1 Million.";
						}
					}
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception happened checkExclusionCriteria-- " + WINAME + "----" + e.getMessage());
		}
		return "true";
	}

	private String RouteBBGConsequenceEligibleWI(String WINAME, String Current_WS, String conditionTYpe, String firstConsequenceDate) {
		try {
			if (expireChildWI(WINAME)) {
				RouteRelatedPartyWI(WINAME, "Send to Consequence_Hold", "");
				String WorkItemID = "";
				String ActivityID = "";
				String ProcessDefID = "";
				String EntryDateTime = "";
				String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE with (nolock) where ProcessInstanceID = '"
						+ WINAME + "' AND Workitemid = '1'";
				String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
				XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
				String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
				int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
				if (dataMainCode.equals("0") && dataTotalRecords > 0) {
					WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
					ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
					ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
					EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

					StringBuffer ipXMLBuffer = new StringBuffer();

					ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
					ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
					ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
					ipXMLBuffer.append("<EngineName>");
					ipXMLBuffer.append(cabinetName);
					ipXMLBuffer.append("</EngineName>\n");
					ipXMLBuffer.append("<SessionID>");
					ipXMLBuffer.append(sessionID);
					ipXMLBuffer.append("</SessionID>\n");
					ipXMLBuffer.append("<ProcessInstanceID>");
					ipXMLBuffer.append(WINAME);
					ipXMLBuffer.append("</ProcessInstanceID>\n");
					ipXMLBuffer.append("<WorkItemID>");
					ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</WorkItemID>\n");
					ipXMLBuffer.append("<SourceUser>");
					// ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</SourceUser>\n");
					ipXMLBuffer.append("<TargetUser>");
					ipXMLBuffer.append("rakbpmutility");
					ipXMLBuffer.append("</TargetUser>\n");
					ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
					String WMUnlockWIInput = ipXMLBuffer.toString();
					CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
					String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

					XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
					String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

					if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

						String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,
								WorkItemID);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
						String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

						XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
						String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger
								.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

						if (getWorkItemMainCode.trim().equals("0")) {
							String ConsequenceGridCount = getConsequenceGridCount(WINAME);
							int consequenceGridCount = Integer.parseInt(ConsequenceGridCount)+3;
							String consequenceDate = getConsequenceDate();
							String consequenceApplyDateTime = getConsequenceApplyDateTime();
							String attributeTAg = "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Debit Cards</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
									+ "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Credit Cards</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
									+ "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Digital Banking</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
									+ "<DECISION>Send to Consequence_Hold</DECISION><ConsequenceRowCount>"+String.valueOf(consequenceGridCount)+"</ConsequenceRowCount><CONSEQUENCE_STATUS>Partial Applied</CONSEQUENCE_STATUS>"
									+ "<CONSEQUENCE_ACTION>Block Debit Cards|Block Credit Cards|Block Digital Banking</CONSEQUENCE_ACTION><LATEST_CONSEQUENCE_DATE>"+consequenceDate+"</LATEST_CONSEQUENCE_DATE>";
							if("".equalsIgnoreCase(firstConsequenceDate))
								attributeTAg += "<FIRST_CONSEQUENCE_DATE>"+consequenceDate+"</FIRST_CONSEQUENCE_DATE>";
							if ("Query4".equalsIgnoreCase(conditionTYpe))
								attributeTAg += "<ConsequenceEntryFlag>CY</ConsequenceEntryFlag>";
							else if ("Query5".equalsIgnoreCase(conditionTYpe))
								attributeTAg += "<ConsequenceEntryFlag>C5</ConsequenceEntryFlag>";
							else if ("Query6".equalsIgnoreCase(conditionTYpe))
								attributeTAg += "<ConsequenceEntryFlag>C6</ConsequenceEntryFlag>";
							else if ("Query7".equalsIgnoreCase(conditionTYpe))
								attributeTAg += "<ConsequenceEntryFlag>C7</ConsequenceEntryFlag>";
							String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
									+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
									+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
									+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
									+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID + "</ActivityId>"
									+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
									+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
									+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
									+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributeTAg
									+ "</Attributes>" + "</WMAssignWorkItemAttributes_Input>";

							CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
							String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
							XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
							String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
							if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("WI routed--- " + WINAME);
								Date d = new Date();
								SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								String strDate = dateFormat.format(d);
								String remarks = "WI eligible for consequence.";
								String tableName = "NG_KYC_REM_GR_HISTORY";
								String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
								String values = "'" + strDate + "','" + Current_WS
										+ "','Send to Consequence_Hold','rakBPMutility','" + remarks + "','" + WINAME
										+ "','" + EntryDateTime + "'";
								String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName,
										values, tableName);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

								String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort,
										1);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

								XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of aapInsertOutputXML for insertion in history grid - "
												+ apInsertOutputXML);
								String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of apInsertMaincode  " + apInsertMaincode);
								if (apInsertMaincode.equalsIgnoreCase("0")) {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("ApInsert successful: " + apInsertMaincode);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Inserted in history table successfully.");
								} else {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Insertion in history table failed.");
								}
							} else {
								CustOutreachLog.KYCcustOutreachLogger.debug("Error in assignWICall--- " + WINAME);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Error in getWICall--- " + WINAME);
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Error in reassigning--- " + WINAME);
					}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Error in getting Activity ID--- " + WINAME);
				}
			} else {
				CustOutreachLog.KYCcustOutreachLogger.debug("Error in deleting child of --- " + WINAME);
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception happened in RouteBBGConsequenceWI-- " + WINAME + "----" + e.getMessage());
		}
		return "success";
	}

	private String getConsequenceApplyDateTime() {
		try{
			Date d = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			return dateFormat.format(d);
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception happened in getting datetime in getConsequenceApplyDateTime method-- "+ e.getMessage());
		}
		return "";
	}

	private String getConsequenceDate() {
		try{
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String consequenceDate = sdf.format(dt);
		return consequenceDate;
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception happened in getting currentDate-- " + e.getMessage());
		}
		return "Exeption in getting date";
	}

	private String getConsequenceGridCount(String wINAME) {
		try{
			String countQuery = "SELECT Count(WINAME) as CountWI from NG_KYC_REM_Consequence_Grid with (nolock) where WINAME = '"
					+ wINAME + "'";
	
			String sInputXML = CommonMethods.apSelectWithColumnNames(countQuery, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Input XML for Apselect from External Table " + sInputXML);
	
			String sOutputXML = CommonMethods.WFNGExecute(sInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("Output XML for external Table select " + sOutputXML);
	
			XMLParser XMLParser = new XMLParser(sOutputXML);
			String sMainCode = XMLParser.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger.debug("SMainCode: " + sMainCode);
	
			int sTotalRecords = Integer.parseInt(XMLParser.getValueOf("TotalRetrieved"));
			CustOutreachLog.KYCcustOutreachLogger.debug("STotalRecords: " + sTotalRecords);
	
			if (sMainCode.equals("0") && sTotalRecords > 0) {
				String ConsequenceGridCount = XMLParser.getValueOf("CountWI");
				CustOutreachLog.KYCcustOutreachLogger.debug("Count received for WI - " + wINAME + " : " + ConsequenceGridCount);
				return ConsequenceGridCount;
			}
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception happened in RouteBBGConsequenceWI-- " + wINAME + "----" + e.getMessage());
		}
		return "0";
	}

	private boolean expireChildWI(String wINAME) {
		try {
			String Query = "select count(*) as childCount from WFINSTRUMENTTABLE " + "where ProcessInstanceID ='"
					+ wINAME + "' AND VAR_STR20='Temp_Email_Hold'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			if (!DataFromDB.isEmpty()) {
				String columnName = "VAR_STR19,ValidTill";
				String values = "'Y',getDate()";
				String whereClause = "ProcessInstanceID = '" + wINAME + "' AND VAR_STR20 = 'Temp_Email_Hold'";
				String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID, "WFINSTRUMENTTABLE",
						columnName, values, whereClause);
				CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
				String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
				XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
				String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
				if (apUpdateMaincode.equalsIgnoreCase("0")) {
					CustOutreachLog.KYCcustOutreachLogger
							.debug("apUpdateOutputXML for setting expiry for child of WI - " + wINAME + "is \n - "
									+ apUpdateOutputXML);
					return true;
				} else {
					CustOutreachLog.KYCcustOutreachLogger
							.debug("apUpdateOutputXML for setting expiry for child of WI - " + wINAME + "is \n - "
									+ apUpdateOutputXML);
					return false;
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception in expireChildWI for - " + wINAME + "\n Exception is - " + e.getMessage());
			return false;
		}
		return true;
	}

	private String RouteConsequenceHeldTillWI() {
		String WINAME = "";
		String Current_WS = "";
		String ConsequenceRowCount = "";
		try {
			String Query = "SELECT WINAME,Current_WS,ConsequenceRowCount FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE CAST(Consequence_held_till AS DATE) = CAST(GETDATE() AS DATE) AND CURRENT_WS IN ('Maker2','RM_Vendor','Controls','Compliance') AND BBGCustomerOutreachFlag NOT IN ('Pending')";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) 
			{
				WINAME = entry.get("WINAME");
				Current_WS = entry.get("Current_WS");
				ConsequenceRowCount = entry.get("ConsequenceRowCount");
				RouteRelatedPartyWI(WINAME, "Send to KYC Consequence", "");
				String WorkItemID = "";
				String ActivityID = "";
				String ProcessDefID = "";
				String EntryDateTime = "";
				String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE with (nolock) where ProcessInstanceID = '"+ WINAME + "' AND workItemID = '1'";
				String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
				XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
				String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
				int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
				if (dataMainCode.equals("0") && dataTotalRecords > 0) {
					WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
					ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
					ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
					EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");
					StringBuffer ipXMLBuffer = new StringBuffer();
					ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
					ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
					ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
					ipXMLBuffer.append("<EngineName>");
					ipXMLBuffer.append(cabinetName);
					ipXMLBuffer.append("</EngineName>\n");
					ipXMLBuffer.append("<SessionID>");
					ipXMLBuffer.append(sessionID);
					ipXMLBuffer.append("</SessionID>\n");
					ipXMLBuffer.append("<ProcessInstanceID>");
					ipXMLBuffer.append(WINAME);
					ipXMLBuffer.append("</ProcessInstanceID>\n");
					ipXMLBuffer.append("<WorkItemID>");
					ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</WorkItemID>\n");
					ipXMLBuffer.append("<SourceUser>");
					// ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</SourceUser>\n");
					ipXMLBuffer.append("<TargetUser>");
					ipXMLBuffer.append("rakbpmutility");
					ipXMLBuffer.append("</TargetUser>\n");
					ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
					String WMUnlockWIInput = ipXMLBuffer.toString();
					CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
					String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

					XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
					String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

					if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

						String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME, WorkItemID);
						CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
						String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);
						XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
						String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

						if (getWorkItemMainCode.trim().equals("0")) {
							String consequenceheldtill = "";
							//String attributeTAg = "<DECISION>Send to KYC Consequence</DECISION><Consequence_held_till>" + consequenceheldtill + "</Consequence_held_till>";
							String consequenceDate = getConsequenceDate();
							String consequenceApplyDateTime = getConsequenceApplyDateTime();
							String attributeTAg = "<DECISION>Send to Consequence_Hold</DECISION><Consequence_held_till>" + consequenceheldtill + "</Consequence_held_till>"
									+"<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Debit Cards</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
									+ "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Credit Cards</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
									+ "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Digital Banking</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
									+"<ConsequenceRowCount>"+ConsequenceRowCount+3+"</ConsequenceRowCount><CONSEQUENCE_STATUS>Partial Applied</CONSEQUENCE_STATUS><CONSEQUENCE_ACTION>Block Debit Cards|Block Credit Cards|Block Digital Banking</CONSEQUENCE_ACTION><LATEST_CONSEQUENCE_DATE>"+consequenceDate+"</LATEST_CONSEQUENCE_DATE>"
									+ "<ConsequenceEntryFlag>Y</ConsequenceEntryFlag>";
							
							String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
									+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
									+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
									+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
									+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID + "</ActivityId>"
									+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
									+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
									+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
									+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributeTAg
									+ "</Attributes>" + "</WMAssignWorkItemAttributes_Input>";

							CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
							String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
							XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
							String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
							if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("WI routed--- " + WINAME);
								Date d = new Date();
								SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								String strDate = dateFormat.format(d);
								String remarks = "Consequence Held till Date reached.";
								String tableName = "NG_KYC_REM_GR_HISTORY";
								String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
								String values = "'" + strDate + "','" + Current_WS
										+ "','Send to KYC Consequence','rakBPMutility','" + remarks + "','" + WINAME
										+ "','" + EntryDateTime + "'";
								String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName,
										values, tableName);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

								String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort,
										1);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

								XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of aapInsertOutputXML for insertion in history grid - "
												+ apInsertOutputXML);
								String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of apInsertMaincode  " + apInsertMaincode);
								if (apInsertMaincode.equalsIgnoreCase("0")) {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("ApInsert successful: " + apInsertMaincode);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Inserted in history table successfully.");
								} else {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Insertion in history table failed.");
								}
							} else {
								CustOutreachLog.KYCcustOutreachLogger.debug("Error in assignWICall--- " + WINAME);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Error in getWICall--- " + WINAME);
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Error in reassigning--- " + WINAME);
					}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Error in getting Activity ID--- " + WINAME);
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception happened for Consequence hold till-- " + WINAME + "----" + e.getMessage());
		}
		return "success";
	}

	private String ExpireEmailHoldWI() {
		String WINAME = "";
		try {
			String Query = "SELECT WINAME FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE EntryAt < DATEADD(HOUR, -72, GETDATE()) AND Prev_Dec = 'Customer Notification' AND "
					+ "CURRENT_WS = 'Email_Hold'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				WINAME = entry.get("WINAME");
				if (expireChildWI(WINAME)) {
					RouteRelatedPartyWI(WINAME, "Send to Maker2", "");
					String WorkItemID = "";
					String ActivityID = "";
					String ProcessDefID = "";
					String EntryDateTime = "";
					String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE with (nolock) where ProcessInstanceID = '"
							+ WINAME + "' AND Workitemid = '1'";
					String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
					String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
					XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
					String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
					int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
					if (dataMainCode.equals("0") && dataTotalRecords > 0) {
						WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
						ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
						ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
						EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

						StringBuffer ipXMLBuffer = new StringBuffer();

						ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
						ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
						ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
						ipXMLBuffer.append("<EngineName>");
						ipXMLBuffer.append(cabinetName);
						ipXMLBuffer.append("</EngineName>\n");
						ipXMLBuffer.append("<SessionID>");
						ipXMLBuffer.append(sessionID);
						ipXMLBuffer.append("</SessionID>\n");
						ipXMLBuffer.append("<ProcessInstanceID>");
						ipXMLBuffer.append(WINAME);
						ipXMLBuffer.append("</ProcessInstanceID>\n");
						ipXMLBuffer.append("<WorkItemID>");
						ipXMLBuffer.append(WorkItemID);
						ipXMLBuffer.append("</WorkItemID>\n");
						ipXMLBuffer.append("<SourceUser>");
						// ipXMLBuffer.append(WorkItemID);
						ipXMLBuffer.append("</SourceUser>\n");
						ipXMLBuffer.append("<TargetUser>");
						ipXMLBuffer.append("rakbpmutility");
						ipXMLBuffer.append("</TargetUser>\n");
						ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
						String WMUnlockWIInput = ipXMLBuffer.toString();
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
						String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

						XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
						String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

						if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

							String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,
									WorkItemID);
							CustOutreachLog.KYCcustOutreachLogger
									.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
							String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort,
									1);
							CustOutreachLog.KYCcustOutreachLogger
									.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

							XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
							String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
							CustOutreachLog.KYCcustOutreachLogger
									.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

							if (getWorkItemMainCode.trim().equals("0")) {

								String attributeTAg = "<DECISION>Send to Maker2</DECISION>";
								String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
										+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
										+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
										+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
										+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID + "</ActivityId>"
										+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
										+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
										+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>"
										+ "<Comments></Comments>" + "<UserDefVarFlag>Y</UserDefVarFlag>"
										+ "<Attributes>" + attributeTAg + "</Attributes>"
										+ "</WMAssignWorkItemAttributes_Input>";

								CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
								String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
								CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
								XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
								String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
								if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {
									CustOutreachLog.KYCcustOutreachLogger.debug("WI routed--- " + WINAME);
									Date d = new Date();
									SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
									String strDate = dateFormat.format(d);
									String remarks = "WI Expired from Email Hold as 72 hours passed.";
									String tableName = "NG_KYC_REM_GR_HISTORY";
									String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
									String values = "'" + strDate
											+ "','Consequence_Hold','Send to Maker2','rakBPMutility','" + remarks
											+ "','" + WINAME + "','" + EntryDateTime + "'";
									String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName,
											values, tableName);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("APInsertInputXML: " + apInsertInputXML);

									String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP,
											jtsPort, 1);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("APInsertOutputXML: " + apInsertOutputXML);

									XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Status of aapInsertOutputXML for insertion in history grid - "
													+ apInsertOutputXML);
									String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Status of apInsertMaincode  " + apInsertMaincode);
									if (apInsertMaincode.equalsIgnoreCase("0")) {
										CustOutreachLog.KYCcustOutreachLogger
												.debug("ApInsert successful: " + apInsertMaincode);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("Data Inserted in history table successfully.");
									} else {
										CustOutreachLog.KYCcustOutreachLogger
												.debug("Data Insertion in history table failed.");
									}
								} else {
									CustOutreachLog.KYCcustOutreachLogger.debug("Error in assignWICall--- " + WINAME);
								}
							} else {
								CustOutreachLog.KYCcustOutreachLogger.debug("Error in getWICall--- " + WINAME);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Error in reassigning--- " + WINAME);
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Error in getting Activity ID--- " + WINAME);
					}
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception happened for Email Hold Expiry-- " + WINAME + "----" + e.getMessage());
			return "Error";
		}
		return "success";
	}

	private void RouteConsequenceWI() {
		try {
			String Query = "Select WINAME,CaseType from RB_KYC_REM_EXTTABLE with (nolock) "
					+ "where Aging > 90 AND CURRENT_WS = 'RM_Vendor' AND (CustomerOutreachFlag != 'Completed' OR CustomerOutreachFlag is null) "
					+ "AND (ConsequenceEntryFlag is null or ConsequenceEntryFlag = '') AND CaseType = 'Individual'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				String ConsequenceGridCount = "";
				String WINAME = entry.get("WINAME");

				String result = "Success";// RouteRelatedPartyWI(WINAME);
				if ("Success".equalsIgnoreCase(result)) {
						ConsequenceGridCount = getConsequenceGridCount(WINAME);
						int consequenceGridCount = Integer.parseInt(ConsequenceGridCount)+3;
						CustOutreachLog.KYCcustOutreachLogger.debug("Count received for WI - " + WINAME + " : " + ConsequenceGridCount);
						String WorkItemID = "";
						String ActivityID = "";
						String ProcessDefID = "";
						String EntryDateTime = "";
						String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE where ProcessInstanceID = '"
								+ WINAME + "' AND Workitemid = '1'";
						String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
						String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
						XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
						String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
						int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
						if (dataMainCode.equals("0") && dataTotalRecords > 0) {
							WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
							ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
							ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
							EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

							StringBuffer ipXMLBuffer = new StringBuffer();

							ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
							ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
							ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
							ipXMLBuffer.append("<EngineName>");
							ipXMLBuffer.append(cabinetName);
							ipXMLBuffer.append("</EngineName>\n");
							ipXMLBuffer.append("<SessionID>");
							ipXMLBuffer.append(sessionID);
							ipXMLBuffer.append("</SessionID>\n");
							ipXMLBuffer.append("<ProcessInstanceID>");
							ipXMLBuffer.append(WINAME);
							ipXMLBuffer.append("</ProcessInstanceID>\n");
							ipXMLBuffer.append("<WorkItemID>");
							ipXMLBuffer.append(WorkItemID);
							ipXMLBuffer.append("</WorkItemID>\n");
							ipXMLBuffer.append("<SourceUser>");
							// ipXMLBuffer.append(WorkItemID);
							ipXMLBuffer.append("</SourceUser>\n");
							ipXMLBuffer.append("<TargetUser>");
							ipXMLBuffer.append("rakbpmutility");
							ipXMLBuffer.append("</TargetUser>\n");
							ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
							String WMUnlockWIInput = ipXMLBuffer.toString();
							CustOutreachLog.KYCcustOutreachLogger
									.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
							String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger
									.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

							XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
							String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
							CustOutreachLog.KYCcustOutreachLogger
									.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

							if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

								String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID,
										WINAME, WorkItemID);
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
								String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP,
										jtsPort, 1);
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

								XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
								String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
								CustOutreachLog.KYCcustOutreachLogger
										.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);
								if (getWorkItemMainCode.trim().equals("0")) {
									String consequenceDate = getConsequenceDate();
									String consequenceApplyDateTime = getConsequenceApplyDateTime();
									String attributeTag = "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Debit Cards</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
											+ "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Credit Cards</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
											+ "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Partial Applied</ConsequenceStatus><ActionTaken>Block Digital Banking</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
											+"<DECISION>Send to Consequence_Hold</DECISION><ConsequenceRowCount>"+String.valueOf(consequenceGridCount)+"</ConsequenceRowCount><CONSEQUENCE_STATUS>Partial Applied</CONSEQUENCE_STATUS><CONSEQUENCE_ACTION>Block Debit Cards|Block Credit Cards|Block Digital Banking</CONSEQUENCE_ACTION><FIRST_CONSEQUENCE_DATE>"+consequenceDate+"</FIRST_CONSEQUENCE_DATE><LATEST_CONSEQUENCE_DATE>"+consequenceDate+"</LATEST_CONSEQUENCE_DATE><ConsequenceEntryFlag>Y</ConsequenceEntryFlag>";
									String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
											+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>"
											+ cabinetName + "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
											+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
											+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID
											+ "</ActivityId>" + "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
											+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
											+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>"
											+ "<Comments></Comments>" + "<UserDefVarFlag>Y</UserDefVarFlag>"
											+ "<Attributes>"+attributeTag+"</Attributes>"
											+ "</WMAssignWorkItemAttributes_Input>";

									CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
									String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
									CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
									XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
									String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal
											.getValueOf("MainCode");
									if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {

										Date d = new Date();
										SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
										String strDate = dateFormat.format(d);

										String tableName = "NG_KYC_REM_GR_HISTORY";
										String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
										String values = "'" + strDate
												+ "','RM_Vendor','Send to Consequence_Hold','rakBPMutility','WI Eligible for Consequence','"
												+ WINAME + "','" + EntryDateTime + "'";

										String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID,
												columnName, values, tableName);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("APInsertInputXML: " + apInsertInputXML);

										String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP,
												jtsPort, 1);
										CustOutreachLog.KYCcustOutreachLogger
												.debug("APInsertOutputXML: " + apInsertOutputXML);

										XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
										String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
										CustOutreachLog.KYCcustOutreachLogger
												.debug("Status of apInsertMaincode  " + apInsertMaincode);
										if (apInsertMaincode.equalsIgnoreCase("0")) {
											CustOutreachLog.KYCcustOutreachLogger
													.debug("ApInsert successful: " + apInsertMaincode);
											CustOutreachLog.KYCcustOutreachLogger
													.debug("Data Inserted in history table successfully.");
										}
									}
								} else {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Errro in getWI call for WI - " + WINAME);
								}
							}
						}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Errro in moving related party WI of - " + WINAME);
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in RouteConsequenceWI method-" + e.getMessage());
		}
	}

	private String RouteRelatedPartyWI(String MainWI, String decision, String lastConsStatus) {
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside RouteRelatedPartyWI for main WI - " + MainWI);
			String Query = "SELECT RP_WI_Number FROM NG_KYC_REM_RP_GRID with (nolock) WHERE WI_Name = '" + MainWI + "'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {
				String WINAME = entry.get("RP_WI_Number");

				String WorkItemID = "";
				String ActivityID = "";
				String ProcessDefID = "";
				String EntryDateTime = "";
				String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE where ProcessInstanceID = '"
						+ WINAME + "' AND workitemID = '1'";
				String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
				XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
				String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
				int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
				if (dataMainCode.equals("0") && dataTotalRecords > 0) {
					WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
					ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
					ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
					EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

					StringBuffer ipXMLBuffer = new StringBuffer();

					ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
					ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
					ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
					ipXMLBuffer.append("<EngineName>");
					ipXMLBuffer.append(cabinetName);
					ipXMLBuffer.append("</EngineName>\n");
					ipXMLBuffer.append("<SessionID>");
					ipXMLBuffer.append(sessionID);
					ipXMLBuffer.append("</SessionID>\n");
					ipXMLBuffer.append("<ProcessInstanceID>");
					ipXMLBuffer.append(WINAME);
					ipXMLBuffer.append("</ProcessInstanceID>\n");
					ipXMLBuffer.append("<WorkItemID>");
					ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</WorkItemID>\n");
					ipXMLBuffer.append("<SourceUser>");
					// ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</SourceUser>\n");
					ipXMLBuffer.append("<TargetUser>");
					ipXMLBuffer.append("rakbpmutility");
					ipXMLBuffer.append("</TargetUser>\n");
					ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
					String WMUnlockWIInput = ipXMLBuffer.toString();
					CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
					String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

					XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
					String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

					if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

						String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,
								WorkItemID);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
						String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

						XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
						String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger
								.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);
						if (getWorkItemMainCode.trim().equals("0")) {
							String attTag = "<DECISION>" + decision + "</DECISION>";
							if(!"".equalsIgnoreCase(lastConsStatus))
								attTag += "<LastConsStatus>"+lastConsStatus+"<LastConsStatus>";
							String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
									+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
									+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
									+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
									+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID + "</ActivityId>"
									+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
									+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
									+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
									+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attTag + "</Attributes>"
									+ "</WMAssignWorkItemAttributes_Input>";

							CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
							String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
							XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
							String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
							if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("Related Party WI routed--- " + WINAME);
							} else {
								CustOutreachLog.KYCcustOutreachLogger.debug("Error in assignWICall--- " + WINAME);
								return "Error";
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Error in getWICall--- " + WINAME);
							return "Error";
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Error in reassigning--- " + WINAME);
						return "Error";
					}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Error in getting Activity ID--- " + WINAME);
					return "Error";
				}
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in RouteRelatedPartyWI method-" + e.getMessage());
			return "Error";
		}
		return "Success";
	}

	private String RouteAutoConsequenceWI() {
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside Route Auto Consequence WI ");
			String Query = "SELECT AUTO_CONSEQUENCE_STATUS,WINAME,CaseType,PREV_WS,CustomerOutreachFlag,BBGCustomerOutreachFlag,FAILURE_REASON,Consequence_Status,Consequence_Action,CompanyEmailID,Customer_Subsegment,Prev_Dec "
					+ "from RB_KYC_REM_EXTTABLE with (nolock) where CURRENT_WS = 'Consequence_Hold' AND AUTO_CONSEQUENCE_STATUS IN ('Success','Fail')";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDBs : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				String autoConsequenceStatus = entry.get("AUTO_CONSEQUENCE_STATUS");
				String WINAME = entry.get("WINAME");
				String caseType = entry.get("CaseType");
				String prevWS = entry.get("PREV_WS");
				String CustomerOutreachFlag = entry.get("CustomerOutreachFlag");
				String BBGCustomerOutreachFlag = entry.get("BBGCustomerOutreachFlag");
				String consequenceStatus = entry.get("Consequence_Status");
				String consequenceAction = entry.get("Consequence_Action");
				String failureReason = entry.get("FAILURE_REASON");
				String CompanyEmailID = entry.get("CompanyEmailID");
				String Customer_Subsegment = entry.get("Customer_Subsegment");
				String prevDecision = entry.get("Prev_Dec");
				String decision = "";
				String remarks = "";
				String lastConsStatus = "";
				
				// deciding where to route the WI
				if ("Consequence".equalsIgnoreCase(prevWS) || "RM_Vendor".equalsIgnoreCase(prevWS) || "Email_Hold".equalsIgnoreCase(prevWS) || "Maker2".equalsIgnoreCase(prevWS) || "Controls".equalsIgnoreCase(prevWS) || "Compliance".equalsIgnoreCase(prevWS)) {
					CustOutreachLog.KYCcustOutreachLogger.debug("inside prev_ws is consequence");
					if ("Fail".equalsIgnoreCase(autoConsequenceStatus)) {
						if ("Fully Applied".equalsIgnoreCase(consequenceStatus)) {
							remarks = "Failure";
							decision = "Send to Consequence Manual";
							if (!"".equalsIgnoreCase(failureReason))
								failureReason += ";Cheque Book Facility Block Pending";
							else
								failureReason = "Cheque Book Facility Block Pending";
						} else if ("Partial Applied".equalsIgnoreCase(consequenceStatus)) {
							if (consequenceAction.contains("Block Cheque Book Facility")) {
								remarks = "Failure";
								decision = "Send to Consequence Manual";
								if (!"".equalsIgnoreCase(failureReason))
									failureReason += ";Cheque Book Facility Block Pending";
								else
									failureReason = "Cheque Book Facility Block Pending";
							} else {
								remarks = "Failure";
								decision = "Send to Consequence Manual";
							}
						}
					} else if ("Success".equalsIgnoreCase(autoConsequenceStatus)) {
						if ("Fully Applied".equalsIgnoreCase(consequenceStatus)) {
							remarks = "Block cheque book manually";
							decision = "Send to Consequence Manual";
							failureReason = "Cheque Book Facility Block Pending";
						} else if ("Partial Applied".equalsIgnoreCase(consequenceStatus)) {
							if (consequenceAction.contains("Block Cheque Book Facility")) {
								remarks = "Block cheque book manually";
								decision = "Send to Consequence Manual";
								failureReason = "Cheque Book Facility Block Pending";
							} else {
								remarks = "Consequence applied successfully";
								decision = "Send to RM Vendor";
								failureReason = "Selected consequence actions applied successfully";
							}
						}
					}
				} 
				if ("Approver".equalsIgnoreCase(prevWS) || "RM_Vendor".equalsIgnoreCase(prevWS) || "Consequence".equalsIgnoreCase(prevWS)) {
					//CustOutreachLog.KYCcustOutreachLogger.debug("inside prev_ws is approver");
					if ("Removal of Consequence Management".equalsIgnoreCase(consequenceStatus)) {
						if ("Fail".equalsIgnoreCase(autoConsequenceStatus)) {
							if("RM_Vendor".equalsIgnoreCase(prevWS) || "Consequence".equalsIgnoreCase(prevWS)){
								remarks = "Failure in Removing Consequence";
								decision = "Send to Consequence Manual";
								lastConsStatus = "Remediation Approved";
							}
							if("Approver".equalsIgnoreCase(prevWS)){
								remarks = "Failure in Removing Consequence";
								decision = "Send to Consequence Manual";
								//lastConsStatus is already set from Approver workstep.
							}		
						} else if ("Success".equalsIgnoreCase(autoConsequenceStatus)) {
							if(checkAppliedConsequences(WINAME)){
								remarks = "Consequence removed successfully";
								if("Approver".equalsIgnoreCase(prevWS)){
									if("Approved".equalsIgnoreCase(prevDecision)) decision = "Approved";
									if("Remove Consequence".equalsIgnoreCase(prevDecision)) decision = "Send to Approver";
								}
								if("RM_Vendor".equalsIgnoreCase(prevWS) || "Consequence".equalsIgnoreCase(prevWS)) decision = "Approved";
								failureReason = "Service restriction removed successfully";
							}
							else
							{
								remarks = "Consequence removed successfully";
								decision = "Send to Consequence Manual";
								failureReason = "Service restriction removed successfully. Cheque book facility block pending to be removed.";
								if("RM_Vendor".equalsIgnoreCase(prevWS) || "Consequence".equalsIgnoreCase(prevWS)){
									lastConsStatus = "Remediation Approved";
								}
								//else if came from Approver lastConsStatus is already set from Approver.
							}
						}
					}
				}
				CustOutreachLog.KYCcustOutreachLogger.debug("decision - " + decision);
				CustOutreachLog.KYCcustOutreachLogger.debug("remarks - " + remarks);
				// deciding where to route the WI end
				if ("Corporate".equalsIgnoreCase(caseType))
					RouteRelatedPartyWI(WINAME, decision,lastConsStatus);
				String WorkItemID = "";
				String ActivityID = "";
				String ProcessDefID = "";
				String EntryDateTime = "";
				String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE with (nolock) where ProcessInstanceID = '"
						+ WINAME + "' AND WorkItemID = '1'";
				String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
				XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
				String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
				int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
				if (dataMainCode.equals("0") && dataTotalRecords > 0) {
					WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
					ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
					ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
					EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

					StringBuffer ipXMLBuffer = new StringBuffer();

					ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
					ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
					ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
					ipXMLBuffer.append("<EngineName>");
					ipXMLBuffer.append(cabinetName);
					ipXMLBuffer.append("</EngineName>\n");
					ipXMLBuffer.append("<SessionID>");
					ipXMLBuffer.append(sessionID);
					ipXMLBuffer.append("</SessionID>\n");
					ipXMLBuffer.append("<ProcessInstanceID>");
					ipXMLBuffer.append(WINAME);
					ipXMLBuffer.append("</ProcessInstanceID>\n");
					ipXMLBuffer.append("<WorkItemID>");
					ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</WorkItemID>\n");
					ipXMLBuffer.append("<SourceUser>");
					// ipXMLBuffer.append(WorkItemID);
					ipXMLBuffer.append("</SourceUser>\n");
					ipXMLBuffer.append("<TargetUser>");
					ipXMLBuffer.append("rakbpmutility");
					ipXMLBuffer.append("</TargetUser>\n");
					ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
					String WMUnlockWIInput = ipXMLBuffer.toString();
					CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
					String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

					XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
					String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

					if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

						String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,
								WorkItemID);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
						String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger
								.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

						XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
						String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
						CustOutreachLog.KYCcustOutreachLogger
								.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

						if (getWorkItemMainCode.trim().equals("0")) {
							String attributeTAg = "<DECISION>" + decision + "</DECISION><FAILURE_REASON>"
									+ failureReason + "</FAILURE_REASON>";
							if(!"".equalsIgnoreCase(lastConsStatus)){
								attributeTAg += "<LastConsStatus>"+lastConsStatus+"</LastConsStatus>";
							}
							String consequenceEmailSent = "N";
							if (!"Approver".equalsIgnoreCase(prevWS) && !"Corporate".equalsIgnoreCase(caseType)
									&& "Send to RM Vendor".equalsIgnoreCase(decision) && !"Completed".equalsIgnoreCase(CustomerOutreachFlag)) {
								attributeTAg += "<CONSEQUENCE_EMAIL_FLAG>Pending</CONSEQUENCE_EMAIL_FLAG><CustomerOutreachFlag>Pending</CustomerOutreachFlag><isReoutreach>N</isReoutreach>";
								/*if (!"In Progress".equalsIgnoreCase(CustomerOutreachFlag))
									attributeTAg += "<WICategory>CAT3</WICategory>";*/
							}
							else if (!"Approver".equalsIgnoreCase(prevWS) && "Corporate".equalsIgnoreCase(caseType)
									&& "Send to RM Vendor".equalsIgnoreCase(decision) && ("SME".equalsIgnoreCase(Customer_Subsegment) 
											|| "PSL".equalsIgnoreCase(Customer_Subsegment)) && !"Completed".equalsIgnoreCase(BBGCustomerOutreachFlag)) {
								CustOutreachLog.KYCcustOutreachLogger.debug("Checking to update Consequence_EMAIL_FLAG");
								String qry = "SELECT Decision from NG_KYC_REM_GR_HISTORY WHERE WI_NAME = '"+WINAME+"' AND Decision IN ('Customer Outreach','Customer Notification','Outreach to Portal') ORDER BY DateTime desc";
								CustOutreachLog.KYCcustOutreachLogger.debug("Query to check if Outreach to portal decision is staken on WI"+qry);
								String dataInputXMLdecision = CommonMethods.apSelectWithColumnNames(qry, cabinetName, sessionID);
								String dataOutputXMLdecision = CommonMethods.WFNGExecute(dataInputXMLdecision, jtsIP, jtsPort, 1);
								XMLParser dataxmlParserAPSelectdecision = new XMLParser(dataOutputXMLdecision);
								String MainCode = dataxmlParserAPSelectdecision.getValueOf("MainCode");
								int TotalRecords = Integer.parseInt(dataxmlParserAPSelectdecision.getValueOf("TotalRetrieved"));
								if (MainCode.equals("0") && TotalRecords > 0) {
									String outreachdecision = dataxmlParserAPSelectdecision.getValueOf("Decision");
									if("Outreach to Portal".equalsIgnoreCase(outreachdecision))
									{
										attributeTAg += "<CONSEQUENCE_EMAIL_FLAG>Pending</CONSEQUENCE_EMAIL_FLAG><BBGCustomerOutreachFlag>Pending</BBGCustomerOutreachFlag><isReoutreach>N</isReoutreach>";
										consequenceEmailSent = "Y";
									}
									else if("Customer Outreach".equalsIgnoreCase(outreachdecision) || "Customer Notification".equalsIgnoreCase(outreachdecision))
									{
										consequenceEmailSent = "N";
									}
									else
									{
										String query1 = "SELECT BBG_OUTREACH_CASE FROM NG_KYC_REM_BO_IBPS_TABLE with(nolock) WHERE Wi_Name = '"+WINAME+"'";
										String dataInputXMLdecision1 = CommonMethods.apSelectWithColumnNames(query1, cabinetName, sessionID);
										String dataOutputXMLdecision1 = CommonMethods.WFNGExecute(dataInputXMLdecision1, jtsIP, jtsPort, 1);
										XMLParser dataxmlParserAPSelectdecision1 = new XMLParser(dataOutputXMLdecision1);
										String MainCode1 = dataxmlParserAPSelectdecision1.getValueOf("MainCode");
										int TotalRecords1 = Integer.parseInt(dataxmlParserAPSelectdecision1.getValueOf("TotalRetrieved"));
										if (MainCode1.equals("0") && TotalRecords1 > 0) {
											String BBGOuteachCase = dataxmlParserAPSelectdecision1.getValueOf("BBG_OUTREACH_CASE");
											if("Y".equalsIgnoreCase(BBGOuteachCase)){
												attributeTAg += "<CONSEQUENCE_EMAIL_FLAG>Pending</CONSEQUENCE_EMAIL_FLAG><BBGCustomerOutreachFlag>Pending</BBGCustomerOutreachFlag><isReoutreach>N</isReoutreach>";
												consequenceEmailSent = "Y";
											}
										}
									}
								}
								else
								{
									String query1 = "SELECT BBG_OUTREACH_CASE FROM NG_KYC_REM_BO_IBPS_TABLE with(nolock) WHERE Wi_Name = '"+WINAME+"'";
									String dataInputXMLdecision1 = CommonMethods.apSelectWithColumnNames(query1, cabinetName, sessionID);
									String dataOutputXMLdecision1 = CommonMethods.WFNGExecute(dataInputXMLdecision1, jtsIP, jtsPort, 1);
									XMLParser dataxmlParserAPSelectdecision1 = new XMLParser(dataOutputXMLdecision1);
									String MainCode1 = dataxmlParserAPSelectdecision1.getValueOf("MainCode");
									int TotalRecords1 = Integer.parseInt(dataxmlParserAPSelectdecision1.getValueOf("TotalRetrieved"));
									if (MainCode1.equals("0") && TotalRecords1 > 0) {
										String BBGOuteachCase = dataxmlParserAPSelectdecision1.getValueOf("BBG_OUTREACH_CASE");
										if("Y".equalsIgnoreCase(BBGOuteachCase)){
											attributeTAg += "<CONSEQUENCE_EMAIL_FLAG>Pending</CONSEQUENCE_EMAIL_FLAG><BBGCustomerOutreachFlag>Pending</BBGCustomerOutreachFlag><isReoutreach>N</isReoutreach>";
											consequenceEmailSent = "Y";
										}
									}
								}
								/*else{
									attributeTAg += "<CONSEQUENCE_EMAIL_FLAG>Pending</CONSEQUENCE_EMAIL_FLAG><BBGCustomerOutreachFlag>Pending</BBGCustomerOutreachFlag><isReoutreach>N</isReoutreach>";
								}*/
							}
							String ConsequenceGridCount = getConsequenceGridCount(WINAME);
							int consequenceGridCount = Integer.parseInt(ConsequenceGridCount);
							attributeTAg += "<ConsequenceRowCount>"+String.valueOf(consequenceGridCount)+"</ConsequenceRowCount>";
							String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
									+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
									+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>"
									+ "<ProcessInstanceId>" + WINAME + "</ProcessInstanceId>" + "<WorkItemId>"
									+ WorkItemID + "</WorkItemId>" + "<ActivityId>" + ActivityID + "</ActivityId>"
									+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
									+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
									+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
									+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributeTAg
									+ "</Attributes>" + "</WMAssignWorkItemAttributes_Input>";

							CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
							String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
							XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
							String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
							if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("WI routed--- " + WINAME);
								if ("Send to RM Vendor".equalsIgnoreCase(decision)
										&& !"Approver".equalsIgnoreCase(prevWS)
										&& "Corporate".equalsIgnoreCase(caseType) && "N".equalsIgnoreCase(consequenceEmailSent))
									sendcustomEmail(WINAME, "consequenceEmail", consequenceAction, CompanyEmailID);
								Date d = new Date();
								SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								String strDate = dateFormat.format(d);
								String tableName = "NG_KYC_REM_GR_HISTORY";
								String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
								String values = "'" + strDate + "','Consequence_Hold','" + decision
										+ "','rakBPMutility','" + remarks + "','" + WINAME + "','" + EntryDateTime
										+ "'";
								String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName,
										values, tableName);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

								String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort,
										1);
								CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

								XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of apInsertOutputXML for insertion in history grid - "
												+ apInsertOutputXML);
								String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
								CustOutreachLog.KYCcustOutreachLogger
										.debug("Status of apInsertMaincode  " + apInsertMaincode);
								if (apInsertMaincode.equalsIgnoreCase("0")) {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("ApInsert successful: " + apInsertMaincode);
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Inserted in history table successfully.");
								} else {
									CustOutreachLog.KYCcustOutreachLogger
											.debug("Data Insertion in history table failed.");
								}
							} else {
								CustOutreachLog.KYCcustOutreachLogger.debug("Error in assignWICall--- " + WINAME);
							}
						} else {
							CustOutreachLog.KYCcustOutreachLogger.debug("Error in getWICall--- " + WINAME);
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Error in reassigning--- " + WINAME);
					}
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Error in getting Activity ID--- " + WINAME);

				}
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in AutoConsequence Method -" + e.getMessage());
			return "Error";
		}
		return "Success";
	}

	private boolean checkAppliedConsequences(String wINAME) {
		boolean status = true;
		try{
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside Route Auto Consequence WI ");
			String Query = "SELECT ActionTaken FROM NG_KYC_REM_Consequence_Grid with(nolock) where ActionTaken IN ('Block All Services','Block Cheque Book Facility') AND WINAME = '"+wINAME+"'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDBs : OF_DATA_DEF_ID " + DataFromDB);
			if(DataFromDB.size()>0)
				return false;
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in checkAppliedConsequences Method -" + e.getMessage());
		}
		return status;
	}

	private void DoneWI(String WINAME, String flag, String OutreachupdateDateTime, String CURRENT_WS, String caseType,
			String cif, HashMap<String, String> socketDetailsMap, String OutreachDocFlag, String outreachFlag,
			String prefAddressFlag, String officeAddressLine1, String officeCountry, String officeCityEmirate,
			String ResidenceFlatVillaNo, String ResidenceCountry, String ResidenceEmirateCity, String riskScore,
			String WICategory, String ProfileChange, String DocumentUpload, String employer, String AutoRRCStatus, String EMPLOYER_CHANGE,String DeclineFlag, String BBG_NSTP_Remark) {
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside DoneWI ");
			CustOutreachLog.KYCcustOutreachLogger.debug("Flag received is - "+flag);
			String decision = "";
			String Remark = "";
			String res = "";
			String isConsequenceApplied = "";
			// String Status = "";
			if("Individual".equalsIgnoreCase(caseType)){
				getListDocsToBeAttachedUploadFlagStatus("'"+WINAME+"'", DocsList);
				CustOutreachLog.KYCcustOutreachLogger.debug("DocdList legth is - "+DocsList.size());
				if ((DocsList.isEmpty() && "0".equalsIgnoreCase(OutreachDocFlag)) || (DocsList.isEmpty() /*&& "1".equalsIgnoreCase(OutreachDocFlag)*/ && "DocsAttached".equalsIgnoreCase(flag))) 
				{
					CustOutreachLog.KYCcustOutreachLogger.debug("Trying to complete WI....");
					decision = "Submit to Maker";
					Remark = "Outreach complete through Online Portal";
					// Status = "Complete";
					//generateKYCform(WINAME, caseType, cif);
					/*if("".equalsIgnoreCase(AutoRRCStatus))
					{*/
						res = generateRRCsheet(WINAME, cif, socketDetailsMap,caseType,riskScore);
						String rs = res.split("-")[1];
						isConsequenceApplied = IsConsequenceApplied(WINAME);
					/*}
					else
					{
						if("Success".equalsIgnoreCase(AutoRRCStatus)) res = "0000";
						else res = "9999";
					}*/
					if ("Negative Processed".equalsIgnoreCase(outreachFlag)) 
					{
						Remark = "";
						if (!res.contains("0000") || ("High".equalsIgnoreCase(rs) || "Elevated".equalsIgnoreCase(rs)) || "".equalsIgnoreCase(prefAddressFlag) || 
								("OFFICE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(officeAddressLine1) || "".equalsIgnoreCase(officeCountry) || "".equalsIgnoreCase(officeCityEmirate))) || 
								("RESIDENCE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(ResidenceFlatVillaNo) || "".equalsIgnoreCase(ResidenceCountry) || "".equalsIgnoreCase(ResidenceEmirateCity)))) 
						{
							decision = "Submit to Approver";
							if (!res.contains("0000"))  Remark = "Negative processed received. WI moved to approver as RRC failed";
							if ("High".equalsIgnoreCase(rs) || "Elevated".equalsIgnoreCase(rs)) Remark += "\nNegative processed. WI moved to approver queue as risk score is " + rs;
							if ("".equalsIgnoreCase(prefAddressFlag))  Remark += "\nNegative processed received. WI moved to approver as preferred address not available.";
							if ("OFFICE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(officeAddressLine1) || "".equalsIgnoreCase(officeCountry) || "".equalsIgnoreCase(officeCityEmirate))) Remark += "\nNegative processed received. WI moved to approver as all mandatory fields for office address are not available.";
							if ("RESIDENCE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(ResidenceFlatVillaNo) || "".equalsIgnoreCase(ResidenceCountry) || "".equalsIgnoreCase(ResidenceEmirateCity))) Remark += "\nNegative processed received. WI moved to approver as all mandatory fields for residence address are not available.";
						} 
						else 
						{	
							if("true".equalsIgnoreCase(isConsequenceApplied) && !"Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) {
								decision = "Send to Consequence_Hold";
								Remark = "Negative processed. WI marked as STP for CIF update. Moved for consequence removal.";
							}
							else/*("false".equalsIgnoreCase(isConsequenceApplied))*/ {
								decision = "Approved";
								Remark = "Negative processed. WI marked as STP for CIF update.";
							}	
						}
					}
					if("Completed".equalsIgnoreCase(outreachFlag) && ("CAT1".equalsIgnoreCase(WICategory) || "CAT2".equalsIgnoreCase(WICategory))){
						Remark = "";
						if("TRUE".equalsIgnoreCase(ProfileChange) || "TRUE".equalsIgnoreCase(DocumentUpload) || ("OTHER".equalsIgnoreCase(employer) || "OTHERS".equalsIgnoreCase(employer) || "ANY OTHER".equalsIgnoreCase(employer)) || 
								!res.contains("0000") || ("High".equalsIgnoreCase(rs) || "Elevated".equalsIgnoreCase(rs)) || "".equalsIgnoreCase(prefAddressFlag) || 
								("OFFICE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(officeAddressLine1) || "".equalsIgnoreCase(officeCountry) || "".equalsIgnoreCase(officeCityEmirate))) || 
								("RESIDENCE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(ResidenceFlatVillaNo) || "".equalsIgnoreCase(ResidenceCountry) || "".equalsIgnoreCase(ResidenceEmirateCity)))){
							decision = "Submit to Approver";
							if("TRUE".equalsIgnoreCase(ProfileChange) && "TRUE".equalsIgnoreCase(DocumentUpload)) 	Remark += "Profile change and document uploaded";
							if("TRUE".equalsIgnoreCase(ProfileChange) && !"TRUE".equalsIgnoreCase(DocumentUpload)) 	Remark += "\nProfile change";
							if(!"TRUE".equalsIgnoreCase(ProfileChange) && "TRUE".equalsIgnoreCase(DocumentUpload)) 	Remark += "\nDocument uploaded";
							if("OTHER".equalsIgnoreCase(employer) || "OTHERS".equalsIgnoreCase(employer) || "ANY OTHER".equalsIgnoreCase(employer)) Remark += "\nEmployer is ''other''. WI not eligible for STP.";
							if (!res.contains("0000")) Remark += "Completed from portal received. WI moved to approver as RRC failed";
							if ("High".equalsIgnoreCase(rs) || "Elevated".equalsIgnoreCase(rs)) Remark += "Completed from portal received. WI moved to approver queue as risk score is " + rs;
							if ("".equalsIgnoreCase(prefAddressFlag))  Remark += "\nWI moved to approver as preferred address not available.";
							if ("OFFICE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(officeAddressLine1) || "".equalsIgnoreCase(officeCountry) || "".equalsIgnoreCase(officeCityEmirate))) Remark += "\nWI moved to approver as all mandatory fields for office address are not available.";
							if ("RESIDENCE".equalsIgnoreCase(prefAddressFlag) && ("".equalsIgnoreCase(ResidenceFlatVillaNo) || "".equalsIgnoreCase(ResidenceCountry) || "".equalsIgnoreCase(ResidenceEmirateCity))) Remark += "\nWI moved to approver as all mandatory fields for residence address are not available.";
						}
						else/* if(!"TRUE".equalsIgnoreCase(ProfileChange) && !"TRUE".equalsIgnoreCase(DocumentUpload))*/
						{
							if("true".equalsIgnoreCase(isConsequenceApplied) && !"Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) {
								decision = "Send to Consequence_Hold";
								Remark = "WI marked as STP for CIF update. Moved for consequence removal.";
							}
							else/*("false".equalsIgnoreCase(isConsequenceApplied))*/ {
								decision = "Approved";
								Remark = "WI marked as STP for CIF update.";
							}
						}
					}
					//setNextReviewDateAndIndustry(riskScore, WINAME, EMPLOYER_CHANGE);
					setNextReviewDateAndIndustry(res, WINAME, EMPLOYER_CHANGE,"PBG",decision);
					if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) deleteConsequenceEntries(WINAME);
					CompleteWI(WINAME, decision, Remark, CURRENT_WS,ProfileChange,DocumentUpload,EMPLOYER_CHANGE,DeclineFlag);
				} else {
					CustOutreachLog.KYCcustOutreachLogger.debug("Inside else. Trying to send to doc error....");
					decision = "Error";
					if ("NoDocument".equalsIgnoreCase(flag))
						Remark = "Documents not found at location";
					else if ("FolderNotPresent".equalsIgnoreCase(flag))
						Remark = "Folder not present with name-->" + WINAME + " at location";
					else
						Remark = "Not all Outreach Docs Attached or received";
					if ("1".equalsIgnoreCase(OutreachDocFlag)) {
						boolean hours48 = HoursPassed(OutreachupdateDateTime);
						if (hours48){
							if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) deleteConsequenceEntries(WINAME);
							CompleteWI(WINAME, decision, Remark, CURRENT_WS,ProfileChange,DocumentUpload,EMPLOYER_CHANGE,DeclineFlag);
						}else
							CustOutreachLog.KYCcustOutreachLogger.debug("Waiting for 48 hours to receive docs for - " + WINAME);
					} else{
						if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) deleteConsequenceEntries(WINAME);
						CompleteWI(WINAME, decision, Remark, CURRENT_WS,ProfileChange,DocumentUpload,EMPLOYER_CHANGE,DeclineFlag);
						}
					}
			}
			if("Corporate".equalsIgnoreCase(caseType))
			{
				isConsequenceApplied = IsConsequenceApplied(WINAME);
				CustOutreachLog.KYCcustOutreachLogger.debug("Flag value identifier"+ flag);
				if(!DeclineFlag.contains("TRUE")) res = generateRRCsheet(WINAME, cif, socketDetailsMap,caseType,riskScore);
				String rpWIName = getRPWINAME(WINAME);
				String wiOutreachDocFlag = rpWIName+"'"+WINAME+"'";
				getListDocsToBeAttachedUploadFlagStatus(wiOutreachDocFlag, DocsList);
				/*boolean contains = DocsList.contains("ABD");*/
				 Set<String> nonMandatoryDocs = new HashSet<>(Arrays.asList("Corporate Tax or UAE TIN Certificate", "VAT Registration Certificate", "Passport Last Page"));
			     boolean result = containsOnlyNonMandatory(DocsList, nonMandatoryDocs);
				if ((DocsList.isEmpty() && "0".equalsIgnoreCase(OutreachDocFlag)) || (DocsList.isEmpty() && (!"0".equalsIgnoreCase(OutreachDocFlag) && !"".equalsIgnoreCase(OutreachDocFlag)) && "DocsAttached".equalsIgnoreCase(flag)) || (!DocsList.isEmpty() && "DocsAttached".equalsIgnoreCase(flag) && result) || (/*"1".equalsIgnoreCase(OutreachDocFlag) &&*/ "DocsAttached".equalsIgnoreCase(flag) && DeclineFlag.contains("TRUE"))) 
				{
					if(DeclineFlag.contains("TRUE"))
					{
						String declineReason = "";
						String splitDeclineFlag[] = DeclineFlag.split("\\|");
						if(splitDeclineFlag.length>0) declineReason = splitDeclineFlag[1];
						decision = "Submit to Maker";
						Remark += "Declined/Dropped case\n"+declineReason;
					}
					else if("TRUE".equalsIgnoreCase(ProfileChange) || "TRUE".equalsIgnoreCase(DocumentUpload) || !res.contains("0000") || res.contains("High") || "".equalsIgnoreCase(prefAddressFlag) || "".equalsIgnoreCase(officeAddressLine1) || "".equalsIgnoreCase(officeCityEmirate) || "".equalsIgnoreCase(officeCountry))
					{
						decision = "Submit to Maker";
						if("TRUE".equalsIgnoreCase(ProfileChange)) Remark = "Profile change - "+BBG_NSTP_Remark.replaceAll("'", "''");
						if("TRUE".equalsIgnoreCase(DocumentUpload)) Remark += "\nDocument Upload";
						//if("TRUE".equalsIgnoreCase(DeclineFlag)) Remark += "\nDeclined/Dropped case";
						if("".equalsIgnoreCase(prefAddressFlag)) Remark +="\nPreferred Address not available";
						if("".equalsIgnoreCase(officeAddressLine1)) Remark +="\nOffice Shop No not available";
						if("".equalsIgnoreCase(officeCountry)) Remark +="\nAddress Country not available";
						if("".equalsIgnoreCase(officeCityEmirate)) Remark +="\nAddress city not available";
						if(!res.contains("0000")) Remark += "\nRRC Failed";
						if(res.contains("High")) Remark += "\nRisk Score is High";
					}
					if(!"TRUE".equalsIgnoreCase(ProfileChange) && !"TRUE".equalsIgnoreCase(DocumentUpload) && !DeclineFlag.contains("TRUE") && res.contains("0000") && !res.contains("High") && !"".equalsIgnoreCase(prefAddressFlag) && !"".equalsIgnoreCase(officeAddressLine1) && !"".equalsIgnoreCase(officeCityEmirate) && !"".equalsIgnoreCase(officeCountry))
					{
						if("true".equalsIgnoreCase(isConsequenceApplied) && !"Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) {
							decision = "Send to Consequence_Hold";
							Remark = "WI marked as STP for CIF update. Moved for consequence removal.";
						}
						else/*("false".equalsIgnoreCase(isConsequenceApplied))*/ {
							decision = "Approved";
							Remark = "WI marked as STP for CIF update.";
						}
					}
					if("Approved".equalsIgnoreCase(decision) || "Send to Consequence_Hold".equalsIgnoreCase(decision)) setNextReviewDateAndIndustry(res, WINAME, EMPLOYER_CHANGE,"BBG",decision);
					if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) deleteConsequenceEntries(WINAME);
					CompleteWI(WINAME, decision, Remark, CURRENT_WS,ProfileChange,DocumentUpload,EMPLOYER_CHANGE,DeclineFlag);
				}
				else
				{
					decision = "Error";
					if ("NoDocument".equalsIgnoreCase(flag))
						Remark = "Documents not found at location";
					else if ("FolderNotPresent".equalsIgnoreCase(flag))
						Remark = "Folder not present with name-->" + WINAME + " at location";
					else
						Remark = "Not all Outreach Docs Attached or received";
					if ("1".equalsIgnoreCase(OutreachDocFlag)) {
						boolean hours48 = HoursPassed(OutreachupdateDateTime);
						if (hours48){
							if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) deleteConsequenceEntries(WINAME);
							CompleteWI(WINAME, decision, Remark, CURRENT_WS,ProfileChange,DocumentUpload,EMPLOYER_CHANGE,DeclineFlag);
						}else
							CustOutreachLog.KYCcustOutreachLogger.debug("Waiting for 48 hours to receive docs for - " + WINAME);
					} else{
						if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)) deleteConsequenceEntries(WINAME);
						CompleteWI(WINAME, decision, Remark, CURRENT_WS,ProfileChange,DocumentUpload,EMPLOYER_CHANGE,DeclineFlag);
					}
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in DoneWI ");
		}
	}

	  private void deleteConsequenceEntries(String wINAME) {
		try{
			String whereClause = "WINAME = '" + wINAME + "'";
			String apDeleteInputXML = CommonMethods.apDeleteInput(cabinetName, sessionID, "NG_KYC_REM_Consequence_GRID",
					 whereClause);
			CustOutreachLog.KYCcustOutreachLogger.debug("apDeleteInputXML: " + apDeleteInputXML);
			String apDeleteOutputXML = CommonMethods.WFNGExecute(apDeleteInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apDeleteOutputXML: " + apDeleteOutputXML);
			XMLParser xmlParserAPDelete = new XMLParser(apDeleteOutputXML);
			String apDeleteMaincode = xmlParserAPDelete.getValueOf("MainCode");
			if (apDeleteMaincode.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("apDeleteInput successfull for WI - "+wINAME);
			}
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in deleteConsequenceEntries - "+e.getMessage());
		}
	}

	private String IsConsequenceApplied(String wINAME) {
		  String isConsequenceApplied = "false";
		  try{
			String query = "SELECT top(1) ConsequenceStatus FROM NG_KYC_REM_Consequence_Grid with(nolock) WHERE WINAME = '"+wINAME+"' order by insertionOrderId desc";
			CustOutreachLog.KYCcustOutreachLogger.debug("query to check if consequency is applied - "+query);  
			String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("Input XML - "+dataInputXML);  
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("Output XML - "+dataOutputXML);  
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				String consequenceStatus = dataxmlParserAPSelect.getValueOf("ConsequenceStatus");
				if("Partial Applied".equalsIgnoreCase(consequenceStatus) || "Fully Applied".equalsIgnoreCase(consequenceStatus))
				{
					isConsequenceApplied = "true";
				}
			}
		  }catch(Exception e){
			  CustOutreachLog.KYCcustOutreachLogger.debug("Exception in IsConsequenceApplied method - "+e.getMessage());  
			  isConsequenceApplied = "error";
		  }
		  return isConsequenceApplied;
	}

	public static boolean containsOnlyNonMandatory(List<String> docsList, Set<String> nonMandatoryDocs) {
		  for (String doc : docsList) {
		        if (!nonMandatoryDocs.contains(doc)) {
		            return false;
		        }
		    }
	        return true;
	    }
	
	private String getRPWINAME(String wINAME) {
		String RP_WI_Number = "";
		try{
			String Query = "SELECT RP_WI_Number from NG_KYC_REM_RP_GRID with(nolock) WHERE WI_Name = '"+wINAME+"'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				RP_WI_Number  += "'"+entry.get("RP_WI_Number")+"',";
			}
		}catch(Exception e){
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getRPWINAME ");
		}
		return RP_WI_Number;
	}

	private void CompleteWI(String WINAME, String decision, String Remark, String CURRENT_WS, String ProfileChange, String documentUpload, String EMPLOYER_CHANGE, String DeclineFlag) {
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside complete WI.");
			RouteRelatedPartyWI(WINAME, decision, "");
			String WorkItemID = "";
			String ActivityID = "";
			String ProcessDefID = "";
			String EntryDateTime = "";
			String query = "select Workitemid,ActivityId,ProcessDefID,EntryDateTime from WFINSTRUMENTTABLE where ProcessInstanceID = '"
					+ WINAME + "' AND Workitemid = '1'";
			String dataInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
			XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
			String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
			int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (dataMainCode.equals("0") && dataTotalRecords > 0) {
				WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
				ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
				ProcessDefID = dataxmlParserAPSelect.getValueOf("ProcessDefID");
				EntryDateTime = dataxmlParserAPSelect.getValueOf("EntryDateTime");

				StringBuffer ipXMLBuffer = new StringBuffer();

				ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
				ipXMLBuffer.append("<WMReassignWorkItem_Input>\n");
				ipXMLBuffer.append("<Option>WMReassignWorkItem</Option>\n");
				ipXMLBuffer.append("<EngineName>");
				ipXMLBuffer.append(cabinetName);
				ipXMLBuffer.append("</EngineName>\n");
				ipXMLBuffer.append("<SessionID>");
				ipXMLBuffer.append(sessionID);
				ipXMLBuffer.append("</SessionID>\n");
				ipXMLBuffer.append("<ProcessInstanceID>");
				ipXMLBuffer.append(WINAME);
				ipXMLBuffer.append("</ProcessInstanceID>\n");
				ipXMLBuffer.append("<WorkItemID>");
				ipXMLBuffer.append(WorkItemID);
				ipXMLBuffer.append("</WorkItemID>\n");
				ipXMLBuffer.append("<SourceUser>");
				// ipXMLBuffer.append(WorkItemID);
				ipXMLBuffer.append("</SourceUser>\n");
				ipXMLBuffer.append("<TargetUser>");
				ipXMLBuffer.append("rakbpmutility");
				ipXMLBuffer.append("</TargetUser>\n");
				ipXMLBuffer.append("</WMReassignWorkItem_Input>\n");
				String WMUnlockWIInput = ipXMLBuffer.toString();
				CustOutreachLog.KYCcustOutreachLogger.debug("Input XML For WMUnlockWIInput: " + WMUnlockWIInput);
				String WMUnlockWIOutputXml = CommonMethods.WFNGExecute(WMUnlockWIInput, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("Output XML For WMUnlockWIInput: " + WMUnlockWIOutputXml);

				XMLParser xmlParserWMUnlockWI = new XMLParser(WMUnlockWIOutputXml);
				String WMUnlockWIMainCode = xmlParserWMUnlockWI.getValueOf("MainCode");
				CustOutreachLog.KYCcustOutreachLogger.debug("WMUnlockWICall Maincode:  " + WMUnlockWIMainCode);

				if (WMUnlockWIMainCode.trim().equals("0") || WMUnlockWIMainCode.trim().equals("17")) {

					String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,
							WorkItemID);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Input XML For WmgetWorkItemCall: " + getWorkItemInputXML);
					String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
					CustOutreachLog.KYCcustOutreachLogger
							.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

					XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
					String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
					CustOutreachLog.KYCcustOutreachLogger.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);
					if (getWorkItemMainCode.trim().equals("0")) {
						//making attribute tag
						//String attributeTag = "<DECISION>" + decision+ "</DECISION>";
						String attributeTag = "";
						if("TRUE".equalsIgnoreCase(ProfileChange) && !DeclineFlag.contains("TRUE"))
							attributeTag += "<qProfileChange>Yes</qProfileChange>";
						else if("FALSE".equalsIgnoreCase(ProfileChange) && !DeclineFlag.contains("TRUE"))
							attributeTag += "<qProfileChange>No</qProfileChange>";
						if("TRUE".equalsIgnoreCase(documentUpload))
							attributeTag += "<qOCRDocumentUpload>Yes</qOCRDocumentUpload>";
						else if("FALSE".equalsIgnoreCase(documentUpload))
							attributeTag += "<qOCRDocumentUpload>No</qOCRDocumentUpload>";
						if(DeclineFlag.contains("TRUE"))
							attributeTag += "<qProfileChange>Decline</qProfileChange>";
						if("Consequence_Hold".equalsIgnoreCase(CURRENT_WS)){
							attributeTag += "<ConsequenceRowCount>0</ConsequenceRowCount>";
						}
						if("Send to Consequence_Hold".equalsIgnoreCase(decision))
						{
							String consequenceDate = getConsequenceDate();
							String consequenceApplyDateTime = getConsequenceApplyDateTime();
							attributeTag += "<Q_NG_KYC_REM_Consequence_Grid><ConsequenceStatus>Removal of Consequence Management</ConsequenceStatus><ActionTaken>Remove Service Restriction</ActionTaken><UserName>system</UserName><DateTime>"+consequenceApplyDateTime+"</DateTime><Remarks>System Applied</Remarks></Q_NG_KYC_REM_Consequence_Grid>"
							+ "<DECISION>Send to Consequence_Hold</DECISION><CONSEQUENCE_STATUS>Removal of Consequence Management</CONSEQUENCE_STATUS>"
							+ "<CONSEQUENCE_ACTION>Remove Service Restriction</CONSEQUENCE_ACTION><LATEST_CONSEQUENCE_DATE>"+consequenceDate+"</LATEST_CONSEQUENCE_DATE>";
						}
						else{
							attributeTag += "<DECISION>" + decision+ "</DECISION>";
						}
						//attribute tag completed
						String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
								+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
								+ "</EngineName>" + "<SessionId>" + sessionID + "</SessionId>" + "<ProcessInstanceId>"
								+ WINAME + "</ProcessInstanceId>" + "<WorkItemId>" + WorkItemID + "</WorkItemId>"
								+ "<ActivityId>" + ActivityID + "</ActivityId>" + "<ProcessDefId>" + ProcessDefID
								+ "</ProcessDefId>" + "<LastModifiedTime></LastModifiedTime>"
								+ "<ActivityType></ActivityType>" + "<complete>D</complete>"
								+ "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
								+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributeTag
								+ "</Attributes>" + "</WMAssignWorkItemAttributes_Input>";

						CustOutreachLog.KYCcustOutreachLogger.debug("assignInputXML--- " + assignInputXML);
						String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger.debug("assignOutXml--- " + assignOutXml);
						XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
						String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
						if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")) {

							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String strDate = dateFormat.format(d);

							String tableName = "NG_KYC_REM_GR_HISTORY";
							String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
							String values = "'" + strDate + "','" + CURRENT_WS + "','" + decision
									+ "','rakBPMutility','" + Remark + "','" + WINAME + "','" + EntryDateTime + "'";

							String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values,
									tableName);
							CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);

							String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

							XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
							String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
							CustOutreachLog.KYCcustOutreachLogger
									.debug("Status of apInsertMaincode  " + apInsertMaincode);
							if (apInsertMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("ApInsert successful: " + apInsertMaincode);
								CustOutreachLog.KYCcustOutreachLogger.debug("Data Inserted in history table successfully.");
							}
						}
					} else {
						CustOutreachLog.KYCcustOutreachLogger.debug("Errro in getWI call for WI - " + WINAME);
					}
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in Complete WI ");
		}
	}

	public String setNextReviewDateAndIndustry(String RiskProfile, String WINAME, String EMPLOYER_CHANGE, String caseType, String decision) {
		String date = "";
		String subSegment = "";
		String segment = "";
		String type = "";
		String reviewMonths = "";
		String signedDatestr = "";
		String expiryDatestr = "";
		//Double rScore = Double.parseDouble(RiskProfile);
		//calculating next review date starts
		/*if (rScore >= 0 && rScore < 3) type = "Low";
		else if (rScore >= 3 && rScore < 4) type = "Med";
		else if (rScore >= 4) type = "High";*/
		if("PBG".equalsIgnoreCase(caseType) && "Approved".equalsIgnoreCase(decision)){
			String Query = "SELECT Nationality,OtherNationality,CountryOfBirth,USpassportHolder_GreencardHolder,PlaceOfBirthUSA,"
					+ "CurrentUSmailingOrResidenceAddress,UStelephoneNumber,StandingInstructions,PowerOfAttorney,USholdMailAddress "
					+ "FROM RB_KYC_REM_EXTTABLE WHERE WINAME = '"+WINAME+"'";

			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);

			for (Map<String, String> entry : DataFromDB) {

				String nationality = entry.get("Nationality");
				String additionalNationality = entry.get("OtherNationality");
				String countryOfBirth = entry.get("CountryOfBirth");
				String usPassportHolder = entry.get("USpassportHolder_GreencardHolder");
				String placeOfBirthUSA = entry.get("PlaceOfBirthUSA");
				String currentUSmailingOrResidenceAddress = entry.get("CurrentUSmailingOrResidenceAddress");
				String usTelephoneNumber = entry.get("UStelephoneNumber");
				String standingInstructions = entry.get("StandingInstructions");
				String powerOfAttorney = entry.get("PowerOfAttorney");
				String usHoldMailAddress = entry.get("USholdMailAddress");
				if("US".equalsIgnoreCase(nationality) || "US".equalsIgnoreCase(additionalNationality) || "US".equalsIgnoreCase(countryOfBirth) || 
						"Yes".equalsIgnoreCase(usPassportHolder) || "Yes".equalsIgnoreCase(placeOfBirthUSA) || "Yes".equalsIgnoreCase(currentUSmailingOrResidenceAddress) || 
						"Yes".equalsIgnoreCase(usTelephoneNumber) || "Yes".equalsIgnoreCase(standingInstructions) || 
						"Yes".equalsIgnoreCase(powerOfAttorney) || "Yes".equalsIgnoreCase(usHoldMailAddress)){
					LocalDate signedDate = LocalDate.now();
					LocalDate expiryDate = signedDate.plusYears(3);
					DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					signedDatestr = format.format(signedDate);
					expiryDatestr = format.format(expiryDate);
				}
			}
		}
		if (RiskProfile.contains("Low")) type = "Low";
		else if (RiskProfile.contains("Standard") || RiskProfile.contains("Medium")) type = "Med";
		else if (RiskProfile.contains("High") || RiskProfile.contains("Elevated")) type = "High";
		CustOutreachLog.KYCcustOutreachLogger.debug("RiskProfile " + type);
		try {
		if("TRUE".equalsIgnoreCase(EMPLOYER_CHANGE) && "PBG".equalsIgnoreCase(caseType))
		{
			String Query = "SELECT VariableValue FROM NG_KYC_REM_Staggered_Count_Table with(nolock) WHERE type = 'PBGSTP"+type+"'";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);
			if (!DataFromDB.isEmpty()) {
				for (Map<String, String> entry : DataFromDB) {
					reviewMonths = entry.get("VariableValue");
					CustOutreachLog.KYCcustOutreachLogger.debug("reviewMonths - "+reviewMonths);
				}
			}
			CustOutreachLog.KYCcustOutreachLogger.debug("Employer change is TRUE");
			LocalDate now = LocalDate.now();
			CustOutreachLog.KYCcustOutreachLogger.debug("Current Date " + now);
			LocalDate futureDate = now.plusMonths(Integer.parseInt(reviewMonths));
			CustOutreachLog.KYCcustOutreachLogger.debug("future Date " + futureDate);
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			date = format.format(futureDate);
			CustOutreachLog.KYCcustOutreachLogger.debug("next KYC Review Date to set" + date);
		}
		else
		{
			String queryType = caseType+type+"Risk";
			String Query = "SELECT VariableValue FROM NG_KYC_REM_Staggered_Count_Table with(nolock) WHERE type = '"+queryType+"'";	
			if("BBGHighRisk".equalsIgnoreCase(queryType))
				Query = "SELECT VariableValue FROM NG_KYC_REM_Staggered_Count_Table with(nolock) WHERE type = '"+queryType+"' AND VariableKey = 'Review_Date_Months_Count'";	
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);
			if (!DataFromDB.isEmpty()) {
				for (Map<String, String> entry : DataFromDB) {
					reviewMonths = entry.get("VariableValue");
					CustOutreachLog.KYCcustOutreachLogger.debug("reviewMonths - "+reviewMonths);
				}
			}
			//CustOutreachLog.KYCcustOutreachLogger.debug("Employer change is FALSE");
/*			LocalDate now = LocalDate.now();
			LocalDate futureDate = now.plusMonths(Integer.parseInt(reviewMonths));
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			date = format.format(futureDate);*/
			LocalDate now = LocalDate.now();
			CustOutreachLog.KYCcustOutreachLogger.debug("Current Date " + now);
			LocalDate futureDate = now.plusMonths(Integer.parseInt(reviewMonths));
			CustOutreachLog.KYCcustOutreachLogger.debug("future Date " + futureDate);
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			date = format.format(futureDate);
			CustOutreachLog.KYCcustOutreachLogger.debug("next KYC Review Date to set" + date);
		}
		//setting industry segment and subsegment 
		String Query = "";
		if("PBG".equalsIgnoreCase(caseType))
			Query = "SELECT TOP 1 Finacle_Code,MappedSegmentCode FROM NG_KYC_REM_Industry_SubSegment_MASTER with(nolock) WHERE SubSegment IN "
					+ "(SELECT SubSegment FROM NG_KYC_REM_IND_SubSegment_GRID with(nolock) WHERE WINAME = '" + WINAME
					+ "')" + "order by RiskScore desc";
		if("BBG".equalsIgnoreCase(caseType))
			Query = "SELECT TOP 1 Finacle_Code,MappedSegmentCode FROM NG_KYC_REM_Industry_SubSegment_MASTER with(nolock) WHERE "
					+ "SubSegment IN (SELECT LicensedBusinessActivity FROM NG_KYC_REM_LBA_GRID with(nolock) WHERE WINAME = '" + WINAME
					+ "') ORDER BY RiskScore desc";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB d : OF_DATA_DEF_ID " + DataFromDB);
			if (!DataFromDB.isEmpty()) {
				for (Map<String, String> entry : DataFromDB) {
					subSegment = entry.get("Finacle_Code");
					segment = entry.get("MappedSegmentCode");
				}
			}
			// updating the values in DB
			String columnName = "IndustrySubSegment,IndustrySegment,NextReviewDate,SignedDate,ExpiryDate";
			String values = "'" + subSegment + "','" + segment + "','" + date + "','" + signedDatestr + "','" + expiryDatestr +"'";
			String whereClause = "WINAME = '" + WINAME + "'";
			String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_KYC_REM_EXTTABLE",
					columnName, values, whereClause);
			CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
			String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
			XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
			String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
			if (apUpdateMaincode.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML for Upload Flag: " + apUpdateOutputXML);
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Error in setting NextReviewDate on formload");
		}
		return "";
	}

	private boolean HoursPassed(String outreachDateTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		try {
			Date date = sdf.parse(outreachDateTime);
			Calendar calender = Calendar.getInstance();
			calender.setTime(date);
			calender.add(Calendar.HOUR_OF_DAY, 48);
			Date date48 = calender.getTime();
			Date now = new Date();
			if (now.after(date48)) {
				CustOutreachLog.KYCcustOutreachLogger.debug("48 hours have passed");
				return true;
			} else {
				CustOutreachLog.KYCcustOutreachLogger.debug("48 hours have not passed");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean moveFile(String sourcePath, String targetPath, String FileName) {
		boolean fileMoved = true;
		Path targetDirecoty = null;
		Path targetDirectory = Paths.get(targetPath);
		if (!Files.exists(targetDirectory)) {
			File f1 = new File(targetPath);
			f1.mkdirs();
		}
		try {
			Files.move(Paths.get(sourcePath), Paths.get(targetPath + File.separator + FileName),
					StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("exception in moving file" + e.getMessage());
			fileMoved = false;
		}
		return fileMoved;
	}

	public String updateUploadFlag(String processinstanceID, String flag, String DocumentName) {
		try {
			String columnName = "UploadFlag,UploadDateTime";
			Date d = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String strDate = dateFormat.format(d);
			String values = "'" + flag + "','" + strDate + "'";
			String whereClause = "WINAME = '" + processinstanceID + "' AND DocName = '" + DocumentName + "'";
			String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,
					"NG_KYC_REM_Outreach_Docs_GRID", columnName, values, whereClause);
			CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
			String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
			XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
			String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
			if (apUpdateMaincode.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML for Upload Flag: " + apUpdateOutputXML);
			}
		} catch (Exception e) {

		}
		return "";
	}

	private String getFolderIndex(String WINAME) {
		try {
			String query = "Select folderindex from pdbfolder with(nolock) where name = '" + WINAME + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			String parentFolderIndex = "";
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("inside if of apSearchMaincodefolderIndex");
				parentFolderIndex = xmlParserAPSearchfolderIndex.getValueOf("folderindex");
				CustOutreachLog.KYCcustOutreachLogger.debug("parentFolderIndex--- " + parentFolderIndex);
				return parentFolderIndex;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occured in getting parent Folder Index");
		}
		return "Error";
	}

	private List<String> getListDocsToBeAttachedUploadFlagStatus(String WINAME, List<String> DocsList) {
		try {
			
			String Query1 = "SELECT DocType FROM NG_KYC_REM_Outreach_Docs_GRID with (nolock) WHERE WINAME IN (" + WINAME
					+ ") AND (UploadFlag IS NULL OR UploadFlag = '' OR UploadFlag = 'N')";
			String ApSelectInputXML = CommonMethods.apSelectWithColumnNames(Query1, cabinetName, sessionID);
			String ApSelectOutputXML = CommonMethods.WFNGExecute(ApSelectInputXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserAPSelect = new XMLParser(ApSelectOutputXML);
			String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
			int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
			if (apSelectMaincode.equals("0") && TotalRecords > 0) {
				// start from here
				NGXmlList objWorkList = xmlParserAPSelect.createList("Records", "Record");
				CustOutreachLog.KYCcustOutreachLogger.debug("objWorkList " + objWorkList);
				for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) {
					String docDetail = xmlParserAPSelect.getNextValueOf("Record");
					XMLParser xmlDocDetail = new XMLParser(docDetail);
					String DocType = xmlDocDetail.getValueOf("DocType");
					CustOutreachLog.KYCcustOutreachLogger.debug("DocType from outreach grid is --> " + DocType);
					DocsList.add(DocType);
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDocsToBeAttached method --" + e.getMessage());
		}
		return DocsList;

	}

	public static void checkAndDelete(File folder) throws IOException {

		File[] files = folder.listFiles();
		//CustOutreachLog.KYCcustOutreachLogger.debug("Inside checkAndDelete: " + folder);

		if (files == null)
			return;

		for (File file : files) {
			//CustOutreachLog.KYCcustOutreachLogger.debug("FileName: " + file.getName());
			try {
				Path path = Paths.get(file.getPath());

				FileTime creationTime = (FileTime) Files.getAttribute(path, "creationTime");

				Date curDate = new Date();

				Date fileDate = new Date(creationTime.toMillis());

				long diffInMillis = Math.abs(curDate.getTime() - fileDate.getTime());
				long diff = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
				if (diff > DaysToDelete) {
					try {
						deletefilesFromFolder(file);
						file.delete();
					} catch (Exception e) {
						CustOutreachLog.KYCcustOutreachLogger.debug("File failed to delete due to: "+folder+" " + file.getName()+" --"+e);
					}
				}
			} catch (Exception e) {
				CustOutreachLog.KYCcustOutreachLogger.debug("Exception in delete folder method: " + e);
			}
		}
	}

	private static void deletefilesFromFolder(File file) {
		for (File subFile : file.listFiles()) {
			try {
				subFile.delete();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void generateKYCform(String wINAME, String caseType, String cif) {
		CustOutreachLog.KYCcustOutreachLogger.debug("Inside function generateKYCform");
		Map<String, String> ht1 = new HashMap<String, String>();
		try {
			String pdfName = "";
			if ("Individual".equalsIgnoreCase(caseType))
				pdfName = "KYC_Form";
			else if ("Corporate".equalsIgnoreCase(caseType))
				pdfName = "KYC_Form_Corporate";

			getiformData(wINAME, caseType, ht1);
			generatePDF(ht1, wINAME, pdfName);
			attachwithWI(wINAME, pdfName, cif);

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in generateKYCform - " + e.getMessage());
		}
	}

	private String attachwithWI(String wINAME, String pdfName, String cif) {
		try {
			String FullPath = KYCformPath + wINAME + pdfName + ".pdf";
			JPISIsIndex ISINDEX = new JPISIsIndex();
			JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
			CustOutreachLog.KYCcustOutreachLogger.debug("trying to add doc on image server");
			CustOutreachLog.KYCcustOutreachLogger.debug("Values passed -- >jtsip-" + jtsIP + " , jtsPort->" + jtsPort
					+ ",cabinetName->" + cabinetName + ",volumeID->" + volumeID + ", File path-->" + FullPath);
			try {
				CPISDocumentTxn.AddDocument_MT(null, jtsIP, Short.parseShort(SMSPort), cabinetName,
						Short.parseShort(volumeID), FullPath.toString(), JPISDEC, "", ISINDEX);
			} catch (JPISException e) {
				CustOutreachLog.KYCcustOutreachLogger
						.debug("Exception in AddDocument_MT call in attachwithWI method- " + e.getMessage());
				e.printStackTrace();
				return "error";
			}

			CustOutreachLog.KYCcustOutreachLogger.debug("after CPISDocumentTxn AddDocument MT: ");
			String sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
			CustOutreachLog.KYCcustOutreachLogger.debug("sISIndex after adding on SMS - " + sISIndex);
			String parentFolderIndex = getFolderIndex(wINAME);
			File file = new File(FullPath);
			String size = String.valueOf(file.length());
			String docName = "";
			String pages = "1";
			String comment = "";
			if (pdfName.contains("KYC")) {
				docName = "KYC Form";
				pages = "3";
				comment = cif + "_KYC Form Updated";
			} else {
				docName = "Risk Score Sheet";
				comment = cif + "_Auto RRC";
			}
			StringBuffer ipXMLBuffer = new StringBuffer();

			ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
			ipXMLBuffer.append("<NGOAddDocument_Input>\n");
			ipXMLBuffer.append("<Option>NGOAddDocument</Option>");
			ipXMLBuffer.append("<CabinetName>");
			ipXMLBuffer.append(cabinetName);
			ipXMLBuffer.append("</CabinetName>\n");
			ipXMLBuffer.append("<UserDBId>");
			ipXMLBuffer.append(sessionID);
			ipXMLBuffer.append("</UserDBId>\n");
			ipXMLBuffer.append("<GroupIndex>0</GroupIndex>\n");
			ipXMLBuffer.append("<Document>\n");
			ipXMLBuffer.append("<VersionFlag>Y</VersionFlag>\n");
			ipXMLBuffer.append("<ParentFolderIndex>");
			ipXMLBuffer.append(parentFolderIndex);
			ipXMLBuffer.append("</ParentFolderIndex>\n");
			ipXMLBuffer.append("<DocumentName>");
			ipXMLBuffer.append(docName);
			ipXMLBuffer.append("</DocumentName>\n");
			ipXMLBuffer.append("<VolumeIndex>");
			ipXMLBuffer.append(volumeID);
			ipXMLBuffer.append("</VolumeIndex>\n");
			ipXMLBuffer.append("<ISIndex>");
			ipXMLBuffer.append(sISIndex);
			ipXMLBuffer.append("</ISIndex>\n");
			ipXMLBuffer.append("<NoOfPages>");
			ipXMLBuffer.append(pages);
			ipXMLBuffer.append("</NoOfPages>\n");
			ipXMLBuffer.append("<DocumentType>");
			ipXMLBuffer.append("N");
			ipXMLBuffer.append("</DocumentType>\n");
			ipXMLBuffer.append("<Comment>");
			ipXMLBuffer.append(comment);
			ipXMLBuffer.append("</Comment>\n");
			ipXMLBuffer.append("<DocumentSize>");
			ipXMLBuffer.append(size);
			ipXMLBuffer.append("</DocumentSize>\n");
			ipXMLBuffer.append("<CreatedByAppName>");
			ipXMLBuffer.append("pdf");
			ipXMLBuffer.append("</CreatedByAppName>\n");
			ipXMLBuffer.append("</Document>\n");
			ipXMLBuffer.append("</NGOAddDocument_Input>\n");
			String NGOaddDocInputXML = ipXMLBuffer.toString();
			CustOutreachLog.KYCcustOutreachLogger.debug("NGOaddDocInputXML--- " + NGOaddDocInputXML);
			String NGOaddDocOutXml = CommonMethods.WFNGExecute(NGOaddDocInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("NGOaddDocOutXml--- " + NGOaddDocOutXml);

			XMLParser xmlParserAddDoc = new XMLParser(NGOaddDocOutXml);
			CustOutreachLog.KYCcustOutreachLogger.debug("xmlParserAddDoc--- " + xmlParserAddDoc);
			String addDocMainCode = xmlParserAddDoc.getValueOf("Status");
			CustOutreachLog.KYCcustOutreachLogger.debug("addDocMainCode--- " + addDocMainCode);
			if (addDocMainCode.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("KYC form attached successfully to WI - " + wINAME);
				file.delete();
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in attachwithWI - " + e.getMessage());
			return "error";
		}
		return "success";
	}

	private String generatePDF(Map<String, String> ht, String wINAME, String pdfName) {
		// KYCformPath
		try {
			String sourceName = KYCformPath + pdfName + ".pdf";
			String destPath = KYCformPath + wINAME + pdfName + ".pdf";

			PdfReader reader = new PdfReader(sourceName);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("createPDF : createNewPDF : Created reader object from source template pdf:");

			PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(destPath));
			CustOutreachLog.KYCcustOutreachLogger
					.debug("createPDF : createNewPDF : Created stamper object in destination pdf:");

			AcroFields form = stamp.getAcroFields();
			BaseFont unicode = BaseFont.createFont(KYCformPath + File.separator + "arabtype.ttf", BaseFont.IDENTITY_H,
					BaseFont.EMBEDDED);
			CustOutreachLog.KYCcustOutreachLogger.debug("createPDF : createNewPDF : Created arabtype font:");

			ArrayList<BaseFont> al = new ArrayList<BaseFont>();
			al.add(unicode);

			form.setSubstitutionFonts(al);

			PdfWriter p = stamp.getWriter();
			p.setRunDirection(p.RUN_DIRECTION_RTL);

			BaseFont bf1 = BaseFont.createFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.EMBEDDED);
			form.addSubstitutionFont(bf1);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("createPDF : createNewPDF :  Created writer, set font times roman :");

			Set<String> PDFSet = ht.keySet();
			Iterator<String> PDFIt = PDFSet.iterator();
			CustOutreachLog.KYCcustOutreachLogger.debug("createPDF : createNewPDF : Replacing values from XMLMap:");

			while (PDFIt.hasNext()) {
				String HT_Key = (String) PDFIt.next();
				String HT_Value = (String) ht.get(HT_Key);
				form.setField(HT_Key, HT_Value);

				if (!(HT_Key.contains("Top5Suppliers") || HT_Key.contains("CountriesDealingWith")
						|| HT_Key.contains("Top5Buyer") || HT_Key.contains("Countriesbuying")
						|| HT_Key.contains("PercentofBusiness") || HT_Key.contains("PercentofBuying")
						|| HT_Key.contains("ShareholdingPercentage") || HT_Key.contains("DOBIncorporation")
						|| HT_Key.contains("POANationality") || HT_Key.contains("NameofShareholder")
						|| HT_Key.contains("POACountryResidence"))) {
					form.setFieldProperty(HT_Key, "setfflags", PdfFormField.FF_READ_ONLY, null);
				}
			}
			form.setFieldProperty("loggedinuser", "setfflags", PdfFormField.FF_READ_ONLY, null);
			CustOutreachLog.KYCcustOutreachLogger.debug("createPDF : createNewPDF : Values replaced from XMLMap:");
			stamp.setFormFlattening(false);

			stamp.close();
			CustOutreachLog.KYCcustOutreachLogger.debug("createPDF : createNewPDF : Stamper closed:");
			return "Success";

		} catch (Exception ex) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("createPDF : createNewPDF : ex.getMessage() : 2 :" + ex.getMessage());
			return "Error";
		}
	}

	private Map<String, String> getiformData(String wINAME, String caseType, Map<String, String> ht) {
		// Map<String, String> ht = new HashMap<String,String>();
		try {
			Date d = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String CurrentDateTime = dateFormat.format(d);
			String[] splitDate = CurrentDateTime.split("-");
			String day = splitDate[2];
			String month = splitDate[1];
			String year = splitDate[0];

			String query = "Select Title,FirstName,MiddleName,LastName,ResidenceAddress,ResidenceEmirateCity,"
					+ "Nationality,OtherNationality,ResidenceCountry,PEP,ResidenceFlatVillaNo,Residence_Address2,"
					+ "Residence_Address3,ResidenceLandmark,ResidenceZIPCode,ResidencePOBox,ResidenceState,"
					+ "OfficeEmploymentType,OfficeOccupation,CountryOfIncorporation,OfficeEmployerNameDesc,"
					+ "OfficeEmployerName,OfficeCityEmirate,CustomerBackground_Personal,CountryOfOperation,MonthlyIncome,"
					+ "PurposeOfAccount,SourceOfFunds,OtherSourceOfIncome,OtherIncome,EstimatedWealth,SourceOfWealth,"
					+ "USpassportHolder_GreencardHolder,TIN_Field,PlaceOfBirthUSA,CurrentUSmailingOrResidenceAddress,"
					+ "UStelephoneNumber,StandingInstructions,PowerOfAttorney,USholdMailAddress,FormObtained,PurposeOthers,"
					+ "Funds_Others,WealthOthers,OccupationOthers "
					+ "from RB_KYC_REM_EXTTABLE with(nolock) where WINAME = '" + wINAME + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0")) {
				CustOutreachLog.KYCcustOutreachLogger.debug("inside if of apSearchMaincodefolderIndex");
				String title = xmlParserAPSearchfolderIndex.getValueOf("Title");
				title = getTitleDesc(title);
				String firstName = xmlParserAPSearchfolderIndex.getValueOf("FirstName");
				String secondName = xmlParserAPSearchfolderIndex.getValueOf("MiddleName");
				String lastName = xmlParserAPSearchfolderIndex.getValueOf("LastName");
				String Address = xmlParserAPSearchfolderIndex.getValueOf("ResidenceAddress");
				String Emirate = xmlParserAPSearchfolderIndex.getValueOf("ResidenceEmirateCity");
				Emirate = getCityDesc(Emirate);
				String Nationality = xmlParserAPSearchfolderIndex.getValueOf("Nationality");
				Nationality = getCountryDesc(Nationality);

				String otherNationality = xmlParserAPSearchfolderIndex.getValueOf("OtherNationality");
				otherNationality = getCountryDesc(otherNationality);
				String residenceCountry = (String) xmlParserAPSearchfolderIndex.getValueOf("ResidenceCountry");
				residenceCountry = getCountryDesc(residenceCountry);
				String PEP = (String) xmlParserAPSearchfolderIndex.getValueOf("PEP");
				PEP = getPEPdesc(PEP);
				String flatVillaNo = (String) xmlParserAPSearchfolderIndex.getValueOf("ResidenceFlatVillaNo");
				String Building = (String) xmlParserAPSearchfolderIndex.getValueOf("Residence_Address2");
				String Street = (String) xmlParserAPSearchfolderIndex.getValueOf("Residence_Address3");
				String Landmark = (String) xmlParserAPSearchfolderIndex.getValueOf("ResidenceLandmark");
				String ZIPCode = (String) xmlParserAPSearchfolderIndex.getValueOf("ResidenceZIPCode");
				String POBox = (String) xmlParserAPSearchfolderIndex.getValueOf("ResidencePOBox");
				String State = (String) xmlParserAPSearchfolderIndex.getValueOf("ResidenceState");
				State = getStateDesc(State);
				String OfficeEmploymentType = (String) xmlParserAPSearchfolderIndex.getValueOf("OfficeEmploymentType");
				OfficeEmploymentType = getempTypeDesc(OfficeEmploymentType);
				String OfficeOccupation = (String) xmlParserAPSearchfolderIndex.getValueOf("OfficeOccupation");
				OfficeOccupation = getOccupationDesc(OfficeOccupation);
				String CountryOfIncorporation = (String) xmlParserAPSearchfolderIndex
						.getValueOf("CountryOfIncorporation");
				CountryOfIncorporation = getCountryDesc(CountryOfIncorporation);
				String OfficeEmployerName = (String) xmlParserAPSearchfolderIndex.getValueOf("OfficeEmployerNameDesc");
				if ("OTHERS".equalsIgnoreCase(OfficeEmployerName) || "OTHER".equalsIgnoreCase(OfficeEmployerName)
						|| "".equalsIgnoreCase(OfficeEmployerName)) {
					OfficeEmployerName = (String) xmlParserAPSearchfolderIndex.getValueOf("OfficeEmployerName");
				}
				CustOutreachLog.KYCcustOutreachLogger.debug("OfficeEmployerName--" + OfficeEmployerName);
				String OfficeCityEmirate = (String) xmlParserAPSearchfolderIndex.getValueOf("OfficeCityEmirate");
				OfficeCityEmirate = getCityDesc(OfficeCityEmirate);
				String ProfEmpHistoryHeldFlag = (String) xmlParserAPSearchfolderIndex
						.getValueOf("CustomerBackground_Personal");
				String CountryOfOperation = (String) xmlParserAPSearchfolderIndex.getValueOf("CountryOfOperation");
				CountryOfOperation = getCountryDesc(CountryOfOperation);
				// String Emirate = (String)
				// xmlParserAPSearchfolderIndex.getValueOf("ResidenceEmirateCity");
				String MonthlyIncome = (String) xmlParserAPSearchfolderIndex.getValueOf("MonthlyIncome");
				String PurposeOfAccount = (String) xmlParserAPSearchfolderIndex.getValueOf("PurposeOfAccount");
				String SourceOfFunds = (String) xmlParserAPSearchfolderIndex.getValueOf("SourceOfFunds");
				String OtherSourceOfIncome = (String) xmlParserAPSearchfolderIndex.getValueOf("OtherSourceOfIncome");
				String OtherIncome = (String) xmlParserAPSearchfolderIndex.getValueOf("OtherIncome");
				String EstimatedWealth = (String) xmlParserAPSearchfolderIndex.getValueOf("EstimatedWealth");
				String SourceOfWealth = (String) xmlParserAPSearchfolderIndex.getValueOf("SourceOfWealth");
				String USpassport = (String) xmlParserAPSearchfolderIndex
						.getValueOf("USpassportHolder_GreencardHolder");// "Beg";
				String TIN = (String) xmlParserAPSearchfolderIndex.getValueOf("TIN_Field");// "Beg
				String PlaceOfBirthUSA = (String) xmlParserAPSearchfolderIndex.getValueOf("PlaceOfBirthUSA");
				String CurrentUSMailing = (String) xmlParserAPSearchfolderIndex
						.getValueOf("CurrentUSmailingOrResidenceAddress");// "Mirza";
				String CurrentUSTel = (String) xmlParserAPSearchfolderIndex.getValueOf("UStelephoneNumber");// "Suhaib";
				String StandingInstructionsUS = (String) xmlParserAPSearchfolderIndex
						.getValueOf("StandingInstructions");// "Beg";
				String EffectivePower = (String) xmlParserAPSearchfolderIndex.getValueOf("PowerOfAttorney");// "Beg
				String USholdMail = (String) xmlParserAPSearchfolderIndex.getValueOf("USholdMailAddress");
				String FormRequired = (String) xmlParserAPSearchfolderIndex.getValueOf("FormObtained");
				String otherPurpose = (String) xmlParserAPSearchfolderIndex.getValueOf("PurposeOthers");
				String otherSourceFund = (String) xmlParserAPSearchfolderIndex.getValueOf("Funds_Others");
				String otherWealth = (String) xmlParserAPSearchfolderIndex.getValueOf("WealthOthers");
				String otherOccupation = (String) xmlParserAPSearchfolderIndex.getValueOf("OccupationOthers");
				String moneySentto = "";
				String Query = "SELECT Country FROM NG_KYC_REM_MoneySentTo_GRID with(nolock) WHERE WINAME = '" + wINAME
						+ "'";
				List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
				DataFromDB = getDataFromDBMap(Query, cabinetName, sessionID, jtsIP, jtsPort);
				CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
				for (Map<String, String> entry : DataFromDB) {
					int i = 1;
					moneySentto = entry.get("Country");
					moneySentto = getCountryDesc(moneySentto);
					ht.put("Expected_Income_Sent" + String.valueOf(i), moneySentto);
					i++;
				}
				DataFromDB.clear();
				String moneyreceivedFrom = "";
				String Query1 = "SELECT Country FROM NG_KYC_REM_MoneyRecFrom_GRID with(nolock) WHERE WINAME = '"
						+ wINAME + "'";
				List<Map<String, String>> DataFromDB1 = new ArrayList<Map<String, String>>();
				DataFromDB1 = getDataFromDBMap(Query1, cabinetName, sessionID, jtsIP, jtsPort);
				CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
				for (Map<String, String> entry : DataFromDB) {
					int i = 1;
					moneyreceivedFrom = entry.get("Country");
					moneyreceivedFrom = getCountryDesc(moneyreceivedFrom);
					ht.put("Expected_Income_Received1" + String.valueOf(i), moneyreceivedFrom);
					i++;
				}
				DataFromDB1.clear();
				ht.put("DD", day);
				ht.put("MM", month);
				ht.put("YYYY", year);
				ht.put("Title", title);
				ht.put("First_Name", firstName);
				ht.put("Middle_Name", secondName);
				ht.put("Last_Name", lastName);
				ht.put("Nationality", Nationality);
				ht.put("Additional_Nationality", otherNationality);
				ht.put("Country_Of_Residence", residenceCountry);
				ht.put("Politically_Exposed_Person", PEP);
				ht.put("Address", Building + " " + Street + " " + Landmark);
				ht.put("Villa_No", flatVillaNo);
				ht.put("BuildingName", Building);
				ht.put("StreetArea", Street);
				ht.put("Landmark", Landmark);
				ht.put("ZipCode", ZIPCode);
				ht.put("POBOX", POBox);
				ht.put("Statenonresident", State);
				ht.put("Emirate_City", Emirate);
				ht.put("Country", residenceCountry);
				ht.put("Employment_Type", OfficeEmploymentType);
				ht.put("Occupation", OfficeOccupation);
				ht.put("Country_Of_Employment", CountryOfIncorporation);
				ht.put("Employer_Business_Name", OfficeEmployerName);
				ht.put("City_Emirate", OfficeCityEmirate);
				ht.put("PreofssionalEmp_5years", ProfEmpHistoryHeldFlag);
				ht.put("Operation_Country", CountryOfOperation);
				ht.put("Monthly_Income", MonthlyIncome);
				ht.put("Account_Purpose", PurposeOfAccount);
				ht.put("Source_Of_Funds", SourceOfFunds);
				ht.put("Identified_Source_of_Income", OtherSourceOfIncome); 
				ht.put("Other_Income_Amount", OtherIncome);
				ht.put("Estimated_Value_Wealth", EstimatedWealth);
				ht.put("Source_Of_Wealth", SourceOfWealth);
				ht.put("US_Passport", USpassport);
				ht.put("TIN", TIN);
				ht.put("Place_Of_Birth_USA", PlaceOfBirthUSA);
				ht.put("Current_US_Mailing", CurrentUSMailing);
				ht.put("Current_US_Telephone", CurrentUSTel);
				ht.put("Standing_Instructions_USA", StandingInstructionsUS);
				ht.put("Effective_Power", EffectivePower);
				ht.put("USA_Hold_Mail", USholdMail);
				ht.put("Form_Required", FormRequired);
				ht.put("Other_Purpose", otherPurpose);
				ht.put("Other_SourceFund", otherSourceFund);
				ht.put("Other_Source_Of_Wealth", otherWealth);
				ht.put("Others_Occupation", otherOccupation);
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getiformData - " + e.getMessage());
		}
		return ht;
	}

	private String getOccupationDesc(String officeOccupation) {
		try {
			String Desc = "";
			String query = "select Occupation from NG_KYC_REM_Occupation_MASTER with (nolock) where Code = '"
					+ officeOccupation + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				Desc = xmlParserAPSearchfolderIndex.getValueOf("Occupation");
				return Desc;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getCityDesc - " + e.getMessage());
		}
		return officeOccupation;
	}

	private String getempTypeDesc(String empType) {
		try {
			String Desc = "";
			String query = "SELECT Description from NG_KYC_REM_EMPLOYMENT_TYPE_MASTER with(nolock) Where Code = '"
					+ empType + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				Desc = xmlParserAPSearchfolderIndex.getValueOf("Description");
				return Desc;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getempTypeDesc - " + e.getMessage());
		}
		return empType;
	}

	private String getStateDesc(String state) {
		try {
			String Desc = "";
			String query = "Select Description from NG_KYC_REM_STATE_MASTER with(nolock) where Code = '" + state + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				Desc = xmlParserAPSearchfolderIndex.getValueOf("Description");
				return Desc;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getCityDesc - " + e.getMessage());
		}
		return state;
	}

	private String getPEPdesc(String pEP) {
		try {
			String Desc = "";
			String query = "SELECT PEP_DESC FROM NG_KYC_REM_PEP_MASTER with (nolock) WHERE  Code = '" + pEP + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				Desc = xmlParserAPSearchfolderIndex.getValueOf("PEP_DESC");
				return Desc;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getCityDesc - " + e.getMessage());
		}
		return pEP;
	}

	private String getCountryDesc(String nationality) {
		try {
			String Desc = "";
			String query = "Select Distinct CD_Desc from NG_MASTER_KYC_REM_COUNTRY_OF_RESIDENCE with(nolock) where CM_Code = '"
					+ nationality + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				Desc = xmlParserAPSearchfolderIndex.getValueOf("CD_Desc");
				return Desc;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getCityDesc - " + e.getMessage());
		}
		return nationality;
	}

	private String getTitleDesc(String title) {
		try {
			String Desc = "";
			String query = "Select Description from ng_kyc_rem_salutation_master with(nolock) WHERE Code = '" + title
					+ "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				String titledesc = xmlParserAPSearchfolderIndex.getValueOf("Description");
				return titledesc;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getCityDesc - " + e.getMessage());
		}
		return title;
	}

	private String getCityDesc(String residenceEmirateCity) {
		try {
			String Desc = "";
			String query = "Select DISTINCT cityName from NG_KYC_REM_CITY_MASTER with(nolock) where cityCode = '"
					+ residenceEmirateCity + "'";
			String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
			String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
			XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
			CustOutreachLog.KYCcustOutreachLogger
					.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
			String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger
					.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
			int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
			if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
				String cityName = xmlParserAPSearchfolderIndex.getValueOf("cityName");
				return cityName;
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception in getCityDesc - " + e.getMessage());
		}
		return residenceEmirateCity;
	}

	private String generateRRCsheet(String WINAME, String cif, HashMap<String, String> socketDetailsMap, String caseType, String riskScore) {
		String risktype = "toBeCalculated";
		String customerCategory = "";
		String PEP = "";
		String Full_name = "";
		String emp_type = "";
		String segment = "";
		String Sub_Segment = "";
		String demographicsTag = "";
		String nationalityTag = "";
		String industry_tag = "";
		String prodinfoTag = "";
		String current_ws = "";
		String return_code = "9999";
		String return_desc = "Exception";
		String requestXML = "";
		try {
			if("Individual".equalsIgnoreCase(caseType)){
				String query = "Select Current_WS,Segment,Sub_Segment,CustomerCategory,PEP,FirstName,MiddleName,LastName,OfficeEmploymentType,ResidenceCountry,Nationality,OtherNationality"
						+ " from RB_KYC_REM_EXTTABLE with(nolock) where WINAME = '" + WINAME + "'";
				String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
				String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
				XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
				CustOutreachLog.KYCcustOutreachLogger
						.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
				String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
				CustOutreachLog.KYCcustOutreachLogger
						.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
				int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
				if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
					customerCategory = xmlParserAPSearchfolderIndex.getValueOf("CustomerCategory");
					PEP = xmlParserAPSearchfolderIndex.getValueOf("PEP");
					if ("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP)) {
						PEP = "N";
					} else if ("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP)
							|| "FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP)) {
						PEP = "Y";
					}
					if(/*Integer.parseInt(riskScore) > 4 &&*/ "".equalsIgnoreCase(PEP))
						PEP = "N";
					segment = xmlParserAPSearchfolderIndex.getValueOf("Segment");
					Sub_Segment = xmlParserAPSearchfolderIndex.getValueOf("Sub_Segment");
					Full_name = xmlParserAPSearchfolderIndex.getValueOf("FirstName") + " "
							+ xmlParserAPSearchfolderIndex.getValueOf("MiddleName") + " "
							+ xmlParserAPSearchfolderIndex.getValueOf("LastName");
					emp_type = xmlParserAPSearchfolderIndex.getValueOf("OfficeEmploymentType");
					emp_type = getempTypeDesc(emp_type);
					demographicsTag = xmlParserAPSearchfolderIndex.getValueOf("ResidenceCountry");
					demographicsTag = "\n" + "<Demographic>" + getCountryDesc(demographicsTag) + "</Demographic>" + "\n";
					demographicsTag += getmoneySentTo(WINAME);
					demographicsTag += getMoneyRecFrom(WINAME);
					nationalityTag = xmlParserAPSearchfolderIndex.getValueOf("Nationality");
					nationalityTag = "\n" + "<Nationality>" + getCountryDesc(nationalityTag) + "</Nationality>" + "\n";
					industry_tag = getIndustry(WINAME);
					prodinfoTag = getProduct(WINAME);
					current_ws = xmlParserAPSearchfolderIndex.getValueOf("Current_WS");
				}
				requestXML = "<EE_EAI_MESSAGE>" + "\n" + "<EE_EAI_HEADER>" + "\n"
						+ "<MsgFormat>RISK_SCORE_DETAILS</MsgFormat>" + "\n" + "<MsgVersion>0001</MsgVersion>" + "\n"
						+ "<RequestorChannelId>CAS</RequestorChannelId>" + "\n"
						+ "<RequestorUserId>RAKUSER</RequestorUserId>" + "\n" + "<RequestorLanguage>E</RequestorLanguage>"
						+ "\n" + "<RequestorSecurityInfo>secure</RequestorSecurityInfo>" + "\n"
						+ "<ReturnCode>911</ReturnCode>" + "\n" + "<ReturnDesc>Issuer Timed Out</ReturnDesc>" + "\n"
						+ "<MessageId>123123453</MessageId>" + "\n" + "<Extra1>REQ||SHELL.JOHN</Extra1>" + "\n"
						+ "<Extra2>YYYY-MM-DDThh:mm:ss.mmm+hh:mm</Extra2>" + "\n" + "</EE_EAI_HEADER>" + "\n"
						+ "<RiskScoreDetailsRequest>" + "\n" + "<RequestInfo>" + "\n"
						+ "<RequestType>Reference Id</RequestType>" + "\n" + "<RequestValue>" + WINAME + "</RequestValue>"
						+ "\n" + "</RequestInfo>" + "\n" + "<RequestInfo>" + "\n" + "<RequestType>CIF Id</RequestType>"
						+ "\n" + "<RequestValue>" + cif + "</RequestValue>" + "\n" + "</RequestInfo>" + "\n"
						+ "<CustomerType>Individual</CustomerType>" + "\n" + "<CustomerCategory>" + customerCategory
						+ "</CustomerCategory>" + "\n" + "<IsPoliticallyExposed>" + PEP + "</IsPoliticallyExposed>" + "\n"
						+ "<CustomerName>" + Full_name + "</CustomerName>" + "\n" + "<EmploymentType>" + emp_type
						+ "</EmploymentType>" + "\n" + "<Segment>" + segment + "</Segment>" + "\n" + "<SubSegment>"
						+ Sub_Segment + "</SubSegment>" + "\n" + "<Demographics>" + demographicsTag + "</Demographics>"
						+ "\n" + "<Nationalities>" + nationalityTag + "</Nationalities>" + "\n" + "<Industries>"
						+ industry_tag + "</Industries>" + prodinfoTag + "\n" + "</RiskScoreDetailsRequest>" + "\n"
						+ "</EE_EAI_MESSAGE>" + "\n";
				CustOutreachLog.KYCcustOutreachLogger.debug("requestXML - " + requestXML);
			}
			else if("Corporate".equalsIgnoreCase(caseType)){
				String query = "Select Current_WS,Segment,Sub_Segment,CustomerCategory,PEP,NameOfCompany,EntityCountryOfIncorporation"
						+ " from RB_KYC_REM_EXTTABLE with(nolock) where WINAME = '" + WINAME + "'";
				String apSelectInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				CustOutreachLog.KYCcustOutreachLogger.debug("apSelectInputXML--- " + apSelectInputXML);
				String apSelectOutXml = CommonMethods.WFNGExecute(apSelectInputXML, jtsIP, jtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("apSelectOutXml--- " + apSelectOutXml);
				XMLParser xmlParserAPSearchfolderIndex = new XMLParser(apSelectOutXml);
				CustOutreachLog.KYCcustOutreachLogger
						.debug("xmlParserAPSearchfolderIndex--- " + xmlParserAPSearchfolderIndex);
				String apSearchMaincodefolderIndex = xmlParserAPSearchfolderIndex.getValueOf("MainCode");
				CustOutreachLog.KYCcustOutreachLogger
						.debug("apSearchMaincodefolderIndex--- " + apSearchMaincodefolderIndex);
				int TotalRecords = Integer.parseInt(xmlParserAPSearchfolderIndex.getValueOf("TotalRetrieved"));
				if (apSearchMaincodefolderIndex.equalsIgnoreCase("0") && TotalRecords > 0) {
					customerCategory = xmlParserAPSearchfolderIndex.getValueOf("CustomerCategory");
					PEP = xmlParserAPSearchfolderIndex.getValueOf("PEP");
					if ("NOT PEP".equalsIgnoreCase(PEP) || "NPEP".equalsIgnoreCase(PEP)) {
						PEP = "N";
					} else if ("LOCAL PEP".equalsIgnoreCase(PEP) || "LPEP".equalsIgnoreCase(PEP)
							|| "FOREIGN PEP".equalsIgnoreCase(PEP) || "FPEP".equalsIgnoreCase(PEP)) {
						PEP = "Y";
					}
					segment = xmlParserAPSearchfolderIndex.getValueOf("Segment");
					Sub_Segment = xmlParserAPSearchfolderIndex.getValueOf("Sub_Segment");
					Full_name = xmlParserAPSearchfolderIndex.getValueOf("NameOfCompany");
					List<String> demographic = new ArrayList <>();
					demographicsTag += getCountryOfOperation(WINAME,demographicsTag,demographic);
					demographicsTag += getBuyersCountry(WINAME,demographicsTag,demographic);
					demographicsTag += getSuppliersCountry(WINAME,demographicsTag,demographic);
					demographicsTag += getSubsidiaryCountry(WINAME,demographicsTag,demographic);
					demographicsTag += getSHResidenceCountry(WINAME,demographicsTag,demographic);
					demographicsTag = "";
					for(String country : demographic){
						demographicsTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";
					}
					List<String> nationality = new ArrayList <>();
					nationalityTag = xmlParserAPSearchfolderIndex.getValueOf("EntityCountryOfIncorporation");
					nationality.add(getCountryDesc(nationalityTag));
					nationalityTag += getSHNationalityCountry(WINAME, nationalityTag,nationality);
					nationalityTag += RPAdditionalNationalityCountry(WINAME, nationalityTag,nationality);
					nationalityTag = "";
					for(String country : nationality){
						nationalityTag += "\n" + "<Nationality>" + country + "</Nationality>" + "\n";
					}
					industry_tag = getBBGIndustry(WINAME);
					prodinfoTag = getProduct(WINAME);
					current_ws = xmlParserAPSearchfolderIndex.getValueOf("Current_WS");
					requestXML = "<EE_EAI_MESSAGE>" + "\n" + "<EE_EAI_HEADER>" + "\n"
							+ "<MsgFormat>RISK_SCORE_DETAILS</MsgFormat>" + "\n" + "<MsgVersion>0001</MsgVersion>" + "\n"
							+ "<RequestorChannelId>CAS</RequestorChannelId>" + "\n"
							+ "<RequestorUserId>RAKUSER</RequestorUserId>" + "\n" + "<RequestorLanguage>E</RequestorLanguage>"
							+ "\n" + "<RequestorSecurityInfo>secure</RequestorSecurityInfo>" + "\n"
							+ "<ReturnCode>911</ReturnCode>" + "\n" + "<ReturnDesc>Issuer Timed Out</ReturnDesc>" + "\n"
							+ "<MessageId>123123453</MessageId>" + "\n" + "<Extra1>REQ||SHELL.JOHN</Extra1>" + "\n"
							+ "<Extra2>YYYY-MM-DDThh:mm:ss.mmm+hh:mm</Extra2>" + "\n" + "</EE_EAI_HEADER>" + "\n"
							+ "<RiskScoreDetailsRequest>" + "\n" + "<RequestInfo>" + "\n"
							+ "<RequestType>Reference Id</RequestType>" + "\n" + "<RequestValue>" + WINAME + "</RequestValue>"
							+ "\n" + "</RequestInfo>" + "\n" + "<RequestInfo>" + "\n" + "<RequestType>CIF Id</RequestType>"
							+ "\n" + "<RequestValue>" + cif + "</RequestValue>" + "\n" + "</RequestInfo>" + "\n"
							+ "<CustomerType>Corporate</CustomerType>" + "\n" + "<CustomerCategory>" + customerCategory
							+ "</CustomerCategory>" + "\n" + "<IsPoliticallyExposed>" + PEP + "</IsPoliticallyExposed>" + "\n"
							+ "<CustomerName>" + Full_name + "</CustomerName>" + "\n" + "<Segment>" + segment + "</Segment>" + "\n" + "<SubSegment>"
							+ Sub_Segment + "</SubSegment>" + "\n" + "<Demographics>" + demographicsTag + "</Demographics>"
							+ "\n" + "<Nationalities>" + nationalityTag + "</Nationalities>" + "\n" + "<Industries>"
							+ industry_tag + "</Industries>" + prodinfoTag + "\n" + "</RiskScoreDetailsRequest>" + "\n"
							+ "</EE_EAI_MESSAGE>" + "\n";
					CustOutreachLog.KYCcustOutreachLogger.debug("requestXML - " + requestXML);
				}
			}
			try {
				CustOutreachLog.KYCcustOutreachLogger.debug("Session Id is " + sessionID);

				socketServerIP = socketDetailsMap.get("SocketServerIP");
				CustOutreachLog.KYCcustOutreachLogger.debug("Socket server IP is " + socketServerIP);

				socketServerPort = Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
				CustOutreachLog.KYCcustOutreachLogger.debug("Socket server port is " + socketServerPort);

				if (!("".equals(socketServerIP)) && socketServerIP != null && !(socketServerPort == 0)) {
					socket = new Socket(socketServerIP, socketServerPort);
					socket.setSoTimeout(sleepIntervalInMin * 1000);
					out = socket.getOutputStream();
					socketInputStream = socket.getInputStream();
					dout = new DataOutputStream(out);
					din = new DataInputStream(socketInputStream);

					CustOutreachLog.KYCcustOutreachLogger.debug("Data output stream is " + dout);
					CustOutreachLog.KYCcustOutreachLogger.debug("Data input stream is " + din);
					outputResponse = "";
					inputRequest = getRequestXML(cabinetName, sessionID, WINAME, current_ws,
							CommonConnection.getUsername(), new StringBuilder(requestXML));

					CustOutreachLog.KYCcustOutreachLogger
							.debug("Input MQ XML for Customer creation is " + inputRequest);

					if (inputRequest != null && inputRequest.length() > 0) {
						int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
						CustOutreachLog.KYCcustOutreachLogger.debug("RequestLen: " + inputRequestLen + "");
						inputRequest = inputRequestLen + "##8##;" + inputRequest;
						CustOutreachLog.KYCcustOutreachLogger
								.debug("InputRequest" + "Input Request Bytes : " + inputRequest.getBytes("UTF-16LE"));
						dout.write(inputRequest.getBytes("UTF-16LE"));
						dout.flush();
					}
					byte[] readBuffer = new byte[500];
					int num = din.read(readBuffer);

					if (num > 0) {

						byte[] arrayBytes = new byte[num];
						System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
						outputResponse = outputResponse + new String(arrayBytes, "UTF-16LE");
						inputMessageID = outputResponse;
						CustOutreachLog.KYCcustOutreachLogger.debug("OutputResponse: " + outputResponse);

						if (!"".equalsIgnoreCase(outputResponse))
							outputResponse = getResponseXML(cabinetName, jtsIP, jtsPort, sessionID, WINAME,
									outputResponse, integrationWaitTime);
						if (outputResponse.contains("&lt;")) {
							outputResponse = outputResponse.replaceAll("&lt;", "<");
							outputResponse = outputResponse.replaceAll("&gt;", ">");
						}
						CustOutreachLog.KYCcustOutreachLogger.debug("OutputResponse: " + outputResponse);
					}
					socket.close();

					outputResponse = outputResponse.replaceAll("</MessageId>",
							"</MessageId>/n<InputMessageId>" + inputMessageID + "</InputMessageId>");
					XMLParser sXMLParser = new XMLParser(outputResponse);
					System.out.println("outputResponse--" + outputResponse);
					return_code = sXMLParser.getValueOf("ReturnCode");
					return_desc = sXMLParser.getValueOf("ReturnDesc");
					CustOutreachLog.KYCcustOutreachLogger.debug("return_code: " + return_code);
					CustOutreachLog.KYCcustOutreachLogger.debug("Response XML is " + outputResponse);
					if (!"0000".equalsIgnoreCase(return_code)) {
						// return_desc = sXMLParser.getValueOf("Description");
						String columnName = "WINAME,CustomerResponseDate,AutoRRCStatus,errorReasonCode,errorReasonDescription";
						String values = "'" + WINAME + "',getDate(),'Failure','" + return_code + "','" + return_desc
								+ "'";
						String tableName = "NG_KYC_REM_AUTORRC_FAILURE_TABLE";
						String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, values,
								tableName);
						CustOutreachLog.KYCcustOutreachLogger.debug("APInsertInputXML: " + apInsertInputXML);
						String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
						CustOutreachLog.KYCcustOutreachLogger.debug("APInsertOutputXML: " + apInsertOutputXML);
						XMLParser xmlParserapInsertMaincode = new XMLParser(apInsertOutputXML);
						String apInsertMaincode = xmlParserapInsertMaincode.getValueOf("MainCode");
						if (apInsertMaincode.equalsIgnoreCase("0")) {
							CustOutreachLog.KYCcustOutreachLogger
									.debug("Auto RRC Status updated successfully: " + apInsertMaincode);
						}
					}
					if ("0000".equalsIgnoreCase(return_code)) {

						String TotalRiskScore = sXMLParser.getValueOf("TotalRiskScore");
						/*if (!"".equalsIgnoreCase(TotalRiskScore)) {
							String rscore = TotalRiskScore;
							if (!rscore.contains("."))
								rscore = rscore + ".00";
							double riskscore = Float.parseFloat(rscore);
							if (riskscore >= 1 && riskscore < 2) {
								risktype = "Low";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} else if (riskscore >= 2 && riskscore < 3) {
								risktype = "Standard";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} else if (riskscore >= 3 && riskscore < 4) {
								risktype = "Medium";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} else if (riskscore >= 4 && riskscore < 5) {
								risktype = "High";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} else if (riskscore >= 5) {
								risktype = "Elevated";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							}
						}*/
						if (!"".equalsIgnoreCase(TotalRiskScore)) {
							String rscore = TotalRiskScore;
							if (!rscore.contains("."))
								rscore = rscore + ".00";
							double riskscore = Float.parseFloat(rscore);
							if (riskscore >= 0 && riskscore < 3) {
								risktype = "Low";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} else if (riskscore >= 3 && riskscore < 4) {
								risktype = "Medium";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} else if (riskscore >= 4) {
								risktype = "High";
								CustOutreachLog.KYCcustOutreachLogger.debug("risktype : " + risktype);
							} 
						}
						
						Date date = new Date();
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
						String today = sdf.format(date);
						String demographics = demographicsTag.replaceAll("<Demographic>", "");
						demographics = demographics.replaceAll("</Demographic>", ",");
						demographics = demographics.trim();
						String industry = industry_tag.replaceAll("</Industry>", ",");
						industry = industry.replaceAll("<Industry>", "");
						industry = industry.trim();
						String Nationality = nationalityTag.replaceAll("</Nationality>", ",");
						Nationality = Nationality.replaceAll("<Nationality>", "");
						Nationality = Nationality.trim();
						String acc_curr = getAccCurr(prodinfoTag);
						String custType = "Retail";
						if("Corporate".equalsIgnoreCase(caseType)) custType = "Corporate";
						String customerType = "Individual";
						if("Corporate".equalsIgnoreCase(caseType)) customerType = "Corporate";
						Map<String, String> ht1 = new HashMap<String, String>();
						ht1.put("custType", custType);
						ht1.put("CIF_NUMBER", cif);
						ht1.put("P_FullName", Full_name);
						ht1.put("EMPLOYMENT_TYPE", emp_type);
						ht1.put("CUSTOMER_SEGMENT", segment);
						ht1.put("CUSTOMER_SUBSEGMENT", Sub_Segment);
						ht1.put("DEMOGRAPHIC", demographics);
						ht1.put("INDUSTRY_SUBSEGMENT", industry);
						ht1.put("NATIONALITY", Nationality);
						ht1.put("CUSTOMER_TYPE", customerType);
						ht1.put("acctype_curr", acc_curr);
						ht1.put("oth_custtype", customerCategory);
						ht1.put("PEP", PEP);
						ht1.put("RISK_SCORE", TotalRiskScore);
						ht1.put("final_risk_type", risktype);
						ht1.put("Date", today);
						String status = generatePDF(ht1, WINAME, "Risk_Score");
						if ("Success".equalsIgnoreCase(status)) {
							attachwithWI(WINAME, "Risk_Score", cif);
							// update flag
							String columnName = "AutoRRCStatus,RiskProfile";
							if("Corporate".equalsIgnoreCase(caseType)) columnName = "AutoRRCStatus,EntityRiskProfile";
							String values = "'Success','" + TotalRiskScore + "'";
							String whereClause = "WINAME = '" + WINAME + "'";
							String apUpdateInputXML = CommonMethods.apUpdateInput(cabinetName, sessionID,
									"RB_KYC_REM_EXTTABLE", columnName, values, whereClause);
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateInputXML: " + apUpdateInputXML);
							String apUpdateOutputXML = CommonMethods.WFNGExecute(apUpdateInputXML, jtsIP, jtsPort, 1);
							CustOutreachLog.KYCcustOutreachLogger.debug("apUpdateOutputXML: " + apUpdateOutputXML);
							XMLParser xmlParserAPUpdate = new XMLParser(apUpdateOutputXML);
							String apUpdateMaincode = xmlParserAPUpdate.getValueOf("MainCode");
							if (apUpdateMaincode.equalsIgnoreCase("0")) {
								CustOutreachLog.KYCcustOutreachLogger.debug("Auto RRC Status updated successfully: " + apUpdateOutputXML);
							}
						} else {
							// update flag
							CustOutreachLog.KYCcustOutreachLogger.debug("Failure in generate PDF method:" + status);
						}
					}
				}
			} catch (Exception e) {
				CustOutreachLog.KYCcustOutreachLogger.debug("The Exception in RRC calculation is " + e.getMessage());
				System.out.println("The Exception in RRC calculation is " + e.getMessage());
				return return_code + "-" + return_desc;
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occured in RRC calculation method" + e.getMessage());
			return return_code + "-" + return_desc;
		}
		return return_code + "-" + risktype;
	}

	private String getAccCurr(String prodinfoTag) {
		String xmlData = "<root>" + prodinfoTag + "</root>";
		StringBuilder output = new StringBuilder();
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new java.io.ByteArrayInputStream(xmlData.getBytes()));

			NodeList productsList = doc.getElementsByTagName("ProductsInfo");

			for (int i = 0; i < productsList.getLength(); i++) {
				Element productInfo = (Element) productsList.item(i);
				String product = productInfo.getElementsByTagName("Product").item(0).getTextContent();
				String currency = productInfo.getElementsByTagName("Currency").item(0).getTextContent();

				if (output.length() > 0) {
					output.append(",");
				}
				output.append(product).append("-").append(currency);
			}
			CustOutreachLog.KYCcustOutreachLogger.debug("product info tag - " + output.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output.toString();
	}

	private String getResponseXML(String cabinetName, String sJtsIp, String iJtsPort, String sessionID, String wi_name,
			String message_ID, int integrationWaitTime) {

		String outputResponseXML = "";
		try {
			String QueryString = "select OUTPUT_XML from " + XMLLOG_HISTORY_TABLE + " with (nolock) where "
					+ "MESSAGE_ID ='" + message_ID + "' and WI_NAME = '" + wi_name + "'";

			String responseInputXML = CommonMethods.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("Response APSelect InputXML: " + responseInputXML);

			int Loop_count = 0;
			do {
				String responseOutputXML = CommonMethods.WFNGExecute(responseInputXML, sJtsIp, iJtsPort, 1);
				CustOutreachLog.KYCcustOutreachLogger.debug("Response APSelect OutputXML: " + responseOutputXML);

				XMLParser xmlParserSocketDetails = new XMLParser(responseOutputXML);
				String responseMainCode = xmlParserSocketDetails.getValueOf("MainCode");
				CustOutreachLog.KYCcustOutreachLogger.debug("ResponseMainCode: " + responseMainCode);

				int responseTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
				CustOutreachLog.KYCcustOutreachLogger.debug("ResponseTotalRecords: " + responseTotalRecords);
				if (responseMainCode.equals("0") && responseTotalRecords > 0) {
					String responseXMLData = xmlParserSocketDetails.getNextValueOf("Record");
					responseXMLData = responseXMLData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					XMLParser xmlParserResponseXMLData = new XMLParser(responseXMLData);

					outputResponseXML = xmlParserResponseXMLData.getValueOf("OUTPUT_XML");
					CustOutreachLog.KYCcustOutreachLogger.debug("OutputResponseXML: " + outputResponseXML);

					if ("".equalsIgnoreCase(outputResponseXML)) {
						outputResponseXML = "Error";
					}
					break;
				}
				Loop_count++;
				Thread.sleep(1000);
			} while (Loop_count < integrationWaitTime);

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occurred in outputResponseXML" + e.getMessage());
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occurred in outputResponseXML" + e.getStackTrace());
			outputResponseXML = "Error";
		}
		return outputResponseXML;
	}

	private String getRequestXML(String cabinetName, String sessionID, String wi_name, String ws_name, String userName,
			StringBuilder final_XML) {
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>" + XMLLOG_HISTORY_TABLE + "</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(final_XML);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		CustOutreachLog.KYCcustOutreachLogger.debug("GetRequestXML: " + strBuff.toString());
		return strBuff.toString();
	}

	private String getProduct(String WINAME) {
		String prodTag = "";
		String product = "";

		String currency = "";
		try {
			String query = "SELECT ProductType,Currency from NG_KYC_REM_PRODUCTCURR_GRID with(nolock) WHERE WINAME = '"
					+ WINAME + "' AND ProductType IS NOT NULL AND Currency IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				product = entry.get("ProductType");
				currency = entry.get("Currency");
				prodTag = prodTag + "\n" + "<ProductsInfo>" + "\n" + "<Product>" + product + "</Product>" + "\n"
						+ "<Currency>" + currency + "</Currency>" + "\n" + "</ProductsInfo>";
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occured in getIndustry method" + e.getMessage());
		}
		return prodTag;
	}

	private String getIndustry(String WINAME) {
		String industryTag = "";
		try {
			String industry = "";
			String query = "SELECT SubSegment from NG_KYC_REM_IND_SubSegment_GRID with(nolock) WHERE WINAME = '"
					+ WINAME + "' AND SubSegment IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				industry = entry.get("SubSegment");
				industryTag += "\n" + "<Industry>" + industry + "</Industry>" + "\n";
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occured in getIndustry method" + e.getMessage());
		}
		return industryTag;
	}
	
	private String getBBGIndustry(String WINAME) {
		String industryTag = "";
		try {
			String industry = "";
			String query = "SELECT LicensedBusinessActivity from NG_KYC_REM_LBA_GRID with(nolock) WHERE WINAME = '"
					+ WINAME + "' AND LicensedBusinessActivity IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				industry = entry.get("LicensedBusinessActivity");
				industryTag += "\n" + "<Industry>" + industry + "</Industry>" + "\n";
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception occured in getIndustry method" + e.getMessage());
		}
		return industryTag;
	}

	private String getmoneySentTo(String WINAME) {
		String demographicsTag = "";
		try {
			String country = "";
			String query = "SELECT Country FROM NG_KYC_REM_MoneySentTo_GRID with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Country IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Country");
				country = getCountryDesc(country);
				demographicsTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicsTag;
	}

	private String getMoneyRecFrom(String WINAME) {
		String demographicsTag = "";
		try {
			String country = "";
			String query = "SELECT Country FROM NG_KYC_REM_MoneyRecFrom_GRID with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Country IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Country");
				country = getCountryDesc(country);
				demographicsTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicsTag;
	}

	private String getCountryOfOperation(String WINAME, String demographicsTag, List<String> lstDemographic) {
		String demographicTag = "";
		try {
			String country = "";
			String query = "SELECT Country FROM NG_KYC_REM_EntityCountryOfOper with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Country IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Country");
				country = getCountryDesc(country);
				//01/06/2026 for duplicate countries being shown in RRC sheet
				if(!lstDemographic.contains(country))
					lstDemographic.add(country);
				/*if(!demographicsTag.contains(country))
					demographicTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";*/
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicTag;
	}
	
	private String getBuyersCountry(String WINAME, String demographicsTag, List<String> lstDemographic) {
		String demographicTag = "";
		try {
			String country = "";
			String query = "SELECT Country FROM NG_KYC_REM_BuyerName with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Country IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Country");
				country = getCountryDesc(country);
				if(!lstDemographic.contains(country))
					lstDemographic.add(country);
				/*if(!demographicsTag.contains(country))
					demographicTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";*/
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicTag;
	}
	
	private String getSuppliersCountry(String WINAME,String demographicsTag, List<String> lstDemographic) {
		String demographicTag = "";
		try {
			String country = "";
			String query = "SELECT Country FROM NG_KYC_REM_SuppliersName with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Country IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Country");
				country = getCountryDesc(country);
				if(!lstDemographic.contains(country))
					lstDemographic.add(country);
				/*if(!demographicsTag.contains(country))
					demographicTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";*/
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicTag;
	}
	
	private String getSubsidiaryCountry(String WINAME, String demographicsTag, List<String> lstDemographic) {
		String demographicTag = "";
		try {
			String country = "";
			String query = "SELECT Country FROM NG_KYC_REM_SSCountryOperation with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Country IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Country");
				country = getCountryDesc(country);
				if(!lstDemographic.contains(country))
					lstDemographic.add(country);
				/*if(!demographicsTag.contains(country))
					demographicTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";*/
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicTag;
	}
	
	private String getSHResidenceCountry(String WINAME, String demographicsTag, List<String> lstDemographic) {
		String demographicTag = "";
		try {
			String country = "";
			String query = "SELECT ResidenceCountry FROM NG_KYC_REM_Shareholder_GRID with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND ResidenceCountry IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("ResidenceCountry");
				country = getCountryDesc(country);
				if(!lstDemographic.contains(country))
					lstDemographic.add(country);
				/*if(!demographicsTag.contains(country))
					demographicTag += "\n" + "<Demographic>" + country + "</Demographic>" + "\n";*/
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return demographicTag;
	}
	
	private String getSHNationalityCountry(String WINAME,String nationalityTag, List<String> listNationality) {
		String nationality = "";
		try {
			String country = "";
			String query = "SELECT Nationality FROM NG_KYC_REM_Shareholder_GRID with(nolock) WHERE WINAME = '" + WINAME
					+ "' AND Nationality IS NOT NULL";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Nationality");
				country = getCountryDesc(country);
				if(!listNationality.contains(country))
					listNationality.add(country);
				/*if(!nationalityTag.contains(country))
					nationality += "\n" + "<Nationality>" + country + "</Nationality>" + "\n";*/
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return nationality;
	}
	
	private String RPAdditionalNationalityCountry(String WINAME, String nationalityTag, List<String> listNationality) {
		String nationality = "";
		try {
			String country = "";
			String query = "SELECT Nationality from NG_KYC_REM_AddNationality_GRID with(nolock) WHERE WINAME IN "
					+ "(SELECT RP_WI_Number FROM NG_KYC_REM_RP_GRID with(nolock) WHERE WI_Name = '"+WINAME+"')";
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			DataFromDB = getDataFromDBMap(query, cabinetName, sessionID, jtsIP, jtsPort);
			CustOutreachLog.KYCcustOutreachLogger.debug("DataFromDB : OF_DATA_DEF_ID " + DataFromDB);
			for (Map<String, String> entry : DataFromDB) {
				country = entry.get("Nationality");
				if(!"".equalsIgnoreCase(country))
				{
					country = getCountryDesc(country);
					if(!listNationality.contains(country))
						listNationality.add(country);
					/*if(!nationalityTag.contains(country))
						nationality += "\n" + "<Nationality>" + country + "</Nationality>" + "\n";*/
				}
			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return nationality;
	}
	
	private static List<Map<String, String>> getDataFromDBMap(String query, String cabinetName, String sessionID,
			String jtsIP, String jtsPort) {
		List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Inside function getDataFromDB");
			CustOutreachLog.KYCcustOutreachLogger.debug("getDataFromDB query is: " + query);
			String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			OutXml = OutXml.replaceAll("&", "#andsymb#");
			Document recordDoc1 = MapXML.getDocument(OutXml);
			NodeList records1 = recordDoc1.getElementsByTagName("Record");
			if (records1.getLength() > 0) {
				for (int i = 0; i < records1.getLength(); i++) {
					Node n = records1.item(i);
					Map<String, String> t = new HashMap<String, String>();
					if (n.hasChildNodes()) {
						NodeList child = n.getChildNodes();
						for (int j = 0; j < child.getLength(); j++) {
							Node n1 = child.item(j);
							String column = n1.getNodeName();
							String value = n1.getTextContent().replaceAll("#andsymb#", "&");
							if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
								// CustOutreachLog.KYCcustOutreachLogger.debug("getDataFromDBMap
								// Setting value of " + column + " as " +
								// value);
								t.put(column, value);
							} else {
								// CustOutreachLog.KYCcustOutreachLogger.debug("getDataFromDBMap
								// Setting value of " + column + " as blank");
								t.put(column, "");
							}
						}
					}
					temp.add(t);
				}
			}

		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return temp;
	}

	private HashMap<String, String> socketConnectionDetails(String cabinetName, String sJtsIp, String iJtsPort,
			String sessionID) {
		HashMap<String, String> socketDetailsMap = new HashMap<String, String>();

		try {
			CustOutreachLog.KYCcustOutreachLogger.debug("Fetching Socket Connection Details.");
			System.out.println("Fetching Socket Connection Details.");

			String socketDetailsQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'KYC_Remediation' and CallingSource = 'Utility'";

			String socketDetailsInputXML = CommonMethods.apSelectWithColumnNames(socketDetailsQuery, cabinetName,
					sessionID);
			CustOutreachLog.KYCcustOutreachLogger.debug("Socket Details APSelect InputXML: " + socketDetailsInputXML);

			String socketDetailsOutputXML = WFNGExecute(socketDetailsInputXML, sJtsIp, iJtsPort, 1);
			CustOutreachLog.KYCcustOutreachLogger.debug("Socket Details APSelect OutputXML: " + socketDetailsOutputXML);

			XMLParser xmlParserSocketDetails = new XMLParser(socketDetailsOutputXML);
			String socketDetailsMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			CustOutreachLog.KYCcustOutreachLogger.debug("SocketDetailsMainCode: " + socketDetailsMainCode);

			int socketDetailsTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			CustOutreachLog.KYCcustOutreachLogger.debug("SocketDetailsTotalRecords: " + socketDetailsTotalRecords);

			if (socketDetailsMainCode.equalsIgnoreCase("0") && socketDetailsTotalRecords > 0) {
				String xmlDataSocketDetails = xmlParserSocketDetails.getNextValueOf("Record");
				xmlDataSocketDetails = xmlDataSocketDetails.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

				XMLParser xmlParserSocketDetailsRecord = new XMLParser(xmlDataSocketDetails);

				String socketServerIP = xmlParserSocketDetailsRecord.getValueOf("SocketServerIP");
				CustOutreachLog.KYCcustOutreachLogger.debug("SocketServerIP: " + socketServerIP);
				socketDetailsMap.put("SocketServerIP", socketServerIP);

				String socketServerPort = xmlParserSocketDetailsRecord.getValueOf("SocketServerPort");
				CustOutreachLog.KYCcustOutreachLogger.debug("SocketServerPort " + socketServerPort);
				socketDetailsMap.put("SocketServerPort", socketServerPort);

				CustOutreachLog.KYCcustOutreachLogger.debug("SocketServer Details found.");
				System.out.println("SocketServer Details found.");

			}
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger
					.debug("Exception in getting Socket Connection Details: " + e.getMessage());
			System.out.println("Exception in getting Socket Connection Details: " + e.getMessage());
		}

		return socketDetailsMap;
	}

	protected static String WFNGExecute(String ipXML, String jtsServerIP, String serverPort, int flag)
			throws IOException, Exception {
		CustOutreachLog.KYCcustOutreachLogger.debug("In WF NG Execute : " + serverPort);
		try {
			if (serverPort.startsWith("33"))
				return WFCallBroker.execute(ipXML, jtsServerIP, Integer.parseInt(serverPort), 1);
			else
				return ngEjbClientOutreach.makeCall(jtsServerIP, serverPort, "WebSphere", ipXML);
		} catch (Exception e) {
			CustOutreachLog.KYCcustOutreachLogger.debug("Exception Occured in WF NG Execute : " + e.getMessage());
			e.printStackTrace();
			return "Error";
		}
	}
}
