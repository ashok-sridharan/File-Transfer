package com.newgen.KYC.KYCWICreate;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.newgen.KYC.KYCWICreate.KYCWICreateLog;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

public class KYCWICreate implements Runnable{
	
	private static String sessionID = "";
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	private static String queueID = "";
	private static String processDefID = "";
	private static int sleepIntervalInMin=0;
	private static String headers = "";
	private static String columnNames = "";
	private static String table = "";
	private static String errorRowNo = "";
	//private static String coumn_external = "";
	static HashMap<String,String>  headerColumnMap= new HashMap<>();
	//static HashMap<String,String>  dbExtColumnMap= new HashMap<>();
	
	
	private static NGEjbClient ngEjbClientODDoc;

	static Map<String, String> ODDocConfigParamMap= new HashMap<String, String>();
	
	@Override
	public void run()
	{
		try
		{
			KYCWICreateLog.setLogger();
			ngEjbClientODDoc = NGEjbClient.getSharedInstance();

			KYCWICreateLog.KYCWICreateLogger.debug("Connecting to Cabinet.");

			int configReadStatus = readConfig();

			KYCWICreateLog.KYCWICreateLogger.debug("configReadStatus "+configReadStatus);
			if(configReadStatus !=0)
			{
				KYCWICreateLog.KYCWICreateLogger.error("Could not Read Config Properties [ODDDStatus]");
				return;
			}

			cabinetName = CommonConnection.getCabinetName();
			KYCWICreateLog.KYCWICreateLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			KYCWICreateLog.KYCWICreateLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			KYCWICreateLog.KYCWICreateLogger.debug("JTSPORT: " + jtsPort);			

			queueID = ODDocConfigParamMap.get("QueueID");
			KYCWICreateLog.KYCWICreateLogger.debug("QueueID: " + queueID);

			sleepIntervalInMin=Integer.parseInt(ODDocConfigParamMap.get("SleepIntervalInMin"));
			KYCWICreateLog.KYCWICreateLogger.debug("SleepIntervalInMin: "+sleepIntervalInMin);
			
			table=ODDocConfigParamMap.get("table");
			KYCWICreateLog.KYCWICreateLogger.debug("table: "+table);
			
			processDefID =ODDocConfigParamMap.get("processDefID");
			KYCWICreateLog.KYCWICreateLogger.debug("processDefID: "+processDefID);
			
 			sessionID = CommonConnection.getSessionID(KYCWICreateLog.KYCWICreateLogger, false);

 			if(sessionID.trim().equalsIgnoreCase(""))
			{
				KYCWICreateLog.KYCWICreateLogger.debug("Could Not Connect to Server!");
			}
			else
			{
 				KYCWICreateLog.KYCWICreateLogger.debug("Session ID found: " + sessionID);
				//HashMap<String, String> socketDetailsMap= socketConnectionDetails(cabinetName, jtsIP, jtsPort,sessionID);
				while(true)
				{
					sessionID = CommonConnection.getSessionID(KYCWICreateLog.KYCWICreateLogger, false);
 					KYCWICreateLog.setLogger();
 					KYCWICreateLog.KYCWICreateLogger.debug("ODDD Utility...123");
 					startUtilityKYCWICreate(cabinetName, sessionID,jtsIP, jtsPort);
					System.out.println("No More workitems to Process, Sleeping!");
					Thread.sleep(sleepIntervalInMin*60*1000);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			KYCWICreateLog.KYCWICreateLogger.error("Exception Occurred in ODDD : "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			KYCWICreateLog.KYCWICreateLogger.error("Exception Occurred in ODDD : "+result);
		}
	}

	private int readConfig()
	{
		Properties p = null;
		try 
		{

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "ConfigFiles"+ File.separator+ "KYC_KYCWICreate_Config.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements())
			{
			    String name = (String) names.nextElement();
			    ODDocConfigParamMap.put(name, p.getProperty(name));
			}										
		}
		catch (Exception e)
		{
			return -1 ;
		}
		return 0;
	}

	private static void startUtilityKYCWICreate(String cabinetName, String sessionId, String JtsIp,String JtsPort) 
	{
 		KYCWICreateLog.KYCWICreateLogger.info("Inside startUtilityKYCWICreate..");
		//ArrayList<String> wiList = new ArrayList<String>();
		/*boolean fileMoved;
		boolean readExcelFileStatus;
		File tmpDir = new File(ExcelPath+"\\"+excelFileName);
 		if(tmpDir.length() == 0)
		{
			boolean exists = tmpDir.exists();
			if(exists){
				fileMoved = moveFile(ExcelPath+"\\"+excelFileName,error+"\\"+excelFileName);
				KYCWICreateLog.KYCWICreateLogger.info("File moved to error folder as it is blank..");
			}
			//fileMoved = moveFile(ExcelPath+"\\"+excelFileName,error+"\\"+excelFileName);
			KYCWICreateLog.KYCWICreateLogger.info("File not available at location..");
			System.out.println("file not available at location");
		}
		
		else if(!(tmpDir.length() == 0))
		{
			fileMoved = moveFile(ExcelPath+"\\"+excelFileName,inProgress+"\\"+excelFileName);
			KYCWICreateLog.KYCWICreateLogger.info("Before Calling Read Excel file");
			if(fileMoved)
			{
			KYCWICreateLog.KYCWICreateLogger.info("Before Calling Read excel file");
			readExcelFileStatus=readExcelFile(inProgress+"\\"+excelFileName);
			KYCWICreateLog.KYCWICreateLogger.info("After Calling Read excel file with readExcelFileStatus  --"+readExcelFileStatus);
			if(readExcelFileStatus){
			String response = insertInDB(inProgress+"\\"+excelFileName,cabinetName,sessionId,"Sheet1",table);
			if(response == "true"){
				if(errorCount==0){
					moveFile(inProgress+"\\"+excelFileName,success+"\\"+excelFileName);
				}
				else{
					moveFile(inProgress+"\\"+excelFileName,error+"\\"+excelFileName);
					KYCWICreateLog.KYCWICreateLogger.info("Error in inserting "+ errorCount +"row(s), so moved to error folder");
					sendEmail(errorRowNo,cabinetName,sessionID,jtsIP,jtsPort);
				}*/
				createIndividualWI(cabinetName,sessionID,jtsIP,jtsPort);
				createCorporateWI(cabinetName,sessionID,jtsIP,jtsPort);
				//createIndividualCorporateWI(cabinetName,sessionID,jtsIP,jtsPort);
			/*}
			}
			else
			{
				KYCWICreateLog.KYCWICreateLogger.info("error in readExcelFile Method");
				moveFile(inProgress+"\\"+excelFileName,error+"\\"+excelFileName);
			}
			}
			else if (!fileMoved)
			{
				KYCWICreateLog.KYCWICreateLogger.info("Error in moving file in Progress folder");
			}
		}*/
	}
	
	public static boolean moveFile(String sourcePath,String targetPath)
	{
		boolean fileMoved = true;
		try{
			Files.move(Paths.get(sourcePath), Paths.get(targetPath), StandardCopyOption.REPLACE_EXISTING);
		}
		catch(Exception e){
			KYCWICreateLog.KYCWICreateLogger.info("exception in moving file"+e.getMessage());
			fileMoved = false;
		}
		return fileMoved;
	}
	public static boolean readExcelFile(String file)
	{
		
		KYCWICreateLog.KYCWICreateLogger.info("Inside readExcelFile Method..");
		String ErrDesc = "";
		Boolean is_excelvalid = false;
		int res=ValidateExcelHeader(file.toString(), CommonConnection.getCabinetName(), CommonConnection.getSessionID(KYCWICreateLog.KYCWICreateLogger, false), "Sheet1");
		if(res==0)
		{
			is_excelvalid=true;
		}
		else if(res==1)
		{
			is_excelvalid=false;
			ErrDesc = "Excel is invalid. Please Correct the Header Column Name.";
			KYCWICreateLog.KYCWICreateLogger.debug("is_excelvalid: "+is_excelvalid);
		}
		else
		{
			is_excelvalid=false;
			ErrDesc = "Excel is invalid. Please Correct the Sheet Name.";
			KYCWICreateLog.KYCWICreateLogger.debug("is_excelvalid: "+is_excelvalid);
		}	
		return is_excelvalid;
	}
	
	public static int ValidateExcelHeader(String fileName,String cabinetName,String sessionId,String tag) {
		
		FileInputStream fis = null;
		try
		{
		String[] header_column = headers.split(",");
		for(int i=0;i<header_column.length;i++)
		{
			String[] value = header_column[i].split("@");
			headerColumnMap.put(value[0], value[1]);
		}
		
			KYCWICreateLog.KYCWICreateLogger.debug(tag+" excel tag : "+ tag);	
			DataFormatter formatter = new DataFormatter();
			fis = new FileInputStream(new File(fileName));
			if(FilenameUtils.getExtension(fileName).trim().equalsIgnoreCase("xls"))
			{
				HSSFWorkbook workBook = new HSSFWorkbook(fis);
				HSSFSheet sheet = workBook.getSheet(tag);
				int cellCount = sheet.getRow(0).getPhysicalNumberOfCells();
				System.out.println(tag+" Sheet index : "+ workBook.getSheetIndex(sheet));
				KYCWICreateLog.KYCWICreateLogger.debug(tag+" Sheet index : "+ workBook.getSheetIndex(sheet));
				if(workBook.getSheetIndex(sheet)==-1)
				{
				return 2;
				}
				int count = 0;
				for(int i=0;i<cellCount;i++)
				{
					
					Object value = formatter.formatCellValue(sheet.getRow(0).getCell(i));
					String cellValue = (String) value;
					boolean res = headerColumnMap.containsKey(cellValue);
					if(!res)
					{
						KYCWICreateLog.KYCWICreateLogger.debug("incorrect data in sheet");
						return 1;
					}
//					if(!(cellValue==header[i]))
//					{
//						count++;
//						KYCWICreateLog.KYCWICreateLogger.debug("Invalid header - '"+cellValue+"'.....Header should be - '"+header[i]+"'");
//						return 1;
//					}
				}
				KYCWICreateLog.KYCWICreateLogger.debug("valid header in excel");
				return 0;
			}
			else if (FilenameUtils.getExtension(fileName).trim().equalsIgnoreCase("XLSX"))
			{
				System.out.println("fileName--->"+fileName);
				XSSFWorkbook workBook = new XSSFWorkbook(fis);
				XSSFSheet sheet = workBook.getSheet(tag);
				int cellCount = sheet.getRow(0).getPhysicalNumberOfCells();
				System.out.println(tag+" Sheet index : "+ workBook.getSheetIndex(sheet));
				KYCWICreateLog.KYCWICreateLogger.debug(tag+" Sheet index : "+ workBook.getSheetIndex(sheet));
				if(workBook.getSheetIndex(sheet)==-1)
				{
					return 2;
				}
				int count = 0;;
				for(int i=0;i<cellCount;i++)
				{
					Object value = formatter.formatCellValue(sheet.getRow(0).getCell(i));
					String cellValue = (String) value;
					boolean res = headerColumnMap.containsKey(cellValue);
					
					if(!res)
					{
						KYCWICreateLog.KYCWICreateLogger.debug("incorrect data in sheet");
						return 1;
					}
//					if(!(cellValue==header[i]))
//					{
//						count++;
//						KYCWICreateLog.KYCWICreateLogger.debug("Invalid header - '"+cellValue+"'.....Header should be - '"+header[i]+"'");
//						return 1;
//					}
				}
			}
			return 0;
		}
		catch(IOException e)
		{
			KYCWICreateLog.KYCWICreateLogger.debug("exception in excel method "+e);
			e.printStackTrace();
		}
		finally
		{
			if(fis!=null)
			{
				try
				{
					fis.close();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
		}
		return 1;
	}

	
	/*public static String insertInDB(String fileName,String cabinetName,String sessionId,String tag,String table){
		FileInputStream fis = null;
		try{
		KYCWICreateLog.KYCWICreateLogger.debug(tag+" excel tag : "+ tag);	
		DataFormatter formatter = new DataFormatter();
		fis = new FileInputStream(new File(fileName));
		if(FilenameUtils.getExtension(fileName).trim().equalsIgnoreCase("xls"))
		{
			HSSFWorkbook workBook = new HSSFWorkbook(fis);
			HSSFSheet sheet = workBook.getSheet(tag);
			int rowCount = sheet.getPhysicalNumberOfRows();
			int cellCount = sheet.getRow(0).getPhysicalNumberOfCells();
			String columnValues = "";
			String WI_Status = "R";
			String[] cellValues = new String[cellCount];
			for(int i=1;i<rowCount;i++){
				for(int k=0;k<cellCount;k++){
					Object value = formatter.formatCellValue(sheet.getRow(i).getCell(k));
					cellValues[k] = (String) value; 
					if(k==0){
						columnValues="'"+cellValues[k] +"'";
					}
					else{
						columnValues = columnValues+",'"+cellValues[k]+"'";
					}
				}
				columnValues = columnValues+",getDate(),'"+WI_Status+"'";
				String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionId, columnNames, columnValues,"USR_0_KYC_ExcelDetails");
				KYCWICreateLog.KYCWICreateLogger.debug("apInsertInputXML: "+apInsertInputXML);
				String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
				KYCWICreateLog.KYCWICreateLogger.debug("apInsertOutputXML: "+apInsertOutputXML);
				XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
				String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
				if (apInsertMaincode.equalsIgnoreCase("0")) 
				{
					KYCWICreateLog.KYCWICreateLogger.debug("Row NO "+i+" is inserted successfully");
					//WRITE IN EXCEL
					//INSERT A FLAG IN EACH ROW TO IDENTIFY ROW IS PROCESSED OR NOT
					Row row = sheet.getRow(i);
					Cell flagCell = row.createCell(row.getLastCellNum());
					flagCell.setCellValue("Y");
					try(FileOutputStream fos = new FileOutputStream(fileName)){
						workBook.write(fos);
					}
				}
				else{
					errorCount++;
					errorRowNo = errorRowNo+i+",";
					KYCWICreateLog.KYCWICreateLogger.debug("Error in inserting row no "+i);
					Row row = sheet.getRow(i);
					Cell flagCell = row.createCell(row.getLastCellNum());
					flagCell.setCellValue("N");
					try(FileOutputStream fos = new FileOutputStream(fileName)){
						workBook.write(fos);	
				}
			  }
			}
			return "true";
		}
		else if(FilenameUtils.getExtension(fileName).trim().equalsIgnoreCase("XLSX")){
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workBook.getSheet(tag);
			int rowCount = sheet.getPhysicalNumberOfRows();
			int cellCount = sheet.getRow(0).getPhysicalNumberOfCells();
			String WI_Status = "R";
			String columnValues = "";
			
			String[] cellValues = new String[cellCount];
			for(int i=1;i<rowCount;i++){
				for(int k=0;k<cellCount;k++){
					Object value = formatter.formatCellValue(sheet.getRow(i).getCell(k));
					cellValues[k] = (String) value; 
					if(k==0){
						columnValues="'"+cellValues[k] +"'";
					}
					else{
						columnValues = columnValues+",'"+cellValues[k]+"'";
					}
				}
				columnValues = columnValues+",getDate(),'"+WI_Status+"'";
				String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionId, columnNames, columnValues,"USR_0_KYC_ExcelDetails");
				KYCWICreateLog.KYCWICreateLogger.debug("apInsertInputXML: "+apInsertInputXML);
				String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
				KYCWICreateLog.KYCWICreateLogger.debug("apInsertOutputXML: "+apInsertOutputXML);
				XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
				String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
				if (apInsertMaincode.equalsIgnoreCase("0")) 
				{
					KYCWICreateLog.KYCWICreateLogger.debug("Row NO "+i+" is inserted successfully");
					//WRITE IN EXCEL
					//INSERT A FLAG IN EACH ROW TO IDENTIFY ROW IS PROCESSED OR NOT
					Row row = sheet.getRow(i);
					Cell flagCell = row.createCell(row.getLastCellNum());
					flagCell.setCellValue("Y");
					try(FileOutputStream fos = new FileOutputStream(fileName)){
						workBook.write(fos);
					}
				}
				else{
					errorCount++;
					errorRowNo = errorRowNo+i+",";
					KYCWICreateLog.KYCWICreateLogger.debug("Error in inserting row no "+i);
					Row row = sheet.getRow(i);
					Cell flagCell = row.createCell(row.getLastCellNum());
					flagCell.setCellValue("N");
					try(FileOutputStream fos = new FileOutputStream(fileName)){
						workBook.write(fos);
					}
				}
			}
			return "true";
		}
		}catch(Exception e){
			KYCWICreateLog.KYCWICreateLogger.debug("exception in InsertIn DB Method");
			KYCWICreateLog.KYCWICreateLogger.debug("ERROR IN INSERTING DATA IN DB IN VENDOR TABLE"+e);
			return "false";
		}
		
		return "";
	}*/
	
	private static String sendEmail(String rowNo,String cabinetName, String sessionID,String jtsIP,String jtsPort)
	{
		try{
		
		int mailPriority= 1;
		String mailStatus = "N";
		String UserNAme = "rakbpm";
		String mailActionType = "TRIGGER";
		String mailContentType = "text/html;charset=UTF-8";
		//String wiName = processInstanceID;
		int workitemid = 1;
		int activityID = 3;
		int noOfTrials = 0;
		String mailFrom = "test11@rakbanktst.ae";
		String mailTo = "test5@rakbanktst.ae";
		String mailSubject = "Excel error";
		String emailBody = "There is an error in inserting the following rows - "+rowNo;
		String tableName = "WFMAILQUEUETABLE";
		String columnName = "mailFrom,mailTo,mailSubject,mailMessage,mailContentType,mailPriority,mailStatus,insertedBy,"
				+ "mailActionType,workitemId,activityId,noOfTrials";
		String values = "'"+mailFrom+"','"+mailTo+"','"+mailSubject+"',N'"+emailBody+"','"+mailContentType+"','"+mailPriority+"','"+mailStatus+"','"+UserNAme+"','"+mailActionType+"','"+workitemid+"','"+activityID+"','"+noOfTrials+"'";
		//String mailInsertQuery = "Insert into " +tableName+" "+columnName+" values "+values;
		
		String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnName, values,tableName);
		KYCWICreateLog.KYCWICreateLogger.debug("APInsertInputXML: "+apInsertInputXML);

		String apInsertOutputXML =CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
		KYCWICreateLog.KYCWICreateLogger.debug("APInsertOutputXML: "+ apInsertOutputXML);

		XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
		String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
		KYCWICreateLog.KYCWICreateLogger.debug("Status of apInsertMaincode  "+ apInsertMaincode);
		if(apInsertMaincode.equalsIgnoreCase("0"))
		{
			KYCWICreateLog.KYCWICreateLogger.debug("ApInsert successful: "+apInsertMaincode);
			KYCWICreateLog.KYCWICreateLogger.debug("Mail sent successfully.");
			return "true";
		}
		}catch(Exception e){
			KYCWICreateLog.KYCWICreateLogger.debug("Exception in sending mail----"+e);
		}
		return "false";
	}
	
	public static String createIndividualWI(String cabinetName, String sessionID, String jtsIP, String jtsPort) {
		try {
			String CUSTOMER_SUBSEGMENT_CODE = "";
			String IndustrySubsegment = "";
			String[] moneySentTo;
			String[] moneyReceivedFrom;
			String coumn_external =ODDocConfigParamMap.get("IndividualDBcolumn&extColumn");
			//KYCWICreateLog.KYCWICreateLogger.debug("coumn_external: "+coumn_external);
			
			String query = "select * from NG_KYC_REM_BO_IBPS_TABLE with (nolock) Where (COPR_CIF is null or COPR_CIF = '')" 
			+ " and (cif_id is not null or cif_id != '') and (Status = 'R' or Status is null or Status = '')";

			//String[] DBcolumn = columnNames.split(",");
			HashMap<String,String>  dbExtColumnMap= new HashMap<>();
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			
			//------High RAM Issue---------------------------//
			
			List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
			//Map<String, String> t = new HashMap<String, String>();
			try {
				temp.clear();
				KYCWICreateLog.KYCWICreateLogger.debug("Inside function getDataFromDB");
				KYCWICreateLog.KYCWICreateLogger.debug("getDataFromDB query is: " + query);
				String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
				OutXml = OutXml.replaceAll("&", "#andsymb#");
				Document recordDoc1 = MapXML.getDocument(OutXml);
				NodeList records1 = recordDoc1.getElementsByTagName("Record");
				if (records1.getLength() > 0) {
					for (int i = 0; i < records1.getLength(); i++) {
						Node n = records1.item(i);
						Map<String, String> t = new HashMap<String, String>();
						if (n.hasChildNodes()) {
							NodeList child = n.getChildNodes();
							for (int j = 0; j < child.getLength(); j++) {
								Node n1 = child.item(j);
								String column = n1.getNodeName();
								String value = n1.getTextContent().replaceAll("#andsymb#", "&");
								if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
									KYCWICreateLog.KYCWICreateLogger.debug("getDataFromDBMap Setting value of " + column + " as " + value);
									t.put(column, value);
								} else {
									KYCWICreateLog.KYCWICreateLogger.debug("getDataFromDBMap Setting value of " + column + " as blank");
									t.put(column, "");
								}
							}
						}
						temp.add(t);
					//	t.clear();
					}
				}
			} catch (Exception e) {
				KYCWICreateLog.KYCWICreateLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
			}
			
			for(Map<String,String> map : temp) {
				DataFromDB.add(new HashMap<>(map));
			}
			temp.clear();
			//t.clear();
			
			//------High RAM Issue---------------------------//
			
			//DataFromDB = getDataFromDBMap(query,cabinetName,sessionID,jtsIP, jtsPort);
			if(!DataFromDB.isEmpty()){
				String[] DbExtColumn = coumn_external.split(",");
				for(int i=0;i<DbExtColumn.length;i++) 
				{
					String[] value = DbExtColumn[i].split("@");
					if(value[1].equalsIgnoreCase("CountryOfIncorporation")){
						dbExtColumnMap.put("Country_Of_Incorporation",value[1]);
					}
					else if(value[1].equalsIgnoreCase("ResidentCountry")){
						dbExtColumnMap.put("Resident_Country",value[1]);
					}
					else
					{
					dbExtColumnMap.put(value[0],value[1]);
					}
				}
				Set<String> keys = dbExtColumnMap.keySet();
				for(Map<String,String> entry : DataFromDB){
					String attributesTag = "";
					String keyValue = "";
					for(String key : keys) {
						if(key.equalsIgnoreCase("Country_Of_Incorporation"))
						{
							keyValue = entry.get("RESIDENCE_CNTRY_CODE");
							System.out.println(keyValue);
						}
						else if(key.equalsIgnoreCase("Resident_Country"))
						{
							keyValue = entry.get("RESIDENCE_CNTRY_CODE");
							System.out.println(keyValue);
						}
						else
						{
						    keyValue = entry.get(key);
						    System.out.println(keyValue);
						}
						String ExtColToKey = dbExtColumnMap.get(key);
						attributesTag = attributesTag+"<"+ExtColToKey+">"+replaceXChars(keyValue)+"</"+ExtColToKey+">";
						if("CUSTOMER_SUBSEGMENT_CODE".equalsIgnoreCase(key)){
							CUSTOMER_SUBSEGMENT_CODE = keyValue;
						}
						if("INDUSTRY_SUB_SEGMENT_CODE_DESC".equalsIgnoreCase(key)){
							IndustrySubsegment = keyValue;
						}
						if("MONEY_SENT_TO".equalsIgnoreCase(key)){
							if(!"".equalsIgnoreCase(key))
							{
								moneySentTo = keyValue.split(",");
								for(String country : moneySentTo)
								{
									attributesTag = attributesTag + "<Q_NG_KYC_REM_MoneySentTo_GRID><Country>"+replaceXChars(country)+"</Country></Q_NG_KYC_REM_MoneySentTo_GRID>";
								}
							}
						}
						if("MONEY_RECEIVED_FROM".equalsIgnoreCase(key))
						{
							if(!"".equalsIgnoreCase(key))
							{
							moneyReceivedFrom = keyValue.split(",");
							for(String country : moneyReceivedFrom)
							{
								attributesTag = attributesTag + "<Q_NG_KYC_REM_MoneyRecFrom_GRID><Country>"+replaceXChars(country)+"</Country></Q_NG_KYC_REM_MoneyRecFrom_GRID>";
							}
						}
						}
					}
					/*if("".equalsIgnoreCase(IndustrySubsegment))
					{
						attributesTag = attributesTag+"<CaseType>Individual</CaseType><CusType>Individual</CusType>";
					}
					else
					{
						attributesTag = attributesTag+"<CaseType>Individual</CaseType><CusType>Individual</CusType>";
						String Query = "SELECT SubSegment FROM NG_KYC_REM_Industry_SubSegment_MASTER with (nolock) Where Finacle_Code = '"+IndustrySubsegment+"'";
						//String Query2 ="SELECT VENDOR_NAME, DATA_CLASS_NAME, iBPS_DATA_DEF_ID, iBPS_FIELD_INDEX_ID, SEARCH_VALUE, SEARCH_TYPE, OF_DATA_DEF_ID, OF_FIELD_INDEX_ID,iBPS_STATUS,OFSTATUS FROM USR_0_ODDD_DATACLASS_SEARCH_DTLS with(nolock) WHERE WINAME ='"+processInstanceID+"' AND ID ='"+nextRowSequence+"' AND (iBPS_STATUS in ('N','I')  OR OFSTATUS  in ('N','I'))";
					    String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
					    KYCWICreateLog.KYCWICreateLogger.debug("InputXML :"+InputXML);
						String OutputXML = CommonMethods.WFNGExecute(InputXML,  jtsIP, jtsPort, 1);
						KYCWICreateLog.KYCWICreateLogger.debug("OutputXML :"+OutputXML);
						XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
						String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
						int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
						KYCWICreateLog.KYCWICreateLogger.debug("apSelectMaincode :"+apSelectMaincode);
						KYCWICreateLog.KYCWICreateLogger.debug("Total No. of records fetched :"+TotalRecords);
						if(apSelectMaincode.equals("0") && TotalRecords>0)
						{
							NGXmlList objWorkList = xmlParserAPSelect.createList("Records", "Record");
							for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
							{ 
								String Subsegment = objWorkList.getVal("SubSegment");
								attributesTag = attributesTag+"<Q_NG_KYC_REM_IND_SubSegment_Grid><SubSegment>"+replaceXChars(Subsegment)+"</SubSegment></Q_NG_KYC_REM_IND_SubSegment_Grid>";

							}
						}
						//attributesTag = attributesTag+"<CaseType>Individual</CaseType><CusType>Individual</CusType><Q_NG_KYC_REM_IND_SubSegment_Grid><SubSegment>"+replaceXChars(IndustrySubsegment)+"</SubSegment></Q_NG_KYC_REM_IND_SubSegment_Grid>";
						
					}*/
					attributesTag = attributesTag+"<CaseType>Individual</CaseType><CusType>Individual</CusType>";
					if("SME".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE) || "PSL".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE)){
						attributesTag = attributesTag+"<qSubSegment>BBG</qSubSegment>";
					}
					else if("CBD".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE)){
						attributesTag = attributesTag+"<qSubSegment>WBG</qSubSegment>";
					}
					else{
						attributesTag = attributesTag+"<qSubSegment>PBG</qSubSegment>";
					}
					String WFuploadInputXML=getWFUploadWorkItemXML(cabinetName,sessionID,processDefID,attributesTag,queueID);
					//WFuploadInputXML = replaceXChars(WFuploadInputXML);
					KYCWICreateLog.KYCWICreateLogger.debug("WFuploadInputXML: "+WFuploadInputXML);
					
					String WFuploadOutputXML =CommonMethods.WFNGExecute(WFuploadInputXML, jtsIP, jtsPort, 1);
					KYCWICreateLog.KYCWICreateLogger.debug("WFuploadOutputXML: "+ WFuploadOutputXML);
	
					XMLParser xmlParserWFupload = new XMLParser(WFuploadOutputXML);
					String Maincode = xmlParserWFupload.getValueOf("MainCode");
					KYCWICreateLog.KYCWICreateLogger.debug("Status of Maincode  "+ Maincode);
					String ProcessInstanceId="";
					ProcessInstanceId=xmlParserWFupload.getValueOf("ProcessInstanceId");
					String UserName=xmlParserWFupload.getValueOf("UserName");
					String MsgFormat=xmlParserWFupload.getValueOf("Option");
					String CreationDateTime=xmlParserWFupload.getValueOf("CreationDateTime");
					insertReqRespINDatabase(WFuploadInputXML,WFuploadOutputXML,MsgFormat,ProcessInstanceId,UserName,CreationDateTime);
					if(Maincode.equalsIgnoreCase("0"))
					{
						KYCWICreateLog.KYCWICreateLogger.debug("WFupload successful: "+Maincode);
						KYCWICreateLog.KYCWICreateLogger.debug("WI Created successfully.");
						
						//going to update status to completed in DB excel table
						String sNO = entry.get("insertionOrderID");
						String columnToUpdate = "Wi_Name,Status";
						String whereClause = "insertionOrderID = "+sNO;
						String values = "'"+ProcessInstanceId+"','C'";
						
						String apUpdateInput=CommonMethods.apUpdateInput(cabinetName,sessionID,table,columnToUpdate,values,whereClause);
						KYCWICreateLog.KYCWICreateLogger.debug("apUpdateInput: "+apUpdateInput);
	
						String apUpdateOutputXML =CommonMethods.WFNGExecute(apUpdateInput, jtsIP, jtsPort, 1);
						KYCWICreateLog.KYCWICreateLogger.debug("apUpdateOutputXML: "+ apUpdateOutputXML);
	
						XMLParser xmlParserapUpdate = new XMLParser(apUpdateOutputXML);
						String MaincodeAPudate = xmlParserapUpdate.getValueOf("MainCode");
						if(MaincodeAPudate.equalsIgnoreCase("0"))
						{
							KYCWICreateLog.KYCWICreateLogger.debug("AP Update successful for row no "+sNO);
							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String strDate = dateFormat.format(d);
							
							String tableName = "NG_KYC_REM_GR_HISTORY";
							String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
							String columnValues = "'"+strDate+"','Introduction','Success','rakBPMutility','Workitem created successfully','"+ProcessInstanceId+"','"+CreationDateTime+"'";
							
							String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnName,columnValues,tableName);
							KYCWICreateLog.KYCWICreateLogger.debug("APInsertInputXML: "+apInsertInputXML);
	
							String apInsertOutputXML =CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
							KYCWICreateLog.KYCWICreateLogger.debug("APInsertOutputXML: "+ apInsertOutputXML);
	
							XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
							String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
							KYCWICreateLog.KYCWICreateLogger.debug("Status of apInsertMaincode  "+ apInsertMaincode);
							if(apInsertMaincode.equalsIgnoreCase("0"))
							{
								KYCWICreateLog.KYCWICreateLogger.debug("ApInsert successful: "+apInsertMaincode);
								KYCWICreateLog.KYCWICreateLogger.debug("Data Inserted in history table successfully.");
							}
						}	
					}
				}
			}
			dbExtColumnMap.clear();
			DataFromDB.clear();
			return "true";
		} catch (Exception e) {
			KYCWICreateLog.KYCWICreateLogger.debug("exception: " + e);
			return "false";
		}
	}
	public static String createCorporateWI(String cabinetName, String sessionID, String jtsIP, String jtsPort) {
		try {
			
			String column_external =ODDocConfigParamMap.get("CorporateDBcolumn&extColumn");
			//KYCWICreateLog.KYCWICreateLogger.debug("coumn_external: "+coumn_external);
			
			HashMap<String,String>  CordbExtColumnMap= new HashMap<>();
			
			String query = "select * from NG_KYC_REM_BO_IBPS_TABLE with (nolock) Where (cif_id is null or cif_id = '')"
					+ " and (COPR_CIF is not null or COPR_CIF != '') and (Status = 'R' or Status is null or Status = '')";

//			String[] DBcolumn = columnNames.split(",");
			String COPR_CIF = "";
			String CUSTOMER_SUBSEGMENT_CODE = "";
			String IndustrySubsegment = "";
			List<Map<String, String>> CorDataFromDB = new ArrayList<Map<String, String>>();
			
			//------High RAM Issue---------------------------//
			
			List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
			//Map<String, String> t = new HashMap<String, String>();
			try {
				KYCWICreateLog.KYCWICreateLogger.debug("Inside function getDataFromDB");
				KYCWICreateLog.KYCWICreateLogger.debug("getDataFromDB query is: " + query);
				String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
				OutXml = OutXml.replaceAll("&", "#andsymb#");
				Document recordDoc1 = MapXML.getDocument(OutXml);
				NodeList records1 = recordDoc1.getElementsByTagName("Record");
				if (records1.getLength() > 0) {
					for (int i = 0; i < records1.getLength(); i++) {
						Node n = records1.item(i);
						Map<String, String> t = new HashMap<String, String>();
						if (n.hasChildNodes()) {
							NodeList child = n.getChildNodes();
							for (int j = 0; j < child.getLength(); j++) {
								Node n1 = child.item(j);
								String column = n1.getNodeName();
								String value = n1.getTextContent().replaceAll("#andsymb#", "&");
								if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
									KYCWICreateLog.KYCWICreateLogger
											.debug("getDataFromDBMap Setting value of " + column + " as " + value);
									t.put(column, value);
								} else {
									KYCWICreateLog.KYCWICreateLogger
											.debug("getDataFromDBMap Setting value of " + column + " as blank");
									t.put(column, "");
								}
							}
						}
						temp.add(t);
					}
				}

			} catch (Exception e) {
				KYCWICreateLog.KYCWICreateLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
			}
			for(Map<String,String> map :temp)
			{
				CorDataFromDB.add(new HashMap<>(map));
			}
			temp.clear();
			//t.clear();
			//------High RAM Issue---------------------------//
			
			//CorDataFromDB = getDataFromDBMap(query,cabinetName,sessionID,jtsIP, jtsPort);
			if(!CorDataFromDB.isEmpty()){
				String[] CorDbExtColumn = column_external.split(",");
				for(int i=0;i<CorDbExtColumn.length;i++)
				{
					String[] value = CorDbExtColumn[i].split("@");
					CordbExtColumnMap.put(value[0],value[1]);
				}
				Set<String> keys = CordbExtColumnMap.keySet();
				for(Map<String,String> entry : CorDataFromDB){
					String attributesTag = "";
					for(String key : keys){
						String keyValue = entry.get(key);
						System.out.println(keyValue);
						String ExtColToKey = CordbExtColumnMap.get(key);
						attributesTag = attributesTag+"<"+ExtColToKey+">"+replaceXChars(keyValue)+"</"+ExtColToKey+">";
						if("COPR_CIF".equalsIgnoreCase(key)){
							COPR_CIF = keyValue;
						}
						if("CUSTOMER_SUBSEGMENT_CODE".equalsIgnoreCase(key)){
							CUSTOMER_SUBSEGMENT_CODE = keyValue;
						}
						if("INDUSTRY_SUB_SEGMENT_CODE_DESC".equalsIgnoreCase(key)){
							IndustrySubsegment = keyValue;
						}
					}
					/*if("".equalsIgnoreCase(IndustrySubsegment))
					{
						attributesTag = attributesTag+"<CaseType>Corporate</CaseType>";
					}
					else
					{
						attributesTag = attributesTag+"<CaseType>Corporate</CaseType>";
						String Query = "SELECT SubSegment,RiskScore FROM NG_KYC_REM_Industry_SubSegment_MASTER with (nolock) Where Finacle_Code = '"+IndustrySubsegment+"'";
						//String Query2 ="SELECT VENDOR_NAME, DATA_CLASS_NAME, iBPS_DATA_DEF_ID, iBPS_FIELD_INDEX_ID, SEARCH_VALUE, SEARCH_TYPE, OF_DATA_DEF_ID, OF_FIELD_INDEX_ID,iBPS_STATUS,OFSTATUS FROM USR_0_ODDD_DATACLASS_SEARCH_DTLS with(nolock) WHERE WINAME ='"+processInstanceID+"' AND ID ='"+nextRowSequence+"' AND (iBPS_STATUS in ('N','I')  OR OFSTATUS  in ('N','I'))";
					    String InputXML = CommonMethods.apSelectWithColumnNames(Query, cabinetName, sessionID);
					    KYCWICreateLog.KYCWICreateLogger.debug("InputXML :"+InputXML);
						String OutputXML = CommonMethods.WFNGExecute(InputXML,  jtsIP, jtsPort, 1);
						KYCWICreateLog.KYCWICreateLogger.debug("OutputXML :"+OutputXML);
						XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
						String apSelectMaincode = xmlParserAPSelect.getValueOf("MainCode");
						int TotalRecords = Integer.parseInt(xmlParserAPSelect.getValueOf("TotalRetrieved"));
						KYCWICreateLog.KYCWICreateLogger.debug("apSelectMaincode :"+apSelectMaincode);
						KYCWICreateLog.KYCWICreateLogger.debug("Total No. of records fetched :"+TotalRecords);
						if(apSelectMaincode.equals("0") && TotalRecords>0)
						{
							//attributesTag = attributesTag+"<CaseType>Corporate</CaseType>";
							NGXmlList objWorkList = xmlParserAPSelect.createList("Records", "Record");
							for (; objWorkList.hasMoreElements(true); objWorkList.skip(true)) 
							{ 
								String Subsegment = objWorkList.getVal("SubSegment");
								String RiskScore = objWorkList.getVal("RiskScore");
								attributesTag = attributesTag+"<Q_NG_KYC_REM_LBA_GRID><LicensedBusinessActivity>"+replaceXChars(Subsegment)+"</LicensedBusinessActivity><RiskScore>"+RiskScore+"</RiskScore></Q_NG_KYC_REM_LBA_GRID>";
							}
							//attributesTag = attributesTag+"<Q_NG_KYC_REM_LBA_GRID><LicensedBusinessActivity>"+replaceXChars(IndustrySubsegment)+"</LicensedBusinessActivity><RiskScore>"+RiskScore+"</RiskScore></Q_NG_KYC_REM_LBA_GRID>";
						}
						String tagData = "Select RiskScore FROM NG_KYC_REM_Industry_SubSegment_MASTER with(nolock) where SubSegment = '"+IndustrySubsegment+"'";
						String dataInputXML = CommonMethods.apSelectWithColumnNames(tagData, cabinetName, sessionID);
						String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
						XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
						String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
						int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
						if (dataMainCode.equals("0") && dataTotalRecords > 0)
						{
							String RiskRating = dataxmlParserAPSelect.getValueOf("RiskScore");
							KYCWICreateLog.KYCWICreateLogger.debug("RiskRating found for : "+IndustrySubsegment+" Rating is-->"+RiskRating);
							attributesTag = attributesTag+"<CaseType>Corporate</CaseType><Q_NG_KYC_REM_LBA_GRID><LicensedBusinessActivity>"+replaceXChars(IndustrySubsegment)+"</LicensedBusinessActivity><RiskScore>"+RiskRating+"</RiskScore></Q_NG_KYC_REM_LBA_GRID>";
						}
						else
						{
							KYCWICreateLog.KYCWICreateLogger.debug("RiskRating not found for : "+IndustrySubsegment);
							attributesTag = attributesTag+"<CaseType>Corporate</CaseType><Q_NG_KYC_REM_LBA_GRID><LicensedBusinessActivity>"+replaceXChars(IndustrySubsegment)+"</LicensedBusinessActivity></Q_NG_KYC_REM_LBA_GRID>";
						}
					}*/
					attributesTag = attributesTag+"<CaseType>Corporate</CaseType>";
					if("SME".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE) || "PSL".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE)){
						attributesTag = attributesTag+"<qSubSegment>BBG</qSubSegment>";
					}
					else if("CBD".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE)){
						attributesTag = attributesTag+"<qSubSegment>WBG</qSubSegment>";
					}
					else{
						attributesTag = attributesTag+"<qSubSegment>PBG</qSubSegment>";
					}
					//String WFuploadInputXML=getWFUploadWorkItemXML(cabinetName,sessionID,processDefID,attributesTag,queueID);
					String WFuploadInputXML =  "<?xml version=\"1.0\"?>"+
							"<WFUploadWorkItem_Input>"+
							"<Option>WFUploadWorkItem</Option>"+
							"<EngineName>"+cabinetName+"</EngineName>"+
							"<SessionId>"+sessionID+"</SessionId>"+
							"<ProcessDefId>"+processDefID+"</ProcessDefId>"+
							"<QueueId>"+queueID+"</QueueId>"+
							"<DataDefName></DataDefName>"+
							"<Fields></Fields>"+
							"<InitiateAlso>N</InitiateAlso>"+
							"<Documents></Documents>"+
							"<Attributes>"+attributesTag+"</Attributes>"+
							"<UserDefVarFlag>Y</UserDefVarFlag>"+
							"</WFUploadWorkItem_Input>";
					//WFuploadInputXML = replaceXChars(WFuploadInputXML);
					KYCWICreateLog.KYCWICreateLogger.debug("WFuploadInputXML: "+WFuploadInputXML);
	
					String WFuploadOutputXML =CommonMethods.WFNGExecute(WFuploadInputXML, jtsIP, jtsPort, 1);
					KYCWICreateLog.KYCWICreateLogger.debug("WFuploadOutputXML: "+ WFuploadOutputXML);
	
					XMLParser xmlParserWFupload = new XMLParser(WFuploadOutputXML);
					String Maincode = xmlParserWFupload.getValueOf("MainCode");
					KYCWICreateLog.KYCWICreateLogger.debug("Status of Maincode  "+ Maincode);
					String ProcessInstanceId="";
					ProcessInstanceId=xmlParserWFupload.getValueOf("ProcessInstanceId");
					String UserName=xmlParserWFupload.getValueOf("UserName");
					String MsgFormat=xmlParserWFupload.getValueOf("Option");
					String CreationDateTime=xmlParserWFupload.getValueOf("CreationDateTime");
					insertReqRespINDatabase(WFuploadInputXML,WFuploadOutputXML,MsgFormat,ProcessInstanceId,UserName,CreationDateTime);
					if(Maincode.equalsIgnoreCase("0"))
					{
						KYCWICreateLog.KYCWICreateLogger.debug("WFupload successful: "+Maincode);
						KYCWICreateLog.KYCWICreateLogger.debug("WI Created successfully.");
						
						//going to update status to completed in DB excel table
						String sNO = entry.get("insertionOrderID");
						String columnToUpdate = "Wi_Name,Status";
						String whereClause = "insertionOrderID = "+sNO;
						String values = "'"+ProcessInstanceId+"','C'";
						
						String apUpdateInput=CommonMethods.apUpdateInput(cabinetName,sessionID,table,columnToUpdate,values,whereClause);
						KYCWICreateLog.KYCWICreateLogger.debug("apUpdateInput: "+apUpdateInput);
	
						String apUpdateOutputXML =CommonMethods.WFNGExecute(apUpdateInput, jtsIP, jtsPort, 1);
						KYCWICreateLog.KYCWICreateLogger.debug("apUpdateOutputXML: "+ apUpdateOutputXML);
	
						XMLParser xmlParserapUpdate = new XMLParser(apUpdateOutputXML);
						String MaincodeAPudate = xmlParserapUpdate.getValueOf("MainCode");
						if(MaincodeAPudate.equalsIgnoreCase("0"))
						{
							KYCWICreateLog.KYCWICreateLogger.debug("AP Update successful for row no "+sNO);
							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String strDate = dateFormat.format(d);
							
							String tableName = "NG_KYC_REM_GR_HISTORY";
							String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
							String columnValues = "'"+strDate+"','Introduction','Success','rakBPMutility','Workitem created successfully','"+ProcessInstanceId+"','"+CreationDateTime+"'";
							
							String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnName,columnValues,tableName);
							KYCWICreateLog.KYCWICreateLogger.debug("APInsertInputXML: "+apInsertInputXML);
	
							String apInsertOutputXML =CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
							KYCWICreateLog.KYCWICreateLogger.debug("APInsertOutputXML: "+ apInsertOutputXML);
	
							XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
							String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
							KYCWICreateLog.KYCWICreateLogger.debug("Status of apInsertMaincode  "+ apInsertMaincode);
							if(apInsertMaincode.equalsIgnoreCase("0"))
							{
								KYCWICreateLog.KYCWICreateLogger.debug("ApInsert successful: "+apInsertMaincode);
								KYCWICreateLog.KYCWICreateLogger.debug("Data Inserted in history table successfully.");
								String RP_WI_Status = createIndividualCorporateWI(cabinetName,sessionID,jtsIP,jtsPort,COPR_CIF);
								
								String tagData = "select Workitemid from WFINSTRUMENTTABLE where ProcessInstanceID = '"+ProcessInstanceId+"'";
								String dataInputXML = CommonMethods.apSelectWithColumnNames(tagData, cabinetName, sessionID);
								String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
								XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
								String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
								int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
								if (dataMainCode.equals("0") && dataTotalRecords > 0) {
									String WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
									
									String getWorkItemInputXML1 = CommonMethods.getWorkItemInput(cabinetName, sessionID, ProcessInstanceId,WorkItemID);
									KYCWICreateLog.KYCWICreateLogger.debug("input XML For WmgetWorkItemCall: "+ getWorkItemInputXML1);
									String getWorkItemOutputXml1 = CommonMethods.WFNGExecute(getWorkItemInputXML1,jtsIP, jtsPort,1);
									KYCWICreateLog.KYCWICreateLogger.debug("Output XML For WmgetWorkItemCall: "+ getWorkItemOutputXml1);
									
									XMLParser xmlParserGetWorkItem1 = new XMLParser(getWorkItemOutputXml1);
									String getWorkItemMainCode1 = xmlParserGetWorkItem1.getValueOf("MainCode");
									KYCWICreateLog.KYCWICreateLogger.debug("WmgetWorkItemCall Maincode:  "+ getWorkItemMainCode1);
									if("0".equalsIgnoreCase(getWorkItemMainCode1)){
								
								String WMCompleteWI = CommonMethods.completeWorkItemInput(cabinetName,sessionID,ProcessInstanceId,WorkItemID);
								KYCWICreateLog.KYCWICreateLogger.debug("WMCompleteWI input XML: "+WMCompleteWI);
								String WMCompleteOutputXML =CommonMethods.WFNGExecute(WMCompleteWI, jtsIP, jtsPort, 1);
								KYCWICreateLog.KYCWICreateLogger.debug("WMCompleteOutputXML: "+ WMCompleteOutputXML);
								XMLParser xmlParserWMComplete = new XMLParser(WMCompleteOutputXML);
								String WMCompleteMaincode = xmlParserWMComplete.getValueOf("MainCode");
								KYCWICreateLog.KYCWICreateLogger.debug("Status of WMCompleteMaincode  "+ WMCompleteMaincode);
									}
								}
							}
						}	
					}
				}
			}
			CordbExtColumnMap.clear();
			CorDataFromDB.clear();
			return "true";
		} catch (Exception e) {
			KYCWICreateLog.KYCWICreateLogger.debug("exception: " + e);
			return "false";
		}
	}
	
	public static String createIndividualCorporateWI(String cabinetName, String sessionID, String jtsIP, String jtsPort,String CORP_CIF) {
		try {
			
			String coumn_external =ODDocConfigParamMap.get("RPDBcolumn&extColumn");
			//KYCWICreateLog.KYCWICreateLogger.debug("coumn_external: "+coumn_external);
			
			String query = "select * from NG_KYC_REM_BO_IBPS_TABLE with (nolock) Where (cif_id is not null or cif_id != '')"
					+ " and (COPR_CIF = "+CORP_CIF+") and (Status = 'R' or Status is null or Status = '')";

//			String[] DBcolumn = columnNames.split(",");
			String RP_CIF_ID = "";
			String RP_Name = "";
			String RP_Type = "";
			String CUSTOMER_SUBSEGMENT_CODE = "";
			HashMap<String,String>  dbExtColumnMap= new HashMap<>();
			List<Map<String, String>> DataFromDB = new ArrayList<Map<String, String>>();
			
			//------High RAM Issue---------------------------//
			
			List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
			//Map<String, String> t = new HashMap<String, String>();
			try {
				KYCWICreateLog.KYCWICreateLogger.debug("Inside function getDataFromDB");
				KYCWICreateLog.KYCWICreateLogger.debug("getDataFromDB query is: " + query);
				String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
				OutXml = OutXml.replaceAll("&", "#andsymb#");
				Document recordDoc1 = MapXML.getDocument(OutXml);
				NodeList records1 = recordDoc1.getElementsByTagName("Record");
				if (records1.getLength() > 0) {
					for (int i = 0; i < records1.getLength(); i++) {
						Node n = records1.item(i);
						Map<String, String> t = new HashMap<String, String>();
						if (n.hasChildNodes()) {
							NodeList child = n.getChildNodes();
							for (int j = 0; j < child.getLength(); j++) {
								Node n1 = child.item(j);
								String column = n1.getNodeName();
								String value = n1.getTextContent().replaceAll("#andsymb#", "&");
								if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
									KYCWICreateLog.KYCWICreateLogger
											.debug("getDataFromDBMap Setting value of " + column + " as " + value);
									t.put(column, value);
								} else {
									KYCWICreateLog.KYCWICreateLogger
											.debug("getDataFromDBMap Setting value of " + column + " as blank");
									t.put(column, "");
								}
							}
						}
						temp.add(t);
					}
				}

			} catch (Exception e) {
				KYCWICreateLog.KYCWICreateLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
			}
			for(Map<String,String> map :temp)
			{
				DataFromDB.add(new HashMap<>(map));
			}
			temp.clear();
			//t.clear();
			//------High RAM Issue---------------------------//
			
			//DataFromDB = getDataFromDBMap(query,cabinetName,sessionID,jtsIP, jtsPort);
			if(!DataFromDB.isEmpty()){
				String[] DbExtColumn = coumn_external.split(",");
				for(int i=0;i<DbExtColumn.length;i++)
				{
					String[] value = DbExtColumn[i].split("@");
					dbExtColumnMap.put(value[0],value[1]);
				}
				Set<String> keys = dbExtColumnMap.keySet();
				for(Map<String,String> entry : DataFromDB){
					String attributesTag = "";
					for(String key : keys){
						String keyValue = entry.get(key);
						System.out.println(keyValue);
						String ExtColToKey = dbExtColumnMap.get(key);
						attributesTag = attributesTag+"<"+ExtColToKey+">"+replaceXChars(keyValue)+"</"+ExtColToKey+">";
						if("CIF_ID".equalsIgnoreCase(key)){
							RP_CIF_ID = keyValue;
						}
						if("RP_NAMES".equalsIgnoreCase(key)){
							RP_Name = keyValue;
						}
						if("RP_DETAILS".equalsIgnoreCase(key)){
							RP_Type = keyValue;
						}
						if("CUSTOMER_SUBSEGMENT_CODE".equalsIgnoreCase(key)){
							CUSTOMER_SUBSEGMENT_CODE = keyValue;
						}
						
					}
					attributesTag = attributesTag+"<CaseType>RelatedParty</CaseType>";
					
					if("SME".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE) || "PSL".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE))
					{
						attributesTag = attributesTag+"<qSubSegment>BBG</qSubSegment>";
					}
					else if("CBD".equalsIgnoreCase(CUSTOMER_SUBSEGMENT_CODE))
					{
						attributesTag = attributesTag+"<qSubSegment>WBG</qSubSegment>";
					}
					else
					{
						attributesTag = attributesTag+"<qSubSegment>PBG</qSubSegment>";
					}
					
					String WFuploadInputXML=getWFUploadWorkItemXML(cabinetName,sessionID,processDefID,attributesTag,queueID);
					//WFuploadInputXML = replaceXChars(WFuploadInputXML);
					KYCWICreateLog.KYCWICreateLogger.debug("WFuploadInputXML: "+WFuploadInputXML);
	
					String WFuploadOutputXML =CommonMethods.WFNGExecute(WFuploadInputXML, jtsIP, jtsPort, 1);
					KYCWICreateLog.KYCWICreateLogger.debug("WFuploadOutputXML: "+ WFuploadOutputXML);
	
					XMLParser xmlParserWFupload = new XMLParser(WFuploadOutputXML);
					String Maincode = xmlParserWFupload.getValueOf("MainCode");
					KYCWICreateLog.KYCWICreateLogger.debug("Status of Maincode  "+ Maincode);
					String ProcessInstanceId="";
					ProcessInstanceId=xmlParserWFupload.getValueOf("ProcessInstanceId");
					String UserName=xmlParserWFupload.getValueOf("UserName");
					String MsgFormat=xmlParserWFupload.getValueOf("Option");
					String CreationDateTime=xmlParserWFupload.getValueOf("CreationDateTime");
					insertReqRespINDatabase(WFuploadInputXML,WFuploadOutputXML,MsgFormat,ProcessInstanceId,UserName,CreationDateTime);
					if(Maincode.equalsIgnoreCase("0"))
					{
						KYCWICreateLog.KYCWICreateLogger.debug("WFupload successful: "+Maincode);
						KYCWICreateLog.KYCWICreateLogger.debug("WI Created successfully.");
						String sNO = entry.get("insertionOrderID");
						String columnToUpdate = "Wi_Name,Status";
						String whereClause = "insertionOrderID = "+sNO;
						String values = "'"+ProcessInstanceId+"','C'";
						
						String apUpdateInput=CommonMethods.apUpdateInput(cabinetName,sessionID,table,columnToUpdate,values,whereClause);
						KYCWICreateLog.KYCWICreateLogger.debug("apUpdateInput: "+apUpdateInput);
	
						String apUpdateOutputXML =CommonMethods.WFNGExecute(apUpdateInput, jtsIP, jtsPort, 1);
						KYCWICreateLog.KYCWICreateLogger.debug("apUpdateOutputXML: "+ apUpdateOutputXML);
	
						XMLParser xmlParserapUpdate = new XMLParser(apUpdateOutputXML);
						String MaincodeAPudate = xmlParserapUpdate.getValueOf("MainCode");
						if(MaincodeAPudate.equalsIgnoreCase("0"))
						{
							KYCWICreateLog.KYCWICreateLogger.debug("AP Update successful for row no "+sNO);
							Date d = new Date();
							SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String strDate = dateFormat.format(d);
							
							String tableName = "NG_KYC_REM_GR_HISTORY";
							String columnName = "DateTime,Workstep,Decision,UserName,Remarks,WI_Name,Entry_Date_Time";
							String columnValues = "'"+strDate+"','Introduction','Success','rakBPMutility','Workitem created successfully','"+ProcessInstanceId+"','"+CreationDateTime+"'";
							
							String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnName,columnValues,tableName);
							KYCWICreateLog.KYCWICreateLogger.debug("APInsertInputXML: "+apInsertInputXML);
	
							String apInsertOutputXML =CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
							KYCWICreateLog.KYCWICreateLogger.debug("APInsertOutputXML: "+ apInsertOutputXML);
	
							XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
							String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
							KYCWICreateLog.KYCWICreateLogger.debug("Status of apInsertMaincode  "+ apInsertMaincode);
							if(apInsertMaincode.equalsIgnoreCase("0"))
							{
								KYCWICreateLog.KYCWICreateLogger.debug("ApInsert successful: "+apInsertMaincode);
								KYCWICreateLog.KYCWICreateLogger.debug("Data Inserted in history table successfully.");
								
								String QueryCaseType = "SELECT CompanyCIF FROM RB_KYC_REM_EXTTABLE with (nolock) where WINAME = '"
										+ ProcessInstanceId + "'";
								String CompanyCIF = "";
								String QueryCaseTypeInputXML = CommonMethods.apSelectWithColumnNames(QueryCaseType, cabinetName, sessionID);
								String QueryCaseTypeOutputXML = CommonMethods.WFNGExecute(QueryCaseTypeInputXML, jtsIP, jtsPort, 1);
								XMLParser QueryCaseTypexmlParserAPSelect = new XMLParser(QueryCaseTypeOutputXML);
								String QueryCaseTypeapSelectMaincode = QueryCaseTypexmlParserAPSelect.getValueOf("MainCode");
								int TotalRecords = Integer.parseInt(QueryCaseTypexmlParserAPSelect.getValueOf("TotalRetrieved"));
								if (QueryCaseTypeapSelectMaincode.equals("0") && TotalRecords > 0) {
									CompanyCIF = QueryCaseTypexmlParserAPSelect.getValueOf("CompanyCIF");
									if(!("".equalsIgnoreCase(CompanyCIF))){
										String WINameQuery = "SELECT TOP 1 WINAME FROM RB_KYC_REM_EXTTABLE with (nolock) where CIF_ID = '"
												+ CompanyCIF + "' order by WI_CREATE_DATETIME desc";
										String WINAME = "";
										String WINAMEInputXML = CommonMethods.apSelectWithColumnNames(WINameQuery, cabinetName, sessionID);
										String OutputXML = CommonMethods.WFNGExecute(WINAMEInputXML, jtsIP, jtsPort, 1);
										XMLParser xmlParserAPSelect = new XMLParser(OutputXML);
										String WINameMaincode = xmlParserAPSelect.getValueOf("MainCode");
										int WINameTotalRecords = Integer.parseInt(QueryCaseTypexmlParserAPSelect.getValueOf("TotalRetrieved"));
										if (WINameMaincode.equals("0") && WINameTotalRecords > 0) {
											String WorkItemID = "";
											String ActivityID = "";
											String ProcessDefID = "";
											WINAME = xmlParserAPSelect.getValueOf("WINAME");
											String tagData = "select Workitemid,ActivityId,ProcessDefID from WFINSTRUMENTTABLE where ProcessInstanceID = '"+WINAME+"'";
											String dataInputXML = CommonMethods.apSelectWithColumnNames(tagData, cabinetName, sessionID);
											String dataOutputXML = CommonMethods.WFNGExecute(dataInputXML, jtsIP, jtsPort, 1);
											XMLParser dataxmlParserAPSelect = new XMLParser(dataOutputXML);
											String dataMainCode = dataxmlParserAPSelect.getValueOf("MainCode");
											int dataTotalRecords = Integer.parseInt(dataxmlParserAPSelect.getValueOf("TotalRetrieved"));
											if (dataMainCode.equals("0") && dataTotalRecords > 0) {
												WorkItemID = dataxmlParserAPSelect.getValueOf("Workitemid");
												ActivityID = dataxmlParserAPSelect.getValueOf("ActivityID");
												ProcessDefID =  dataxmlParserAPSelect.getValueOf("ProcessDefID");
												
												String getWorkItemInputXML1 = CommonMethods.getWorkItemInput(cabinetName, sessionID, WINAME,WorkItemID);
												KYCWICreateLog.KYCWICreateLogger.debug("input XML For WmgetWorkItemCall: "+ getWorkItemInputXML1);
												String getWorkItemOutputXml1 = CommonMethods.WFNGExecute(getWorkItemInputXML1,jtsIP, jtsPort,1);
												KYCWICreateLog.KYCWICreateLogger.debug("Output XML For WmgetWorkItemCall: "+ getWorkItemOutputXml1);
												
												XMLParser xmlParserGetWorkItem1 = new XMLParser(getWorkItemOutputXml1);
												String getWorkItemMainCode1 = xmlParserGetWorkItem1.getValueOf("MainCode");
												KYCWICreateLog.KYCWICreateLogger.debug("WmgetWorkItemCall Maincode:  "+ getWorkItemMainCode1);
												if("0".equalsIgnoreCase(getWorkItemMainCode1)){
												String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
							                            + "<Option>WMAssignWorkItemAttributes</Option>"
							                            + "<EngineName>"+cabinetName+"</EngineName>"
							                            + "<SessionId>"+sessionID+"</SessionId>"
							                            + "<ProcessInstanceId>"+WINAME+"</ProcessInstanceId>"
							                            + "<WorkItemId>"+WorkItemID+"</WorkItemId>"
							                            + "<ActivityId>"+ActivityID+"</ActivityId>"
							                            + "<ProcessDefId>"+ProcessDefID+"</ProcessDefId>"
							                            + "<LastModifiedTime></LastModifiedTime>"
							                            + "<ActivityType></ActivityType>"
							                            + "<complete></complete>"
							                            + "<AuditStatus></AuditStatus>"
							                            + "<Comments></Comments>"
							                            + "<UserDefVarFlag>Y</UserDefVarFlag>"
							                            + "<Attributes><Q_NG_KYC_REM_RP_GRID><CIF>"+RP_CIF_ID+"</CIF><RP_WI_Number>"+ProcessInstanceId+"</RP_WI_Number><RP_Name>"+RP_Name+"</RP_Name><RP_Details>"+RP_Type+"</RP_Details></Q_NG_KYC_REM_RP_GRID></Attributes>"
							                            + "</WMAssignWorkItemAttributes_Input>";
												
												KYCWICreateLog.KYCWICreateLogger.debug("assignInputXML--- "+assignInputXML);
												String assignOutXml = CommonMethods.WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
												KYCWICreateLog.KYCWICreateLogger.debug("assignOutXml--- "+assignOutXml);
												// PRINT MAINCODE
												XMLParser xmlParserAPSelectFinal = new XMLParser(assignOutXml);
												String xmlParserAPSelectFinalMaincode = xmlParserAPSelectFinal.getValueOf("MainCode");
												if (xmlParserAPSelectFinalMaincode.equalsIgnoreCase("0")){
													KYCWICreateLog.KYCWICreateLogger.debug("Related Item added in grid");
													/*String unlockWI_XML = "<?xml version=\"1.0\"?><WMUnlockWorkItem_Input>"
							                            + "<Option>WMUnlockWorkItem</Option>"
							                            + "<EngineName>"+cabinetName+"</EngineName>"
							                            + "<SessionId>"+sessionID+"</SessionId>"
							                            + "<ProcessInstanceID>"+WINAME+"</ProcessInstanceId>"
							                            + "<WorkItemId>"+WorkItemID+"</WorkItemId>"
							                            + "<UnlockOption>U</UnlockOption>"
							                            +"</WMUnlockWorkItem_Input>";
													KYCWICreateLog.KYCWICreateLogger.debug("assignInputXML--- "+unlockWI_XML);
													String unlockWIOutXml = CommonMethods.WFNGExecute(unlockWI_XML, jtsIP, jtsPort, 1);
													KYCWICreateLog.KYCWICreateLogger.debug("unlockWIOutXml--- "+unlockWIOutXml);*/
												}
											}
											}
										}
										else{
											KYCWICreateLog.KYCWICreateLogger.debug("CCorporate WIname not found ");
										}
									}
								} else {
									KYCWICreateLog.KYCWICreateLogger.debug("CompanyCIF not recieved ");
								}
							}
						}	
					}
				}
			}
			dbExtColumnMap.clear();
			DataFromDB.clear();
			return "true";
		} catch (Exception e) {
			KYCWICreateLog.KYCWICreateLogger.debug("exception: " + e);
			return "false";
		}
	}
	
	private static String replaceXChars(String value)
    {
           // handling of special characters
           if(!"".equalsIgnoreCase(value) && !"null".equalsIgnoreCase(value)  && value != null)
           {
                  if(value.contains("&amp;"))
                        value = value.replace("&amp;", "AAMPRRSNDD");
                  if(value.contains("&lt;"))
                        value = value.replace("&lt;", "LLSSTNSPX");
                  if(value.contains("&gt;"))
                        value = value.replace("&gt;", "GGRTTNSPX");
                  /*if(value.contains("&quote;"))
                        value = value.replace("&quote;", "DOBBULEQOTTS");*/
                  if(value.contains("&"))
                        value = value.replace("&", "&amp;");
                  
                  if(value.contains("AAMPRRSNDD"))
                        value = value.replace("AAMPRRSNDD", "&amp;");
                  if(value.contains("LLSSTNSPX"))
                        value = value.replace("LLSSTNSPX", "&lt;");
                  if(value.contains("GGRTTNSPX"))
                        value = value.replace("GGRTTNSPX", "&gt;");
                  /*if(value.contains("DOBBULEQOTTS"))
                        value = value.replace("DOBBULEQOTTS", "&quote;");*/
                  
                  if(value.contains("<"))
                        value = value.replace("<", "&lt;");
                  if(value.contains(">"))
                        value = value.replace(">", "&gt;");
                  /*if(value.contains("\""))
                        value = value.replace("\"", "&quote;");*/
           }
           return value;
    }
	
	private static List<Map<String, String>> getDataFromDBMap(String query, String cabinetName, String sessionID, String jtsIP, String jtsPort) {
		
		List<Map<String, String>> temp = new ArrayList<Map<String, String>>();
		try {
			//clear temp
			temp.clear();
			KYCWICreateLog.KYCWICreateLogger.debug("Inside function getDataFromDB");
			KYCWICreateLog.KYCWICreateLogger.debug("getDataFromDB query is: " + query);
			String InputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			String OutXml = CommonMethods.WFNGExecute(InputXML, jtsIP, jtsPort, 1);
			OutXml = OutXml.replaceAll("&", "#andsymb#");
			Document recordDoc1 = MapXML.getDocument(OutXml);
			NodeList records1 = recordDoc1.getElementsByTagName("Record");
			if (records1.getLength() > 0) {
				for (int i = 0; i < records1.getLength(); i++) {
					Node n = records1.item(i);
					Map<String, String> t = new HashMap<String, String>();
					t.clear();
					if (n.hasChildNodes()) {
						NodeList child = n.getChildNodes();
						for (int j = 0; j < child.getLength(); j++) {
							Node n1 = child.item(j);
							String column = n1.getNodeName();
							String value = n1.getTextContent().replaceAll("#andsymb#", "&");
							if (null != value && !"null".equalsIgnoreCase(value) && !"".equals(value)) {
								KYCWICreateLog.KYCWICreateLogger
										.debug("getDataFromDBMap Setting value of " + column + " as " + value);
								t.put(column, value);
							} else {
								KYCWICreateLog.KYCWICreateLogger
										.debug("getDataFromDBMap Setting value of " + column + " as blank");
								t.put(column, "");
							}
						}
					}
					temp.add(t);
				}
			}

		} catch (Exception e) {
			KYCWICreateLog.KYCWICreateLogger.debug("Exception occured in getDataFromDBMap method" + e.getMessage());
		}
		return temp;
	}
	private static String getAPProcedureInputXML(String engineName,String sSessionId,String procName,String Params)
	{
		StringBuffer bfrInputXML = new StringBuffer();
		bfrInputXML.append("<?xml version=\"1.0\"?>\n");
		bfrInputXML.append("<APProcedure_WithDBO_Input>\n");
		bfrInputXML.append("<Option>APProcedure_WithDBO</Option>\n");
		bfrInputXML.append("<ProcName>");
		bfrInputXML.append(procName);
		bfrInputXML.append("</ProcName>");
		bfrInputXML.append("<Params>");
		bfrInputXML.append(Params);
		bfrInputXML.append("</Params>");
		bfrInputXML.append("<EngineName>");
		bfrInputXML.append(engineName);
		bfrInputXML.append("</EngineName>");
		bfrInputXML.append("<SessionId>");
		bfrInputXML.append(sSessionId);
		bfrInputXML.append("</SessionId>");
		bfrInputXML.append("</APProcedure_WithDBO_Input>");		
		return bfrInputXML.toString();
	}
	private static String executeAPI(String sInputXML){
		String sOutputXML="";
		try{
			 Socket sock = null;
			 sock = new Socket(jtsIP,Integer.parseInt(jtsPort));
			 DataOutputStream oOut = new DataOutputStream(new BufferedOutputStream(sock.getOutputStream()));
			 DataInputStream oIn = new DataInputStream(new BufferedInputStream(sock.getInputStream()));
			 byte[] SendStream = sInputXML.getBytes("8859_1");
			 int strLen = SendStream.length;
	         oOut.writeInt(strLen);
	    	 oOut.write(SendStream, 0, strLen);
			 oOut.flush();
			 int length = 0;
			 length = oIn.readInt();
			 byte[] readStream = new byte[length];
			 oIn.readFully(readStream);
			 sOutputXML= new String(readStream, "8859_1");
			 sock.close(); 
		}
		catch (Exception e){
			KYCWICreateLog.KYCWICreateLogger.debug("sOutputXML: XML Log "+sOutputXML);
			KYCWICreateLog.KYCWICreateLogger.debug("Exception: "+e.getMessage());
			
		}
		return sOutputXML;
    }
	
	public static boolean insertReqRespINDatabase(String WFuploadInputXML,String WFuploadOutputXML,String MsgFormat,String ProcessInstanceId,String UserName,String requestedDateTime){
		try{
			
			Date localDate = new Date();
			SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.mmm");
			String actionDateTime = localSimpleDateFormat.format(localDate);
			String XMLHISTORY_TABLENAME = "NG_KYC_Remedation_XMLLOG_HISTORY";
			String MsgIDInReq="";
            String params="'"+XMLHISTORY_TABLENAME+"'"
					+",'" +ProcessInstanceId+"'"
					+",'" +MsgFormat+"'"
					+",'" +MsgFormat+"'"
					+",'" +UserName+"'"
					+",'" +MsgIDInReq+"'"
					+",'" +WFuploadInputXML.replaceAll("'", "''")+"'"
					+",'" +WFuploadOutputXML.replaceAll("'", "''")+"'"
					+",'" +requestedDateTime+"'"
					+",'" +actionDateTime+"'";
			String inputXML = getAPProcedureInputXML(cabinetName,sessionID,"NG_XML_INSERT_PROC",params);
			//KYCWICreateLog.KYCWICreateLogger.debug("inputXML AP Procedure new params: "+params);
			KYCWICreateLog.KYCWICreateLogger.debug("inputXML AP Procedure XML Entry "+inputXML);
			String sOutputXML=executeAPI(inputXML);
			KYCWICreateLog.KYCWICreateLogger.debug("outputXML AP Procedure XML Entry "+sOutputXML);			

			if(sOutputXML.indexOf("<MainCode>0</MainCode>")>-1){
				KYCWICreateLog.KYCWICreateLogger.debug("inputXML AP Procedure Insert Successful");	
				return true;
			}	
			else{
				KYCWICreateLog.KYCWICreateLogger.debug("inputXML AP Procedure Insert Failed");
				return false;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	private static String getWFUploadWorkItemXML(String sCabinetName,String sSessionID,String processDefID,String attributeTag,String queueID){	
			return  "<?xml version=\"1.0\"?>"+
					"<WFUploadWorkItem_Input>"+
					"<Option>WFUploadWorkItem</Option>"+
					"<EngineName>"+sCabinetName+"</EngineName>"+
					"<SessionId>"+sSessionID+"</SessionId>"+
					"<ProcessDefId>"+processDefID+"</ProcessDefId>"+
					"<QueueId>"+queueID+"</QueueId>"+
					"<DataDefName></DataDefName>"+
					"<Fields></Fields>"+
					"<InitiateAlso>Y</InitiateAlso>"+
					"<Documents></Documents>"+
					"<Attributes>"+attributeTag+"</Attributes>"+
					"<UserDefVarFlag>Y</UserDefVarFlag>"+
					"</WFUploadWorkItem_Input>";
		}
}
