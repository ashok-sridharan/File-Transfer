/*
---------------------------------------------------------------------------------------------------------
                  NEWGEN SOFTWARE TECHNOLOGIES LIMITED

Group                   : Application - Projects
Project/Product			: RAK BPM
Application				: RAK BPM Utility
Module					: Main
File Name				: RAKBankUtility.java
Author 					: Sakshi Grover
Date (DD/MM/YYYY)		: 30/04/2019

---------------------------------------------------------------------------------------------------------
                 	CHANGE HISTORY
---------------------------------------------------------------------------------------------------------

Problem No/CR No        Change Date           Changed By             Change Description
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
*/


package com.newgen.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.PropertyConfigurator;
import com.newgen.KYC.CBS.KYC_CBS;
import com.newgen.KYC.CustOutreach.CustOutreach;
import com.newgen.KYC.KYCodDownloadPBG1.KYCodDownloadPBG1;
import com.newgen.KYC.KYCodDownloadPBG2.KYCodDownloadPBG2;
import com.newgen.KYC.KYCodDownloadPBG3.KYCodDownloadPBG3;
import com.newgen.KYC.KYCodDownloadPBG4.KYCodDownloadPBG4;
import com.newgen.KYC.KYCodDownloadPBG5.KYCodDownloadPBG5;
import com.newgen.KYC.KYCodDownloadBBG1.KYCodDownloadBBG1;
import com.newgen.KYC.KYCodDownloadBBG2.KYCodDownloadBBG2;
import com.newgen.KYC.KYCodDownloadBBG3.KYCodDownloadBBG3;
import com.newgen.KYC.KYCodDownloadBBG4.KYCodDownloadBBG4;
import com.newgen.KYC.KYCodDownloadBBG5.KYCodDownloadBBG5;
import com.newgen.KYC.KYCodDownloadWBG1.KYCodDownloadWBG1;
import com.newgen.KYC.KYCodDownloadWBG2.KYCodDownloadWBG2;
import com.newgen.KYC.KYCodDownloadWBG3.KYCodDownloadWBG3;
import com.newgen.KYC.KYCodDownloadWBG4.KYCodDownloadWBG4;
import com.newgen.KYC.KYCodDownloadWBG5.KYCodDownloadWBG5;
import com.newgen.KYC.KYCWICreate.KYCWICreate;
import com.newgen.KYC.CelebalCIFsDocDownload.CelebalCIFsDocDownload;
import com.newgen.KYC.CelebalCIFsDocUpload.CelebalCIFsDocUpload;
import com.newgen.common.CommonConnection;
import com.newgen.encryption.DataEncryption;

public class RAK_KYC_Utility
{
	private static Map<String, String> mainPropMap= new HashMap<String, String>();
	private static String loggerName = "MainLogger";
	private static org.apache.log4j.Logger MainLogger = org.apache.log4j.Logger.getLogger(loggerName);

	 static
	 {
			setLogger();
	 }

	public static void main(String[] args)
	{
		System.out.println("Starting utility...");
		MainLogger.info("Starting Utility");
		int mainPropFileReadCode = readMainPropFile();

		if(mainPropFileReadCode!=0)
		{
			System.out.println("Error in Readin Main Property FIle");
			MainLogger.error("Error in Readin Main Property FIle "+mainPropFileReadCode);
			return;
		}

		try
		{
			int socketPort =  Integer.parseInt(mainPropMap.get("Utility_Port"));
			if(socketPort==0)
			{
				System.out.println("Not able to Get Utility Port");
				MainLogger.error("Not able to Get Utility Port "+socketPort);
				return;
			}
			ServerSocket serverSocket = new ServerSocket(socketPort);



			CommonConnection.setUsername(mainPropMap.get("UserName"));
			CommonConnection.setPassword(DataEncryption.decrypt(mainPropMap.get("Password")));
			CommonConnection.setJTSIP(mainPropMap.get("JTSIP"));
			CommonConnection.setJTSPort(mainPropMap.get("JTSPort"));
			CommonConnection.setsSMSPort(mainPropMap.get("SMSPort"));
			CommonConnection.setCabinetName(mainPropMap.get("CabinetName"));
			CommonConnection.setsVolumeID(mainPropMap.get("VolumeID"));
			CommonConnection.setsSiteID(mainPropMap.get("SiteID"));
			
			CommonConnection.setOFCabinetName(mainPropMap.get("OFCabinetName"));
			CommonConnection.setOFBAISProcessDefId(mainPropMap.get("OFBAISProcessDefId"));
			CommonConnection.setOFJTSIP(mainPropMap.get("OFJTSIP"));
			CommonConnection.setOFJTSPort(mainPropMap.get("OFJTSPort"));
			CommonConnection.setOFVOLUMNID(mainPropMap.get("OFVOLUMNID"));
			CommonConnection.setOFUserName(mainPropMap.get("OFUserName"));
			CommonConnection.setOFPassword(mainPropMap.get("OFPassword"));
			
			/*CommonConnection.setsDataClassName(mainPropMap.get("DataClassName"));
			CommonConnection.setsDataDefId(mainPropMap.get("DataDefId"));
			CommonConnection.setsRcifIndexId(mainPropMap.get("RcifIndexId"));
			CommonConnection.setsCcifIndexId(mainPropMap.get("CcifIndexId"));
			CommonConnection.setsLookInFolder(mainPropMap.get("SLookInFolder"));*/
			
			String sessionID = CommonConnection.getSessionID(MainLogger,false);

			if(sessionID==null || sessionID.equalsIgnoreCase("") || sessionID.equalsIgnoreCase("null"))
			{
				MainLogger.info("Could Not Get Session ID "+sessionID);
				return;
			}

			
//			if(mainPropMap.get("KYCWICreate")!=null && mainPropMap.get("KYCWICreate").equalsIgnoreCase("Y"))
//			{
//				System.out.println("Going To start KYCWICreate Utility..");
//				Thread KYCWICreate = new Thread(new KYCWICreate());
//				System.out.println("KYCWICreate thread initiallized..");
//				KYCWICreate.start();
//				System.out.println("KYCWICreate Utility Started");
//				MainLogger.info("KYCWICreate Utility Started");
//			}
			if(mainPropMap.get("KYCodDownloadPBG1")!=null && mainPropMap.get("KYCodDownloadPBG1").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadPBG1 Utility..");
				Thread KYCodDownloadPBG1 = new Thread(new KYCodDownloadPBG1());
				System.out.println("KYCodDownloadPBG1 thread initiallized..");
				KYCodDownloadPBG1.start();
				System.out.println("KYCodDownloadPBG1 Utility Started");
				MainLogger.info("KYCodDownloadPBG1 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadPBG2")!=null && mainPropMap.get("KYCodDownloadPBG2").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadPBG2 Utility..");
				Thread KYCodDownloadPBG2 = new Thread(new KYCodDownloadPBG2());
				System.out.println("KYCodDownloadPBG2 thread initiallized..");
				MainLogger.info("KYCodDownloadPBG2 before wait");
				TimeUnit.SECONDS.sleep(1);
				MainLogger.info("KYCodDownloadPBG2 after wait");
				KYCodDownloadPBG2.start();
				System.out.println("KYCodDownloadPBG2 Utility Started");
				MainLogger.info("KYCodDownloadPBG2 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadPBG3")!=null && mainPropMap.get("KYCodDownloadPBG3").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadPBG3 Utility..");
				Thread KYCodDownloadPBG3 = new Thread(new KYCodDownloadPBG3());
				System.out.println("KYCodDownloadPBG3 thread initiallized..");
				MainLogger.info("KYCodDownloadPBG3 before wait");
				TimeUnit.SECONDS.sleep(3);
				MainLogger.info("KYCodDownloadPBG3 after wait");
				KYCodDownloadPBG3.start();
				System.out.println("KYCodDownloadPBG3 Utility Started");
				MainLogger.info("KYCodDownloadPBG3 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadPBG4")!=null && mainPropMap.get("KYCodDownloadPBG4").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadPBG4 Utility..");
				Thread KYCodDownloadPBG4 = new Thread(new KYCodDownloadPBG4());
				System.out.println("KYCodDownloadPBG4 thread initiallized..");
				MainLogger.info("KYCodDownloadPBG4 before wait");
				TimeUnit.SECONDS.sleep(5);
				MainLogger.info("KYCodDownloadPBG4 after wait");
				KYCodDownloadPBG4.start();
				System.out.println("KYCodDownloadPBG4 Utility Started");
				MainLogger.info("KYCodDownloadPBG4 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadPBG5")!=null && mainPropMap.get("KYCodDownloadPBG5").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadPBG5 Utility..");
				Thread KYCodDownloadPBG5 = new Thread(new KYCodDownloadPBG5());
				System.out.println("KYCodDownloadPBG5 thread initiallized..");
				MainLogger.info("KYCodDownloadPBG5 before wait");
				TimeUnit.SECONDS.sleep(7);
				MainLogger.info("KYCodDownloadPBG5 after wait");
				KYCodDownloadPBG5.start();
				System.out.println("KYCodDownloadPBG5 Utility Started");
				MainLogger.info("KYCodDownloadPBG5 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadBBG1")!=null && mainPropMap.get("KYCodDownloadBBG1").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadBBG1 Utility..");
				Thread KYCodDownloadBBG1 = new Thread(new KYCodDownloadBBG1());
				System.out.println("KYCodDownloadBBG1 thread initiallized..");
				KYCodDownloadBBG1.start();
				System.out.println("KYCodDownloadBBG1 Utility Started");
				MainLogger.info("KYCodDownloadBBG1 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadBBG2")!=null && mainPropMap.get("KYCodDownloadBBG2").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadBBG2 Utility..");
				Thread KYCodDownloadBBG2 = new Thread(new KYCodDownloadBBG2());
				System.out.println("KYCodDownloadBBG2 thread initiallized..");
				MainLogger.info("KYCodDownloadBBG2 before wait");
				TimeUnit.SECONDS.sleep(1);
				MainLogger.info("KYCodDownloadBBG2 after wait");
				KYCodDownloadBBG2.start();
				System.out.println("KYCodDownloadBBG2 Utility Started");
				MainLogger.info("KYCodDownloadBBG2 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadBBG3")!=null && mainPropMap.get("KYCodDownloadBBG3").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadBBG3 Utility..");
				Thread KYCodDownloadBBG3 = new Thread(new KYCodDownloadBBG3());
				System.out.println("KYCodDownloadBBG3 thread initiallized..");
				MainLogger.info("KYCodDownloadBBG3 before wait");
				TimeUnit.SECONDS.sleep(3);
				MainLogger.info("KYCodDownloadBBG3 after wait");
				KYCodDownloadBBG3.start();
				System.out.println("KYCodDownloadBBG3 Utility Started");
				MainLogger.info("KYCodDownloadBBG3 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadBBG4")!=null && mainPropMap.get("KYCodDownloadBBG4").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadBBG4 Utility..");
				Thread KYCodDownloadBBG4 = new Thread(new KYCodDownloadBBG4());
				System.out.println("KYCodDownloadBBG4 thread initiallized..");
				MainLogger.info("KYCodDownloadBBG4 before wait");
				TimeUnit.SECONDS.sleep(5);
				MainLogger.info("KYCodDownloadBBG4 after wait");
				KYCodDownloadBBG4.start();
				System.out.println("KYCodDownloadBBG4 Utility Started");
				MainLogger.info("KYCodDownloadBBG4 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadBBG5")!=null && mainPropMap.get("KYCodDownloadBBG5").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadBBG5 Utility..");
				Thread KYCodDownloadBBG5 = new Thread(new KYCodDownloadBBG5());
				System.out.println("KYCodDownloadBBG5 thread initiallized..");
				MainLogger.info("KYCodDownloadBBG5 before wait");
				TimeUnit.SECONDS.sleep(7);
				MainLogger.info("KYCodDownloadBBG5 after wait");
				KYCodDownloadBBG5.start();
				System.out.println("KYCodDownloadBBG5 Utility Started");
				MainLogger.info("KYCodDownloadBBG5 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadWBG1")!=null && mainPropMap.get("KYCodDownloadWBG1").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadWBG1 Utility..");
				Thread KYCodDownloadWBG1 = new Thread(new KYCodDownloadWBG1());
				System.out.println("KYCodDownloadWBG1 thread initiallized..");
				KYCodDownloadWBG1.start();
				System.out.println("KYCodDownloadWBG1 Utility Started");
				MainLogger.info("KYCodDownloadWBG1 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadWBG2")!=null && mainPropMap.get("KYCodDownloadWBG2").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadWBG2 Utility..");
				Thread KYCodDownloadWBG2 = new Thread(new KYCodDownloadWBG2());
				System.out.println("KYCodDownloadWBG2 thread initiallized..");
				MainLogger.info("KYCodDownloadWBG2 before wait");
				TimeUnit.SECONDS.sleep(1);
				MainLogger.info("KYCodDownloadWBG2 after wait");
				KYCodDownloadWBG2.start();
				System.out.println("KYCodDownloadWBG2 Utility Started");
				MainLogger.info("KYCodDownloadWBG2 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadWBG3")!=null && mainPropMap.get("KYCodDownloadWBG3").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadWBG3 Utility..");
				Thread KYCodDownloadWBG3 = new Thread(new KYCodDownloadWBG3());
				System.out.println("KYCodDownloadWBG3 thread initiallized..");
				MainLogger.info("KYCodDownloadWBG3 before wait");
				TimeUnit.SECONDS.sleep(3);
				MainLogger.info("KYCodDownloadWBG3 after wait");
				KYCodDownloadWBG3.start();
				System.out.println("KYCodDownloadWBG3 Utility Started");
				MainLogger.info("KYCodDownloadWBG3 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadWBG4")!=null && mainPropMap.get("KYCodDownloadWBG4").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadWBG4 Utility..");
				Thread KYCodDownloadWBG4 = new Thread(new KYCodDownloadWBG4());
				System.out.println("KYCodDownloadWBG4 thread initiallized..");
				MainLogger.info("KYCodDownloadWBG4 before wait");
				TimeUnit.SECONDS.sleep(5);
				MainLogger.info("KYCodDownloadWBG4 after wait");
				KYCodDownloadWBG4.start();
				System.out.println("KYCodDownloadWBG4 Utility Started");
				MainLogger.info("KYCodDownloadWBG4 Utility Started");
			}
			if(mainPropMap.get("KYCodDownloadWBG5")!=null && mainPropMap.get("KYCodDownloadWBG5").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYCodDownloadWBG5 Utility..");
				Thread KYCodDownloadWBG5 = new Thread(new KYCodDownloadWBG5());
				System.out.println("KYCodDownloadWBG5 thread initiallized..");
				MainLogger.info("KYCodDownloadWBG5 before wait");
				TimeUnit.SECONDS.sleep(7);
				MainLogger.info("KYCodDownloadWBG5 after wait");
				KYCodDownloadWBG5.start();
				System.out.println("KYCodDownloadWBG5 Utility Started");
				MainLogger.info("KYCodDownloadWBG5 Utility Started");
			}
			if(mainPropMap.get("KYC_CIF_Update")!=null && mainPropMap.get("KYC_CIF_Update").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYC_CIF_Update Utility..");
				Thread KYCodDownload = new Thread(new KYC_CBS());
				System.out.println("KYC_CIF_Update thread initiallized..");
				KYCodDownload.start();
				System.out.println("KYC_CIF_Update Utility Started");
				MainLogger.info("KYC_CIF_Update Utility Started");
			}
			if(mainPropMap.get("KYC_CustOutreach")!=null && mainPropMap.get("KYC_CustOutreach").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYC_CustOutreach Utility..");
				Thread CustOutreach = new Thread(new CustOutreach());
				System.out.println("KYC_CustOutreach thread initiallized..");
				CustOutreach.start();
				System.out.println("KYC_CustOutreach Utility Started");
				MainLogger.info("KYC_CustOutreach Utility Started");
			}
			if(mainPropMap.get("KYC_CelebalCIFsDocDownload")!=null && mainPropMap.get("KYC_CelebalCIFsDocDownload").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYC_CelebalCIFsDocDownload Utility..");
				Thread CelebalCIFsDocDownload = new Thread(new CelebalCIFsDocDownload());
				System.out.println("KYC_CelebalCIFsDocDownload thread initiallized..");
				CelebalCIFsDocDownload.start();
				System.out.println("KYC_CelebalCIFsDocDownload Utility Started");
				MainLogger.info("KYC_CelebalCIFsDocDownload Utility Started");
			}
			if(mainPropMap.get("KYC_CelebalCIFsDocUpload")!=null && mainPropMap.get("KYC_CelebalCIFsDocUpload").equalsIgnoreCase("Y"))
			{
				System.out.println("Going To start KYC_CelebalCIFsDocUpload Utility..");
				Thread CelebalCIFsDocUpload = new Thread(new CelebalCIFsDocUpload());
				System.out.println("KYC_CelebalCIFsDocUpload thread initiallized..");
				CelebalCIFsDocUpload.start();
				System.out.println("KYC_CelebalCIFsDocUpload Started");
				MainLogger.info("KYC_CelebalCIFsDocUpload Started");
			}
		}
		catch (Exception e)
		{
			if(e.getMessage().toUpperCase().startsWith("Address already in use".toUpperCase()))
			{
				System.out.println("Utility Instance Already Running");
				MainLogger.error("Utility Instance Already Running");
			}
			else
			{
				e.printStackTrace();
				MainLogger.error("Exception Occurred in Main Thread: "+e);
				final Writer result = new StringWriter();
				final PrintWriter printWriter = new PrintWriter(result);
				e.printStackTrace(printWriter);
				MainLogger.error("Exception Occurred in Main Thread : "+result);
			}
			return;
		}
		finally
		{
			System.gc();
		}
	}

	private static void setLogger()
	{
		try
		{
			Date date = new Date();
			DateFormat logDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			Properties p = new Properties();
			p.load(new FileInputStream(System.getProperty("user.dir")+ File.separator + "log4jFiles"+ File.separator+ "Main_log4j.properties"));
			String dynamicLog = null;
			String orgFileName = null;
			File d = null;
			File fl = null;

			dynamicLog = "Logs/Main_Logs/"+logDateFormat.format(date)+"/Main_Log.xml";
			orgFileName = p.getProperty("log4j.appender."+loggerName+".File");
			if(!(orgFileName==null || orgFileName.equalsIgnoreCase("")))
			{
				dynamicLog = orgFileName.substring(0,orgFileName.lastIndexOf("/")+1)+logDateFormat.format(date)+orgFileName.substring(orgFileName.lastIndexOf("/"));
			}
			d = new File(dynamicLog.substring(0,dynamicLog.lastIndexOf("/")));
			d.mkdirs();
			fl = new File(dynamicLog);
			if(!fl.exists())
				fl.createNewFile();
			p.put("log4j.appender."+loggerName+".File", dynamicLog );

			PropertyConfigurator.configure(p);
			//System.out.println("Dynamic Logger Created");
		}
		catch(Exception e)
		{
			System.out.println("Exception in creating dynamic log :"+e);
			e.printStackTrace();
		}
	}

	private static int readMainPropFile()
	{
		Properties p = null;
		try {

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "ConfigFiles"+ File.separator+ "Main_Config.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements())
			{
			    String name = (String) names.nextElement();
			    mainPropMap.put(name, p.getProperty(name));
			}

		} catch (Exception e) {

			return -1 ;
		}
		return 0;
	}
}