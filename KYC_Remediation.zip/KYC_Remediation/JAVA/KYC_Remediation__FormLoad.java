package com.newgen.iforms.user;

import java.io.FileInputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Properties;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;

public class KYC_Remediation__FormLoad extends KYC_Remediation_Common {

	public String formLoadEvent(IFormReference iform, String controlName, String event, String data) {
		try {
			KYC_Remediation.mLogger.debug("This is KYC_Remediation_Event" + event + " controlName :" + controlName);
			String Workstep = iform.getActivityName();
			String loggedInUser = iform.getUserName();
			String processinstanceID = getWorkitemName(iform);
			iform.setValue("LoggedInUser", loggedInUser);
			KYC_Remediation.mLogger.debug("WINAME : " + getWorkitemName(iform) + ", WSNAME: " + iform.getActivityName()
					+ ", Workstep :" + Workstep);
			String caseType = (String) iform.getValue("CaseType");
			// iform.setStyle("frame16","disable","true");
			
			String subSegment = "";
			String selectQuery = "Select VAR_STR8 FROM WFINSTRUMENTTABLE with (nolock) WHERE processinstanceid = '"
					+ getWorkitemName(iform) + "' AND workitemID = '1'";
			List<List<String>> Segment_ = iform.getDataFromDB(selectQuery);
			if (!Segment_.isEmpty()) {
				KYC_Remediation.mLogger.debug("Sub Segment from wfinstrumenttable is - " + Segment_);
				for (List<String> data1 : Segment_) {
					subSegment = data1.get(0);
				}
			}
			iform.setValue("subSegment", subSegment);
			
			if("WBG".equalsIgnoreCase(subSegment)){
				iform.setStyle("OutreachInitialDateTime", "visible", "true");
			} else {
				iform.setStyle("OutreachInitialDateTime", "visible", "false");
			}
			
			if (("Individual").equalsIgnoreCase(caseType)) {
				iform.setValue("label8", "KYC Remediation Retail");
				iform.setStyle("frame13", "visible", "false");
				iform.setStyle("frame11", "visible", "false");
				iform.setStyle("frame12", "visible", "false");
				iform.setStyle("frame14", "visible", "false");
				
				iform.setStyle("frame22", "visible", "false");
				iform.setStyle("frame23", "visible", "false");
				iform.setStyle("frame24", "visible", "false");
				iform.setStyle("frame25", "visible", "false");
				iform.setStyle("frame26", "visible", "false");
				iform.setStyle("frame27", "visible", "false");
				
				iform.setStyle("evidenceOnSourceOfFunds", "visible", "false");
				iform.setStyle("KYC_Review_Date", "visible", "false");
				iform.setStyle("CountriesDealingWith", "visible", "false");
				iform.setStyle("Top5Suppliers", "visible", "false");
				iform.setStyle("Top5Buyers", "visible", "false");
				iform.setStyle("VAT_RegistrationNo", "visible", "false");
				iform.setStyle("CorporateTax", "visible", "false");
				iform.setStyle("DNFBP_Status", "visible", "false");
				iform.setStyle("NoOfEmployees", "visible", "false");
				iform.setStyle("AnnualTurnover", "visible", "false");
				iform.setStyle("Subsidiaries_Name", "visible", "false");
				iform.setStyle("Subsidiaries_Business", "visible", "false");
				iform.setStyle("SubsidiaryCountryOfOperation", "visible", "false");
				iform.setStyle("NetWorth", "visible", "false");
				iform.setStyle("HawalaActivity", "visible", "false");
				iform.setStyle("HawalaServiceProvider", "visible", "false");
				iform.setStyle("CorporateTaxRegDate", "visible", "false");
				iform.setStyle("DownstreamServiceVASP", "visible", "false");
				iform.setStyle("ShareholderUSperson", "visible", "false");
				iform.setStyle("UScitizenship_ResidencyDetails", "visible", "false");
				iform.setStyle("Certify", "visible", "false");
				iform.setStyle("NotTaxResident", "visible", "false");
				iform.setStyle("NoTINreason", "visible", "false");
				iform.setStyle("EntityOrganisedInUSA", "visible", "false");
				iform.setStyle("label7", "visible", "false");
				iform.setStyle("ActiveNFE", "visible", "false");
				iform.setStyle("PassiveNFE", "visible", "false");
				iform.setStyle("FinancialInstitution", "visible", "false");
				iform.setStyle("SecuritiesMarket", "visible", "false");
				iform.setStyle("RelatedEntity", "visible", "false");
				iform.setStyle("GIIN", "visible", "false");
				iform.setStyle("AccountInformation", "visible", "false");
				iform.setStyle("DoYouMaintainAccount", "visible", "false");
				iform.setStyle("LengthOfBusinessRelationship", "visible", "false");
				iform.setStyle("Consequence_held_till", "visible", "false");
				iform.setStyle("AverageAnnualIncome", "visible", "false");
				iform.setStyle("ShareholderSection", "visible", "false");
				iform.setStyle("frame17", "visible", "false"); // BoD table
				iform.setStyle("frame20", "visible", "false"); // Customer
																// Communication
																// section
				String employerOthers = (String) iform.getValue("OfficeEmployerName");
				String employerNamedesc = (String) iform.getValue("OfficeEmployerNameDesc");
				if (!employerOthers.equalsIgnoreCase("")) {
					iform.setStyle("OfficeEmployerName", "visible", "true");
					iform.setValue("OfficeEmployerNameDesc", "OTHERS");
					iform.setValue("OfficeEmployerCode", "76423");
				}
				if (employerOthers.equalsIgnoreCase("") && employerNamedesc.equalsIgnoreCase("OTHERS")
						|| employerNamedesc.equalsIgnoreCase("OTHER")) {
					iform.setStyle("OfficeEmployerName", "visible", "true");
				}
				try {
					int size = iform.getDataFromGrid("IndustrySubSegmentGrid").size();
					for (int i = 0; i < size; i++) {
						String existingSegment = iform.getTableCellValue("IndustrySubSegmentGrid", i, 1);
						if ("".equalsIgnoreCase(existingSegment)) {
							String Segmentcode = "";
							String subsegment = iform.getTableCellValue("IndustrySubSegmentGrid", i, 0);
							String query = "Select Top 1 MappedSegmentCode from NG_KYC_REM_Industry_SubSegment_MASTER WHERE SubSegment = '"
									+ subsegment + "'";
							List<List<String>> Segment = iform.getDataFromDB(query);
							if (!Segment.isEmpty()) {
								KYC_Remediation.mLogger.debug("Segment from Subsegment master - " + Segment);
								for (List<String> data1 : Segment) {
									Segmentcode = data1.get(0);
									iform.setTableCellValue("IndustrySubSegmentGrid", i, 1, Segmentcode);
								}
							}
						}
					}
				} catch (Exception e) {
					KYC_Remediation.mLogger.debug("Exception in updatin segment in Subsegment grid on formload");
				}

				// JIRA 313 Date 14/10/2024
				String CustomerCategory = (String) iform.getValue("CustomerCategory");
				if ("".equalsIgnoreCase(CustomerCategory)) {
					String ResidentCountry = (String) iform.getValue("ResidentCountry");
					if ("AE".equalsIgnoreCase(ResidentCountry))
						iform.setValue("CustomerCategory", "Resident Individual");
				}
				// JIRA 313 Date 14/10/2024 end

				String persona = (String) iform.getValue("CIFPersona");
				KYC_Remediation.mLogger.debug("persona----->" + persona);
				if ("Self Employed - Non Resident".equalsIgnoreCase(persona.trim())
						|| "Self Employed - Resident".equalsIgnoreCase(persona.trim())
						|| "Ruling Family".equalsIgnoreCase(persona.trim())
						|| "Loan Only Customers".equalsIgnoreCase(persona.trim())
						|| "Credit Card Only".equalsIgnoreCase(persona.trim())) {
					iform.setStyle("CountryOfOperation", "visible", "true");
				} else {
					iform.setStyle("CountryOfOperation", "visible", "false");
				}
				if ("Self Employed - Non Resident".equalsIgnoreCase(persona.trim())
						|| "Self Employed - Resident".equalsIgnoreCase(persona.trim())) {
					KYC_Remediation.mLogger.debug("Inside if block ofpersona----->" + persona);
					iform.setStyle("label2", "visible", "true");
					iform.setStyle("BusinessAddress", "visible", "true");
					iform.setStyle("BusinessCountry", "visible", "true");
					iform.setStyle("BusinessFlatVillaNo", "visible", "true");
					iform.setStyle("BusinessEmirateCity", "visible", "true");
				} else {
					KYC_Remediation.mLogger.debug("Inside else block of persona----->" + persona);
					iform.setStyle("label2", "visible", "false");
					iform.setStyle("BusinessAddress", "visible", "false");
					iform.setStyle("BusinessCountry", "visible", "false");
					iform.setStyle("BusinessFlatVillaNo", "visible", "false");
					iform.setStyle("BusinessEmirateCity", "visible", "false");
				}
				try {
					if ("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)) {
						String city = (String) iform.getValue("ResidenceEmirateCity");
						KYC_Remediation.mLogger.debug("city----->" + city);
						String Emirate = (String) iform.getValue("ResidenceEmirate");
						KYC_Remediation.mLogger.debug("Emirate----->" + Emirate);
						String residenceCountry = (String) iform.getValue("ResidenceCountry");
						if ("AE".equalsIgnoreCase(residenceCountry) && !("".equalsIgnoreCase(city))
								&& "".equalsIgnoreCase(Emirate)) {
							KYC_Remediation.mLogger.debug("inside if for setting emirate in dropdown");
							iform.setValue("ResidenceEmirate", city);
						}
						if ("Maker2".equalsIgnoreCase(Workstep)) {
							String updatedFields = (String) iform.getValue("PortalUpdatedFields");
							if (!"".equalsIgnoreCase(updatedFields)) {
								String arr[] = updatedFields.split("|");
								for (String field : arr) {
									iform.setStyle(field, "fontcolor", "red");
								}
							}
						}
					}
				} catch (Exception e) {
					KYC_Remediation.mLogger.debug("Exception - Emirate not set as expected");
				}
				// nextReviewDate(iform,"RiskProfile",event);
				try {
					String RiskProfile = (String) iform.getValue("RiskProfile");
					if (!"".equalsIgnoreCase(RiskProfile)) {
						Double rScore = Double.parseDouble(RiskProfile);
						if (rScore >= 0 && rScore < 3) {
							KYC_Remediation.mLogger.debug("Inside low");
							iform.setValue("RiskProfileDesc", "Low");
						}
						if (rScore >= 3 && rScore < 4) {
							KYC_Remediation.mLogger.debug("Inside medium");
							iform.setValue("RiskProfileDesc", "Medium");
						}
						if (rScore >= 4) {
							KYC_Remediation.mLogger.debug("Inside high");
							iform.setValue("RiskProfileDesc", "High");
						}
					}
				} catch (Exception e) {
					KYC_Remediation.mLogger.debug("Exception in RiskProfileDesc: " + e);
				}
				try {
					// table31 RP Grid Individual
					String jointFlag = (String) iform.getValue("Joint_Flag");
					String minorFlag = (String) iform.getValue("Minor_Flag");
					String poaFlag = (String) iform.getValue("PoA_Flag");
					String suppFlag = (String) iform.getValue("Supplementary_Flag");
					String jointCIF = (String) iform.getValue("Joint_Cif");
					// iform.clearTable("table31");
					String deletequery = "DELETE FROM NG_KYC_REM_IND_RP_GRID WHERE WINAME = '" + processinstanceID
							+ "'";
					iform.saveDataInDB(deletequery);
					if (!"".equalsIgnoreCase(jointCIF)) {
						/*
						 * String RPType = "";
						 * if(jointFlag.equalsIgnoreCase("Y")) RPType =
						 * "Joint Account"; if(minorFlag.equalsIgnoreCase("Y"))
						 * RPType += ", Minor";
						 * if(poaFlag.equalsIgnoreCase("Y")) RPType += ", POA";
						 * if(suppFlag.equalsIgnoreCase("Y")) RPType +=
						 * ", Supplementary";
						 */
						String RPType = "";
						if (jointFlag.equalsIgnoreCase("Y"))
							RPType = "Joint Account";
						if (minorFlag.equalsIgnoreCase("Y"))
							RPType += RPType.isEmpty() ? "Minor" : ", Minor";
						if (poaFlag.equalsIgnoreCase("Y"))
							RPType += RPType.isEmpty() ? "POA" : ", POA";
						if (suppFlag.equalsIgnoreCase("Y"))
							RPType += RPType.isEmpty() ? "Supplementary" : ", Supplementary";
						String[] arrJointCif = jointCIF.split((";"));
						for (String cifID : arrJointCif) {
							KYC_Remediation.mLogger.debug("cifID of RP: " + cifID);
							String RPWINumber = "";
							String currentWS = "";
							String firstName = "";
							String middleName = "";
							String lastName = "";
							String riskProfile = "";
							String fullName = "";
							String query = "SELECT TOP 1 WINAME,CURRENT_WS,FirstName,MiddleName,LastName,RiskProfile "
									+ "FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE CIF_ID = '" + cifID
									+ "' ORDER BY CreatedAt desc";
							KYC_Remediation.mLogger.debug("query of RP: " + query);
							List<List<String>> dataRP = iform.getDataFromDB(query);
							KYC_Remediation.mLogger.debug("dataRP of RP: " + dataRP);
							if (!dataRP.isEmpty()) {
								KYC_Remediation.mLogger.debug("RP data on load - " + dataRP);
								for (List<String> data1 : dataRP) {
									RPWINumber = data1.get(0);
									currentWS = data1.get(1);
									firstName = data1.get(2);
									middleName = data1.get(3);
									lastName = data1.get(4);
									riskProfile = data1.get(5);
									if (!"".equalsIgnoreCase(middleName)) {
										fullName = firstName + " " + middleName + " " + lastName;
									} else
										fullName = firstName + " " + lastName;
									String insertQuery = "INSERT INTO NG_KYC_REM_IND_RP_GRID (WINAME,CIF_ID,RP_WI_NAME,WI_Status,CustomerName,RiskScore,RPType) "
											+ "VALUES('" + processinstanceID + "','" + cifID + "','" + RPWINumber
											+ "','" + currentWS + "','" + fullName.trim() + "','" + riskProfile + "','"
											+ RPType + "')";
									KYC_Remediation.mLogger.debug("insertQuery - " + insertQuery);
									int res = iform.saveDataInDB(insertQuery);
									KYC_Remediation.mLogger.debug("result of insert query - " + res);
								}
							} else {
								String insertQuery = "INSERT INTO NG_KYC_REM_IND_RP_GRID (WINAME,CIF_ID,RP_WI_NAME,WI_Status,CustomerName,RiskScore,RPType) "
										+ "VALUES('" + processinstanceID + "','" + cifID + "',NULL,NULL,NULL,NULL,'"
										+ RPType + "')";
								KYC_Remediation.mLogger.debug("insertQuery - " + insertQuery);
								int res = iform.saveDataInDB(insertQuery);
								KYC_Remediation.mLogger.debug("result of insert query - " + res);
							}
						}
					}
					
				} catch (Exception e) {
					KYC_Remediation.mLogger.debug("Exception in loading RP Grid : " + e);
				}
				
				iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SOL_ID", "visible", "false");
				
			} else if (("Corporate").equalsIgnoreCase(caseType)) {

				iform.setStyle("frame21", "visible", "false");// Ind RP Frame
				iform.setValue("label8", "KYC Remediation Entity");
				iform.setStyle("frame1", "visible", "false");
				iform.setStyle("frame2", "visible", "false");
				iform.setStyle("frame3", "visible", "false");
				iform.setStyle("frame14", "visible", "false");
				
				iform.setStyle("frame22", "visible", "false");
				iform.setStyle("frame23", "visible", "false");
				iform.setStyle("frame24", "visible", "false");
				iform.setStyle("frame25", "visible", "false");
				iform.setStyle("frame26", "visible", "false");
				iform.setStyle("frame27", "visible", "false");
				
				iform.setStyle("table12", "visible", "false");
				iform.setStyle("table13", "visible", "false");
				iform.setStyle("MonthlyIncome", "visible", "false");
				iform.setStyle("OtherSourceOfIncome", "visible", "false");
				iform.setStyle("OtherIncome", "visible", "false");
				iform.setStyle("GrossMonthlyIncome", "visible", "false");
				iform.setStyle("OfficeOccupation", "visible", "false");
				iform.setStyle("EstimatedWealth", "visible", "false");
				iform.setStyle("ProfEmpHistoryHekdFlag", "visible", "false");
				iform.setStyle("ListCountryMoneyToSent", "visible", "false");
				iform.setStyle("ListCountryMoneyToReceived", "visible", "false");
				iform.setStyle("CountryOfIncorporation", "visible", "false");
				// iform.setStyle("PEP","visible","false");
				iform.setStyle("IndustrySegment", "visible", "false");
				iform.setStyle("IndustrySubSegment", "visible", "false");
				iform.setStyle("CustomerClassification", "visible", "false");
				

				// iform.setStyle("DetailsOfPEP","visible","false");
				iform.setStyle("SourceOfWealth", "visible", "false");
				iform.setStyle("KYC_Review_Date", "visible", "false");
				// fatca

				iform.setStyle("ShareholderUSperson", "visible", "false");
				iform.setStyle("PlaceOfBirthUSA", "visible", "false");
				iform.setStyle("CurrentUSmailingOrResidenceAddress", "visible", "false");
				iform.setStyle("UStelephoneNumber", "visible", "false");

				iform.setStyle("StandingInstructions", "visible", "false");
				iform.setStyle("PowerOfAttorney", "visible", "false");
				iform.setStyle("USholdMailAddress", "visible", "false");
				iform.setStyle("UScitizenship_ResidencyDetails", "visible", "false");

				iform.setStyle("Certify", "visible", "false");
				iform.setStyle("USpassportHolder_GreencardHolder", "visible", "false");
				iform.setStyle("TIN_Field", "visible", "false");

				iform.setStyle("NotTaxResident", "visible", "false");
				iform.setStyle("FormObtained", "visible", "false");

				iform.setStyle("SignedDate", "visible", "false");
				iform.setStyle("ExpiryDate", "visible", "false");
				iform.setStyle("NoTINreason", "visible", "false");
				iform.setStyle("frame17", "visible", "true"); // BoD table
				iform.setStyle("frame16", "visible", "false"); // Documents for
																// outreach
																// section

				subSegment = (String)iform.getValue("subSegment");
				if(subSegment.equalsIgnoreCase("WBG")){
										
					if("RM_Vendor".equalsIgnoreCase(Workstep)){
						iform.setStyle("OutreachInitialDateTime", "disable", "false");
					} else{
						iform.setStyle("OutreachInitialDateTime", "disable", "true");
					}
				}
				
				String CustomerSubsegmentCode = (String) iform.getValue("Customer_Subsegment");
				if (!"SME".equalsIgnoreCase(CustomerSubsegmentCode)
						&& !"PSL".equalsIgnoreCase(CustomerSubsegmentCode)) {
					iform.setStyle("frame20", "visible", "false");
					iform.setStyle("Consequence_held_till", "visible", "false");
					iform.setStyle("AverageAnnualIncome", "visible", "false");
				}
				if (("SME".equalsIgnoreCase(CustomerSubsegmentCode) || "PSL".equalsIgnoreCase(CustomerSubsegmentCode))
						&& !"Consequence".equalsIgnoreCase(Workstep)) {
					iform.setStyle("Consequence_held_till", "visible", "false");
				}
				try {
					int size = iform.getDataFromGrid("table21").size(); // Licensed
																		// business
																		// activity
																		// grid.
					for (int i = 0; i < size; i++) {
						String existingSegment = iform.getTableCellValue("table21", i, 2);
						if ("".equalsIgnoreCase(existingSegment)) {
							String Segmentcode = "";
							String subsegment = iform.getTableCellValue("table21", i, 0);
							String query = "Select Top 1 MappedSegmentCode from NG_KYC_REM_Industry_SubSegment_MASTER WHERE SubSegment = '"
									+ subsegment + "'";
							List<List<String>> Segment = iform.getDataFromDB(query);
							if (!Segment.isEmpty()) {
								KYC_Remediation.mLogger.debug("Segment from Subsegment master - " + Segment);
								for (List<String> data1 : Segment) {
									Segmentcode = data1.get(0);
									iform.setTableCellValue("table21", i, 2, Segmentcode);
								}
							}
						}
					}
				} catch (Exception e) {
					KYC_Remediation.mLogger.debug("Exception in updating segment in Subsegment grid");
				}
				// for calculating next review date
				/*String subSegment = "";
				String query = "Select VAR_STR8 FROM WFINSTRUMENTTABLE with (nolock) WHERE processinstanceid = '"
						+ processinstanceID + "'";
				List<List<String>> Segment = iform.getDataFromDB(query);
				if (!Segment.isEmpty()) {
					KYC_Remediation.mLogger.debug("Sub Segment from wfinstrumenttable is - " + Segment);
					for (List<String> data1 : Segment) {
						subSegment = data1.get(0);
					}
				}*/
				/*
				 * if(!"BBG".equalsIgnoreCase(subSegment)){
				 * KYC_Remediation.mLogger.debug("setting not in case of BBG");
				 * nextReviewDate(iform,"EntityRiskProfile",event); }
				 */
				// end of calculating next review date
				setlengthofBusiness(iform);
				
				
								
				iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SOL_ID", "visible", "false");
				
			} else if (("RelatedParty").equalsIgnoreCase(caseType)) {
				iform.setStyle("frame21", "visible", "false");// Ind RP Frame
				iform.setStyle("DECISION", "mandatory", "false");
				iform.setStyle("Remarks", "mandatory", "false");
				iform.setValue("label8", "KYC Remediation Related Party");
				iform.setStyle("ShareholderSection", "visible", "false");
				iform.setStyle("frame11", "visible", "false");
				iform.setStyle("frame12", "visible", "false");
				iform.setStyle("frame13", "visible", "false");
				iform.setStyle("frame16", "visible", "false");
				iform.setStyle("frame1", "visible", "false");
				iform.setStyle("frame2", "visible", "false");
				iform.setStyle("frame3", "visible", "false");
				iform.setStyle("frame6", "visible", "false");
				iform.setStyle("frame7", "visible", "false");
				iform.setStyle("frame20", "visible", "false"); // Customer Communication section
				
				iform.setStyle("frame22", "visible", "false");
				iform.setStyle("frame23", "visible", "false");
				iform.setStyle("frame24", "visible", "false");
				iform.setStyle("frame25", "visible", "false");
				iform.setStyle("frame26", "visible", "false");
				iform.setStyle("frame27", "visible", "false");
				
				iform.setStyle("OfficeOccupation", "visible", "false");
				iform.setStyle("CountryOfIncorporation", "visible", "false");
				// fatca
				iform.setStyle("EntityOrganisedInUSA", "visible", "false");
				iform.setStyle("label7", "visible", "false");
				iform.setStyle("ActiveNFE", "visible", "false");
				iform.setStyle("PassiveNFE", "visible", "false");
				iform.setStyle("FinancialInstitution", "visible", "false");
				iform.setStyle("SecuritiesMarket", "visible", "false");
				iform.setStyle("RelatedEntity", "visible", "false");
				iform.setStyle("GIIN", "visible", "false");
				iform.setStyle("Risk_score_trigger", "visible", "false");

				iform.setStyle("evidenceOnSourceOfFunds", "visible", "false");
				iform.setStyle("KYC_Review_Date", "visible", "false");
				iform.setStyle("CountriesDealingWith", "visible", "false");
				iform.setStyle("Top5Suppliers", "visible", "false");
				iform.setStyle("Top5Buyers", "visible", "false");
				iform.setStyle("VAT_RegistrationNo", "visible", "false");
				iform.setStyle("CorporateTax", "visible", "false");
				iform.setStyle("DNFBP_Status", "visible", "false");
				iform.setStyle("NoOfEmployees", "visible", "false");
				iform.setStyle("AnnualTurnover", "visible", "false");
				iform.setStyle("Subsidiaries_Name", "visible", "false");
				iform.setStyle("Subsidiaries_Business", "visible", "false");
				iform.setStyle("SubsidiaryCountryOfOperation", "visible", "false");
				iform.setStyle("NetWorth", "visible", "false");
				iform.setStyle("HawalaActivity", "visible", "false");
				iform.setStyle("HawalaServiceProvider", "visible", "false");
				iform.setStyle("CorporateTaxRegDate", "visible", "false");
				iform.setStyle("AccountInformation", "visible", "false");
				iform.setStyle("DoYouMaintainAccount", "visible", "false");
				iform.setStyle("EstimatedWealth", "visible", "false");
				iform.setStyle("ExpectedMonthlyCreditTurnover", "visible", "false");

				iform.setStyle("MonthlyCashCRturnover", "visible", "false");
				iform.setStyle("MonthlyCashNoonCRturnover", "visible", "false");
				iform.setStyle("HighestCashCRtransaction", "visible", "false");
				iform.setStyle("HighestNonCashCrTransaction", "visible", "false");
				iform.setStyle("ProfEmpHistoryHekdFlag", "visible", "false");
				iform.setStyle("PurposeOfAccount", "visible", "false");
				iform.setStyle("table12", "visible", "false");
				iform.setStyle("table13", "visible", "false");
				iform.setStyle("DownstreamServiceVASP", "visible", "false");
				iform.setStyle("MonthlyIncome", "visible", "false");
				iform.setStyle("OtherSourceOfIncome", "visible", "false");
				iform.setStyle("OtherIncome", "visible", "false");
				iform.setStyle("GrossMonthlyIncome", "visible", "false");
				iform.setStyle("frame17", "visible", "false"); // BoD table
				iform.setStyle("ConsequenceManagementSection", "visible", "false");
				// JIRA 200
				iform.setStyle("IndustrySegment", "visible", "false");
				iform.setStyle("CustomerClassification", "visible", "false");
				iform.setStyle("IndustrySubSegment", "visible", "false");
				iform.setStyle("AverageAnnualIncome", "visible", "false");
				String sourceOfCapital = (String) iform.getValue("OwnerSourceOfCapital");
				if ("Any Other (Specify)".equalsIgnoreCase(sourceOfCapital)) {
					iform.setStyle("OwnerSourceCapitalOthers", "visible", "true");
				}

				KYC_Remediation.mLogger.debug("Updating back to RelatedParty");
				IFormXmlResponse xmlParserData = new IFormXmlResponse();
				StringBuffer ipXMLBuffer = new StringBuffer();
				String sCabname = getCabinetName(iform);
				KYC_Remediation.mLogger.debug("sCabname" + sCabname);
				String sSessionId = getSessionId(iform);
				KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
				/*
				 * int rowIndex = Integer.parseInt(data); String WINAme =
				 * iform.getTableCellValue("table4",rowIndex,1);
				 */
				String WINAME = getWorkitemName(iform);
				String qSubSegment = (String) iform.getValue("Mandatory_Field_List");
				String columnNames = "VAR_STR1,VAR_STR8";
				String columnValues = "'RelatedParty','" + qSubSegment + "'";
				String sWhereClause = "ProcessInstanceID ='" + WINAME + "' ";

				ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
				ipXMLBuffer.append("<APUpdate_Input>\n");
				ipXMLBuffer.append("<Option>APUpdate</Option>\n");
				ipXMLBuffer.append("<TableName>");
				ipXMLBuffer.append("WFINSTRUMENTTABLE");
				ipXMLBuffer.append("</TableName>\n");
				ipXMLBuffer.append("<ColName>");
				ipXMLBuffer.append(columnNames);
				ipXMLBuffer.append("</ColName>\n");
				ipXMLBuffer.append("<Values>");
				ipXMLBuffer.append(columnValues);
				ipXMLBuffer.append("</Values>\n");
				ipXMLBuffer.append("<WhereClause>");
				ipXMLBuffer.append(sWhereClause);
				ipXMLBuffer.append("</WhereClause>\n");
				ipXMLBuffer.append("<EngineName>");
				ipXMLBuffer.append(sCabname);
				ipXMLBuffer.append("</EngineName>\n");
				ipXMLBuffer.append("<SessionId>");
				ipXMLBuffer.append(sSessionId);
				ipXMLBuffer.append("</SessionId>\n");
				ipXMLBuffer.append("</APUpdate_Input>");

				String apUpdateinput = ipXMLBuffer.toString();
				KYC_Remediation.mLogger.debug("apUpdateinput--->" + apUpdateinput);
				String OutputXML = ExecuteQueryOnServer(apUpdateinput, iform);
				KYC_Remediation.mLogger.debug("sOutputXML--->" + OutputXML);

				// nextReviewDate(iform,"OwnerRiskProfile",event);
				setlengthofBusiness(iform);
				
				iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SOL_ID", "visible", "false");

			} else if(("FI").equalsIgnoreCase(caseType)) { // byVar
				
				// basic validations
				iform.setStyle("frame1", "visible", "false");
				iform.setStyle("frame14", "visible", "false");
				iform.setStyle("frame11", "visible", "false");
				iform.setStyle("frame2", "visible", "false");
				iform.setStyle("frame3", "visible", "false");
				iform.setStyle("frame12", "visible", "false");
				iform.setStyle("frame4", "visible", "false");
				iform.setStyle("ConsequenceManagementSection", "visible", "false");
				iform.setStyle("ShareholderSection", "visible", "false");
				iform.setStyle("frame17", "visible", "false");
				iform.setStyle("frame9", "visible", "false");
				iform.setStyle("frame13", "visible", "false");
				iform.setStyle("frame21", "visible", "false");
				iform.setStyle("frame10", "visible", "false");
				iform.setStyle("frame16", "visible", "false");
				iform.setStyle("frame20", "visible", "false");
				iform.setStyle("frame8", "visible", "false");
				
				iform.setStyle("Risk_score_trigger", "visible", "false");			
				iform.setStyle("Consequence_held_till", "visible", "false");				
				iform.setStyle("table22", "visible", "false");
				iform.setStyle("KYC_Download", "disable", "true");
				
				
				
				if ("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)) {
					
					// mandatory/non-mandatory
					String mandatoryFIFields[] = {"Q_NG_KYC_REM_FI_TR_TABLE_InstitutionName","Q_NG_KYC_REM_FI_TR_TABLE_InstitutionCountry","Q_NG_KYC_REM_FI_TR_TABLE_OfficeShopNo","Q_NG_KYC_REM_FI_TR_TABLE_Building","Q_NG_KYC_REM_FI_TR_TABLE_Street","Q_NG_KYC_REM_FI_TR_TABLE_CityEmirate","Q_NG_KYC_REM_FI_TR_TABLE_Country","Q_NG_KYC_REM_FI_TR_TABLE_InstitutionIDType","Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseNo","Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseIssueDate","Q_NG_KYC_REM_FI_TR_TABLE_InstitutionType","Q_NG_KYC_REM_FI_TR_TABLE_RiskProfile","Q_NG_KYC_REM_FI_TR_TABLE_LegalStatus","Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName","Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry","Q_NG_KYC_REM_FI_TR_TABLE_ParentPrincipalPlaceOp","Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType","Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo","Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate","Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate","Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress","Q_NG_KYC_REM_FI_TR_TABLE_BankRelationshipScope","Q_NG_KYC_REM_FI_TR_TABLE_GovtOwnershipFlag","Q_NG_KYC_REM_FI_TR_TABLE_ListedFlag","Q_NG_KYC_REM_FI_TR_TABLE_PEPHit","Q_NG_KYC_REM_FI_TR_TABLE_CustomerSegment","Q_NG_KYC_REM_FI_TR_TABLE_CustomerSubSegment","Q_NG_KYC_REM_FI_TR_TABLE_RMName","Q_NG_KYC_REM_FI_TR_TABLE_RMCode","Q_NG_KYC_REM_FI_TR_TABLE_ContactCountry","Q_NG_KYC_REM_FI_TR_TABLE_ContactCityEmirate","Q_NG_KYC_REM_FI_TR_TABLE_ContactEmail","Q_NG_KYC_REM_FI_TR_TABLE_CountryCode","Q_NG_KYC_REM_FI_TR_TABLE_ContactNumber","Q_NG_KYC_REM_FI_TR_TABLE_IsRegulated","Q_NG_KYC_REM_FI_TR_TABLE_ScreeningResults","Q_NG_KYC_REM_FI_TR_TABLE_SanctionsDeclared"};
					for(String field : mandatoryFIFields){
						iform.setStyle(field, "mandatory", "true");
					}
					
					// visible/not-visible
					
					
					// enabled/disabled
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SOL_ID", "disable", "false");			
					
					
					
					// validations start					
					
					
					if(!"Yes".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_ListedFlag"))){
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "disable", "true");
						
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "mandatory", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "mandatory", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "mandatory", "false");
						
						iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "");
						iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "");
						iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "");					
					} else {
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "disable", "false");
						
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "mandatory", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "mandatory", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "mandatory", "true");
					}
					
					String pepHit = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_PEPHit");				
					if(!"Yes".equalsIgnoreCase(pepHit)){
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefENC", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefOFAC", "disable", "true");
						
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "mandatory", "false");
					} else {
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefENC", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefOFAC", "disable", "false");
						
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "mandatory", "true");
					}
					
					if(!"Yes".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_IsRegulated"))){
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "disable", "true");
						
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "mandatory", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "mandatory", "false");
					} else {
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "disable", "false");
						
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "mandatory", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "mandatory", "true");
					}			
					
					if("".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_GIINNumber"))){
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_USRelationFlag", "mandatory", "true");
					} else {
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_USRelationFlag", "mandatory", "false");
					}
					
					// ExpiryDate logic
					String signedDate = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_SignedDate");
					if(!"".equalsIgnoreCase(signedDate)){
						DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // Set formatter				
						LocalDate originalDate = LocalDate.parse(signedDate, outputFormat); // Parse the string to LocalDate				
						LocalDate updatedExpDate = originalDate.plusYears(3); // Add 3 years				
						String updatedExpDateStr = updatedExpDate.format(outputFormat); // Convert back to string in the same format
						iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ExpiryDate", updatedExpDateStr);
					}
					
					if("Yes".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsDeclared"))){
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "mandatory", "true");
					} else {
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "mandatory", "false");
					}
					
					String IDType = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionIDType");
					if("AMIRI".equalsIgnoreCase(IDType))
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate", "disable", "true");
					else
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate", "disable", "false");
					
					
					String parentIDType = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType");
					if("AMIRI".equalsIgnoreCase(parentIDType)){
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "disable", "true");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "mandatory", "false");
					} else {
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "disable", "false");
						iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "mandatory", "true");
					}
					
					
					// Default
					if("".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_DocumentsAvailable"))){
						iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_DocumentsAvailable", "W8");
					}
				
				} else {
					iform.setStyle("frame22", "disable", "true");
					iform.setStyle("frame23", "disable", "true");
					iform.setStyle("frame24", "disable", "true");
					iform.setStyle("frame25", "disable", "true");
					iform.setStyle("frame26", "disable", "true");
					iform.setStyle("frame27", "disable", "true");
				}
				
				
				if ("Approver".equalsIgnoreCase(Workstep)){
					String instLicsExpDate = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate");
					if("".equals(instLicsExpDate))
						nextReviewDate(iform, "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate", event);
				}
				
				
				String institutionType = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionType");				
				if("Parent".equalsIgnoreCase(institutionType)){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName", "visible", "false");
//					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress", "visible", "false");					

					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName", "");
//					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress", "");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "visible", "false");
					
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "");
										
				} else{
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName", "visible", "true");
//					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress", "visible", "true");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "visible", "true");
				}
				
				try {
					int size = iform.getDataFromGrid("table38").size(); //Industry grid
					for (int i = 0; i < size; i++) {
						String existingSegment = iform.getTableCellValue("table38", i, 1);
						if ("".equalsIgnoreCase(existingSegment)) {
							String Segmentcode = "";
							String subsegment = iform.getTableCellValue("table38", i, 0);
							String query = "Select Top 1 MappedSegmentCode from NG_KYC_REM_Industry_SubSegment_MASTER WHERE SubSegment = '"
									+ subsegment + "'";
							List<List<String>> Segment = iform.getDataFromDB(query);
							if (!Segment.isEmpty()) {
								KYC_Remediation.mLogger.debug("Segment from Subsegment master - " + Segment);
								for (List<String> data1 : Segment) {
									Segmentcode = data1.get(0);
									iform.setTableCellValue("table38", i, 1, Segmentcode);
								}
							}
						}
					}
				} catch (Exception e) {
					KYC_Remediation.mLogger.debug("Exception in updating segment in Subsegment grid");
				}
			}
			// FI scope ends here

			
			// start here
			// String CustomerSubsegmentCode =
			// (String)iform.getValue("Customer_Subsegment");
			
			/*
			 * if("SME".equalsIgnoreCase(CustomerSubsegmentCode) ||
			 * "PSL".equalsIgnoreCase(CustomerSubsegmentCode)) {
			 * iform.setValue("subSegment","BBG"); } else if
			 * ("CBD".equalsIgnoreCase(CustomerSubsegmentCode)) {
			 * iform.setValue("subSegment","WBG"); } else {
			 * iform.setValue("subSegment","PBG"); }
			 */
			// stop here

			if ("RM_Vendor".equalsIgnoreCase(Workstep)) {
				iform.setValue("RMvendorUser", loggedInUser);
			}
			if ("Compliance".equalsIgnoreCase(Workstep)) {
				iform.setValue("ComplianceUser", loggedInUser);
			}
			if ("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)) {
				iform.setValue("MakerUser", loggedInUser);
				// iform.clearTable("table22");
				int DefDocCount = iform.getDataFromGrid("table22").size();
				if (DefDocCount > 0) {
					iform.setStyle("table22", "visible", "true");
				} else {
					iform.setStyle("table22", "visible", "false");
				}
				
				
				if ("Maker2".equalsIgnoreCase(Workstep))
					iform.setStyle("table29", "disable", "true");
				
			}
			String hiddenRemarks = (String) iform.getValue("Change_Field_List");
			String[] WS_remarks = hiddenRemarks.split("-");
			String WS = WS_remarks[0];
			if (!WS.equalsIgnoreCase(Workstep)) {
				iform.setValue("Remarks", "");
			}
			String savedDecision = (String) iform.getValue("DECISION");
			iform.setValue("DECISION", "");
			iform.clearCombo("DECISION");

			String previous_WS = (String) iform.getValue("PREV_WS");
			if (("RM_Vendor".equalsIgnoreCase(previous_WS) || "Consequence".equalsIgnoreCase(previous_WS)) && "Doc_Error_Handling".equalsIgnoreCase(Workstep)) {
				iform.addItemInCombo("DECISION", "Re-Integrate");
				iform.addItemInCombo("DECISION", "Do not Integrate");
			}
			String query = "Select Decision FROM NG_MASTER_KYC_REM_Decision WHERE WorkstepName = '" + Workstep
					+ "' AND Is_Active = 'Y'";
			List<List<String>> dataFromDB = iform.getDataFromDB(query);
			for (List<String> listValue : dataFromDB) {
				for (String valueIs : listValue) {
					if(!"FI".equalsIgnoreCase(caseType)){
						if (!(("RM_Vendor".equalsIgnoreCase(previous_WS) || "Consequence".equalsIgnoreCase(previous_WS))
								&& "Doc_Error_Handling".equalsIgnoreCase(Workstep))) {
							KYC_Remediation.mLogger.debug("Value is --" + valueIs);
							
							
							if ((caseType).equalsIgnoreCase("Corporate") && subSegment.equalsIgnoreCase("BBG")
									&& "Customer Outreach".equalsIgnoreCase(valueIs) && "Maker2".equalsIgnoreCase(Workstep))
								KYC_Remediation.mLogger.debug("Not adding Customer Outreach decision in BBG case on Maker 2 queue");
							
							
							else if ((caseType).equalsIgnoreCase("Corporate") && subSegment.equalsIgnoreCase("WBG")
									&& ("Customer Outreach".equalsIgnoreCase(valueIs) || "Remove Consequence".equalsIgnoreCase(valueIs)))
								KYC_Remediation.mLogger.debug("Not adding Customer Outreach or Remove Consequence decision in WBG case");
							
							else if ((caseType).equalsIgnoreCase("Corporate") && subSegment.equalsIgnoreCase("WBG")
									&& "Initiate Consequence".equalsIgnoreCase(valueIs))
								KYC_Remediation.mLogger.debug("Not adding Customer Outreach decision in WBG case");
							
							else if (((caseType).equalsIgnoreCase("Individual")
									&& "Customer Notification".equalsIgnoreCase(valueIs))
									|| ((caseType).equalsIgnoreCase("Corporate") && subSegment.equalsIgnoreCase("WBG")
											&& "Customer Notification".equalsIgnoreCase(valueIs)))
								KYC_Remediation.mLogger.debug("Not adding Customer Notification decision in Individual case or WBG case");
							
							else
								iform.addItemInCombo("DECISION", valueIs);
						}
						
					} else{
						KYC_Remediation.mLogger.debug("in FI case type for decisions");
						if("Customer Notification".equalsIgnoreCase(valueIs) || "Initiate Consequence".equalsIgnoreCase(valueIs) ||
								"Customer Outreach".equalsIgnoreCase(valueIs) || "Remove Consequence".equalsIgnoreCase(valueIs) || "Send to KYC Consequence".equalsIgnoreCase(valueIs))
							continue;
						

						KYC_Remediation.mLogger.debug("adding decision: "+ valueIs);
						iform.addItemInCombo("DECISION", valueIs);
					}
				}
			}

			
			if ("RM_Vendor".equalsIgnoreCase(Workstep) || "Maker".equalsIgnoreCase(Workstep)) {

				
				int rowCount = iform.getDataFromGrid("table29").size();
				String str = iform.getTableCellValue("table29", rowCount - 1, 4);
				if ("".equals(str)) {
					String s = iform.getTableCellValue("table29", rowCount - 1, 6);
					KYC_Remediation.mLogger.debug("savedDecision: " + savedDecision);
					KYC_Remediation.mLogger.debug("tableDataArr scope: " + s);

					String tableDataArr[] = s.split("~");
					int len = tableDataArr.length;
					if (len > 0) {
						String decision = tableDataArr[len - 1];
						iform.setValue("DECISION", decision);
					}
				}
			}
			

			KYC_Remediation.mLogger.debug("Disabling frames if workstep not maker");
			if ("RM_Vendor".equalsIgnoreCase(Workstep) || "Compliance".equalsIgnoreCase(Workstep)
					|| "Approver".equalsIgnoreCase(Workstep) || "Controls".equalsIgnoreCase(Workstep)
					|| "Remediated_Cases".equalsIgnoreCase(Workstep) || "Consequence".equalsIgnoreCase(Workstep)
					|| "Email_Hold".equalsIgnoreCase(Workstep)) {
				iform.setStyle("frame1", "disable", "true");
				iform.setStyle("frame2", "disable", "true");
				iform.setStyle("frame3", "disable", "true");
				iform.setStyle("frame4", "disable", "true");
				
				
				if (!"RM_Vendor".equalsIgnoreCase(Workstep))
					iform.setStyle("table29", "disable", "true"); // customer
														// communication
																	// table
				// iform.setStyle("frame13","disable","true");
				// iform.setStyle("frame11","disable","true");
				iform.setStyle("NameOfCompany", "disable", "true");
				iform.setStyle("DateOfBusinessEstablishment", "disable", "true");
				iform.setStyle("LegalEntity", "disable", "true");

				iform.setStyle("TradeLicenseDate", "disable", "true");

				iform.setStyle("TLIssueAuthority", "disable", "true");
				iform.setStyle("EntityCountryOfIncorporation", "disable", "true");

				iform.setStyle("NoOfBranches", "disable", "true");
				iform.setStyle("Customer_Base", "disable", "true");
				iform.setStyle("ListedInStockExchange", "disable", "true");
				iform.setStyle("CustomerWebsite", "disable", "true");

				iform.setStyle("CommercialRegNo", "disable", "true");
				iform.setStyle("CustomerBackground", "disable", "true");
				iform.setStyle("table10", "disable", "true");
				if ("WBG".equalsIgnoreCase(subSegment) || ("BBG".equalsIgnoreCase(subSegment)
						&& ("Compliance".equalsIgnoreCase(Workstep) || "Remediated_Cases".equalsIgnoreCase(Workstep)
								|| "Email_Hold".equalsIgnoreCase(Workstep)))) {
					iform.setStyle("table21", "disable", "true");
					iform.setStyle("EntityRiskProfile", "disable", "true");
					iform.setStyle("EntityTLNumber", "disable", "true");
					iform.setStyle("TradeLicenseExpiryDate", "disable", "true");
				}
				if ("BBG".equalsIgnoreCase(subSegment)
						&& (!"Compliance".equalsIgnoreCase(Workstep) && !"Remediated_Cases".equalsIgnoreCase(Workstep)
								&& !"Email_Hold".equalsIgnoreCase(Workstep))) {
					iform.setStyle("AnnualTurnover", "disable", "false");
					iform.setStyle("ExpectedMonthlyCreditTurnover", "disable", "false");
					iform.setStyle("MonthlyCashCRturnover", "disable", "false");
					iform.setStyle("MonthlyCashNoonCRturnover", "disable", "false");
					iform.setStyle("HighestCashCRtransaction", "disable", "false");
					iform.setStyle("HighestNonCashCrTransaction", "disable", "false");
					iform.setStyle("Top5Suppliers", "disable", "false");
					iform.setStyle("Top5Buyers", "disable", "false");
					iform.setStyle("DNFBP_Status", "disable", "false");
				}
				//
				iform.setStyle("frame12", "disable", "true");
				iform.setStyle("frame9", "disable", "true");
				iform.setStyle("frame14", "disable", "true");
				iform.setStyle("ShareholderSection", "disable", "true");
				if (!"Approver".equalsIgnoreCase(Workstep)) {
					iform.setStyle("Risk_score_trigger", "disable", "true");
				}
				iform.setStyle("table22", "visible", "true");
				iform.setStyle("table22", "disable", "true");
			}

			if ("Corporate".equalsIgnoreCase("caseType")) {
				iform.setStyle("frame13", "visible", "true");
				iform.setStyle("frame11", "visible", "true");
				iform.setStyle("frame12", "visible", "true");

			}
			
			if ("Corporate".equalsIgnoreCase(caseType)) {
				if("Controls".equalsIgnoreCase(Workstep)){
					iform.setStyle("VAT_RegistrationNo", "disable", "false");
					iform.setStyle("CorporateTax", "disable", "false");
				}
			}

			if ("Approver".equalsIgnoreCase(Workstep)) {
				int rowCount = iform.getDataFromGrid("table25").size();
				String ConsequenceRowCount = (String) iform.getValue("ConsequenceRowCount");
				KYC_Remediation.mLogger.debug("Consequence row count..." + ConsequenceRowCount);
				if (!"".equalsIgnoreCase(ConsequenceRowCount)) {
					if (Integer.parseInt(ConsequenceRowCount) > 0) {
						String statusVAlue = iform.getTableCellValue("table25",
								Integer.parseInt(ConsequenceRowCount) - 1, 0);
						if ("Partial Applied".equalsIgnoreCase(statusVAlue)
								|| "Fully Applied".equalsIgnoreCase(statusVAlue)) {
							iform.setStyle("table25", "disable", "false");
						} else {
							iform.setStyle("table25", "disable", "true");
						}
					} else {
						iform.setStyle("table25", "disable", "true");
					}
				} else {
					iform.setStyle("table25", "disable", "true");
				}
			} else {
				if (!"Consequence".equalsIgnoreCase(Workstep))
					iform.setStyle("table25", "disable", "true");
			}
			/*
			 * if("Consequence".equalsIgnoreCase(Workstep)){ String outreachFlag
			 * = (String)iform.getValue("CustomerOutreachFlag");
			 * KYC_Remediation.mLogger.debug("outreachFlag - "+outreachFlag);
			 * int rowCount = iform.getDataFromGrid("Outreach_Grid").size();
			 * KYC_Remediation.mLogger.debug("rowCount - "+rowCount);
			 * if(("".equalsIgnoreCase(outreachFlag) || "Offline Outreach"
			 * .equalsIgnoreCase(outreachFlag)) && rowCount == 0){
			 * KYC_Remediation.mLogger.debug("inside if of consequence");
			 * iform.setStyle("frame16","disable","false");
			 * //iform.setStyle("Outreach_Grid","disable","false"); } }
			 */

			String strReturn = "";
			String RiskProfile = (String) iform.getValue("RiskProfileDesc");
			if (caseType.equalsIgnoreCase("Individual") && ("High".equalsIgnoreCase(RiskProfile))) {
				String persona = (String) iform.getValue("CIFPersona");
				persona = persona.trim();
				persona = persona.replaceAll(" ", "");
				KYC_Remediation.mLogger.debug("persona - " + persona);
				String cusType = (String) iform.getValue("CusType");
				cusType = cusType.trim();
				KYC_Remediation.mLogger.debug("cusType - " + cusType);
				Properties properties = new Properties();
				properties.load(new FileInputStream(System.getProperty("user.dir")
						+ System.getProperty("file.separator") + "CustomConfig" + System.getProperty("file.separator")
						+ "KYC_Remediation" + System.getProperty("file.separator") + "KYC_Config.properties"));
				String tag = cusType + "_" + persona;
				tag = tag.trim();
				KYC_Remediation.mLogger.debug("tag - " + tag);
				String mandatoryFields = properties.getProperty(tag);
				KYC_Remediation.mLogger.debug("mandatoryFields - " + mandatoryFields);
				String[] mandatoryField = mandatoryFields.split(",");
				for (String field : mandatoryField) {
					KYC_Remediation.mLogger.debug("setting mandatory");
					iform.setStyle(field, "backcolor", "#ffc1c175");
					// iform.setStyle(field,"mandatory","true");
				}
			}
			RiskProfile = (String) iform.getValue("RiskProfileDesc");
			KYC_Remediation_Change.handleLowMedValidations(iform, "load");

			return strReturn;
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Error in formload event");
			KYC_Remediation.mLogger.debug("Exception - " + e.toString());
		}
		return "";
	}

}
