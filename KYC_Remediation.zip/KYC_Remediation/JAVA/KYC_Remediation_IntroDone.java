package com.newgen.iforms.user;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;

public class KYC_Remediation_IntroDone extends KYC_Remediation_Common {
	@SuppressWarnings("unchecked")
	public String onIntroduceDone(IFormReference iform, String controlName, String event, String data) {
		String processinstanceID = getWorkitemName(iform);
		KYC_Remediation.mLogger.debug("This is KYC_IntroDone_Event WI Number is - " + processinstanceID);
		String Workstep = iform.getActivityName();
		String caseType = (String) iform.getValue("CaseType");
		String strReturn = "";
		String Decision = (String) iform.getValue("DECISION");
		String consStatus = "";
		String consAction = "";
		String ConsequenceRowCount = "";
		KYC_Remediation.mLogger.debug("Consequence row count..." + ConsequenceRowCount);
		int ConsequenceRowCountGrid = iform.getDataFromGrid("table25").size();
		KYC_Remediation.mLogger.debug("ConsequenceRowCountGrid..." + ConsequenceRowCountGrid);
		if ("InsertIntoHistory".equals(controlName)) {
			try {
				if (caseType.equalsIgnoreCase("Corporate") && Workstep.equalsIgnoreCase("Maker")
						&& (Decision.equalsIgnoreCase("Customer Outreach")
								|| Decision.equalsIgnoreCase("Customer Notification"))) {
					String email = (String) iform.getValue("CompanyEmailID");
					String squery = "select PREFERRED_EMAIL from NG_KYC_REM_BO_IBPS_TABLE with(nolock) where Wi_Name = '"
							+ processinstanceID + "'";
					KYC_Remediation.mLogger.debug("query address: " + squery);
					List<List<String>> sdataFromDB = iform.getDataFromDB(squery);
					KYC_Remediation.mLogger.debug("dataFromDB: " + sdataFromDB);
					if (!sdataFromDB.isEmpty()) {
						String PREFERRED_EMAIL = sdataFromDB.get(0).get(0);
						if (!PREFERRED_EMAIL.equalsIgnoreCase(email))
							return "EmailID@Move this WI to RM Vendor as Company Email ID is changed.";
					}
					int rowCountRP = Integer.parseInt(data);
					for (int i = 0; i < rowCountRP; i++) {
						String WIName = iform.getTableCellValue("table4", i, 1);
						KYC_Remediation.mLogger.debug("WIName RP Address: " + WIName);
						String query = "SELECT  NG.PREFERRED_EMAIL AS Email_From_BO_Table, RB.OwnerEmailID AS "
								+ "Email_From_EXT_Table FROM NG_KYC_REM_BO_IBPS_TABLE NG WITH (NOLOCK) JOIN "
								+ "RB_KYC_REM_EXTTABLE RB WITH (NOLOCK) ON NG.Wi_Name = RB.WINAME "
								+ "WHERE NG.Wi_Name = '" + WIName + "';";
						KYC_Remediation.mLogger.debug("query address: " + query);
						List<List<String>> dataFromDB = iform.getDataFromDB(query);
						KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
						if (!dataFromDB.isEmpty()) {
							String Email_From_BO_Table = dataFromDB.get(0).get(0);
							String Email_From_EXT_Table = dataFromDB.get(0).get(1);
							if (!Email_From_BO_Table.equalsIgnoreCase(Email_From_EXT_Table))
								return "EmailID@Move this WI to RM Vendor as EmailID changed for Related Party";
						}
					}

				}
				if (caseType.equalsIgnoreCase("Corporate")
						&& (Workstep.equalsIgnoreCase("Maker") || Workstep.equalsIgnoreCase("RM_Vendor"))
						&& (Decision.equalsIgnoreCase("Customer Outreach")
								|| Decision.equalsIgnoreCase("Customer Notification"))) {
					String res = checkKYCForm(iform, processinstanceID);
					if ("KYCMain".equalsIgnoreCase(res))
						return "KYCForm@Please generate KYC form for Company";
					if (res.startsWith("KYCRP"))
						return "KYCForm" + res.substring(5);
				}
				if ((caseType.equalsIgnoreCase("Individual") && Workstep.equalsIgnoreCase("Maker2")
						&& Decision.equalsIgnoreCase("Submit to Approver"))
						|| (caseType.equalsIgnoreCase("Individual") && Workstep.equalsIgnoreCase("Approver")
								&& Decision.equalsIgnoreCase("Approved"))) {
					String PrefAddress = (String) iform.getValue("PreferredAddressFlag");
					if ("".equalsIgnoreCase(PrefAddress))
						return "Deficient Address @ Please select Preferred Address.";
					else if ("OFFICE".equalsIgnoreCase(PrefAddress)) {
						String AddLine1 = (String) iform.getValue("OfficeAddressLine1");
						String Country = (String) iform.getValue("OfficeCountry");
						String city = (String) iform.getValue("OfficeCityEmirate");
						if ("".equalsIgnoreCase(AddLine1) && "".equalsIgnoreCase(Country) && "".equalsIgnoreCase(city))
							return "Deficient Address @ Please enter Address Line 1, City and Country in Office address";
						if ("".equalsIgnoreCase(AddLine1))
							return "Deficient Address @ Please enter Address Line 1 in office address.";
						if ("".equalsIgnoreCase(Country))
							return "Deficient Address @ Please enter country in office address.";
						if ("".equalsIgnoreCase(city))
							return "Deficient Address @ Please enter city in office address.";

					} else if ("RESIDENCE".equalsIgnoreCase(PrefAddress)) {
						String AddLine1 = (String) iform.getValue("ResidenceFlatVillaNo");
						String Country = (String) iform.getValue("ResidenceCountry");
						String city = (String) iform.getValue("ResidenceEmirateCity");
						if ("".equalsIgnoreCase(AddLine1) && "".equalsIgnoreCase(Country) && "".equalsIgnoreCase(city))
							return "Deficient Address @ Please enter Flat Villa No, City and Country in Residence address";
						if ("".equalsIgnoreCase(AddLine1))
							return "Deficient Address @ Please enter Flat Villa No in Residence address.";
						if ("".equalsIgnoreCase(Country))
							return "Deficient Address @ Please enter country in Residence address.";
						if ("".equalsIgnoreCase(city))
							return "Deficient Address @ Please enter city in Residence address.";
					} else
						return "Deficient Address @ Incorrect Preferred Address";
				}
				if ((caseType.equalsIgnoreCase("Corporate") && Workstep.equalsIgnoreCase("Maker2")
						&& Decision.equalsIgnoreCase("Submit to Approver"))
						|| (caseType.equalsIgnoreCase("Corporate") && Workstep.equalsIgnoreCase("Approver")
								&& Decision.equalsIgnoreCase("Approved"))) {
					String PrefAddress = (String) iform.getValue("CompanyPreferredAddress");
					if ("".equalsIgnoreCase(PrefAddress))
						return "Deficient Address @ Please select Preferred Address.";

					String AddLine1 = (String) iform.getValue("CompanyofficeShopNo");
					String Country = (String) iform.getValue("CompanyCountry");
					String city = (String) iform.getValue("CompanyEmirateCity");
					if ("".equalsIgnoreCase(AddLine1) && "".equalsIgnoreCase(Country) && "".equalsIgnoreCase(city))
						return "Deficient Address @ Please enter Office/Shop No, City and Country in address.";
					if ("".equalsIgnoreCase(AddLine1))
						return "Deficient Address @ Please enter Office/Shop No";
					if ("".equalsIgnoreCase(Country))
						return "Deficient Address @ Please enter Country";
					if ("".equalsIgnoreCase(city))
						return "Deficient Address @ Please enter City";

					int rowCountRP = Integer.parseInt(data);
					for (int i = 0; i < rowCountRP; i++) {
						String WIName = iform.getTableCellValue("table4", i, 1);
						KYC_Remediation.mLogger.debug("WIName RP Address: " + WIName);
						String query = "select OwnerPrefAddress,OwnerResidentialAddress,OwnerCity,OwnerCountry from RB_KYC_REM_EXTTABLE with(nolock) where WINAME = '"
								+ WIName + "'";
						KYC_Remediation.mLogger.debug("query address: " + query);
						List<List<String>> dataFromDB = iform.getDataFromDB(query);
						KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
						if (!dataFromDB.isEmpty()) {
							String OwnerPrefAddress = dataFromDB.get(0).get(0);
							String OwnerResidentialAddress = dataFromDB.get(0).get(1);
							String OwnerCity = dataFromDB.get(0).get(2);
							String OwnerCountry = dataFromDB.get(0).get(3);

							if ("".equalsIgnoreCase(OwnerPrefAddress))
								return "Deficient Address @ Preferred Address not present for related Party " + WIName;

							if ("".equalsIgnoreCase(OwnerResidentialAddress) && "".equalsIgnoreCase(OwnerCity)
									&& "".equalsIgnoreCase(OwnerCountry))
								return "Deficient Address @ Please enter Flat Villa No, City and Country for related party "
										+ WIName;
							if ("".equalsIgnoreCase(OwnerResidentialAddress))
								return "Deficient Address @ Please enter Flat Villa No for related party " + WIName;
							if ("".equalsIgnoreCase(OwnerCity))
								return "Deficient Address @ Please enter City for related party " + WIName;
							if ("".equalsIgnoreCase(OwnerCountry))
								return "Deficient Address @ Please enter Country for related party " + WIName;
						}
					}
				}
				
				if("FI".equalsIgnoreCase(caseType)){ // byVar
					KYC_Remediation.mLogger.debug("Inside FI caseType, IntroDone scope.");
					
					// FI Shareholding Grid % logic
					int rowCount = iform.getDataFromGrid("table41").size();
					double totalPrcnt = 0.0;
					for(int i=0; i<rowCount; i++){
						String str = iform.getTableCellValue("table41", i, 5);
						totalPrcnt += Double.parseDouble("".equalsIgnoreCase(str) ? "0.0" : str);						
					}
					
					if(totalPrcnt > 100.0) return "FI SH percentage more than 100";
					
				}
				
				if ("Approver".equalsIgnoreCase(Workstep)) {
					String gridName = "";
					if ("Corporate".equalsIgnoreCase(caseType)) {
						gridName = "table21";
					} else if("FI".equalsIgnoreCase(caseType)){
						gridName = "table38";
					} else {
						gridName = "IndustrySubSegmentGrid";
					}
					int industrySize = iform.getDataFromGrid(gridName).size();
					KYC_Remediation.mLogger.debug("Size of grid is --" + industrySize);
					String code = "";
					String RiskRating = "";
					String FinalIndustry = "";
					String segment = "";
					String FinalSegment = "";
					BigDecimal riskScore = new BigDecimal(0);
					for (int i = 0; i < industrySize; i++) {
						String SubSegment = iform.getTableCellValue(gridName, i, 0);
						KYC_Remediation.mLogger.debug("SubSegment--" + SubSegment);
						String query = "SELECT DISTINCT RiskScore,Finacle_Code,MappedSegmentCode FROM NG_KYC_REM_Industry_SubSegment_MASTER"
								+ " with(nolock) where SubSegment = '" + SubSegment + "'";
						List<List<String>> dataFromDB = iform.getDataFromDB(query);
						KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
						if (!dataFromDB.isEmpty()) {
							RiskRating = dataFromDB.get(0).get(0);
							code = dataFromDB.get(0).get(1);
							segment = dataFromDB.get(0).get(2);
							KYC_Remediation.mLogger.debug("RiskRating: " + RiskRating);
							KYC_Remediation.mLogger.debug("code: " + code);
							KYC_Remediation.mLogger.debug("segment: " + segment);
							if (0 == i) {
								riskScore = new BigDecimal(RiskRating);
								FinalIndustry = code;
								FinalSegment = segment;
								KYC_Remediation.mLogger.debug("i if if: " + i);
							} else {
								BigDecimal rs = new BigDecimal(RiskRating);
								if (rs.compareTo(riskScore) > 0) {
									riskScore = rs;
									FinalIndustry = code;
									FinalSegment = segment;
									KYC_Remediation.mLogger.debug("i in else: " + i);
								}
							}
						}
					}
					if (!"".equalsIgnoreCase(FinalIndustry)) {
						iform.setValue("IndustrySubSegment", FinalIndustry);
						iform.setValue("IndustrySegment", FinalSegment);
					}
					// nextReviewDate calculation starts

					// setting next review date for Individual cases
					String staggeredRiskScore = (String) iform.getValue("EntityRiskProfile");
					String query = "SELECT var_str8 FROM WFINSTRUMENTTABLE WITH(NOLOCK) WHERE ProcessInstanceID ='"
							+ processinstanceID + "' AND WorkItemId = '1'";
					List<List<String>> dataFromDB = iform.getDataFromDB(query);
					KYC_Remediation.mLogger.debug("dataFromDB1: " + dataFromDB);
					String type = (String) dataFromDB.get(0).get(0);

					KYC_Remediation.mLogger.debug("caseType: " + caseType);
					/*
					if ("Approved".equalsIgnoreCase(Decision)) {
						if ("Individual".equalsIgnoreCase(caseType)) // bbg
							nextReviewDate(iform, "RiskProfile", event);
						if ("Corporate".equalsIgnoreCase(caseType) && !"".equalsIgnoreCase(staggeredRiskScore)) {
							if ("WBG".equalsIgnoreCase(type) || "PBG".equalsIgnoreCase(type) || ("BBG".equalsIgnoreCase(type) && Float.parseFloat(staggeredRiskScore) < 4.0))
								nextReviewDate(iform, "EntityRiskProfile", event);
						
						} else if("FI".equalsIgnoreCase(caseType)){
							nextReviewDate(iform, "Q_NG_KYC_REM_FI_TR_TABLE_RiskProfile", event);
						}
					}
					*/
					
					if ("Approved".equalsIgnoreCase(Decision)) {
						KYC_Remediation.mLogger.debug("Inside Decision check for KYC Review Date.");
						if ("PBG".equalsIgnoreCase(type)){
							if("Corporate".equalsIgnoreCase(caseType)) 
								nextReviewDate(iform, "EntityRiskProfile", event);
							else 
								nextReviewDate(iform, "RiskProfile", event);
							
						} else if ("WBG".equalsIgnoreCase(type) || "BBG".equalsIgnoreCase(type)){						
							nextReviewDate(iform, "EntityRiskProfile", event);
							
						} else if("FI".equalsIgnoreCase(caseType)){
							nextReviewDate(iform, "Q_NG_KYC_REM_FI_TR_TABLE_RiskProfile", event);
						}
						
					} else if("Send Back to Maker".equalsIgnoreCase(Decision)){
						iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate", "");
					}
					

					if (!"".equalsIgnoreCase(staggeredRiskScore)) {
						if ("Approved".equalsIgnoreCase(Decision)
								&& (Float.parseFloat(staggeredRiskScore) > 4.0
										&& Float.parseFloat(staggeredRiskScore) <= 5.0)
								&& "Corporate".equalsIgnoreCase(caseType) && "BBG".equalsIgnoreCase(type)) {
							KYC_Remediation.mLogger.debug("inside high risk block.");
							query = "SELECT VariableKey, VariableValue FROM NG_KYC_REM_Staggered_Count_Table WHERE VariableKey IN ('WI_Count_Sys_Integration','Review_Date_Months_Count','BucketSize') AND TYPE='BBGHighRisk'";
							dataFromDB = iform.getDataFromDB(query); // NG_KYC_REM_Staggered_Count_Table
							KYC_Remediation.mLogger.debug("dataFromDB fro staggered table: " + dataFromDB);
							Integer WI_Count = 0, month_Count = 0, Modulo = 0;
							for (int i = 0; i < 3; i++) {
								if ("WI_Count_Sys_Integration".equalsIgnoreCase(dataFromDB.get(i).get(0)))
									WI_Count = Integer.parseInt(dataFromDB.get(i).get(1)) + 1;
								else if ("Review_Date_Months_Count".equalsIgnoreCase(dataFromDB.get(i).get(0)))
									month_Count = Integer.parseInt(dataFromDB.get(i).get(1));
								else if ("BucketSize".equalsIgnoreCase(dataFromDB.get(i).get(0)))
									Modulo = Integer.parseInt(dataFromDB.get(i).get(1));
							}
							String columnNames = "VariableValue";
							String columnValues = "'" + WI_Count + "'";
							String sWhereClause = "VariableKey = 'WI_Count_Sys_Integration'";
							updateTable(iform, columnNames, columnValues, sWhereClause,
									"NG_KYC_REM_Staggered_Count_Table"); // updating
																			// WI_count
							KYC_Remediation.mLogger.debug("WI_Count: " + WI_Count);
							KYC_Remediation.mLogger.debug("month_Count: " + month_Count);
							KYC_Remediation.mLogger.debug("WI_Count: " + WI_Count);
							if (WI_Count % Modulo == 0) {
								KYC_Remediation.mLogger.debug("inside modulo calc block");
								month_Count++;
								columnNames = "VariableValue";
								columnValues = "'" + month_Count + "'";
								sWhereClause = "VariableKey = 'Review_Date_Months_Count'";
								updateTable(iform, columnNames, columnValues, sWhereClause,
										"NG_KYC_REM_Staggered_Count_Table"); // updating
																				// months
							}
							// updating ReviewDate
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss.SSSS");
							LocalDateTime addedDateTime = LocalDateTime.now().plusMonths(month_Count);
							KYC_Remediation.mLogger.debug("addedDateTime: " + addedDateTime);

							LocalDate lastDayOfMonth = addedDateTime.toLocalDate()
									.with(TemporalAdjusters.lastDayOfMonth());
							KYC_Remediation.mLogger.debug("lastDayOfMonth: " + lastDayOfMonth);
							LocalDateTime lastDateOfMonth = lastDayOfMonth.atTime(addedDateTime.toLocalTime());
							KYC_Remediation.mLogger.debug("lastDateOfMonth: " + lastDateOfMonth);

							String formattedLastDate = lastDateOfMonth.format(df);
							KYC_Remediation.mLogger.debug("formattedLastDate: " + formattedLastDate);

							iform.setValue("NextReviewDate", formattedLastDate);
						}
					}
					// nextReviewDateCalc ends
				}
				/*
				 * if("Remediated_Cases".equalsIgnoreCase(Workstep)){ String
				 * Decision = (String)iform.getValue("DECISION");
				 * if("Corporate".equalsIgnoreCase(caseType) &&
				 * ("Expired".equalsIgnoreCase(Decision) ||
				 * "Complete".equalsIgnoreCase(Decision))){ String CIF_ID =
				 * (String) iform.getValue("CIF_ID");
				 * iform.setValue("CompanyCIF", CIF_ID);
				 * iform.setValue("CIF_ID", ""); } }
				 */
				if ("Consequence".equalsIgnoreCase(Workstep) || "Approver".equalsIgnoreCase(Workstep)) {
					ConsequenceRowCount = (String) iform.getValue("ConsequenceRowCount");
					KYC_Remediation.mLogger.debug("Consequence row count..." + ConsequenceRowCount);
					ConsequenceRowCountGrid = iform.getDataFromGrid("table25").size();
					KYC_Remediation.mLogger.debug("ConsequenceRowCountGrid..." + ConsequenceRowCountGrid);

					if ("Consequence".equalsIgnoreCase(Workstep)) {
						if (ConsequenceRowCountGrid > 0) {
							if (!(ConsequenceRowCountGrid == Integer.parseInt(ConsequenceRowCount) + 1)) {
								// if(ConsequenceRowCountGrid==Integer.parseInt(ConsequenceRowCount))
								// return "ErrorConsequence";
								for (int i = Integer.parseInt(ConsequenceRowCount); i < ConsequenceRowCountGrid; i++) {
									if (i > Integer.parseInt(ConsequenceRowCount)) {
										String status = (String) iform.getTableCellValue("table25", i, 0);
										String previousStatus = (String) iform.getTableCellValue("table25", i - 1, 0);
										if (!(status.equalsIgnoreCase(previousStatus)
												&& "Partial Applied".equalsIgnoreCase(previousStatus))) {
											return "ErrorConsequence1";
										}
									}
								}
							}
						}
						if ("Corporate".equalsIgnoreCase(caseType) && "BBG".equalsIgnoreCase((String)iform.getValue("subSegment"))) {
							String response = checkConsequenceHeldTill(iform, ConsequenceRowCount,
									ConsequenceRowCountGrid);
							if (!"true".equalsIgnoreCase(response))
								return response;
						}
						if(!"WBG".equalsIgnoreCase((String)iform.getValue("subSegment"))){
						String res = validateConsequenceDecision(iform, ConsequenceRowCount, ConsequenceRowCountGrid);
						if (!"true".equalsIgnoreCase(res))
							return res;
						}
						// 3 march change remove mandatory entryfrom consequence
						// grid even if consequence grid is empty
						// if(ConsequenceRowCountGrid==0) return
						// "ErrorConsequence";
						// 3 march change remove mandatory entryfrom consequence
						// grid even if consequence grid is empty end

						// if(!(ConsequenceRowCountGrid==Integer.parseInt(ConsequenceRowCount)+1))return
						// "ErrorConsequence";
						// --------------Changes for consequence outreach 18
						// december delivery date-------------------
						String outreachFlag = (String) iform.getValue("CustomerOutreachFlag");
						KYC_Remediation.mLogger.debug("outreachFlag - " + outreachFlag);
						int rowCount = iform.getDataFromGrid("Outreach_Grid").size();
						KYC_Remediation.mLogger.debug("rowCount - " + rowCount);
						String conseStatus = (String) iform.getTableCellValue("table25", ConsequenceRowCountGrid - 1,
								0);
						/*
						 * if("Individual".equalsIgnoreCase(caseType) &&
						 * ConsequenceRowCountGrid>Integer.parseInt(
						 * ConsequenceRowCount)) {
						 * if(("".equalsIgnoreCase(outreachFlag) ||
						 * "Offline Outreach".equalsIgnoreCase(outreachFlag)) &&
						 * rowCount == 0 && !(ConsequenceRowCountGrid==0) && !
						 * "Put On Hold".equalsIgnoreCase(conseStatus) &&
						 * "Initiate Consequence".equalsIgnoreCase(Decision)) {
						 * return "OutreachDocsNotSelected"; } }
						 */
						/*
						 * if(("".equalsIgnoreCase(outreachFlag) ||
						 * "Offline Outreach".equalsIgnoreCase(outreachFlag)) &&
						 * rowCount > 0) {
						 * iform.setValue("CustomerOutreachFlag", "Pending");
						 * iform.setValue("WICategory", "CAT3"); }
						 */
						if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount)
								&& "Initiate Consequence".equalsIgnoreCase(Decision)) {
							for (int i = Integer.parseInt(ConsequenceRowCount); i < ConsequenceRowCountGrid; i++) {
								// if(!"".equalsIgnoreCase(consStatus))
								// consStatus +="|";
								if (!"".equalsIgnoreCase(consAction))
									consAction += "|";
								if ("".equalsIgnoreCase(consStatus))
									consStatus = (String) iform.getTableCellValue("table25", i, 0);
								consAction += (String) iform.getTableCellValue("table25", i, 1);
							}
							KYC_Remediation.mLogger.debug("consStatus - " + consStatus);
							KYC_Remediation.mLogger.debug("consAction - " + consAction);
							String query = "";
							if (Integer.parseInt(ConsequenceRowCount) == 0)
								/*
								 * query =
								 * "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '"
								 * +consStatus+"'" +",CONSEQUENCE_ACTION = '"
								 * +consAction+
								 * "',CONSEQUENCE_EMAIL_FLAG = 'PENDING'," +
								 * "FIRST_CONSEQUENCE_DATE = getdate(),LATEST_CONSEQUENCE_DATE = getdate() "
								 * +"WHERE WINAME = '"+processinstanceID+"'";
								 */
								query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
										+ ",CONSEQUENCE_ACTION = '" + consAction
										+ "',FIRST_CONSEQUENCE_DATE = getdate(),LATEST_CONSEQUENCE_DATE = getdate() "
										+ "WHERE WINAME = '" + processinstanceID + "'";
							else
								/*
								 * query =
								 * "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '"
								 * +consStatus+"'" +",CONSEQUENCE_ACTION = '"
								 * +consAction+
								 * "',CONSEQUENCE_EMAIL_FLAG = 'PENDING'," +
								 * "LATEST_CONSEQUENCE_DATE = getdate() WHERE WINAME = '"
								 * +processinstanceID+"'";
								 */
								query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
										+ ",CONSEQUENCE_ACTION = '" + consAction
										+ "',LATEST_CONSEQUENCE_DATE = getdate() WHERE WINAME = '" + processinstanceID
										+ "'";
							int returnMsg = iform.saveDataInDB(query);
							KYC_Remediation.mLogger.debug("query for consequence update..." + query);

							KYC_Remediation.mLogger
									.debug("returnMsg -->" + returnMsg + "for WI - " + processinstanceID + ".....");
						} else if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount)
								&& "Submit to RM Vendor".equalsIgnoreCase(Decision)) {
							String status = (String) iform.getTableCellValue("table25", ConsequenceRowCountGrid - 1, 0);
							if ("Put On Hold".equalsIgnoreCase(status) && "Individual".equalsIgnoreCase(caseType)) {
								consStatus = "Put On Hold";
								String query = "";
								if (Integer.parseInt(ConsequenceRowCount) == 0)
									query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
											+ ",CONSEQUENCE_EMAIL_FLAG = 'PENDING', CustomerOutreachFlag = 'Pending', WICategory = 'CAT3',"
											+ "isReoutreach = 'N', FIRST_CONSEQUENCE_DATE = getdate(),LATEST_CONSEQUENCE_DATE = getdate() "
											+ "WHERE WINAME = '" + processinstanceID + "'";
								else
									query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
											+ ",CONSEQUENCE_EMAIL_FLAG = 'PENDING', CustomerOutreachFlag = 'Pending', WICategory = 'CAT3',"
											+ "isReoutreach = 'N', LATEST_CONSEQUENCE_DATE = getdate() WHERE WINAME = '"
											+ processinstanceID + "'";
								int returnMsg = iform.saveDataInDB(query);
								KYC_Remediation.mLogger.debug("query for consequence update..." + query);
								KYC_Remediation.mLogger
										.debug("returnMsg -->" + returnMsg + "for WI - " + processinstanceID + ".....");
							} else if ("Put On Hold".equalsIgnoreCase(status)
									&& "Corporate".equalsIgnoreCase(caseType)) {
								consStatus = "Put On Hold";
								String query = "";
								if (Integer.parseInt(ConsequenceRowCount) == 0)
									query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
											+ ", FIRST_CONSEQUENCE_DATE = getdate(),LATEST_CONSEQUENCE_DATE = getdate() "
											+ "WHERE WINAME = '" + processinstanceID + "'";
								else
									query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
											+ ", LATEST_CONSEQUENCE_DATE = getdate() WHERE WINAME = '"
											+ processinstanceID + "'";
								int returnMsg = iform.saveDataInDB(query);
								KYC_Remediation.mLogger.debug("query for consequence update..." + query);
								KYC_Remediation.mLogger
										.debug("returnMsg -->" + returnMsg + "for WI - " + processinstanceID + ".....");
							}
						}
						// --------------Changes for consequence outreach 18
						// december delivery date end--------------
					}
					if ("Approver".equalsIgnoreCase(Workstep)) {
						KYC_Remediation.mLogger.debug("getting last consequence status...");
						String status = (String) iform.getTableCellValue("table25", ConsequenceRowCountGrid - 1, 0);
						KYC_Remediation.mLogger.debug("last consequence status is - " + status);
						iform.setValue("LastConsStatus", status);
						// String Decision = (String)iform.getValue("DECISION");
						if ("Approved".equalsIgnoreCase(Decision)) {
							if (ConsequenceRowCountGrid > 0) {
								if (ConsequenceRowCountGrid == Integer.parseInt(ConsequenceRowCount)) {
									if ("Partial Applied".equalsIgnoreCase(status)
											|| "Fully Applied".equalsIgnoreCase(status)) {
										return "ErrorConsequence";
									}
								} else if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount) + 1) {
									return "ErrorConsequence";
								}
							}
						}
						else if ("Remove Consequence".equalsIgnoreCase(Decision)) {
							if (ConsequenceRowCountGrid > 0) {
								if (ConsequenceRowCountGrid == Integer.parseInt(ConsequenceRowCount)) {
									if ("Partial Applied".equalsIgnoreCase(status)
											|| "Fully Applied".equalsIgnoreCase(status)) {
										return "ErrorConsequence";
									}
								} else if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount) + 1) {
									return "ErrorConsequence";
								}
							}
						}
						if(!"WBG".equalsIgnoreCase((String)iform.getValue("subSegment"))){
						String res = validateConsequenceDecision(iform, ConsequenceRowCount, ConsequenceRowCountGrid);
						if (!"true".equalsIgnoreCase(res))
							return res;
						}

						if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount)
								&& "Remove Consequence".equalsIgnoreCase(Decision)) {
							for (int i = Integer.parseInt(ConsequenceRowCount); i < ConsequenceRowCountGrid; i++) {
								// if(!"".equalsIgnoreCase(consStatus))
								// consStatus +="|";
								if (!"".equalsIgnoreCase(consAction))
									consAction += "|";
								if ("".equalsIgnoreCase(consStatus))
									consStatus = (String) iform.getTableCellValue("table25", i, 0);
								consAction += (String) iform.getTableCellValue("table25", i, 1);
							}
							KYC_Remediation.mLogger.debug("consStatus - " + consStatus);
							KYC_Remediation.mLogger.debug("consAction - " + consAction);
							String query = "";
							if (Integer.parseInt(ConsequenceRowCount) == 0)
								/*
								 * query =
								 * "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '"
								 * +consStatus+"'" +",CONSEQUENCE_ACTION = '"
								 * +consAction+
								 * "',CONSEQUENCE_EMAIL_FLAG = 'PENDING'," +
								 * "FIRST_CONSEQUENCE_DATE = getdate(),LATEST_CONSEQUENCE_DATE = getdate() "
								 * +"WHERE WINAME = '"+processinstanceID+"'";
								 */
								query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
										+ ",CONSEQUENCE_ACTION = '" + consAction
										+ "',FIRST_CONSEQUENCE_DATE = getdate(),LATEST_CONSEQUENCE_DATE = getdate() "
										+ "WHERE WINAME = '" + processinstanceID + "'";
							else
								/*
								 * query =
								 * "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '"
								 * +consStatus+"'" +",CONSEQUENCE_ACTION = '"
								 * +consAction+
								 * "',CONSEQUENCE_EMAIL_FLAG = 'PENDING'," +
								 * "LATEST_CONSEQUENCE_DATE = getdate() WHERE WINAME = '"
								 * +processinstanceID+"'";
								 */
								query = "UPDATE RB_KYC_REM_EXTTABLE SET CONSEQUENCE_STATUS = '" + consStatus + "'"
										+ ",CONSEQUENCE_ACTION = '" + consAction
										+ "',LATEST_CONSEQUENCE_DATE = getdate() WHERE WINAME = '" + processinstanceID
										+ "'";
							int returnMsg = iform.saveDataInDB(query);
							KYC_Remediation.mLogger.debug("query for consequence update..." + query);

							KYC_Remediation.mLogger
									.debug("returnMsg -->" + returnMsg + "for WI - " + processinstanceID + ".....");
						}
					}
				}
				if ("Approver".equalsIgnoreCase(Workstep) || "Consequence".equalsIgnoreCase(Workstep)
						|| "RM_Vendor".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)
						|| "Maker".equalsIgnoreCase(Workstep)) {
					Integer consequenceRowCount = iform.getDataFromGrid("table25").size();
					KYC_Remediation.mLogger.debug("setting consequenceRowCount as - " + consequenceRowCount);
					String count = consequenceRowCount.toString();
					iform.setValue("ConsequenceRowCount", count);
				}
				// String caseType = (String) iform.getValue("CaseType");
				if ("Corporate".equalsIgnoreCase(caseType)) {

					// Shareholder percentage logic
					if ("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)) {
						String LegalEntity = (String)iform.getValue("LegalEntity");						
						
						Map<String, Double> shHoldingGridMap = new HashMap<>();
						JSONArray shHoldingGridJsonArray = iform.getDataFromGrid("table26");
						for (int i = 0; i < shHoldingGridJsonArray.size(); i++) {
							JSONObject jsonObj = (JSONObject) shHoldingGridJsonArray.get(i);
							KYC_Remediation.mLogger.debug("jsonObj - " + jsonObj);
							Object identifier = "Main Holder";
							String mainHolder = (String) jsonObj.getOrDefault(identifier, "0.0");
							identifier = "% Shareholding(If applicable)";
							String percent = (String) jsonObj.getOrDefault(identifier, "0.0");
							Double dblPercent = Double.parseDouble(percent);
							KYC_Remediation.mLogger.debug("dblPercent - " + dblPercent);

							shHoldingGridMap.put(mainHolder,
									shHoldingGridMap.getOrDefault(mainHolder, 0.0) + dblPercent);
						}

						for (String key : shHoldingGridMap.keySet()) {
							BigDecimal bd = new BigDecimal(shHoldingGridMap.get(key)).setScale(2, RoundingMode.HALF_UP);
							double num = bd.doubleValue();
							KYC_Remediation.mLogger.debug("num - " + num);
							if("Public Shareholding Company PJSC".equalsIgnoreCase(LegalEntity) || "Public Joint Stock Company".equalsIgnoreCase(LegalEntity) ||
									"Society/ Trusts/ Clubs".equalsIgnoreCase(LegalEntity)){
								if (num > 100.0) {
									KYC_Remediation.mLogger.debug("returning as sum is - " + num);
									return "Failure due to percentage greater than 100 for: " + key;
								}
								
							} else{
								if (num != 100.0) {
									KYC_Remediation.mLogger.debug("returning as sum is - " + num);
									return "Failure due to percentage not being equal to 100 for: " + key;
								}
							}
						}
						
					}
					// Shareholder percentage logic end

					KYC_Remediation.mLogger
							.debug("Inside IntroDone , trying to move related party WI of..." + processinstanceID);
					// getting queue details of main WI
					String q_QueueName = "KYC_Remediation_" + Workstep;
					if ("Consequence".equalsIgnoreCase(Workstep))
						q_QueueName = q_QueueName + "_Decision";
					KYC_Remediation.mLogger.debug("q_QueueName - " + q_QueueName);
					String ActivityIDmain = "";
					String Q_QueueID = "";
					String queryMain = "select ActivityId,ActivityName from WFINSTRUMENTTABLE where ProcessInstanceID = '"
							+ processinstanceID + "' AND Workitemid = '1'";
					KYC_Remediation.mLogger.debug("queryMain: " + queryMain);
					List<List<String>> dataFromDBMain = iform.getDataFromDB(queryMain);
					KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDBMain);
					if (!dataFromDBMain.isEmpty()) {
						ActivityIDmain = dataFromDBMain.get(0).get(0);
						String queryQueueID = "SELECT QueueID FROM queuedeftable WHERE QueueName = '" + q_QueueName
								+ "'";
						KYC_Remediation.mLogger.debug("queryfor getting queueID of main WI : " + queryQueueID);
						List<List<String>> dataFromDBqueueID = iform.getDataFromDB(queryQueueID);
						KYC_Remediation.mLogger.debug("dataFromDBqueueID: " + dataFromDBqueueID);
						if (!dataFromDBqueueID.isEmpty()) {
							Q_QueueID = dataFromDBqueueID.get(0).get(0);
						}
					} else {
						KYC_Remediation.mLogger.debug("queryName result empty");
					}
					// getting queue details of main WI end
					String sCabname = getCabinetName(iform);
					KYC_Remediation.mLogger.debug("sCabname" + sCabname);
					String sSessionId = getSessionId(iform);
					KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
					int rowCount = Integer.parseInt(data);
					for (int i = 0; i < rowCount; i++) {
						String WIName = iform.getTableCellValue("table4", i, 1);
						// String Decision = (String)iform.getValue("DECISION");
						String attTag = "<DECISION>" + Decision + "</DECISION>";
						if ("Approver".equalsIgnoreCase(Workstep) && "Approved".equalsIgnoreCase(Decision)) {
							String nextReviewDate = RPnextReviewDate(iform, WIName);
							if (!"".equalsIgnoreCase(nextReviewDate))
								attTag += "<NextReviewDate>" + nextReviewDate + "</NextReviewDate>";
						}
						if ("Consequence".equalsIgnoreCase(Workstep)
								&& "Block Cheque Book Facility".equalsIgnoreCase(consAction)
								&& "Initiate Consequence".equalsIgnoreCase(Decision)) {
							attTag += "<CONSEQUENCE_ACTION>Block Cheque Book Facility</CONSEQUENCE_ACTION>";
						}
						String WI_ID = "";
						String ProcessDefID = "";
						String ActivityID = "";
						String VAR_STR8 = "";
						String ActivityName = "";
						KYC_Remediation.mLogger.debug("RP WI under processing: " + WIName);
						String query = "select WorkItemId,ProcessDefID,ActivityId,VAR_STR8,ActivityName from WFINSTRUMENTTABLE where ProcessInstanceID = '"
								+ WIName + "' AND WorkItemId = '1'";
						List<List<String>> dataFromDB = iform.getDataFromDB(query);
						KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
						if (!dataFromDB.isEmpty()) {
							WI_ID = dataFromDB.get(0).get(0);
							ProcessDefID = dataFromDB.get(0).get(1);
							ActivityID = dataFromDB.get(0).get(2);
							VAR_STR8 = dataFromDB.get(0).get(3);
							ActivityName = dataFromDB.get(0).get(4);
							KYC_Remediation.mLogger.debug("WorkItemId: " + WI_ID);
							if (!ActivityName.equalsIgnoreCase(Workstep)) {
								KYC_Remediation.mLogger
										.debug("RP WI " + WIName + " not on same stage so moving RP to same stage.");
								KYC_Remediation.mLogger.debug("Main Stage - " + Workstep);
								KYC_Remediation.mLogger.debug("RP Stage - " + ActivityName);
								String updateWFquery = "update WFINSTRUMENTTABLE set  activityname='" + Workstep
										+ "',activityid = '" + ActivityIDmain + "',Q_QueueId = '" + Q_QueueID
										+ "',Q_UserId='0'," + "WorkItemState='2',Statename='RUNNING', Queuename='"
										+ q_QueueName + "' WHERE ProcessInstanceID = '" + WIName
										+ "'AND processDefID = '" + ProcessDefID + "' AND Workitemid = '1'";
								KYC_Remediation.mLogger.debug("updateWFquery: " + updateWFquery);
								int res = iform.saveDataInDB(updateWFquery);
								KYC_Remediation.mLogger.debug("res: " + res);
							}
						} else {
							KYC_Remediation.mLogger.debug("Workitem ID not found!!");

						}
						// -----update wftable---------
						IFormXmlResponse xmlParser = new IFormXmlResponse();
						StringBuffer XMLBuffer = new StringBuffer();
						String columnNames = "VAR_STR1,VAR_STR8";
						String columnValues = "'ToVisible','ToVisible'";
						String sWhereClause = "ProcessInstanceID ='" + WIName + "'";

						KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);

						XMLBuffer.append("<?xml version=\"1.0\"?>\n");
						XMLBuffer.append("<APUpdate_Input>\n");
						XMLBuffer.append("<Option>APUpdate</Option>\n");
						XMLBuffer.append("<TableName>");
						XMLBuffer.append("WFINSTRUMENTTABLE");
						XMLBuffer.append("</TableName>\n");
						XMLBuffer.append("<ColName>");
						XMLBuffer.append(columnNames);
						XMLBuffer.append("</ColName>\n");
						XMLBuffer.append("<Values>");
						XMLBuffer.append(columnValues);
						XMLBuffer.append("</Values>\n");
						XMLBuffer.append("<WhereClause>");
						XMLBuffer.append(sWhereClause);
						XMLBuffer.append("</WhereClause>\n");
						XMLBuffer.append("<EngineName>");
						XMLBuffer.append(sCabname);
						XMLBuffer.append("</EngineName>\n");
						XMLBuffer.append("<SessionId>");
						XMLBuffer.append(sSessionId);
						XMLBuffer.append("</SessionId>\n");
						XMLBuffer.append("</APUpdate_Input>");

						String apUpdateinput = XMLBuffer.toString();
						KYC_Remediation.mLogger.debug("apUpdateinput--->" + apUpdateinput);
						String stOutputXML = ExecuteQueryOnServer(apUpdateinput, iform);
						KYC_Remediation.mLogger.debug("sOutputXML--->" + stOutputXML);
						xmlParser.setXmlString((stOutputXML));
						String statusapUpdate = xmlParser.getVal("MainCode");
						KYC_Remediation.mLogger.debug("status for wf table--->" + statusapUpdate);
						// ------------end update
						if ("0".equalsIgnoreCase(statusapUpdate)) {
							IFormXmlResponse xmlParserData = new IFormXmlResponse();
							StringBuffer ipXMLBuffer = new StringBuffer();

							ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
							ipXMLBuffer.append("<WMGetWorkItem_Input>\n");
							ipXMLBuffer.append("<Option>WMGetWorkItem</Option>\n");
							ipXMLBuffer.append("<EngineName>");
							ipXMLBuffer.append(sCabname);
							ipXMLBuffer.append("</EngineName>\n");
							ipXMLBuffer.append("<SessionId>");
							ipXMLBuffer.append(sSessionId);
							ipXMLBuffer.append("</SessionId>\n");
							ipXMLBuffer.append("<ProcessInstanceId>");
							ipXMLBuffer.append(WIName);
							ipXMLBuffer.append("</ProcessInstanceId>\n");
							ipXMLBuffer.append("<WorkItemId>");
							ipXMLBuffer.append(WI_ID);
							ipXMLBuffer.append("</WorkItemId>\n");
							ipXMLBuffer.append("</WMGetWorkItem_Input>");

							String getWIinput = ipXMLBuffer.toString();
							KYC_Remediation.mLogger.debug("getWIinput--->" + getWIinput);
							String OutputXML = ExecuteQueryOnServer(getWIinput, iform);
							KYC_Remediation.mLogger.debug("sOutputXML--->" + OutputXML);
							xmlParserData.setXmlString((OutputXML));
							String status_get = xmlParserData.getVal("MainCode");
							if (status_get.equalsIgnoreCase("0")) {
								KYC_Remediation.mLogger.debug("Get WI call successfull...");
								String assignInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
										+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + sCabname
										+ "</EngineName>" + "<SessionId>" + sSessionId + "</SessionId>"
										+ "<ProcessInstanceId>" + WIName + "</ProcessInstanceId>" + "<WorkItemId>"
										+ WI_ID + "</WorkItemId>" + "<ActivityId>" + ActivityIDmain + "</ActivityId>"
										+ "<ProcessDefId>" + ProcessDefID + "</ProcessDefId>"
										+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType></ActivityType>"
										+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>"
										+ "<Comments></Comments>" + "<UserDefVarFlag>Y</UserDefVarFlag>"
										+ "<Attributes>" + attTag + "</Attributes>"
										+ "</WMAssignWorkItemAttributes_Input>";
								KYC_Remediation.mLogger.debug("assignInputXML--->" + assignInputXML);
								String sOutputXML = ExecuteQueryOnServer(assignInputXML, iform);
								KYC_Remediation.mLogger.debug("sOutputXML--->" + sOutputXML);
								xmlParserData.setXmlString((sOutputXML));
								String status = xmlParserData.getVal("MainCode");
								if (status.equalsIgnoreCase("0")) {
									KYC_Remediation.mLogger.debug("Related Party WI moved successfullly...");
									updateBackToRelatedParty(iform, VAR_STR8, WIName, sCabname, sSessionId);
								} else {
									KYC_Remediation.mLogger.debug("Error in moving related party WI");
									updateBackToRelatedParty(iform, VAR_STR8, WIName, sCabname, sSessionId);
									return "Error";
								}
							} else {
								KYC_Remediation.mLogger.debug("Error in get WI CAll...");
								updateBackToRelatedParty(iform, VAR_STR8, WIName, sCabname, sSessionId);
								return "Error";
							}
						} else {
							KYC_Remediation.mLogger.debug("Error in AP Update in wfinstrument Table 'To Visible'.");
							return "Error";
						}
					}
					
					
					if ("Customer Outreach".equalsIgnoreCase(Decision)
							|| ("Customer Notification").equalsIgnoreCase(Decision)) {
						String res = sendCustomerCommunication(iform);
					}
					if ("Consequence_Manual".equalsIgnoreCase(Workstep)) {
						sendConsequenceEmail(iform);
					}

					if ("Consequence".equalsIgnoreCase(Workstep)
							&& (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount)) && !"WBG".equalsIgnoreCase((String)iform.getValue("subSegment"))) {
						sendConsequenceEmail(iform);
					}
					
					
				}

				KYC_Remediation.mLogger.debug("InsertIntoHistory : Try ");

				JSONArray jsonArray = new JSONArray();
				JSONObject obj = new JSONObject();

				Date d = new Date();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String strDate = dateFormat.format(d);

				KYC_Remediation.mLogger.debug("strDate: " + strDate);

				String EntryDateTime = (String) iform.getValue("EntryAt");
				Date dt = dateFormat.parse(EntryDateTime);
				String EntryAt = dateFormat.format(dt);
				KYC_Remediation.mLogger.debug("EntryAt: " + EntryAt);

				obj.put("Date Time", strDate);
				obj.put("Entry Date Time", EntryAt);
				obj.put("Workstep", iform.getActivityName());
				obj.put("Decision", iform.getValue("DECISION"));
				obj.put("User Name", iform.getUserName());
				obj.put("Remarks", iform.getValue("Remarks"));

				KYC_Remediation.mLogger.debug("Decision: " + iform.getValue("Decision"));
				KYC_Remediation.mLogger.debug("Remarks_dec: " + iform.getValue("Remarks_dec"));
				KYC_Remediation.mLogger.debug("Entry Date Time: " + iform.getValue("EntryDateTime"));
				KYC_Remediation.mLogger.debug("Entry At: " + iform.getValue("EntryAt"));

				jsonArray.add(obj);
				iform.addDataToGrid("DECISION_HISTORY", jsonArray);
				KYC_Remediation.mLogger.debug("jsonArray : " + jsonArray);
				strReturn = "INSERTED";

				KYC_Remediation.mLogger
						.debug("WINAME: " + getWorkitemName(iform) + ", WSNAME: " + iform.getActivityName()
								+ ", ControlName: " + controlName + ", WI Histroy Added Successfully!");
				// Attach KYC form when taking outreach manually
				if ("Individual".equalsIgnoreCase(caseType) && "Customer Outreach".equalsIgnoreCase(Decision)) {
					String output = generateApplicationFrom("KYC_Form", getWorkitemName(iform), getSessionId(iform),
							iform, "");
					if (output.contains("Success")) {
						String Res = AttachKYC_FormWithWI(iform, getWorkitemName(iform), "KYC_Form", "IntroDone");
						KYC_Remediation.mLogger.debug(
								" No Error in attaching KYC form post taking customer outreach decision - " + Res);
					}
				}
				InsertIntoEmailAudit(iform, getWorkitemName(iform), caseType, Workstep, Decision, data);
				// Attach KYC form when taking outreach manually end
			} catch (Exception e) {
				KYC_Remediation.mLogger.debug("Exception in inserting WI History!" + e.getMessage());
				return "false";
			}
		}
		return strReturn;
	}

	private void sendConsequenceEmail(IFormReference iform) {
		try {
			String processInstanceID = getWorkitemName(iform);
			String mailFrom = "";
			String mailTo = (String) iform.getValue("CompanyEmailID");
			String emailSubject = "";
			String emailContent = "";
			String mailContentType = "text/html;charset=UTF-8";
			String mailPriority = "1";
			String mailStatus = "N";
			String insertedBy = getUserName(iform);
			String mailActionType = "TRIGGER";
			String workItemID = "";
			String ActivityID = "";
			String noOfTrials = "0";
			String processdefID = "";
			String consequenceAction = "";
			String consequenceStatus = "";
			String squery = "SELECT CONSEQUENCE_STATUS,CONSEQUENCE_ACTION FROM RB_KYC_REM_EXTTABLE with(nolock) WHERE WINAME = '"
					+ getWorkitemName(iform) + "'";
			List<List<String>> sdataFromDB = iform.getDataFromDB(squery);
			KYC_Remediation.mLogger.debug("dataFromDB: " + sdataFromDB);
			if (!sdataFromDB.isEmpty()) {
				consequenceStatus = sdataFromDB.get(0).get(0);
				KYC_Remediation.mLogger.debug("consequenceStatus - " + consequenceStatus);
				consequenceAction = sdataFromDB.get(0).get(1);
				KYC_Remediation.mLogger.debug("consequenceAction - " + consequenceAction);
			}

			String query = "";
			if ("Block All Services".equalsIgnoreCase(consequenceAction)
					&& "Consequence_Manual".equalsIgnoreCase(getActivityName(iform)))
				query = "SELECT FomEmail,Content,Subject from NG_KYC_REM_EMAIL_TEMPLATE with(nolock) where Type = 'All_Blocked'";
			else if ((consequenceAction.contains("Block Debit Cards")
					|| consequenceAction.contains("Block Credit Cards"))
					&& consequenceAction.contains("Block Digital Banking")
					&& "Consequence_Manual".equalsIgnoreCase(getActivityName(iform)))
				query = "SELECT FomEmail,Content,Subject FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'All_Blocked'";
			else if ("Block Digital Banking".equalsIgnoreCase(consequenceAction)
					&& "Consequence_Manual".equalsIgnoreCase(getActivityName(iform)))
				query = "SELECT FomEmail,Content,Subject FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'DB_Blocked'";
			else if ((consequenceAction.contains("Block Debit Cards")
					|| consequenceAction.contains("Block Credit Cards"))
					&& !consequenceAction.contains("Block Digital Banking")
					&& "Consequence_Manual".equalsIgnoreCase(getActivityName(iform)))
				query = "SELECT FomEmail,Content,Subject FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'Cards_Blocked'";
			else if (!(consequenceAction.contains("Block Debit Cards")
					|| consequenceAction.contains("Block Credit Cards"))
					&& consequenceAction.contains("Block Digital Banking")
					&& "Consequence_Manual".equalsIgnoreCase(getActivityName(iform)))
				query = "SELECT FomEmail,Content,Subject FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'DB_Blocked'";
			else if ("Put On Hold".equalsIgnoreCase(consequenceStatus)
					&& "Consequence".equalsIgnoreCase(getActivityName(iform)))
				query = "SELECT FomEmail,Content,Subject FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'On_Hold'";
			else if ("Block Cheque Book Facility".equalsIgnoreCase(consequenceAction))
				KYC_Remediation.mLogger.debug("No Email for cheque book");
			KYC_Remediation.mLogger.debug("query to get email content - " + query);
			/*
			 * if("".equalsIgnoreCase(query) &&
			 * "Consequence".equalsIgnoreCase(getActivityName(iform))) query =
			 * "SELECT FomEmail,Content,Subject FROM NG_KYC_REM_EMAIL_TEMPLATE with(nolock) WHERE Type = 'On_Hold'"
			 * ;
			 */if ("".equalsIgnoreCase(query))
				return;
			List<List<String>> dataFromDB = iform.getDataFromDB(query);
			KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
			if (!dataFromDB.isEmpty()) {
				mailFrom = dataFromDB.get(0).get(0);
				emailContent = dataFromDB.get(0).get(1);
				emailSubject = dataFromDB.get(0).get(2) + " " + processInstanceID;
				emailContent = emailContent.replaceAll("DD/MM/YYYY", getDate());
				emailContent = emailContent.replaceAll("'", "''");
			}

			String query1 = "SELECT WorkItemId,ActivityId,ProcessDefID FROM WFINSTRUMENTTABLE with(nolock) WHERE ProcessInstanceID = '"
					+ getWorkitemName(iform) + "' AND WorkItemId = '1'";
			List<List<String>> dataFromDB1 = iform.getDataFromDB(query1);
			KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB1);
			if (!dataFromDB1.isEmpty()) {
				workItemID = dataFromDB1.get(0).get(0);
				ActivityID = dataFromDB1.get(0).get(1);
				processdefID = dataFromDB1.get(0).get(2);
			}
			String columnName = "(mailFrom,mailTo,mailSubject,mailMessage,mailContentType,mailPriority,mailStatus,insertedBy,mailActionType,processInstanceID,workItemID,ActivityID,"
					+ "noOfTrials,insertedTime,ProcessDefID)";
			String values = "('" + mailFrom + "','" + mailTo + "','" + emailSubject + "',N'" + emailContent + "','"
					+ mailContentType + "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','"
					+ mailActionType + "','" + processInstanceID + "','" + workItemID + "','" + ActivityID + "','"
					+ noOfTrials + "',getDate(),'" + processdefID + "')";
			String queryInsertMAil = "INSERT INTO WFMAILQUEUETABLE " + columnName + " VALUES " + values;
			KYC_Remediation.mLogger.debug("Insert Mail Query: " + queryInsertMAil);
			int response = iform.saveDataInDB(queryInsertMAil);
			KYC_Remediation.mLogger.debug("Response of Insert Mail Query for consequence email: " + response);
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception in sendConsequenceEmail method" + e.getMessage());
		}
	}

	private String getDate() {
		String dt = "";
		try {
			LocalDate currentDate = LocalDate.now();
			int daysToAdd = 14; // Two weeks
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

			LocalDate futureDate = currentDate;
			int weekdaysCount = 0;

			while (weekdaysCount < daysToAdd) {
				futureDate = futureDate.plusDays(1);
				if (futureDate.getDayOfWeek() != DayOfWeek.SATURDAY && futureDate.getDayOfWeek() != DayOfWeek.SUNDAY) {
					weekdaysCount++;
				}
			}
			return dt = futureDate.format(formatter);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception - " + e.getMessage());
		}
		return dt;
	}

	private void InsertIntoEmailAudit(IFormReference iform, String workitemName, String caseType, String Workstep,
			String Decision, String data) {
		try {
			String CustomerSubsegmentCode = (String) iform.getValue("Customer_Subsegment");
			String oldEmail = "";
			if (caseType.equalsIgnoreCase("Corporate") && Workstep.equalsIgnoreCase("Maker")
					&& Decision.equalsIgnoreCase("Refer to RM Vendor")
					&& ("SME".equalsIgnoreCase(CustomerSubsegmentCode)
							|| "PSL".equalsIgnoreCase(CustomerSubsegmentCode))) {
				String email = (String) iform.getValue("CompanyEmailID");
				String squery = "select PREFERRED_EMAIL from NG_KYC_REM_BO_IBPS_TABLE with(nolock) where Wi_Name = '"
						+ workitemName + "'";
				KYC_Remediation.mLogger.debug("query address: " + squery);
				List<List<String>> sdataFromDB = iform.getDataFromDB(squery);
				KYC_Remediation.mLogger.debug("dataFromDB: " + sdataFromDB);
				if (!sdataFromDB.isEmpty()) {
					String PREFERRED_EMAIL = sdataFromDB.get(0).get(0);
					if (!PREFERRED_EMAIL.equalsIgnoreCase(email)) {
						String CIF = (String) iform.getValue("CIF_ID");
						String insertQuery = "INSERT INTO NG_KYC_REM_EMAIL_AUDIT_TABLE VALUES ('" + workitemName + "','"
								+ CIF + "','" + PREFERRED_EMAIL + "','" + email + "','" + getUserName(iform)
								+ "',getDate())";
						iform.saveDataInDB(insertQuery);
						oldEmail = workitemName;
					}
				}
				int rowCountRP = Integer.parseInt(data);
				for (int i = 0; i < rowCountRP; i++) {
					String WIName = iform.getTableCellValue("table4", i, 1);
					KYC_Remediation.mLogger.debug("WIName RP Address: " + WIName);
					String query = "SELECT  NG.PREFERRED_EMAIL AS Email_From_BO_Table, RB.OwnerEmailID AS "
							+ "Email_From_EXT_Table,RB.CIF_ID FROM NG_KYC_REM_BO_IBPS_TABLE NG WITH (NOLOCK) JOIN "
							+ "RB_KYC_REM_EXTTABLE RB WITH (NOLOCK) ON NG.Wi_Name = RB.WINAME " + "WHERE NG.Wi_Name = '"
							+ WIName + "';";
					KYC_Remediation.mLogger.debug("query address: " + query);
					List<List<String>> dataFromDB = iform.getDataFromDB(query);
					KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
					if (!dataFromDB.isEmpty()) {
						String Email_From_BO_Table = dataFromDB.get(0).get(0);
						String Email_From_EXT_Table = dataFromDB.get(0).get(1);
						String CIF_ID = dataFromDB.get(0).get(2);
						if (!Email_From_BO_Table.equalsIgnoreCase(Email_From_EXT_Table)) {
							String insertQuery = "INSERT INTO NG_KYC_REM_EMAIL_AUDIT_TABLE VALUES ('" + WIName + "','"
									+ CIF_ID + "','" + Email_From_BO_Table + "','" + Email_From_EXT_Table + "','"
									+ getUserName(iform) + "',getDate())";
							iform.saveDataInDB(insertQuery);
							if ("".equalsIgnoreCase(oldEmail))
								oldEmail = WIName;
							else
								oldEmail += "," + WIName;
						}
					}
				}
				if (!"".equalsIgnoreCase(oldEmail))
					iform.setValue("oldEmail", oldEmail);
			}
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception in InsertIntoEmailAudit!" + e.getMessage());
		}

	}

	private String checkConsequenceHeldTill(IFormReference iform, String ConsequenceRowCount,
			int ConsequenceRowCountGrid) {
		try {
			String consStatus = (String) iform.getTableCellValue("table25", ConsequenceRowCountGrid - 1, 0);
			if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount)
					&& "Put On Hold".equalsIgnoreCase(consStatus)
					&& "".equalsIgnoreCase((String) iform.getValue("Consequence_held_till"))) {
				return "ConsequenceHeldTill@Please select Consequence held till date if Consequence Status selected as 'Put On Hold'";
			}
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception in checkConsequenceHeldTill method!" + e.getMessage());
		}
		return "true";
	}

	private String checkKYCForm(IFormReference iform, String processinstanceID) {
		try {
			String strFolderIndex = "";
			String strInputQry1 = "SELECT FOLDERINDEX FROM PDBFOLDER WITH(NOLOCK) WHERE NAME='" + processinstanceID
					+ "'";
			KYC_Remediation.mLogger.debug("sInputXML: " + strInputQry1);
			List<List<String>> dataFromDB = iform.getDataFromDB(strInputQry1);
			for (List<String> tableFrmDB : dataFromDB) {
				strFolderIndex = tableFrmDB.get(0).trim();
			}
			KYC_Remediation.mLogger.debug("strFolderIndex: " + strFolderIndex);
			if (!(strFolderIndex.equalsIgnoreCase(""))) {
				String strInputQry2 = "";
				strInputQry2 = "SELECT a.documentindex,b.ParentFolderIndex,a.CreatedbyUser,A.Comment FROM PDBDOCUMENT A WITH (NOLOCK), PDBDOCUMENTCONTENT B WITH (NOLOCK)"
						+ "WHERE A.DOCUMENTINDEX= B.DOCUMENTINDEX AND A.NAME IN ('KYC Form','KYC_Form_Corporate') AND B.PARENTFOLDERINDEX ='"
						+ strFolderIndex + "'";

				KYC_Remediation.mLogger.debug("sInputXML: " + strInputQry2);
				List<List<String>> dataFromDB2 = iform.getDataFromDB(strInputQry2);
				KYC_Remediation.mLogger.debug("dataFromDB2: " + dataFromDB2);
				if (dataFromDB2.isEmpty()) {
					return "KYCMain";
				}
			}
			int rpsize = iform.getDataFromGrid("table4").size();
			for (int i = 0; i < rpsize; i++) {
				String RP_WINAME = (String) iform.getTableCellValue("table4", i, 1);
				String strFolderIndexRP = "";
				String strInputQry1RP = "SELECT FOLDERINDEX FROM PDBFOLDER WITH(NOLOCK) WHERE NAME='" + RP_WINAME + "'";
				KYC_Remediation.mLogger.debug("sInputXML for RP : " + RP_WINAME + " - " + strInputQry1RP);
				List<List<String>> dataFromDBRP = iform.getDataFromDB(strInputQry1RP);
				for (List<String> tableFrmDBRP : dataFromDBRP) {
					strFolderIndexRP = tableFrmDBRP.get(0).trim();
				}
				KYC_Remediation.mLogger.debug("strFolderIndexRP: " + strFolderIndexRP);
				if (!(strFolderIndexRP.equalsIgnoreCase(""))) {
					String strInputQry2 = "";
					strInputQry2 = "SELECT a.documentindex,b.ParentFolderIndex,a.CreatedbyUser,A.Comment FROM PDBDOCUMENT A WITH (NOLOCK), PDBDOCUMENTCONTENT B WITH (NOLOCK)"
							+ "WHERE A.DOCUMENTINDEX= B.DOCUMENTINDEX AND A.NAME IN ('KYC Form','KYC_Form_RP') AND B.PARENTFOLDERINDEX ='"
							+ strFolderIndexRP + "'";

					KYC_Remediation.mLogger.debug("sInputXML: " + strInputQry2);
					List<List<String>> dataFromDB2 = iform.getDataFromDB(strInputQry2);
					KYC_Remediation.mLogger.debug("dataFromDB2: " + dataFromDB2);
					if (dataFromDB2.isEmpty()) {
						return "KYCRP@Generate KYC form for Related Party WI - " + RP_WINAME;
					}
				}

			}
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception in checking KYC form---" + e.getMessage());
			return "false";
		}
		return "true";
	}

	public String updateBackToRelatedParty(IFormReference iform, String VAR_STR8, String WIName, String sCabname,
			String sSessionId) {

		try {
			KYC_Remediation.mLogger.debug("Updating back to RelatedParty");
			IFormXmlResponse ParserData = new IFormXmlResponse();
			StringBuffer ipXMLBuffers = new StringBuffer();
			/*
			 * int rowIndex = Integer.parseInt(data); String WINAme =
			 * iform.getTableCellValue("table4",rowIndex,1);
			 */
			String scolumnNames = "VAR_STR1,VAR_STR8";
			String scolumnValues = "'RelatedParty','" + VAR_STR8 + "'";
			String WhereClause = "ProcessInstanceID ='" + WIName + "' ";

			ipXMLBuffers.append("<?xml version=\"1.0\"?>\n");
			ipXMLBuffers.append("<APUpdate_Input>\n");
			ipXMLBuffers.append("<Option>APUpdate</Option>\n");
			ipXMLBuffers.append("<TableName>");
			ipXMLBuffers.append("WFINSTRUMENTTABLE");
			ipXMLBuffers.append("</TableName>\n");
			ipXMLBuffers.append("<ColName>");
			ipXMLBuffers.append(scolumnNames);
			ipXMLBuffers.append("</ColName>\n");
			ipXMLBuffers.append("<Values>");
			ipXMLBuffers.append(scolumnValues);
			ipXMLBuffers.append("</Values>\n");
			ipXMLBuffers.append("<WhereClause>");
			ipXMLBuffers.append(WhereClause);
			ipXMLBuffers.append("</WhereClause>\n");
			ipXMLBuffers.append("<EngineName>");
			ipXMLBuffers.append(sCabname);
			ipXMLBuffers.append("</EngineName>\n");
			ipXMLBuffers.append("<SessionId>");
			ipXMLBuffers.append(sSessionId);
			ipXMLBuffers.append("</SessionId>\n");
			ipXMLBuffers.append("</APUpdate_Input>");

			String apUpdateinputs = ipXMLBuffers.toString();
			KYC_Remediation.mLogger.debug("apUpdateinput--->" + apUpdateinputs);
			String OutputXMLs = ExecuteQueryOnServer(apUpdateinputs, iform);
			KYC_Remediation.mLogger.debug("sOutputXMLs--->" + OutputXMLs);
			return "successfull";
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception in updating back to related party--->" + e.getMessage());
			return "Exception";
		}
	}

	public void updateTable(IFormReference iform, String columnNames, String columnValues, String sWhereClause,
			String tableName) {
		String sSessionId = getSessionId(iform);
		KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
		String sCabname = getCabinetName(iform);
		KYC_Remediation.mLogger.debug("sCabname" + sCabname);
		IFormXmlResponse xmlParser = new IFormXmlResponse();
		StringBuffer XMLBuffer = new StringBuffer();
		KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
		XMLBuffer.append("<?xml version=\"1.0\"?>\n");
		XMLBuffer.append("<APUpdate_Input>\n");
		XMLBuffer.append("<Option>APUpdate</Option>\n");
		XMLBuffer.append("<TableName>");
		XMLBuffer.append(tableName);
		XMLBuffer.append("</TableName>\n");
		XMLBuffer.append("<ColName>");
		XMLBuffer.append(columnNames);
		XMLBuffer.append("</ColName>\n");
		XMLBuffer.append("<Values>");
		XMLBuffer.append(columnValues);
		XMLBuffer.append("</Values>\n");
		XMLBuffer.append("<WhereClause>");
		XMLBuffer.append(sWhereClause);
		XMLBuffer.append("</WhereClause>\n");
		XMLBuffer.append("<EngineName>");
		XMLBuffer.append(sCabname);
		XMLBuffer.append("</EngineName>\n");
		XMLBuffer.append("<SessionId>");
		XMLBuffer.append(sSessionId);
		XMLBuffer.append("</SessionId>\n");
		XMLBuffer.append("</APUpdate_Input>");
		String apUpdateinput = XMLBuffer.toString();
		KYC_Remediation.mLogger.debug("apUpdateinput--->" + apUpdateinput);
		String stOutputXML = ExecuteQueryOnServer(apUpdateinput, iform);
		KYC_Remediation.mLogger.debug("sOutputXML--->" + stOutputXML);
		xmlParser.setXmlString((stOutputXML));
		String statusapUpdate = xmlParser.getVal("MainCode");
		KYC_Remediation.mLogger.debug("status for wf table--->" + statusapUpdate);
	}

	public String RPnextReviewDate(IFormReference iform, String WIName) {
		String RiskProfile = "";
		String reviewDate = "";
		try {
			String query = "SELECT OwnerRiskProfile from RB_KYC_REM_EXTTABLE where WINAME = '" + WIName + "'";
			List<List<String>> dataFromDB = iform.getDataFromDB(query);
			KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
			if (!dataFromDB.isEmpty()) {
				RiskProfile = dataFromDB.get(0).get(0);
				if (!"".equalsIgnoreCase(RiskProfile)) {
					Double rScore = Double.parseDouble(RiskProfile);
					if (rScore >= 1 && rScore < 3) {
						KYC_Remediation.mLogger.debug("Inside low");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(4);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						reviewDate = format.format(futureDate);
					}
					if (rScore >= 3 && rScore < 4) {
						KYC_Remediation.mLogger.debug("Inside medium");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(3);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						reviewDate = format.format(futureDate);
					}
					if (rScore >= 4 && rScore <= 5) {
						KYC_Remediation.mLogger.debug("Inside high");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(1).plusMonths(6);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						reviewDate = format.format(futureDate);
					}
				}
			}
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Error in setting NextReviewDate on Approver for related Party --" + WIName);
		}
		return reviewDate;
	}

	public String validateConsequenceDecision(IFormReference iform, String ConsequenceRowCount,
			int ConsequenceRowCountGrid) {
		String Decision = (String) iform.getValue("DECISION");
		String consStatus = (String) iform.getTableCellValue("table25", ConsequenceRowCountGrid - 1, 0);
		String consAction = (String) iform.getTableCellValue("table25", ConsequenceRowCountGrid - 1, 1);
		String caseType = (String) iform.getValue("CaseType");

		if (ConsequenceRowCountGrid > Integer.parseInt(ConsequenceRowCount)) {
			if (("Partial Applied".equalsIgnoreCase(consStatus) || "Fully Applied".equalsIgnoreCase(consStatus))
					&& !"Initiate Consequence".equalsIgnoreCase(Decision))
				return "ConsequenceDecision@Please select Initiate Consequence decision when Consequence Status is selected as Partial Applied or Fully Applied";
			if ("Put On Hold".equalsIgnoreCase(consStatus) && !"Submit to RM Vendor".equalsIgnoreCase(Decision))
				return "ConsequenceDecision@Please select Submit to RM Vendor decision when Consequence Status is selected as Put On Hold";
			if ("Remove Service Restriction".equalsIgnoreCase(consAction)
					&& !"Remove Consequence".equalsIgnoreCase(Decision))
				return "ConsequenceDecision@Please select Remove Consequence decision when consequence action is selected as 'Remove Service Restriction'";
			if (!"Remove Service Restriction".equalsIgnoreCase(consAction)
					&& "Remove Consequence".equalsIgnoreCase(Decision))
				return "ConsequenceDecision@Remove Consequence decision can be selected only when consequence action is selected as 'Remove Service Restriction'";
			
		}
		if (ConsequenceRowCountGrid == Integer.parseInt(ConsequenceRowCount)
				&& "Individual".equalsIgnoreCase(caseType) && "Consequence".equalsIgnoreCase(iform.getActivityName())) {
			if (!"Submit to RM Vendor".equalsIgnoreCase(Decision))
				return "ConsequenceDecision@Please select Submit to RM Vendor decision when no Consequence status is selected";
		}
		return "true";
	}

	public String sendCustomerCommunication(IFormReference iform) {
		try {
			sendSMS(iform);
			sendEmail(iform);
			String updateSendDateTime = "UPDATE NG_KYC_REM_CUST_COMMUNICATION SET SendDateTime = GETDATE() WHERE WINAME = '"
					+ getWorkitemName(iform) + "' AND SendDateTime IS NULL";
			iform.saveDataInDB(updateSendDateTime);
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Error in sendCustomerCommunication --" + e.getMessage());
		}
		return "";
	}

	private void sendEmail(IFormReference iform) {
		try {
			String Decision = (String) iform.getValue("DECISION");
			String cif = (String) iform.getValue("CIF_ID");
			int size = iform.getDataFromGrid("table29").size();
			String processInstanceID = getWorkitemName(iform);
			String mailFrom = "";
			String mailTo = iform.getTableCellValue("table29", size - 1, 1);
			String mailMessage = iform.getTableCellValue("table29", size - 1, 6);
			KYC_Remediation.mLogger.debug("mailMessage: " + mailMessage);

			String textareaEn = "", textareaAr = "", textFieldEn = "", textFieldAr = "",
					mailArr[] = mailMessage.split("~");
			if (mailArr.length > 0){
				textareaEn = mailArr[0];
				textareaEn = convertBrToList(textareaEn);
			}
			if (mailArr.length > 1){
				textareaAr = mailArr[1];
				textareaAr = convertBrToList(textareaAr);
			}
			if (mailArr.length > 2){
				textFieldEn = mailArr[2];
			}
			if (mailArr.length > 3){
				textFieldAr = mailArr[3];
			}

			String emailData = getEmailContent(Decision, iform);
			String emailContent = emailData.split("~~")[1];
			String emailSubject = emailData.split("~~")[0] + " " + processInstanceID;
			mailFrom = emailData.split("~~")[2];
			if ("Customer Outreach".equalsIgnoreCase(Decision)) {
				KYC_Remediation.mLogger.debug("emailContent before replacing: " + emailContent);
				emailContent = emailContent.replaceAll("#toReplaceEn#", textareaEn);
				emailContent = emailContent.replaceAll("#toReplaceAr#", textareaAr);
				emailContent = emailContent.replaceAll("#toReplaceTFEn#", textFieldEn);
				emailContent = emailContent.replaceAll("#toReplaceTFAr#", textFieldAr);
				emailContent = emailContent.replaceAll("&lt;", "<");
				emailContent = emailContent.replaceAll("&gt;", ">");
				KYC_Remediation.mLogger.debug("emailContent after replacing: " + emailContent);
			}
			emailContent = emailContent.replaceAll("#CaseID#", processInstanceID);
			String mailContentType = "text/html;charset=UTF-8";
			String mailPriority = "1";
			String mailStatus = "N";
			String insertedBy = getUserName(iform);
			String mailActionType = "TRIGGER";
			String workItemID = "";
			String ActivityID = "";
			String noOfTrials = "0";
			String ccEmail = emailData.split("~~")[3];
			String imgIndex = "";
			String volID = "";
			String attachmentISIndex = "";
			String attachmentName = "";
			String extension = "";
			String query1 = "SELECT WorkItemId,ActivityId FROM WFINSTRUMENTTABLE with(nolock) WHERE ProcessInstanceID = '"
					+ getWorkitemName(iform) + "' AND WorkItemId = '1'";
			List<List<String>> dataFromDB1 = iform.getDataFromDB(query1);
			KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB1);
			if (!dataFromDB1.isEmpty()) {
				workItemID = dataFromDB1.get(0).get(0);
				ActivityID = dataFromDB1.get(0).get(1);
			}
			/*
			 * String query =
			 * "SELECT Value FROM NG_KYC_REM_Variable_TABLE WHERE Variable IN ('FromEmail','CCEmail')"
			 * ; List<List<String>> dataFromDB = iform.getDataFromDB(query);
			 * KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB); if
			 * (!dataFromDB.isEmpty()) { mailFrom = dataFromDB.get(0).get(0);
			 * ccEmail = dataFromDB.get(1).get(0); }
			 */
			String RMEmailID = (String) iform.getValue("RM_EmailID");
			if (!"".equalsIgnoreCase(RMEmailID))
				ccEmail += "," + RMEmailID;
			String RPWINAME = "";
			String WINAMES = "('";
			int RPsize = iform.getDataFromGrid("table4").size();
			for (int i = 0; i < RPsize; i++) {
				RPWINAME = iform.getTableCellValue("table4", i, 1);
				WINAMES += RPWINAME + "','";
			}
			WINAMES += processInstanceID + "')";
			String strInputQry = "SELECT a.ImageIndex,a.VolumeId,A.Name,A.AppName,A.Comment FROM PDBDOCUMENT A WITH (NOLOCK),"
					+ "PDBDOCUMENTCONTENT B WITH (NOLOCK) WHERE A.DOCUMENTINDEX= B.DOCUMENTINDEX AND A.NAME IN ('KYC Form','KYC_Form_Corporate','KYC Form_Manual','KYC_Form_RP') "
					+ "AND B.PARENTFOLDERINDEX IN (SELECT FOLDERINDEX FROM PDBFOLDER WITH(NOLOCK) WHERE NAME IN "
					+ WINAMES + ") AND A.Comment NOT LIKE '%KYC Form Previous%'";
			KYC_Remediation.mLogger.debug("Query for getting attachments - " + strInputQry);
			List<List<String>> dataFromDBRP = iform.getDataFromDB(strInputQry);
			for (List<String> tableFrmDBRP : dataFromDBRP) {
				imgIndex = tableFrmDBRP.get(0).trim();
				volID = tableFrmDBRP.get(1).trim();

				if ("".equalsIgnoreCase(attachmentISIndex))
					attachmentISIndex = imgIndex + "#" + volID + "#";
				else
					attachmentISIndex += ";" + imgIndex + "#" + volID + "#";
				extension = tableFrmDBRP.get(3).trim();
				if ("".equalsIgnoreCase(attachmentName))
					attachmentName = tableFrmDBRP.get(4).trim() + "." + extension;
				else
					attachmentName += ";" + tableFrmDBRP.get(4).trim() + "." + extension;
			}

			String columnName = "(mailFrom,mailTo,mailCC,mailSubject,mailMessage,attachmentISINDEX,attachmentNames,mailContentType,mailPriority,mailStatus,insertedBy,mailActionType,processInstanceID,workItemID,ActivityID,"
					+ "noOfTrials,insertedTime)";
			String values = "('" + mailFrom + "','" + mailTo + "','" + ccEmail + "','" + emailSubject + "',N'"
					+ emailContent + "','" + attachmentISIndex + "','" + attachmentName + "','" + mailContentType
					+ "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','" + mailActionType + "','"
					+ processInstanceID + "','" + workItemID + "','" + ActivityID + "','" + noOfTrials + "',getDate())";
			String queryInsertMAil = "INSERT INTO WFMAILQUEUETABLE " + columnName + " VALUES " + values;
			KYC_Remediation.mLogger.debug("Insert Mail Query: " + queryInsertMAil);
			int response = iform.saveDataInDB(queryInsertMAil);
			KYC_Remediation.mLogger.debug("Response of Insert Mail Query: " + response);
			if (response == 1)
				insertIntoMailHistory(iform, mailFrom, mailTo, ccEmail, emailSubject, emailContent, attachmentISIndex,
						attachmentName, mailContentType, mailPriority, mailStatus, insertedBy, mailActionType,
						processInstanceID, workItemID, ActivityID, noOfTrials);
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception happened in sending mail " + e.getMessage());
		}
	}
	
	private String convertBrToList(String input) {
	    if (input == null || input.trim().isEmpty())
	        return "";
	    
	    KYC_Remediation.mLogger.debug("input content before replacing: " + input);	    
	    input = input.replaceAll("&lt;", "<");
	    input = input.replaceAll("&gt;", ">");
	    KYC_Remediation.mLogger.debug("input content after replacing: " + input);
	    
	    String[] items = input.split("<br>");
	    StringBuilder htmlList = new StringBuilder();

	    boolean hasValidItem = false;
	    for (int i = 0; i < items.length; i++) {
	        String item = items[i].trim();
	        
	        if (!item.isEmpty()) {
	            if (!hasValidItem) {
	                htmlList.append("<ul>");
	                hasValidItem = true;
	            }
	            htmlList.append("  <li>").append(item).append("</li>");
	        }
	    }

	    if (hasValidItem) htmlList.append("</ul>");

	    KYC_Remediation.mLogger.debug("html for textArea: " + htmlList.toString());
	    
	    return htmlList.toString();
	}


	private void insertIntoMailHistory(IFormReference iform, String mailFrom, String mailTo, String ccEmail,
			String mailSubject, String emailContent, String attachmentISIndex, String attachmentName,
			String mailContentType, String mailPriority, String mailStatus, String insertedBy, String mailActionType,
			String processInstanceID, String workItemID, String activityID, String noOfTrials) {
		try {
			String columnName = "(mailFrom,mailTo,mailCC,mailSubject,mailMessage,mailContentType,attachmentISINDEX,attachmentNames,"
					+ "mailPriority,mailStatus,insertedBy,mailActionType,processInstanceID,workItemID,ActivityID,"
					+ "noOfTrials,insertedTime,mailType)";
			String values = "('" + mailFrom + "','" + mailTo + "','" + ccEmail + "','" + mailSubject + "',N'"
					+ emailContent + "','" + mailContentType + "','" + attachmentISIndex + "','" + attachmentName
					+ "','" + mailPriority + "','" + mailStatus + "','" + insertedBy + "','" + mailActionType + "','"
					+ processInstanceID + "','" + workItemID + "','" + activityID + "','" + noOfTrials
					+ "',getDate(),'Outreach')";
			String queryInsertMAil = "INSERT INTO NG_KYC_REM_EMAIL_HISTORY_TABLE " + columnName + " VALUES " + values;
			KYC_Remediation.mLogger.debug("Insert Mail History Query: " + queryInsertMAil);
			int response = iform.saveDataInDB(queryInsertMAil);
			KYC_Remediation.mLogger.debug("Response of Insert History Mail Query: " + response);

		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception happened in inserting in mail history" + e.getMessage());
		}

	}

	private String getEmailContent(String Decision, IFormReference iform) {
		String type = "Customer Outreach".equalsIgnoreCase(Decision) ? "Customer_Outreach" : "Customer_Notification";

		String ret = "";
		String query = "SELECT Subject, Content, FomEmail, CCEmail FROM ng_kyc_rem_email_template with(nolock) WHERE Type = '"
				+ type + "'";
		List<List<String>> dataFromDB = iform.getDataFromDB(query);
		KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
		if (!dataFromDB.isEmpty()) {
			String subject = dataFromDB.get(0).get(0);
			String content = dataFromDB.get(0).get(1);
			String FromEmail = dataFromDB.get(0).get(2);
			String CCEmail = dataFromDB.get(0).get(3);

			ret = subject + "~~" + content + "~~" + FromEmail + "~~" + CCEmail;
		}

		return ret;
	}

	private void sendSMS(IFormReference iform) {
		try {
			// check decision
			// fetch from DB for notification(only 1 template)
			String alertTExt;

			int size = iform.getDataFromGrid("table29").size();
			if (size <= 3) {
				String Decision = (String) iform.getValue("DECISION");
				String alertCode = "SMS1";
				if (("Customer Notification").equalsIgnoreCase(Decision))
					alertCode = "SMS1_Notification";

				String query = "SELECT SMSContent FROM NG_KYC_REM_SMS_TEMPLATE with(nolock) WHERE SMSNumber = '"
						+ alertCode + "'";
				List<List<String>> dataFromDB = iform.getDataFromDB(query);
				KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
				if (!dataFromDB.isEmpty()) {
					alertTExt = dataFromDB.get(0).get(0);
					String tablename = "NG_RLOS_SMSQUEUETABLE";
					String alertName = "KYC_SMS";
					String alertStatus = "P";
					String mobileNo = (String) iform.getValue("CompanyMobileOffice");
					// String AlertSubject = "Important : KYC Update";
					String Workstep = iform.getActivityName();
					String processinstanceID = getWorkitemName(iform);
					String columnNAme = "(Alert_Name,Alert_Code,Alert_Status,Mobile_No,Alert_Text,WI_Name,Workstep_Name,inserted_Date_time)";
					String values = "('" + alertName + "','" + alertCode + "','" + alertStatus + "','" + mobileNo
							+ "','" + alertTExt + "','" + processinstanceID + "','" + Workstep + "',getDate())";
					String SMSquery = "INSERT INTO " + tablename + " " + columnNAme + " VALUES " + values;
					KYC_Remediation.mLogger.debug("SMSquery: " + SMSquery);
					int res = iform.saveDataInDB(SMSquery);
					if (res == 1) {
						KYC_Remediation.mLogger.debug("response for SMS " + res);
						iform.setTableCellValue("table29", size - 1, 7, alertTExt);
					}
				} else
					KYC_Remediation.mLogger.debug("No SMS to send");
			}
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Error in sendSMS --" + e.getMessage());
		}
	}

}