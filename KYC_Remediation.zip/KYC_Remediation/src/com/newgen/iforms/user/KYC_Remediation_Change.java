package com.newgen.iforms.user;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import com.newgen.iforms.custom.IFormReference;

public class KYC_Remediation_Change extends KYC_Remediation_Common {

	public String changeEvent(IFormReference iform, String controlName, String event, String data) {
		String Workstep = iform.getActivityName();
		try{
			if("DECISION".equalsIgnoreCase(controlName)){
				String caseType = (String) iform.getValue("CaseType");
				String subSegment = (String) iform.getValue("subSegment");
				String Decision = (String) iform.getValue("DECISION");
				if("FI".equalsIgnoreCase(caseType)){
					
					// none
					
				} else {					
					String status = "";
					if(("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)) && (!"Reject".equalsIgnoreCase(Decision) && !"".equalsIgnoreCase(Decision))){
						iform.setStyle("table22","visible","true");//Deficiency list dropdown
					}
					else if(("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep))&& ("Reject".equalsIgnoreCase(Decision) || "".equalsIgnoreCase(Decision)))
					{
						iform.setStyle("table22","visible","false");//Deficiency list dropdown
						iform.clearTable("table22");
					} 
					else if("RM_Vendor".equalsIgnoreCase(Workstep))
					{
						if("Submit to Maker".equals(Decision)) iform.setStyle("OutreachInitialDateTime","mandatory","true");
						else iform.setStyle("OutreachInitialDateTime","mandatory","false");
					}
					String RiskProfile = (String)iform.getValue("RiskProfileDesc");
					if("High".equalsIgnoreCase(RiskProfile))
			        {
						if(("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)) && "Submit to Approver".equalsIgnoreCase(Decision)){
							String persona = (String) iform.getValue("CIFPersona");
							persona = persona.trim();
							persona = persona.replaceAll(" ", "");
							KYC_Remediation.mLogger.debug("persona - "+persona);
							String cusType = (String) iform.getValue("CusType");
							cusType = cusType.trim();
							KYC_Remediation.mLogger.debug("cusType - "+cusType);
							Properties properties = new Properties();
							properties.load(new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")+ "CustomConfig" + System.getProperty("file.separator")+ "KYC_Remediation" + System.getProperty("file.separator")+ "KYC_Config.properties"));
							String tag = cusType+"_"+persona;
							tag = tag.trim();
							KYC_Remediation.mLogger.debug("tag - "+tag);
							String mandatoryFields = properties.getProperty(tag);
							KYC_Remediation.mLogger.debug("mandatoryFields - "+mandatoryFields);
							String[] mandatoryField = mandatoryFields.split(",");
							for(String field : mandatoryField){
								KYC_Remediation.mLogger.debug("setting mandatory");
								iform.setStyle(field,"backcolor","#ffc1c175");
								iform.setStyle(field,"mandatory","true");
							}
					    }
						else
						{
							String persona = (String) iform.getValue("CIFPersona");
							persona = persona.trim();
							persona = persona.replaceAll(" ", "");
							KYC_Remediation.mLogger.debug("persona - "+persona);
							String cusType = (String) iform.getValue("CusType");
							cusType = cusType.trim();
							KYC_Remediation.mLogger.debug("cusType - "+cusType);
							Properties properties = new Properties();
							properties.load(new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")+ "CustomConfig" + System.getProperty("file.separator")+ "KYC_Remediation" + System.getProperty("file.separator")+ "KYC_Config.properties"));
							String tag = cusType+"_"+persona;
							tag = tag.trim();
							KYC_Remediation.mLogger.debug("tag - "+tag);
							String mandatoryFields = properties.getProperty(tag);
							KYC_Remediation.mLogger.debug("mandatoryFields - "+mandatoryFields);
							String[] mandatoryField = mandatoryFields.split(",");
							for(String field : mandatoryField){
								KYC_Remediation.mLogger.debug("setting mandatory");
								iform.setStyle(field,"backcolor","#ffc1c175");
								iform.setStyle(field,"mandatory","false");
							}
						}
			        } else{
			        	handleLowMedValidations(iform, "change");
			        }
					
					return status;
					
				}
				
				
		}
			else if("OtherSourceOfIncome".equalsIgnoreCase(controlName)){
				//jira 251
				String sourceOfIncome = (String)iform.getValue("OtherSourceOfIncome");
				KYC_Remediation.mLogger.debug("sourceOfIncome---"+sourceOfIncome);
				if(!sourceOfIncome.equalsIgnoreCase("")){
					KYC_Remediation.mLogger.debug("inside if of source of income");
					iform.setStyle("OtherIncome","mandatory","true");
				}
				else{
					KYC_Remediation.mLogger.debug("inside else of source of income");
					iform.setStyle("OtherIncome","mandatory","false");
					iform.setValue("OtherIncome", "");
				}		
			}
			
			else if(controlName.equalsIgnoreCase("CIFPersona")){
				String persona = (String)iform.getValue("CIFPersona");
				KYC_Remediation.mLogger.debug("persona----->"+persona);
				// setting mandatory fields
				persona = persona.trim();
				persona = persona.replaceAll(" ", "");
				KYC_Remediation.mLogger.debug("persona - "+persona);
				String cusType = (String) iform.getValue("CusType");
				cusType = cusType.trim();
				KYC_Remediation.mLogger.debug("cusType - "+cusType);
				Properties properties = new Properties();
				properties.load(new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")+ "CustomConfig" + System.getProperty("file.separator")+ "KYC_Remediation" + System.getProperty("file.separator")+ "KYC_Config.properties"));
				String tag = cusType+"_"+persona;
				tag = tag.trim();
				KYC_Remediation.mLogger.debug("tag - "+tag);
				String nonMandatoryFields = properties.getProperty("NonMandatory");
				String nonMandatoryField[] = nonMandatoryFields.split(",");
				for(String field : nonMandatoryField){
					iform.setStyle(field,"backcolor","#fcfcff");
					iform.setStyle(field,"mandatory","false");
					iform.setValue("DECISION","");
				}
				String mandatoryFields = properties.getProperty(tag);
				KYC_Remediation.mLogger.debug("mandatoryFields - "+mandatoryFields);
				String[] mandatoryField = mandatoryFields.split(",");
				for(String field : mandatoryField){
					iform.setStyle(field,"backcolor","#ffc1c175");
				}
				
				String persona1 = (String)iform.getValue("CIFPersona");
				if("Self Employed - Non Resident".equalsIgnoreCase(persona1.trim()) || "Self Employed - Resident".equalsIgnoreCase(persona1.trim()) || "Ruling Family".equalsIgnoreCase(persona1.trim()) || "Loan Only Customers".equalsIgnoreCase(persona1.trim()) || "Credit Card Only".equalsIgnoreCase(persona1.trim())){
					KYC_Remediation.mLogger.debug("Inside if block of persona country of operation----->"+persona1.trim());
					iform.setStyle("CountryOfOperation","visible","true");
				}
				else{
					KYC_Remediation.mLogger.debug("Inside else block of persona country of operation----->"+persona1.trim());
					iform.setStyle("CountryOfOperation","visible","false");
				}
				if ("Self Employed - Non Resident".equalsIgnoreCase(persona1.trim()) || "Self Employed - Resident".equalsIgnoreCase(persona1.trim())){
					KYC_Remediation.mLogger.debug("Inside if block of persona----->"+persona1.trim());
					iform.setStyle("label2","visible","true");
					iform.setStyle("BusinessAddress","visible","true");
					iform.setStyle("BusinessCountry","visible","true");
					iform.setStyle("BusinessFlatVillaNo","visible","true");
					iform.setStyle("BusinessEmirateCity","visible","true");
				}
				else{
					KYC_Remediation.mLogger.debug("Inside else block of persona----->"+persona1.trim());
					iform.setStyle("label2","visible","false");
					iform.setStyle("BusinessAddress","visible","false");
					iform.setStyle("BusinessCountry","visible","false");
					iform.setStyle("BusinessFlatVillaNo","visible","false");
					iform.setStyle("BusinessEmirateCity","visible","false");
				}
				if("Dependent - Resident".equalsIgnoreCase(persona1.trim()) || "Dependent - Non Resident".equalsIgnoreCase(persona1.trim()) || "Housewife - Non Resident".equalsIgnoreCase(persona1.trim()) || "Housewife - Resident".equalsIgnoreCase(persona1.trim()) || "Minor Account - Non - Resident".equalsIgnoreCase(persona1.trim()) || "Minor Account - Resident".equalsIgnoreCase(persona1.trim()) || "Students - Resident".equalsIgnoreCase(persona1.trim()) || "Students - Non Resident".equalsIgnoreCase(persona1.trim())){
					iform.setStyle("OfficeSponsorName", "mandatory", "true");
					iform.setStyle("OfficeSponsorName","backcolor","#ffc1c175");
				}
				else{
					iform.setStyle("OfficeSponsorName", "mandatory", "false");
					iform.setStyle("OfficeSponsorName","backcolor","#fcfcff");
				}
				
				handleLowMedValidations(iform, "change");
			}
			else if(controlName.equalsIgnoreCase("ResidentCountry")){
				KYC_Remediation.mLogger.debug("Inside ResidentCountry----->"+controlName);
				String residentCountry = (String)iform.getValue("ResidentCountry");
				iform.setValue("ResidenceCountry",residentCountry);
				iform.setValue("OfficeCountry",residentCountry);
				if("AE".equalsIgnoreCase(residentCountry)){
					iform.setValue("CusNonResidentIndicator","No");
					iform.setStyle("CusNonResidentIndicator","disable","true");
					iform.setValue("CustomerCategory","Resident Individual");
				}
				else{
					iform.setValue("CusNonResidentIndicator","Yes");
					iform.setStyle("CusNonResidentIndicator","disable","true");
					iform.setStyle("EmiratesIDexpiryDate","disable","true");
					iform.setStyle("EmiratedIDcardNumber","disable","true");
					iform.setStyle("EmiratesIDpingStatus","disable","true");
					iform.setStyle("EmiratesIDpingDate","disable","true");
				}
			}
			
			else if(controlName.equalsIgnoreCase("EmiratedIDcardNumber")){
				String DOB = (String)iform.getValue("DateOfBirth");
				String arrDOB[] = DOB.split("/");
				String year = arrDOB[2];
				String emiratesID = (String)iform.getValue("EmiratedIDcardNumber");
				boolean matchesYear = emiratesID.substring(3,7).equalsIgnoreCase(year);
				if(!matchesYear){
					iform.setValue("EmiratedIDcardNumber","");
					return "incorrectValue";
				}	
			}
			
			else if(controlName.equalsIgnoreCase("OwnerEmiratesID")){
				String DOB = (String)iform.getValue("OwnerDOB");
				if(!"".equalsIgnoreCase(DOB)){
				String arrDOB[] = DOB.split("/");
				String year = arrDOB[2];
				String emiratesID = (String)iform.getValue("OwnerEmiratesID");
				boolean matchesYear = emiratesID.substring(3,7).equalsIgnoreCase(year);
				if(!matchesYear){
					iform.setValue("OwnerEmiratesID","");
					return "incorrectValue";
				}
				}
			}
			
			else if (controlName.equalsIgnoreCase("GIIN"))
			{
				String GIIN = (String)iform.getValue("GIIN");
				if(!"".equalsIgnoreCase(GIIN)){
					int len = GIIN.length();
					if(len<16){
						iform.setValue("GIIN", "");
						return "GIIN invalid";
					}
				}
			}
			
			/*else if (controlName.equalsIgnoreCase("OwnerRiskProfile"))
			{
				String OwnerRiskProfile = (String)iform.getValue("OwnerRiskProfile");
				if(!"".equalsIgnoreCase(OwnerRiskProfile)){
				Double rScore = Double.parseDouble(OwnerRiskProfile);
					if(rScore>=1 && rScore<3){
						KYC_Remediation.mLogger.debug("Inside low");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(4);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
					if(rScore>=3 && rScore<4){
						KYC_Remediation.mLogger.debug("Inside medium");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(3);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
					if(rScore>=4 && rScore<5){
						KYC_Remediation.mLogger.debug("Inside high");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(1).plusMonths(6);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
				}
				else
				{
					iform.setValue("NextReviewDate","");
				}
			}
			
			
			else if (controlName.equalsIgnoreCase("EntityRiskProfile"))
			{
				String subSegment = "";
				String query = "Select VAR_STR8 FROM WFINSTRUMENTTABLE with (nolock) WHERE processinstanceid = '"+getWorkitemName(iform)+"'";
				List<List<String>> Segment = iform.getDataFromDB(query);
				if(!Segment.isEmpty()){
					KYC_Remediation.mLogger.debug("Sub Segment from wfinstrumenttable is - " + Segment);
					for(List<String> data1 : Segment)
					{
						subSegment = data1.get(0);
					}
				  }
				if(!"BBG".equalsIgnoreCase(subSegment)){
				String EntityRiskProfile = (String)iform.getValue("EntityRiskProfile");
				if(!"".equalsIgnoreCase(EntityRiskProfile)){
				Double rScore = Double.parseDouble(EntityRiskProfile);
					if(rScore>=1 && rScore<3){
						KYC_Remediation.mLogger.debug("Inside low");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(4);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
					if(rScore>=3 && rScore<4){
						KYC_Remediation.mLogger.debug("Inside medium");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(3);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
					if(rScore>=4 && rScore<5){
						KYC_Remediation.mLogger.debug("Inside high");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(1).plusMonths(6);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
				}
				else
				{
					iform.setValue("NextReviewDate","");
				}
			  }
			}
			
			else if (controlName.equalsIgnoreCase("RiskProfile"))
			{
				String RiskProfile = (String)iform.getValue("RiskProfile");
				if(!"".equalsIgnoreCase(RiskProfile)){
				Double rScore = Double.parseDouble(RiskProfile);
					if(rScore>=1 && rScore<3){
						KYC_Remediation.mLogger.debug("Inside low");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(4);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
					if(rScore>=3 && rScore<4){
						KYC_Remediation.mLogger.debug("Inside medium");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(3);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
					if(rScore>=4 && rScore<5){
						KYC_Remediation.mLogger.debug("Inside high");
						LocalDate now = LocalDate.now();
						LocalDate futureDate = now.plusYears(1).plusMonths(6);
						DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						String date = format.format(futureDate);
						iform.setValue("NextReviewDate", date);
					}
				}
				else
				{
					iform.setValue("NextReviewDate","");
				}
			}*/
			
			else if (controlName.equalsIgnoreCase("RiskProfile"))
			{
				try{
					String RiskProfile = (String)iform.getValue("RiskProfile");
					String caseType = (String)iform.getValue("CaseType");
					if(!"".equalsIgnoreCase(RiskProfile) && "Individual".equalsIgnoreCase(caseType)){
						Double rScore = Double.parseDouble(RiskProfile);
						if(rScore>=0 && rScore<3){
							KYC_Remediation.mLogger.debug("Inside low");
							iform.setValue("RiskProfileDesc", "Low");
						}
						if(rScore>=3 && rScore<4){
							KYC_Remediation.mLogger.debug("Inside medium");
							iform.setValue("RiskProfileDesc", "Medium");
						}
						if(rScore>=4 && rScore<=5){
							KYC_Remediation.mLogger.debug("Inside high");
							iform.setValue("RiskProfileDesc", "High");
						}
					}
					
					handleLowMedValidations(iform, "change");
					
				} catch (Exception e){
					KYC_Remediation.mLogger.debug("Exception in RiskProfile_desc: " + e);
				}
			}
			else if(controlName.equalsIgnoreCase("Remarks")){
				String remarks = (String) iform.getValue("Remarks");
				String append = Workstep+"-"+remarks;
				iform.setValue("Change_Field_List", append);
			}
			
			else if("ShareholderGrid_DOB".equalsIgnoreCase(controlName))
			{
				try{
				String selectedDate = data;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate inputDate = LocalDate.parse(selectedDate,formatter);
				LocalDate currentDate = LocalDate.now();
				if(inputDate.isAfter(currentDate) || inputDate.equals(currentDate)){
					return "Exceeds";
				}
				}catch(Exception e){
					KYC_Remediation.mLogger.debug("Exception in comparing date");
				}
			}
		
		else if("IndustrySubSegmentGrid".equalsIgnoreCase(controlName))
			{
				String Segmentcode = "";
				String subsegment = data;
				String query = "Select Top 1 MappedSegmentCode from NG_KYC_REM_Industry_SubSegment_MASTER WHERE SubSegment = '"+subsegment+"'";
				List<List<String>> Segment = iform.getDataFromDB(query);
				if(!Segment.isEmpty()){
					KYC_Remediation.mLogger.debug("Segment from Subsegment master - " + Segment);
					for(List<String> data1 : Segment)
					{
						Segmentcode = data1.get(0);
					}
				}
				return Segmentcode;
			}
			
			else if("table21".equalsIgnoreCase(controlName))
			{
				String Segmentcode = "";
				String subsegment = data;
				String query = "Select Top 1 MappedSegmentCode from NG_KYC_REM_Industry_SubSegment_MASTER WHERE SubSegment = '"+subsegment+"'";
				List<List<String>> Segment = iform.getDataFromDB(query);
				if(!Segment.isEmpty()){
					KYC_Remediation.mLogger.debug("Segment from Subsegment master - " + Segment);
					for(List<String> data1 : Segment)
					{
						Segmentcode = data1.get(0);
					}
				}
				return Segmentcode;
			}
			/*else if("OfficeEmployerNameDesc".equalsIgnoreCase(controlName)){
				String OfficeEmployerNameDesc = (String)iform.getValue("OfficeEmployerNameDesc");
				if(OfficeEmployerNameDesc.equalsIgnoreCase("OTHERS")){
					iform.setStyle("OfficeEmployerName","visible","true");
					//clearValue("OfficeEmployerName");
					iform.setValue("OfficeEmployerName","");
				}
				else{
					iform.setStyle("OfficeEmployerName","visible","false");
					//clearValue("OfficeEmployerName");
					iform.setValue("OfficeEmployerName","");
				}
			}*/
			else if("OfficeEmployerCode".equalsIgnoreCase(controlName))
			{
				String code = (String) iform.getValue("OfficeEmployerCode");
				String empName = "";
				String query = "SELECT TOP 1 EMPR_NAME FROM NG_RLOS_ALOC_OFFLINE_DATA with(nolock) where LTRIM(RTRIM(EMPLOYER_CODE)) = LTRIM(RTRIM('"+code+"')) AND EMPR_NAME is not null";
				List<List<String>> name = iform.getDataFromDB(query);
				if(!name.isEmpty()){
					KYC_Remediation.mLogger.debug("Employer Name from Employer master is - " + name);
					for(List<String> data1 : name)
					{
						empName = data1.get(0);
					}
				}
				iform.setValue("OfficeEmployerNameDesc", empName);
				if(empName.equalsIgnoreCase("OTHERS") || empName.equalsIgnoreCase("OTHER")){
					iform.setStyle("OfficeEmployerName","visible","true");
					//clearValue("OfficeEmployerName");
					iform.setValue("OfficeEmployerName","");
				}
				else{
					iform.setStyle("OfficeEmployerName","visible","false");
					//clearValue("OfficeEmployerName");
					iform.setValue("OfficeEmployerName","");
				}
			}
			else if("OwnerSourceOfCapital".equalsIgnoreCase(controlName))
			{
				String sourceOfCapital = (String)iform.getValue("OwnerSourceOfCapital");
				if("Any Other (Specify)".equalsIgnoreCase(sourceOfCapital)){
					iform.setStyle("OwnerSourceCapitalOthers","visible","true");
					iform.setValue("OwnerSourceCapitalOthers","");
				}
				else{
					iform.setStyle("OwnerSourceCapitalOthers","visible","false");
					iform.setValue("OwnerSourceCapitalOthers","");
				}
			}
			else if("ConsequenceStatus".equalsIgnoreCase(controlName))
			{
				String status = (String)iform.getValue("table25_ConsequenceStatus");
				String ConsequenceRowCount = (String)iform.getValue("ConsequenceRowCount");
				KYC_Remediation.mLogger.debug("Consequence row count..."+ConsequenceRowCount);
				int ConsequenceRowCountGrid = iform.getDataFromGrid("table25").size();
				KYC_Remediation.mLogger.debug("ConsequenceRowCountGrid..."+ConsequenceRowCountGrid);
				if("Consequence".equalsIgnoreCase(Workstep))
				{
					if("Partial Applied".equalsIgnoreCase(status))
					{
						for(int i=0;i<ConsequenceRowCountGrid;i++)
						{
							String existingStatus = iform.getTableCellValue("table25", i, 0);
							if("Fully Applied".equalsIgnoreCase(existingStatus))
							{
								iform.setValue("table25_ConsequenceStatus", "");
								return "Consequence Status is already set to Fully Applied.";
							}
						}
						for(int i=Integer.parseInt(ConsequenceRowCount);i<ConsequenceRowCountGrid;i++)
						{
							String existingStatus = iform.getTableCellValue("table25", i, 0);
							if("Put On Hold".equalsIgnoreCase(existingStatus))
							{
								iform.setValue("table25_ConsequenceStatus", "");
								return "Only one Consequence status can be selected at a time.";
							}
						}
					}
					if("Fully Applied".equalsIgnoreCase(status) || "Put On Hold".equalsIgnoreCase(status))
					{
						if(ConsequenceRowCountGrid>=Integer.parseInt(ConsequenceRowCount)+1)
						{
							iform.setValue("table25_ConsequenceStatus", "");
							return "Only one Consequence status can be selected at a time.";
						}
					}
					
				}
				else if("Approver".equalsIgnoreCase(Workstep))
				{
					if(ConsequenceRowCountGrid>=Integer.parseInt(ConsequenceRowCount)+1)
					{
						iform.setValue("table25_ConsequenceStatus", "");
						return "Only one Consequence status can be selected at a time.";
					}
				}
				return "true";
			} 
			else if("OutreachInitialDateTime".equalsIgnoreCase(controlName)){
				String query = "select top 1 DateTime from NG_KYC_REM_GR_HISTORY where Workstep = 'Maker' and Decision = 'Refer to RM Vendor' and WI_NAME = '" +getWorkitemName(iform)+"' order by DateTime";
				List<List<String>> dataFromDB = iform.getDataFromDB(query);
				if(!dataFromDB.isEmpty())
				{
					KYC_Remediation.mLogger.debug("dataFromDB - " + dataFromDB);
					String DBdateTimeStr = dataFromDB.get(0).get(0);
					
					try {
						if (DBdateTimeStr.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{1,2}")) {
							DBdateTimeStr = DBdateTimeStr + "0"; // Pad with a zero to // make it .SSS
							KYC_Remediation.mLogger.debug("DBdateTimeStr in if - " + DBdateTimeStr);
						}
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // 2024-01-28 13:14:48
						KYC_Remediation.mLogger.debug("after Sdf..");
						String outreachDateStr = (String)(iform.getValue("OutreachInitialDateTime"));
						KYC_Remediation.mLogger.debug("outreachDateStr.. - " + outreachDateStr);
						
						SimpleDateFormat sdfOutreach = new SimpleDateFormat("dd/MM/yyyy");
						Date outreachDate = sdfOutreach.parse(outreachDateStr);
						KYC_Remediation.mLogger.debug("after outreachDate parsing.");
						Date DBdateTime = sdf.parse(DBdateTimeStr);
						KYC_Remediation.mLogger.debug("after DBdateTime parsing.");
						
						if (outreachDate.before(DBdateTime)) {
							KYC_Remediation.mLogger.debug("in before..");
							iform.setValue("OutreachInitialDateTime", "");
							return "OutreachDateInvalid";
						} else {
							KYC_Remediation.mLogger.debug("in after..");
							return "OutreachDateValid";
						}
					} catch (Exception e) {
						KYC_Remediation.mLogger.debug("Exception: " + e);
						e.printStackTrace();
					}

				}
				
			}
			else if("OtherIncome".equalsIgnoreCase(controlName))
			{
				String monthlyIncomeStr = (String) iform.getValue("MonthlyIncome");
				Double monthlyIncome = Double.parseDouble("".equals(monthlyIncomeStr) ? "0" : monthlyIncomeStr);
				String otherIncomeStr = (String) iform.getValue("OtherIncome");
				Double otherIncome = Double.parseDouble("".equals(otherIncomeStr) ? "0" : otherIncomeStr);
				iform.setStyle("GrossMonthlyIncome","disable","true");
				iform.setValue("GrossMonthlyIncome", monthlyIncome + otherIncome + "");
			}
			else if("MonthlyIncome".equalsIgnoreCase(controlName))
			{
				String monthlyIncomeStr = (String) iform.getValue("MonthlyIncome");
				Double monthlyIncome = Double.parseDouble("".equals(monthlyIncomeStr) ? "0" : monthlyIncomeStr);
				String otherIncomeStr = (String) iform.getValue("OtherIncome");
				Double otherIncome = Double.parseDouble("".equals(otherIncomeStr) ? "0" : otherIncomeStr);
				iform.setStyle("GrossMonthlyIncome","disable","true");
				iform.setValue("GrossMonthlyIncome", monthlyIncome + otherIncome + "");
			}
			else if("frame21".equalsIgnoreCase(controlName))
			{
				String CIF_ID = (String)iform.getValue("CIF_ID");
				String primaryWI = "";
				String jointCifs = "";
				String query = "SELECT WINAME,Joint_Cif FROM RB_KYC_REM_EXTTABLE with(nolock) where Joint_Cif IS NOT NULL";
				List<List<String>> dataFromDB = iform.getDataFromDB(query);
				if(!dataFromDB.isEmpty())
				{
					KYC_Remediation.mLogger.debug("dataFromDB - " + dataFromDB);
					for(List<String> data1 : dataFromDB)
					{
						primaryWI = data1.get(0);
						jointCifs = data1.get(1);
						String[] arrJointCifs = jointCifs.split(";");
						for(String jointcif : arrJointCifs)
						{
							if(CIF_ID.equalsIgnoreCase(jointcif))
							{
								iform.setValue("PrimaryWI", primaryWI);
								break;
							}
						}
					}
				}
				
				
				// FI initial changes
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionType".equalsIgnoreCase(controlName)){
				String institutionType = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionType");				
				if("Parent".equalsIgnoreCase(institutionType)){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName", "visible", "false");
//					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress", "visible", "false");					

					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName", "");
//					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry", ""); // Q_NG_KYC_REM_FI_TR_TABLE_ParentPrincipalPlaceOp
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress", "");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate", "visible", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "visible", "false");
					
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "");
										
				} else{
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName", "visible", "true");
//					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress", "visible", "true");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate", "visible", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "visible", "true");
				}				
				
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_ListedFlag".equalsIgnoreCase(controlName)){
				if(!"Yes".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_ListedFlag"))){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "disable", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "disable", "true");
					//iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "disable", "true");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "mandatory", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "mandatory", "false");
					//iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "mandatory", "false");
					
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "");
					//iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "");					
				} else {
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "disable", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "disable", "false");
					//iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "disable", "false");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName", "mandatory", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite", "mandatory", "true");
					//iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite", "mandatory", "true");
				}
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_PEPHit".equalsIgnoreCase(controlName)){
				String pepHit = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_PEPHit");				
				if(!"Yes".equalsIgnoreCase(pepHit)){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "disable", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefENC", "disable", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefOFAC", "disable", "true");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "mandatory", "false");

					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefENC", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefOFAC", "");
				} else{
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "disable", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefENC", "disable", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPRefOFAC", "disable", "false");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus", "mandatory", "true");
				}
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_IsRegulated".equalsIgnoreCase(controlName)){
				if(!"Yes".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_IsRegulated"))){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "disable", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "disable", "true");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "mandatory", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "mandatory", "false");
					
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "");
				} else {
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "disable", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "disable", "false");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName", "mandatory", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry", "mandatory", "true");
				}
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_GIINNumber".equalsIgnoreCase(controlName)){
				if("".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_GIINNumber"))){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_USRelationFlag", "mandatory", "true");
				} else {
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_USRelationFlag", "mandatory", "false");
				}
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsDeclared".equalsIgnoreCase(controlName)){
				if("Yes".equalsIgnoreCase((String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsDeclared"))){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "disable", "false");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "mandatory", "true");
				} else{
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "disable", "true");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "");
					
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks", "mandatory", "false");
				}
			} else if("table41_PEPHit".equalsIgnoreCase(controlName)){
				String pepHit = (String)iform.getValue("table41_PEPHit");				
				if(!"Yes".equalsIgnoreCase(pepHit)){
					iform.setStyle("table41_PEPStatus", "disable", "true");
					iform.setStyle("table41_PEPHitRefNumberENC", "disable", "true");
					iform.setStyle("table41_PEPHitRefNumberOFAC", "disable", "true");
					
					iform.setStyle("table41_PEPStatus", "mandatory", "false");

					iform.setValue("table41_PEPStatus", "");
					iform.setValue("table41_PEPHitRefNumberENC", "");
					iform.setValue("table41_PEPHitRefNumberOFAC", "");
				} else{
					iform.setStyle("table41_PEPStatus", "disable", "false");
					iform.setStyle("table41_PEPHitRefNumberENC", "disable", "false");
					iform.setStyle("table41_PEPHitRefNumberOFAC", "disable", "false");
					
					iform.setStyle("table41_PEPStatus", "mandatory", "true");
				}
				
			} else if("table42_PEPHit".equalsIgnoreCase(controlName)){
				String pepHit = (String)iform.getValue("table42_PEPHit");				
				if(!"Yes".equalsIgnoreCase(pepHit)){
					iform.setStyle("table42_PEPStatus", "disable", "true");
					iform.setStyle("table42_PEPHitRefNumberENC", "disable", "true");
					iform.setStyle("table42_PEPHitRefNumberOFAC", "disable", "true");
					
					iform.setStyle("table42_PEPStatus", "mandatory", "false");

					iform.setValue("table42_PEPStatus", "");
					iform.setValue("table42_PEPHitRefNumberENC", "");
					iform.setValue("table42_PEPHitRefNumberOFAC", "");
				} else{
					iform.setStyle("table42_PEPStatus", "disable", "false");
					iform.setStyle("table42_PEPHitRefNumberENC", "disable", "false");
					iform.setStyle("table42_PEPHitRefNumberOFAC", "disable", "false");
					
					iform.setStyle("table42_PEPStatus", "mandatory", "true");
				}
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionIDType".equalsIgnoreCase(controlName)){
				KYC_Remediation.mLogger.debug("inside: "+ controlName);
				String IDType = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionIDType");
				if("AMIRI".equalsIgnoreCase(IDType))
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate", "disable", "true");
				else
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate", "disable", "false");
				
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType".equalsIgnoreCase(controlName)){
				KYC_Remediation.mLogger.debug("inside: "+ controlName);
				String IDType = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType");
				if("AMIRI".equalsIgnoreCase(IDType)){
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "disable", "true");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "mandatory", "false");
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "");
				} else {
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "disable", "false");
					iform.setStyle("Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate", "mandatory", "true");
				}
			}
			
			// FI changes end
			
		
		} catch(Exception e){
			KYC_Remediation.mLogger.debug("exception in change event -- "+e);
		}
		return controlName;
	}

	
	public static void handleLowMedValidations(IFormReference iform, String callingSource){
		try{
			String Decision = (String)iform.getValue("DECISION");
			String caseType = (String)iform.getValue("CaseType");
			String RiskProfile = (String)iform.getValue("RiskProfileDesc");
			
			if( caseType.equalsIgnoreCase("Individual") && ("Low".equalsIgnoreCase(RiskProfile) || "Medium".equalsIgnoreCase(RiskProfile)) ){
				String persona = (String) iform.getValue("CIFPersona");
				persona = persona.trim();
				persona = persona.replaceAll(" ", "");
				KYC_Remediation.mLogger.debug("persona - "+persona);
				String cusType = (String) iform.getValue("CusType");
				cusType = cusType.trim();
				KYC_Remediation.mLogger.debug("cusType - "+cusType);
				Properties properties = new Properties();
				properties.load(new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")+ "CustomConfig" + System.getProperty("file.separator")+ "KYC_Remediation" + System.getProperty("file.separator")+ "KYC_Config.properties"));
				
				// resetting everything
				String nonMandatoryFields = properties.getProperty("NonMandatory");
				String[] nonMandatoryField = nonMandatoryFields.split(",");
				for (String field : nonMandatoryField) {
					iform.setStyle(field, "backcolor", "#fcfcff");
					iform.setStyle(field, "mandatory", "false");
				}
				
				String tag = cusType+"_LowMed_"+persona;
				tag = tag.trim();
				KYC_Remediation.mLogger.debug("tag - "+tag);
				String mandatoryFieldStr = properties.getProperty(tag);
				KYC_Remediation.mLogger.debug("mandatoryFields - "+mandatoryFieldStr);
				String[] mandatoryFields = mandatoryFieldStr.split(",");
				persona = (String) iform.getValue("CIFPersona");
				for(String field : mandatoryFields){
					KYC_Remediation.mLogger.debug("field: "+ field);
					if("C3 Customers".equalsIgnoreCase(persona)){
					} else if("Corporate Cards".equalsIgnoreCase(persona)){
					} else if("Credit Card Only".equalsIgnoreCase(persona)){
						if("OfficeCountry".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("OfficeSponsorName".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("CountryOfIncorporation".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Supplementary Card Only".equalsIgnoreCase(persona)){
						if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Loan Only Customers".equalsIgnoreCase(persona)){
						if("OfficeSponsorName".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("CountryOfIncorporation".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Ruling Family".equalsIgnoreCase(persona)){
						
					} else if("Dependent - Resident".equalsIgnoreCase(persona) || "Dependent - Non Resident".equalsIgnoreCase(persona)){
						if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Employed - Resident".equalsIgnoreCase(persona) || "Employed - Non Resident".equalsIgnoreCase(persona)){
						if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Minor Account - Resident".equalsIgnoreCase(persona) || "Minor Account - Non - Resident".equalsIgnoreCase(persona)){
						if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Retired Individuals  - Resident".equalsIgnoreCase(persona) || "Retired Individuals  - Non Resident".equalsIgnoreCase(persona)){
						if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Self Employed - Resident".equalsIgnoreCase(persona) || "Self Employed - Non Resident".equalsIgnoreCase(persona)){
						if("OfficeSponsorName".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else if("Students  - Resident".equalsIgnoreCase(persona) || "Students  - Non Resident".equalsIgnoreCase(persona)){
						if("MonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("GrossMonthlyIncome".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else if("AECBBureauReferenceNo".equalsIgnoreCase(field))
							processID(field, iform, persona);
						else{
							iform.setStyle(field, "backcolor", "#ffc1c175");
							if (Decision.equalsIgnoreCase("Submit to Approver"))
								iform.setStyle(field, "mandatory", "true");
						}
					} else{
						iform.setStyle(field, "backcolor", "#ffc1c175");
						if (Decision.equalsIgnoreCase("Submit to Approver"))
							iform.setStyle(field, "mandatory", "true");
					}
				}
			}
		} catch(Exception e){
			KYC_Remediation.mLogger.debug("Error in change event");
			KYC_Remediation.mLogger.debug("Exception - "+e.toString());
		}
	}

	public static void processID(String id, IFormReference iform, String persona){
		
		String Decision = (String)iform.getValue("DECISION");
		KYC_Remediation.mLogger.debug("processID for id: "+ id +"and persona: " + persona);
		
		switch(id){
			case "OfficeCountry":
			String employmentType = (String) iform.getValue("OfficeEmploymentType");
			if("Self employed".equalsIgnoreCase(employmentType)){
				if("Loan Only Customers".equalsIgnoreCase(persona) || "Credit Card Only".equalsIgnoreCase(persona)){
					iform.setStyle("OfficeCountry", "backcolor", "#ffc1c175");
					if (Decision.equalsIgnoreCase("Submit to Approver")) {
						iform.setStyle("OfficeCountry", "mandatory", "true");
					}

				}
			}
			break;
			
			case "CountryOfIncorporation":					
			employmentType = (String) iform.getValue("OfficeEmploymentType");
			if("Self employed".equalsIgnoreCase(employmentType)){
				if("Loan Only Customers".equalsIgnoreCase(persona) || "Credit Card Only".equalsIgnoreCase(persona)){
					iform.setStyle("CountryOfIncorporation", "backcolor", "#ffc1c175");
					if (Decision.equalsIgnoreCase("Submit to Approver")) {
						iform.setStyle("CountryOfIncorporation", "mandatory", "true");
					}								 
				}
			}
			break;
			
			case "GrossMonthlyIncome":
			KYC_Remediation.mLogger.debug("Inside GrossMonthlyIncome");
			String monthlyIncomeStr = (String) iform.getValue("MonthlyIncome");
			Double monthlyIncome = Double.parseDouble("".equals(monthlyIncomeStr) ? "0" : monthlyIncomeStr);
			String otherIncomeStr = (String) iform.getValue("OtherIncome");
			Double otherIncome = Double.parseDouble("".equals(otherIncomeStr) ? "0" : otherIncomeStr);
			iform.setStyle("GrossMonthlyIncome","disable","true");
			iform.setValue("GrossMonthlyIncome", monthlyIncome + otherIncome + "");
						
			if("Supplementary Card Only".equalsIgnoreCase(persona) || "Credit Card Only".equalsIgnoreCase(persona)){
				iform.setStyle("ExpectedMonthlyCreditTurnover","disable","true");	
				iform.setStyle("MonthlyCashCRturnover","disable","true");	
				iform.setStyle("MonthlyCashNoonCRturnover","disable","true");	
				iform.setStyle("HighestCashCRtransaction","disable","true");	
				iform.setStyle("HighestNonCashCrTransaction","disable","true");			
			}
			break;
			
			case "AECBBureauReferenceNo":
			if("borrowing".equalsIgnoreCase("borrowing")){
				if("Students  - Resident".equalsIgnoreCase(persona) || "Students  - Non Resident".equalsIgnoreCase(persona)
					|| "Dependent - Non Resident".equalsIgnoreCase(persona) || "Dependent - Resident".equalsIgnoreCase(persona)
					||  "Employed - Non Resident".equalsIgnoreCase(persona) || "Employed - Resident".equalsIgnoreCase(persona)
					|| "Loan Only Customers".equalsIgnoreCase(persona) || "Credit Card Only".equalsIgnoreCase(persona)
					|| "Minor Account - Non - Resident".equalsIgnoreCase(persona) || "Minor Account - Resident".equalsIgnoreCase(persona)
					|| "Self Employed - Non Resident".equalsIgnoreCase(persona) || "Self Employed - Resident ".equalsIgnoreCase(persona)
				){								
					iform.setStyle("AECBBureauReferenceNo", "backcolor", "#ffc1c175");
					if (Decision.equalsIgnoreCase("Submit to Approver")) {
						iform.setStyle("AECBBureauReferenceNo", "mandatory", "true");
					}
				}							
			}
			break;
			
			case "OfficeSponsorName":
			if("Loan Only Customers".equalsIgnoreCase(persona) || "Credit Card Only".equalsIgnoreCase(persona)
					|| "Self Employed - Resident".equalsIgnoreCase(persona) || "Self Employed - Non Resident".equalsIgnoreCase(persona)){
				String employerNameDesc = (String) iform.getValue("OfficeEmployerNameDesc");
				if(!"".equalsIgnoreCase(employerNameDesc)){
					iform.setStyle("OfficeSponsorName", "backcolor", "#ffc1c175");
					if (Decision.equalsIgnoreCase("Submit to Approver")) {
						iform.setStyle("OfficeSponsorName", "mandatory", "true");
					}
				}
			}
		}
	}
	
}
