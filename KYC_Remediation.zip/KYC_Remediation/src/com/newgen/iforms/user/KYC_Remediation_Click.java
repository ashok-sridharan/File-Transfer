package com.newgen.iforms.user;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPageEventHelper;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.List;


import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.io.MemoryUsageSetting;




public class KYC_Remediation_Click extends KYC_Remediation_Common {

	public String clickEvent(IFormReference iform, String controlName, String data) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException 
	{
		KYC_Remediation.mLogger.debug("KYC_Remediation_Clicks");
		KYC_Remediation.mLogger.debug("WINAME : " + getWorkitemName(iform) + ", WSNAME: " + getActivityName(iform) + ", controlName " + controlName + ", data " + data);
		KYC_Remediation.mLogger.debug("controlName" + controlName);
		String response="";
		KYC_Remediation.mLogger.debug("onclickevent : control : " + controlName + " StringData :" + data);
		String MQ_response = "";
		try{
			String cramFlag = getCRAMFlag(iform);
			if(controlName.equalsIgnoreCase("Risk_score_trigger") && "N".equalsIgnoreCase(cramFlag)) {
				KYC_Remediation.mLogger.debug("onclickevent : Risk_score_trigger :");
				String finalXml = "";
				finalXml = RISK_SCORE_DETAILS(iform);
				
				if(!finalXml.contains("PEP Error") && !finalXml.contains("false - "))
				{
				MQ_response = KYC_Remediation_Integration.MQ_connection_response(iform, controlName, data, finalXml);
				KYC_Remediation.mLogger.debug("onclickevent : Risk_score_trigger : MQ_response: " + MQ_response);
				// code to set the risk score
				MQ_response = MQ_response.substring(MQ_response.indexOf("<?xml v"), MQ_response.indexOf("</MQ_RESPONSE_XML>"));
	
				Document doc = MapXML.getDocument(MQ_response);
				KYC_Remediation.mLogger.debug("onclickevent : Risk_score_trigger :" + MQ_response);
				String strCode = doc.getElementsByTagName("ReturnCode").item(0).getTextContent();
				KYC_Remediation.mLogger.debug("onclickevent : Risk_score_trigger : ReturnCode: " + strCode);
				String strDesc = doc.getElementsByTagName("ReturnDesc").item(0).getTextContent();
				KYC_Remediation.mLogger.debug("onclickevent : Risk_score_trigger : ReturnDesc: " + strDesc);
				String riskScore = doc.getElementsByTagName("TotalRiskScore").item(0).getTextContent();
				KYC_Remediation.mLogger.debug("onclickevent : Risk_score_trigger : ReturnDesc: " + strDesc);
				String  CaseType = (String)iform.getValue("CaseType");
				iform.setValue("RiskProfile",riskScore);
				iform.setValue("EntityRiskProfile",riskScore);
				Double rScore = Double.parseDouble(riskScore);
				KYC_Remediation.mLogger.debug("rScore: " + rScore);
				try{
					String caseType = (String)iform.getValue("CaseType");
					if(!"".equalsIgnoreCase(riskScore) && "Individual".equalsIgnoreCase(caseType) ){
						if(rScore>=0 && rScore<3){
							KYC_Remediation.mLogger.debug("Inside low");
							iform.setValue("RiskProfileDesc", "Low");
						}
						if(rScore>=3 && rScore<4){
							KYC_Remediation.mLogger.debug("Inside medium");
							iform.setValue("RiskProfileDesc", "Medium");
						}
						if(rScore>=4 && rScore<=5){
							KYC_Remediation.mLogger.debug("Inside high");
							iform.setValue("RiskProfileDesc", "High");
						}
					}
				} catch (Exception e){
					KYC_Remediation.mLogger.debug("Exception in RiskProfile_desc: " + e);
				}
				String query = "SELECT var_str8 FROM WFINSTRUMENTTABLE WITH(NOLOCK) WHERE ProcessInstanceID ='"+ getWorkitemName(iform) +"' AND Workitemid = '1'";
				List<List<String>> dataFromDB = iform.getDataFromDB(query);
				KYC_Remediation.mLogger.debug("dataFromDB1: " + dataFromDB);
				String type = (String)dataFromDB.get(0).get(0);
				KYC_Remediation.mLogger.debug("Subsegment: " + type);
				/*if(!"BBG".equalsIgnoreCase(type) && !"PBG".equalsIgnoreCase(type))
				{
				if(rScore>=1 && rScore<3){
					KYC_Remediation.mLogger.debug("Inside low");
					LocalDate now = LocalDate.now();
					LocalDate futureDate = now.plusYears(4);
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					String date = format.format(futureDate);
					iform.setValue("NextReviewDate", date);
				}
				if(rScore>=3 && rScore<4){
					KYC_Remediation.mLogger.debug("Inside medium");
					LocalDate now = LocalDate.now();
					LocalDate futureDate = now.plusYears(3);
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					String date = format.format(futureDate);
					iform.setValue("NextReviewDate", date);
				}
				if(rScore>=4 && rScore<5){
					KYC_Remediation.mLogger.debug("Inside high");
					LocalDate now = LocalDate.now();
					LocalDate futureDate = now.plusYears(1).plusMonths(6);
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					String date = format.format(futureDate);
					iform.setValue("NextReviewDate", date);
				}
				}*/
				String Res="";
				// risk sheet generation - Start 
				String PdfName="Risk Score Sheet";
				String Status=createPDF(iform,"Risk_Score",getWorkitemName(iform),PdfName);
				KYC_Remediation.mLogger.debug("WINAME : "+getWorkitemName(iform)+", WSNAME: "+getActivityName(iform)+", Status : "+Status);
	
				if(!Status.contains("Error")){
					Res=AttachDocumentWithWI(iform,getWorkitemName(iform),PdfName,"Click");
					KYC_Remediation.mLogger.debug(" No Error in RISK PDF Gen :  Res"+Res);
					KYC_Remediation.mLogger.debug("No Error in RISK PDF Gen :  Res"+strCode+"~"+strDesc+"~"+Res);
					//return strCode+"~"+strDesc+"~"+Res;
					return Res;
				}
				else{
					KYC_Remediation.mLogger.debug("Error in RISK PDF Gen :  Res"+strCode+"~"+Status+"~"+strDesc);
					return Res=strCode+"~"+Status;
				}
			}
				else
					return finalXml;	
			}
			//start CRAM RRC Integration
			else if(controlName.equalsIgnoreCase("Risk_score_trigger") && "Y".equalsIgnoreCase(cramFlag)){
				KYC_Remediation.mLogger.debug("onclickevent : CRAM Risk_score_trigger.....");
				String wiName = getWorkitemName(iform);
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		        String dateTime = LocalDateTime.now().format(formatter);
				String requestId = wiName.substring(4, 14)+dateTime;
				JSONObject req = new JSONObject();
				makeJSONRequest(req, requestId, iform);
				String CRAMresponse = callCRAMRRCGateway(req.toString(), requestId, iform);
				String finalRes = processCramResponse(iform, CRAMresponse, wiName);
				if(finalRes.startsWith("0000"))
				{
					String riskScore = finalRes.substring(13);
					iform.setValue("RiskProfile",riskScore);
					iform.setValue("EntityRiskProfile",riskScore);
					Double rScore = Double.parseDouble(riskScore);
					KYC_Remediation.mLogger.debug("rScore: " + rScore);
					try{
						String caseType = (String)iform.getValue("CaseType");
						if(!"".equalsIgnoreCase(riskScore) && "Individual".equalsIgnoreCase(caseType) ){
							if(rScore>=0 && rScore<3){
								KYC_Remediation.mLogger.debug("Inside low");
								iform.setValue("RiskProfileDesc", "Low");
							}
							if(rScore>=3 && rScore<4){
								KYC_Remediation.mLogger.debug("Inside medium");
								iform.setValue("RiskProfileDesc", "Medium");
							}
							if(rScore>=4 && rScore<=5){
								KYC_Remediation.mLogger.debug("Inside high");
								iform.setValue("RiskProfileDesc", "High");
							}
						}
					} catch (Exception e){
						KYC_Remediation.mLogger.debug("Exception in RiskProfile_desc: " + e);
					}
					
					return finalRes;
				}
				else
				{
					return finalRes;
				}
				
			}
			//end CRAM RRC integration
			else if (controlName.equalsIgnoreCase("KYC_Download")){
				
				String caseType = (String)iform.getValue("CaseType");
				String Res = "", PdfName="KYC_Form";
				
				if(caseType.equalsIgnoreCase("FI")){
					String output1 = createCustomPDfFI(iform);
					KYC_Remediation.mLogger.debug("output1: "+ output1);
					
					if(output1.contains("Success")){
						Res = AttachKYC_FormWithWI(iform,getWorkitemName(iform),PdfName,"Click");
						KYC_Remediation.mLogger.debug("No Error in RISK PDF Gen for FI case :  Res"+Res);
						
						return Res;
					}
					
					return "Failure in Application Form generation with result as, output1: " + output1;					
				}
				
				 
				 if(caseType.equalsIgnoreCase("Individual")){
					 PdfName="KYC_Form";
				 }
				 if(caseType.equalsIgnoreCase("Corporate")){
					 PdfName="KYC_Form_Corporate";
					//Shareholder percentage logic
					 KYC_Remediation.mLogger.debug("debugging start....");
					 String LegalEntity = (String)iform.getValue("LegalEntity");
					 KYC_Remediation.mLogger.debug("LegalEntity in click: " + LegalEntity);
										
					Map<String,Double> shHoldingGridMap = new HashMap<>();
		            JSONArray shHoldingGridJsonArray = iform.getDataFromGrid("table26");
		            for(int i=0; i<shHoldingGridJsonArray.size(); i++){
		                  JSONObject jsonObj = (JSONObject)shHoldingGridJsonArray.get(i);
		                  KYC_Remediation.mLogger.debug("jsonObj - "+jsonObj);
		                  Object identifier = "Main Holder";
		                  String mainHolder = (String) jsonObj.getOrDefault(identifier, "0.0");
		                  identifier = "% Shareholding(If applicable)";
		                  String percent = (String) jsonObj.getOrDefault(identifier, "0.0");
		                  Double dblPercent = Double.parseDouble(percent);
		                  KYC_Remediation.mLogger.debug("dblPercent - "+dblPercent);

		                  shHoldingGridMap.put(mainHolder, shHoldingGridMap.getOrDefault(mainHolder, 0.0) + dblPercent);
		            }
		            
		            for(String key : shHoldingGridMap.keySet()){
	                   BigDecimal bd = new BigDecimal(shHoldingGridMap.get(key)).setScale(2, RoundingMode.HALF_UP);
	                   double num = bd.doubleValue();
	                   KYC_Remediation.mLogger.debug("num - "+num);
	                   
	                   if("Public Shareholding Company PJSC".equalsIgnoreCase(LegalEntity) || "Public Joint Stock Company".equalsIgnoreCase(LegalEntity) ||
								"Society/ Trusts/ Clubs".equalsIgnoreCase(LegalEntity)){
							if (num > 100.0) {
								KYC_Remediation.mLogger.debug("returning as sum is - " + num);
								return "Failure due to percentage greater than 100 for: " + key;
							}
							
						} else {
							if (num != 100.0) {
								KYC_Remediation.mLogger.debug("returning as sum is - " + num);
								return "Failure due to percentage not being equal to 100 for: " + key;
							}
						}
	                   
		            }
			            
				 	
						// Shareholder percentage logic end
				 }
				if(caseType.equalsIgnoreCase("RelatedParty")){
					PdfName="KYC_Form_RP";
				}
				
				String output1 = generateApplicationFrom("KYC_Form",getWorkitemName(iform),getSessionId(iform),iform, "");
				String output2 = caseType.equalsIgnoreCase("Corporate") ? createCustomPDf(iform) : "Success, Cuz it's Individual/RP.";				
				KYC_Remediation.mLogger.debug("output1: "+ output1);
				KYC_Remediation.mLogger.debug("output2: "+ output2);
				
				if(output1.contains("Success") && output2.contains("Success")){
					Res = AttachKYC_FormWithWI(iform,getWorkitemName(iform),PdfName,"Click");
					KYC_Remediation.mLogger.debug(" No Error in RISK PDF Gen :  Res"+Res);
					// return strCode+"~"+strDesc+"~"+Res;
					return Res;
				} else {
					return "Failure in Application Form generation with reult as, output1: " + output1 + "output2: " + output2;
				}
			}
			else if (controlName.equalsIgnoreCase("SignedDate"))
			{ 
				String signedDate = (String)iform.getValue("SignedDate");
				if("".equalsIgnoreCase(signedDate)){
					iform.setValue("ExpiryDate","");
				}
				else{
				DateTimeFormatter inputformatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate localDate = LocalDate.parse(signedDate,inputformatter);
				LocalDate newDate = localDate.plusYears(3);
				DateTimeFormatter outputformatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				String outputDate = newDate.format(outputformatter);
				iform.setValue("ExpiryDate",outputDate);	
				}
			}
			else if (controlName.equalsIgnoreCase("PassportIssueDate"))
			{
				String expiryDate = (String)iform.getValue("PassportExpiryDate");
				if(!expiryDate.equalsIgnoreCase("")){
				//LocalDate currentDate = LocalDate.now();
				String issueDate = (String)iform.getValue("PassportIssueDate");
				LocalDate date1 = LocalDate.parse(issueDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				LocalDate date2 = LocalDate.parse(expiryDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				if(date1.isAfter(date2)){
					iform.setValue("PassportIssueDate", "");
					return "IssueDateGreater";
				}
				long yearsBetween = ChronoUnit.DAYS.between(date1,date2);
				//LocalDate tenYearsAgo = LocalDate.now().minusYears(10).minusDays(15);
				if(yearsBetween>(10*365)+15){
					iform.setValue("PassportIssueDate", "");
					return "beforedate";
				}
				}
				return "afterDate";
			}
			else if (controlName.equalsIgnoreCase("PassportExpiryDate"))
			{
				String issueDate = (String)iform.getValue("PassportIssueDate");
				String expiryDate = (String)iform.getValue("PassportExpiryDate");
				LocalDate date1 = LocalDate.parse(issueDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				LocalDate date2 = LocalDate.parse(expiryDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				if(date2.isBefore(date1)){
					iform.setValue("PassportExpiryDate","");
					return "ExpiryDateLess";
				}
				long yearsBetween = ChronoUnit.DAYS.between(date1,date2);
				if(yearsBetween<(10*365)+15){
					return "lessThan10Years";
				}
				iform.setValue("PassportExpiryDate","");
				return "moreThan10Years";
			}
			else if (controlName.equalsIgnoreCase("OwnerPassportIssueDate"))
			{
				String issueDate = (String)iform.getValue("OwnerPassportIssueDate");
				LocalDate date = LocalDate.parse(issueDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				LocalDate tenYearsAgo = LocalDate.now().minusYears(10).minusDays(15);
				if(date.isBefore(tenYearsAgo)){
					iform.setValue("OwnerPassportIssueDate", "");
					return "beforedate";
				}
				return "afterDate";
			}
			else if (controlName.equalsIgnoreCase("OwnerPassportExpiryDate"))
			{
				String issueDate = (String)iform.getValue("OwnerPassportIssueDate");
				String expiryDate = (String)iform.getValue("OwnerPassportExpiryDate");
				LocalDate date1 = LocalDate.parse(issueDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				LocalDate date2 = LocalDate.parse(expiryDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				long yearsBetween = ChronoUnit.DAYS.between(date1,date2);
				if(yearsBetween<(10*365)+15){
					return "lessThan10Years";
				}
				iform.setValue("OwnerPassportExpiryDate","");
				return "moreThan10Years";
			}
			
			//26 January 2026
			else if (controlName.equalsIgnoreCase("Consequence_held_till"))
			{
				String consequenceheldTillDate = (String)iform.getValue("Consequence_held_till");
				
				LocalDate date1 = LocalDate.parse(consequenceheldTillDate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				LocalDate today = LocalDate.now();
				
				long daysBetween = ChronoUnit.DAYS.between(today, date1); 
				if (daysBetween > 45) { 
					return "moreThan45Days"; 
					} 
				return "lessThanOrEqual45Days";
			}
			// end 26 January 2026
			
			else if(controlName.equalsIgnoreCase("Doc_ID")){
				List DOC_ID=iform.getDataFromDB("select next value for [KYC_REM_DOC_ID] As DOC_ID");
				KYC_Remediation.mLogger.debug("Generated DOC_ID:"+DOC_ID);
	            String value="";
	            for(int i=0;i<DOC_ID.size();i++)
	            {
	                  List<String> arr1=(List)DOC_ID.get(i);
	                  value=arr1.get(0);
	            }
	            iform.setTableCellValue("Outreach_Grid",(Integer.parseInt(data)-1),0,value);
			}
			else if(controlName.equalsIgnoreCase("table25"))  //Consequence Management Grid
			{ 
				String user = iform.getUserName();
				iform.setValue("table25_UserName", user);
				Date cDate = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				String strdate = sdf.format(cDate);
				iform.setValue("table25_DateTime", strdate);
				
				String ConsequenceRowCount = (String)iform.getValue("ConsequenceRowCount");
				KYC_Remediation.mLogger.debug("Consequence row count..."+ConsequenceRowCount);
				int ConsequenceRowCountGrid = iform.getDataFromGrid("table25").size();
				KYC_Remediation.mLogger.debug("ConsequenceRowCountGrid..."+ConsequenceRowCountGrid);
				
				iform.clearCombo("table25_ActionTaken");
				
				if(ConsequenceRowCountGrid>Integer.parseInt(ConsequenceRowCount))
				{
					String subSegment = (String)iform.getValue("subSegment");
					String previousStatus = (String)iform.getTableCellValue("table25", ConsequenceRowCountGrid-1, 0);
					String query = "SELECT Action From NG_KYC_REM_CONSEQUENCE_ACTION_MASTER WHERE Activity = '"+getActivityName(iform)+"' AND ConsStaus = '"+previousStatus+"' AND isActive = 'Y' AND SubSegment = '"+subSegment+"'";
					List<List<String>> dataFromDB = iform.getDataFromDB(query);
					if(!dataFromDB.isEmpty())
					{
						for(List<String> listValue : dataFromDB)
						{
							for(String valueIs : listValue)
							{
								iform.addItemInCombo("table25_ActionTaken", valueIs);
							}
						}
					}
					if("Partial Applied".equalsIgnoreCase(previousStatus))
					{
						KYC_Remediation.mLogger.debug("inside Partial Applied table 25");
						iform.setValue("table25_ConsequenceStatus", previousStatus);
						iform.setStyle("table25_ConsequenceStatus", "disable", "true");
						KYC_Remediation.mLogger.debug("ConsequenceRowCountGrid..."+ConsequenceRowCountGrid);
						return "enable";
					}
					if("Fully Applied".equalsIgnoreCase(previousStatus) || "Put On Hold".equalsIgnoreCase(previousStatus))
					{
						KYC_Remediation.mLogger.debug("inside Fully Applied table 25");
						iform.setValue("table25_ConsequenceStatus", previousStatus);
						iform.setStyle("table25_ConsequenceStatus", "disable", "true");
						iform.setStyle("addrowandnext_table25", "disable", "true");
						iform.setStyle("addrow_table25", "disable", "true");
						iform.setStyle("table25_ActionTaken", "disable", "true");
						return "disable";
					}
				}
				else
				{
					iform.setStyle("table25_ConsequenceStatus", "disable", "false");
					iform.setStyle("table25_ActionTaken", "disable", "false");
					iform.setStyle("addrowandnext_table25", "disable", "false");
					iform.setStyle("addrow_table25", "disable", "false");
					return "enable";
				}
			}
			
			else if("table29".equalsIgnoreCase(controlName)) // customer communication grid
			{
				int rowCount = iform.getDataFromGrid("table29").size();
				String email = (String)iform.getValue("CompanyEmailID");
	                        
				JSONArray RPGridArray = iform.getDataFromGrid("table4");    		
				KYC_Remediation.mLogger.debug("RPGridArray: "+ RPGridArray);
	    		for(int i=0; i<RPGridArray.size(); i++){
	    			List<String> list = new ArrayList<>();
	    			
	    			JSONObject rowObj = (JSONObject)RPGridArray.get(i);
	    			KYC_Remediation.mLogger.debug("rowObj: "+ rowObj);
	                
	                String WINAME = (String) rowObj.get("WI Number");
	                KYC_Remediation.mLogger.debug("WINAME: "+ WINAME);
	                
	    			List<List<String>> RPEmailList = iform.getDataFromDB("SELECT OwnerEmailID FROM RB_KYC_REM_EXTTABLE WHERE WINAME = '"+ WINAME +"'");
	    			KYC_Remediation.mLogger.debug("RP WI List: "+ RPEmailList);
	    			if(RPEmailList != null && !RPEmailList.isEmpty()){
	    			    for (List<String> emailID : RPEmailList) {
	    			        if (emailID != null && !emailID.isEmpty() && emailID.size()>0) { // Extra null check
	    			            String recepient = emailID.get(0);
	    			            if (recepient != null && !recepient.isEmpty()) {
	    			                email += "," + recepient;
	    			            }
	    			        } else {
	    			            KYC_Remediation.mLogger.debug("Skipping empty emailID list.");
	    			        }
	    			    }
	    			} else {
	    			    KYC_Remediation.mLogger.debug("RPEmailList is empty or null.");
	    			}
	
	    		}
				//int RProwCount = iform.getDataFromGrid("table4").size();
	    		
				if(rowCount == 0)
				{
					iform.setValue("table29_SNO","1");
					iform.setValue("table29_ToEmail",email);
					iform.setValue("table29_Subject","Action Required: Update You KYC Details -");
				}
				if(rowCount > 0)
				{
					String sno = (iform.getTableCellValue("table29", rowCount-1, 0)).trim();
				    KYC_Remediation.mLogger.debug("sno - "+sno);
					String majorversion = sno.split("\\.")[0];
				    KYC_Remediation.mLogger.debug("majorversion - "+majorversion);
					int version = Integer.parseInt(majorversion)+1;
				    KYC_Remediation.mLogger.debug("version - "+version);
					//int version = Character.getNumericValue(majorversion)+1;
					iform.setValue("table29_SNO",String.valueOf(version));
					iform.setValue("table29_ToEmail",email);
					iform.setValue("table29_Subject","Action Required: Update You KYC Details -");
				}
			}
			
			/*else if("ModalSaveBtn".equalsIgnoreCase(controlName))
			{
				KYC_Remediation.mLogger.debug("inside save mail on click button");
				int rowCount = iform.getDataFromGrid("table29").size();
				KYC_Remediation.mLogger.debug("rowCount --> "+rowCount);
				//String emailContent = iform.getTableCellValue("table29", rowCount-1, 6);
				KYC_Remediation.mLogger.debug("data: --> " + data);
				String emailContent = getEmailContent();
				emailContent = emailContent.replaceAll("#toReplace#", data);
				KYC_Remediation.mLogger.debug("emailContent --> "+emailContent);
				String query = "UPDATE NG_KYC_REM_CUST_COMMUNICATION SET EmailFinal = N'"+emailContent+"' WHERE WINAME = '"+getWorkitemName(iform)+"' AND SendDateTime IS NULL";
				KYC_Remediation.mLogger.debug("query" + query);
				int res = iform.saveDataInDB(query);
				KYC_Remediation.mLogger.debug("response--" + res);
				if (res==1) return "success";
				else return "error";
			}*/
			
			else if(controlName.equalsIgnoreCase("WI_Open"))
			{
				IFormXmlResponse xmlParserData = new IFormXmlResponse();
				StringBuffer ipXMLBuffer=new StringBuffer();
				String sCabname = getCabinetName(iform);
				KYC_Remediation.mLogger.debug("sCabname" + sCabname);
				String sSessionId = getSessionId(iform);
				KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
				
				String caseType = (String)iform.getValue("CaseType");
				if("Corporate".equalsIgnoreCase(caseType))
				{
				int rowIndex = Integer.parseInt(data);
				String WINAme = iform.getTableCellValue("table4",rowIndex,1);
				
				String query2 = "Select VAR_STR8 from WFINSTRUMENTTABLE where ProcessInstanceID ='"+WINAme+"' AND Workitemid = '1'";
				List<List<String>> query_output2 = iform.getDataFromDB(query2);
				KYC_Remediation.mLogger.debug("query_output--:"+query_output2);
				String  VAR_STR8 = query_output2.get(0).get(0);
				String Decision = (String) iform.getValue("DECISION");
				String saveQuery = "UPDATE RB_KYC_REM_EXTTABLE SET Mandatory_Field_List = '"+VAR_STR8+"',EntityDecision = '"+Decision+"' Where WINAME = '"+WINAme+"'";
				KYC_Remediation.mLogger.debug("saveQuery--:"+saveQuery);
				iform.saveDataInDB(saveQuery);
				
				//updateWInameInext(iform,WINAme);
				String columnNames="VAR_STR1,VAR_STR8";
				String columnValues="'ToVisible','ToVisible'";
				String sWhereClause ="ProcessInstanceID ='"+WINAme+"'";
				
				KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
				
				ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
				ipXMLBuffer.append("<APUpdate_Input>\n");
				ipXMLBuffer.append("<Option>APUpdate</Option>\n");
				ipXMLBuffer.append("<TableName>");
				ipXMLBuffer.append("WFINSTRUMENTTABLE");
				ipXMLBuffer.append("</TableName>\n");
				ipXMLBuffer.append("<ColName>");
				ipXMLBuffer.append(columnNames);
				ipXMLBuffer.append("</ColName>\n");
				ipXMLBuffer.append("<Values>");
				ipXMLBuffer.append(columnValues);
				ipXMLBuffer.append("</Values>\n");
				ipXMLBuffer.append("<WhereClause>");
				ipXMLBuffer.append(sWhereClause);
				ipXMLBuffer.append("</WhereClause>\n");
				ipXMLBuffer.append("<EngineName>");
				ipXMLBuffer.append(sCabname);
				ipXMLBuffer.append("</EngineName>\n");
				ipXMLBuffer.append("<SessionId>");
				ipXMLBuffer.append(sSessionId);
				ipXMLBuffer.append("</SessionId>\n");
				ipXMLBuffer.append("</APUpdate_Input>");
				
				String apUpdateinput = ipXMLBuffer.toString();
				KYC_Remediation.mLogger.debug("apUpdateinput--->"+apUpdateinput);
				String OutputXML = ExecuteQueryOnServer(apUpdateinput, iform);
				KYC_Remediation.mLogger.debug("sOutputXML--->"+OutputXML);
				xmlParserData.setXmlString((OutputXML));
				String status_get = xmlParserData.getVal("MainCode");
				KYC_Remediation.mLogger.debug("status for wf table--->"+status_get);
				}
				String query = "Select CONST_FIELD_VALUE from USR_0_BPM_CONSTANTS where CONST_FIELD_NAME = 'KYC_Rem_IP_PORT'";
				List<List<String>> query_output = iform.getDataFromDB(query);
				KYC_Remediation.mLogger.debug("query_output--:"+query_output);
				String  IpPort = query_output.get(0).get(0);
				String userName = getUserName(iform);
				String userIndexquery = "Select UserIndex from pdbuser where username = '"+userName+"'";
				List<List<String>> userIndexqueryOutput = iform.getDataFromDB(userIndexquery);
				KYC_Remediation.mLogger.debug("query_output--:"+query_output);
				String  UserIndex = userIndexqueryOutput.get(0).get(0);
				return IpPort+"-"+UserIndex;
				
			} 
			else if(controlName.equalsIgnoreCase("DateOfBirth")){
				String dob = (String)iform.getValue("DateOfBirth");
				if(!dob.equalsIgnoreCase(""))
				{
					LocalDate date1 = LocalDate.now();
					LocalDate date2 = LocalDate.parse(dob,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
					if(date1.equals(date2)){
						iform.setValue("DateOfBirth", "");
						return "IssueDateSame";
					}
				}
			} else if("SHGrid_MasterDataReq".equalsIgnoreCase(controlName)){
				
				StringBuilder sb = new StringBuilder();
				
				// title
				String query = "Select Description,Code FROM NG_KYC_REM_Salutation_MASTER with(nolock) where isActive = 'Y'";
				String rv = getMasterData(query, iform, "Title");				
				sb.append(rv);
								
				// country of birth
				query = "select distinct CD_DESC,CM_CODE from NG_MASTER_KYC_REM_COUNTRY_OF_RESIDENCE";
				rv = getMasterData(query, iform, "Country of Birth");				
				sb.append(rv);
				
				// resident country
				query = "select distinct CD_DESC,CM_CODE from NG_MASTER_KYC_REM_COUNTRY_OF_RESIDENCE";
				rv = getMasterData(query, iform, "Resident Country");			
				sb.append(rv);
				
				// tin reason
				query = "Select TINReason,TINReason from NG_KYC_REM_NoTINReason_MASTER with (nolock)";
				rv = getMasterData(query, iform, "No TIN Reason");
				sb.append(rv);
				
				// form obtained
				query = "Select Form,Code from NG_KYC_REM_FORM_OBTAINED_MASTER with(nolock) Where isActive = 'Y'";
				rv = getMasterData(query, iform, "Form obtained");
				sb.append(rv);
				
				// Emirate City
				query = "Select cityName,cityCode  from NG_KYC_REM_CITY_MASTER with(nolock)";
				rv = getMasterData(query, iform, "Emirate City");
				sb.append(rv);
				
				// Docs Outreach
				query = "SELECT DOCUMENT_NAME,DOCUMENT_NAME FROM NG_KYC_REM_OUTREACH_DOCS_MASTER WITH(NOLOCK) WHERE ISACTIVE = 'Y' AND CaseType = 'Shareholder'";
				rv = getMasterData(query, iform, "Docs Outreach");
				sb.append(rv);
				
				KYC_Remediation.mLogger.debug("Final sb string --: "+ sb.toString());
				return sb.toString();
				
			} else if("SHGrid_GenerateForm".equalsIgnoreCase(controlName)){ // byVar
				
				String idx = data;
				String output1 = generateApplicationFrom("KYC_Form_SH",getWorkitemName(iform),getSessionId(iform),iform, idx);
				KYC_Remediation.mLogger.debug("output1 for KYC_Form_SH: "+ output1);
				
				if(output1.contains("Success")){
					String name = iform.getTableCellValue("table26",Integer.parseInt(idx),1);
					String lvl = iform.getTableCellValue("table26",Integer.parseInt(idx),0);
					lvl = lvl.replace('.', '_');
					
					String Res = AttachKYC_FormWithWI(iform,getWorkitemName(iform),"KYC_Form_RP", "KYC_Form_SH"+ "~" + name +"~"+lvl);
					KYC_Remediation.mLogger.debug(" No Error in RISK PDF Gen : "+Res);
					
					/*
					String sCabname = getCabinetName(iform);
					String sSessionId = getSessionId(iform);
					String colNames = "Name,FormGenFlag,GenerationDateTime,CurrentWS";
					String colValues = "";
					
					String datetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					
					colValues += "'"+name +"',"+ "'Success'" +",'"+ datetime +"','"+ getActivityName(iform) + "','" + getWorkitemName(iform)+ "'";
					
					String insertQuery = "INSERT INTO NG_KYC_REM_SH_AUDIT_DETAILS (Name, FormGenFlag, GenerationDateTime,CurrentWS,WINAME) VALUES ("+ colValues +")";
					KYC_Remediation.mLogger.debug("insertQuery for Shareholder Audit table : "+ insertQuery);
					
					int retVal = iform.saveDataInDB(insertQuery);
					KYC_Remediation.mLogger.debug("response--" + retVal);
					
					if (retVal != 1) return "Error in Insertion";
					*/
					return "Success ~~ " + Res;
				} 
				else
					return "Failure in Shareholder Application Form generation with result as, output1: " + output1;
				
				
				// FI changes start
			} else if("Q_NG_KYC_REM_FI_TR_TABLE_SignedDate".equalsIgnoreCase(controlName)){
				
				String signedDate = (String)iform.getValue("Q_NG_KYC_REM_FI_TR_TABLE_SignedDate");
				if(!"".equalsIgnoreCase(signedDate)){
					DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // Set formatter				
					LocalDate originalDate = LocalDate.parse(signedDate, outputFormat); // Parse the string to LocalDate				
					LocalDate updatedExpDate = originalDate.plusYears(3); // Add 3 years				
					String updatedExpDateStr = updatedExpDate.format(outputFormat); // Convert back to string in the same format
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ExpiryDate", updatedExpDateStr);
				} else{
					iform.setValue("Q_NG_KYC_REM_FI_TR_TABLE_ExpiryDate", "");
				}
				
			} 
			
			String Workstep = iform.getActivityName();
			if ("Maker".equalsIgnoreCase(Workstep) || "Maker2".equalsIgnoreCase(Workstep)){
			
				if("table41".equalsIgnoreCase(controlName)){						
					String pepHit = (String)iform.getValue("table41_PEPHit");				
					if(!"Yes".equalsIgnoreCase(pepHit)){
						iform.setStyle("table41_PEPStatus", "disable", "true");
						iform.setStyle("table41_PEPHitRefNumberENC", "disable", "true");
						iform.setStyle("table41_PEPHitRefNumberOFAC", "disable", "true");
	
						iform.setStyle("table41_PEPStatus", "mandatory", "false");
	
					} else{
						iform.setStyle("table41_PEPStatus", "disable", "false");
						iform.setStyle("table41_PEPHitRefNumberENC", "disable", "false");
						iform.setStyle("table41_PEPHitRefNumberOFAC", "disable", "false");
						
						iform.setStyle("table41_PEPStatus", "mandatory", "true");
					}
					
					String mandFields[] = {"table41_NameOfShareholder","table41_ShareholdingPercentage","table41_ENameScreening","table41_PEPHit"};
					for(String field : mandFields){
						iform.setStyle(field, "mandatory", "true");
					}						
					
				} else if("table42".equalsIgnoreCase(controlName)){
					String pepHit = (String)iform.getValue("table42_PEPHit");				
					if(!"Yes".equalsIgnoreCase(pepHit)){
						iform.setStyle("table42_PEPStatus", "disable", "true");
						iform.setStyle("table42_PEPHitRefNumberENC", "disable", "true");
						iform.setStyle("table42_PEPHitRefNumberOFAC", "disable", "true");
	
						iform.setStyle("table42_PEPStatus", "mandatory", "false");
	
					} else{
						iform.setStyle("table42_PEPStatus", "disable", "false");
						iform.setStyle("table42_PEPHitRefNumberENC", "disable", "false");
						iform.setStyle("table42_PEPHitRefNumberOFAC", "disable", "false");
	
						iform.setStyle("table42_PEPStatus", "mandatory", "true");
					}
					
					String mandFields[] = {"table42_Name","table42_ENameScreening","table42_PEPHit"};
					for(String field : mandFields){
						iform.setStyle(field, "mandatory", "true");
					}				
					
				} else if("table38".equalsIgnoreCase(controlName)){
					String mandFields[] = {"table38_IndustrySegment","table38_IndustrySubSegment"};
					for(String field : mandFields){
						iform.setStyle(field, "mandatory", "true");
					}				
					
				}
			}
			// FI changes end
			
		} catch(Exception e){
			KYC_Remediation.mLogger.debug("Exception in click event--:"+e);
			return "false";
		}
		return "";
	}
	

private String processCramResponse(IFormReference iform, String response, String wiName) {

    try {
        JSONParser parser = new JSONParser();
        JSONObject res = (JSONObject) parser.parse(response);

        if (res.containsKey("totalRiskScore")) {

            //Handle both integer and decimal values
            Number scoreNum = res.get("totalRiskScore") != null
                    ? (Number) res.get("totalRiskScore")
                    : 0;

            double scoreVal = scoreNum.doubleValue();

            
            String score = (scoreVal % 1 == 0)
                    ? String.valueOf((int) scoreVal)
                    : String.valueOf(scoreVal); 

            return String.format("0000~SUCCESS~"+score);
        }

        KYC_Remediation.mLogger.debug("[CRAM][" + wiName + "] Invalid response: " + response);
        return "9999~Invalid Response";

    } catch (Exception e) {
    	KYC_Remediation.mLogger.debug("[CRAM][" + wiName + "] Parsing Error", e);
        return "9999~Parsing Error";
    }
}


	private String callCRAMRRCGateway(String requestBody, String requestId, IFormReference iform) throws Exception {
		
			 String wiName = getWorkitemName(iform);
			 KYC_Remediation.mLogger.debug("[CRAM-Int][" + wiName + "] Initializing CRAM API call");
			 
			 Map<String, String> config = getCRAMParameters(iform);
			 KYC_Remediation.mLogger.debug("[CRAM-Int][" + wiName + "] Calling CRAM endpoint");

		        URL url = new URL(config.get("Kong_CRAM_Endpoint"));
		        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

		        conn.setRequestMethod("POST");
		        conn.setConnectTimeout(30000);
		        conn.setReadTimeout(30000);

		        // Kong Authentication
		        conn.setRequestProperty("apikey", config.get("Kong_API_KEY"));
		        
		        conn.setRequestProperty("Content-Type", "application/json");
		        conn.setDoOutput(true);

		        try (OutputStream os = conn.getOutputStream()) {
		            os.write(requestBody.getBytes("UTF-8"));
		            KYC_Remediation.mLogger.debug("[CRAM-Int][" + wiName + "] Request JSON payload streamed.");
		        }

		        int status = conn.getResponseCode();
		        KYC_Remediation.mLogger.debug("[CRAM-Int][" + wiName + "] CRAM API Response Code: " + status);
		        
		        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
		        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		        StringBuilder responseBody = new StringBuilder();
		        String line;
		        while ((line = br.readLine()) != null) {
					responseBody.append(line.trim());
				}
		        conn.disconnect();

		        // audit in  NG_DAO_XMLLOG_HISTORY
		        insertCramAudit(iform, requestBody, responseBody.toString(), requestId, status, wiName);

		        return responseBody.toString();
	}

	 private void insertCramAudit(IFormReference iform, String req, String res, String msgId, int status, String wi) {

	        KYC_Remediation.mLogger.debug("[CRAM-Audit] Entering insertCramAudit()");
	         KYC_Remediation.mLogger.debug("[CRAM-Audit] WI: " + wi + ", MsgId: " + msgId + ", Status: " + status);

	        try {
	        	String workstepName = getActivityName(iform);
	        	String userName = getUserName(iform);

	            //  handling of null values
	            String safeReq = (req != null) ? req.replace("'", "''") : "";
	            String safeRes = (res != null) ? res.replace("'", "''") : "";

	             KYC_Remediation.mLogger.debug("[CRAM-Audit] Request Payload: " + safeReq);
	             KYC_Remediation.mLogger.debug("[CRAM-Audit] Response Payload: " + safeRes);
	            String col = "WI_NAME,WORKSTEP_NAME,INPUT_XML,OUTPUT_XML,MESSAGE_ID,REQ_DATE_TIME,ACT_DATE_TIME,CALLNAME,USER_NAME";
	           
	            String reqDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());



	            String val = "'" + wi + "','" + workstepName + "','" + safeReq + "','" + safeRes + "','" + msgId + "','" +
	            		reqDateTime + "',GETDATE(),'CRAM_RISK_SCORE','" + userName + "'";


	            
	            KYC_Remediation.mLogger.debug("[CRAM-Audit] Preparing insert query");

	            String insertXml = apInsert(
	                    getCabinetName(iform),
	                    getSessionId(iform),
	                    col,
	                    val,
	                    "NG_KYC_Remedation_XMLLOG_HISTORY"
	            );

	             KYC_Remediation.mLogger.debug("[CRAM-Audit] Insert XML: " + insertXml);

	            String response = WFNGExecute(insertXml, iform.getServerIp(), iform.getServerPort(), 1);

	            KYC_Remediation.mLogger.debug("[CRAM-Audit] Insert executed successfully");
	             KYC_Remediation.mLogger.debug("[CRAM-Audit] WF Response: " + response);

	        } catch (Exception e) {
	            KYC_Remediation.mLogger.debug("[CRAM-Audit] Exception in insertCramAudit()", e);
	        }

	        KYC_Remediation.mLogger.debug("[CRAM-Audit] Exiting insertCramAudit()");
	    }
	
	
	private Map getCRAMParameters(IFormReference iform) {
		 Map<String, String> configMap = new HashMap<>();
			try{
			String query = "SELECT CONST_FIELD_NAME,CONST_FIELD_VALUE FROM USR_0_BPM_CONSTANTS WHERE CONST_FIELD_NAME IN ('Kong_API_KEY','Kong_CRAM_Endpoint')";
			List<List<String>> dataFromDB = iform.getDataFromDB(query);
			KYC_Remediation.mLogger.debug("dataFromDB: " + dataFromDB);
			if(!dataFromDB.isEmpty()){
				 for (List<String> row : dataFromDB) { configMap.put(row.get(0), row.get(1)); }
			}
			}catch(Exception e){
				KYC_Remediation.mLogger.debug("Exception in getIndustryCode...");
				return configMap;
			}
			return configMap;
	}

	private void makeJSONRequest(JSONObject req, String requestId, IFormReference iform) {
		try{
			KYC_Remediation.mLogger.debug("Creating CRAM RRC json request...");
			String userId = (String)iform.getUserName();
			String businessSubSegment = (String)iform.getValue("Customer_Subsegment");
			String businessSegment = "";
			if ("SME".equalsIgnoreCase(businessSubSegment) || "PSL".equalsIgnoreCase(businessSubSegment))
				businessSegment = "BBG";
			else if ("CBD".equalsIgnoreCase(businessSubSegment))
				businessSegment = "WBG";
			else 
				businessSegment = "PBG";
			String caseType = (String)iform.getValue("CaseType");
			String cif_ID = (String)iform.getValue("CIF_ID");
	            // =========================================================
	            // Common Fields Start
	            // =========================================================
	            req.put("serviceId", "CRAM_DecisionEngine_V1");
	            req.put("serviceType", "DecisionEngineCRAM");
	            req.put("serviceChannelId", "KYC_CRAM");
	            req.put("requestId", requestId);
	            req.put("timeStamp", new SimpleDateFormat("MM/dd/yyyy HH:mm").format(new Date()));
	            req.put("userId", userId);
	            req.put("journey", "KYC");
	            req.put("businessSegment", businessSegment);
	            req.put("businessSubsegment", businessSubSegment);
	            req.put("custType", caseType);
	            req.put("type", "ETB");
	            req.put("custIdType", "CIF");
	            req.put("custIdValue", cif_ID);
	            // =========================================================
	            // Common Fields end
	            // =========================================================
	            if("Individual".equalsIgnoreCase(caseType)){
	            	String custName = (String)iform.getValue("FirstName")+" "+(String)iform.getValue("MiddleName")+" "+(String)iform.getValue("LastName");
	            	req.put("customerName", custName);
	            	//nationality tag
	            	String Nationality = (String) iform.getValue("Nationality");
	            	String additionalNationality = (String) iform.getValue("OtherNationality");
	            	
					JSONArray nationalityArray = new JSONArray();
					nationalityArray.add(Nationality);
					if(!nationalityArray.contains(additionalNationality))
						nationalityArray.add(additionalNationality);
					req.put("nationality", nationalityArray);
					
					//demographic tag
					String residenceCountry = (String) iform.getValue("ResidenceCountry");
	            	
					JSONArray demogrpahicyArray = new JSONArray();
					demogrpahicyArray.add(residenceCountry);
					int moneySentCountrysize = iform.getDataFromGrid("table12").size();
					KYC_Remediation.mLogger.debug("size of Country money sent to grid is--"+moneySentCountrysize);
					for (int i = 0;i<moneySentCountrysize;i++){
						String moneySent = iform.getTableCellValue("table12",i,0);
						if(!"".equalsIgnoreCase(moneySent) && !demogrpahicyArray.contains(moneySent)){
							demogrpahicyArray.add(moneySent);
						}
					}
					
					int moneyReceivedCountrysize = iform.getDataFromGrid("table13").size();
					KYC_Remediation.mLogger.debug("size of Country money from grid is--"+moneyReceivedCountrysize);
					for (int i = 0;i<moneyReceivedCountrysize;i++){
						String moneyReceived = iform.getTableCellValue("table13",i,0);
						if(!"".equalsIgnoreCase(moneyReceived) && !demogrpahicyArray.contains(moneyReceived)){
							demogrpahicyArray.add(moneyReceived);
						}
					}
					req.put("demographic", demogrpahicyArray);
					
					//length of residency start
					if(!"AE".equalsIgnoreCase(Nationality)){
						String cifCreationDate = (String) iform.getValue("CIF_creation_Date");
						String lor = getYearMonthDiff(cifCreationDate);
						req.put("lengthOfResidency", lor);
					}
					else{
						String dob = (String) iform.getValue("DateOfBirth");
						String lor = getYearMonthDiff(dob);
						req.put("lengthOfResidency", lor);
					}
					//length of residency end
					String persona = (String) iform.getValue("CIFPersona");
					persona = getPersonaCode(persona, iform);
					req.put("persona", persona);
					
					//industry start
					JSONArray industryArray = new JSONArray();
					int indutryGridSize = iform.getDataFromGrid("IndustrySubSegmentGrid").size();
					KYC_Remediation.mLogger.debug("size of industry grid is--"+indutryGridSize);
					for (int i = 0;i<indutryGridSize;i++){
						String subSegment = iform.getTableCellValue("IndustrySubSegmentGrid",i,0);
						KYC_Remediation.mLogger.debug("subSegment--"+subSegment);
						if(!"".equalsIgnoreCase(subSegment)){
							subSegment = getIndustryCode(subSegment, iform);
							if(!industryArray.contains(subSegment)) industryArray.add(subSegment);
						}
					}
					req.put("industry", industryArray);
					//industry end
					String pep = (String) iform.getValue("PEP");
					if(pep.equalsIgnoreCase("FOREIGN PEP")) pep = "FPEP";
					else if(pep.equalsIgnoreCase("LOCAL PEP")) pep = "LPEP";
					else if(pep.equalsIgnoreCase("NOT PEP")) pep = "NPEP";
					else if(pep.equalsIgnoreCase("Associated FPEP")) pep = "APEP";
					req.put("pepStatus", pep);
					/*String formattedHnwi = "";
					try{
						String monthlyIncome = (String) iform.getValue("MonthlyIncome");
						if(!"".equalsIgnoreCase(monthlyIncome)){
							double hnwi = Double.parseDouble(monthlyIncome) * 12;
							// Format to 2 decimal places (string output)
							formattedHnwi = String.format("%.2f", hnwi);
					}
					}catch(Exception e){
						formattedHnwi="";
					}
					req.put("hnwi", formattedHnwi);*/

					Object hnwiValue = null;
					
					try {
					    String monthlyIncome = (String) iform.getValue("MonthlyIncome");
					    if (monthlyIncome != null && !monthlyIncome.isEmpty()) {
					        BigDecimal hnwi = new BigDecimal(monthlyIncome).multiply(new BigDecimal("12"));
					        hnwi = hnwi.setScale(2, RoundingMode.HALF_UP); // 2 decimal precision
					        hnwiValue = hnwi;  
					    }
					} catch (Exception e) {
					    hnwiValue = null;
					}
					req.put("hnwi", hnwiValue);
					req.put("hnwe", null);
					
					JSONArray cashTurnoverArray = new JSONArray();
					String monthlyCashCRturnover = (String) iform.getValue("MonthlyCashCRturnover");
					//cashTurnoverArray.add(monthlyCashCRturnover);
					try{
					cashTurnoverArray.add(Double.parseDouble(monthlyCashCRturnover));
					req.put("cashTurnoverPerc", cashTurnoverArray);
					}catch(Exception e){
						req.put("cashTurnoverPerc", cashTurnoverArray);
					}
					String cifCreationDate = (String) iform.getValue("CIF_creation_Date");
					cifCreationDate = convertToDDMMYYYY(cifCreationDate);
					req.put("maturityRelationship", cifCreationDate);
					req.put("licensingAuthority", null);
					JSONArray productArray = new JSONArray();
					JSONArray currencyArray = new JSONArray();
					int size = iform.getDataFromGrid("table15").size();
					KYC_Remediation.mLogger.debug("size of product currency grid is--"+size);
					for (int i = 0;i<size;i++){
						String product_typ = iform.getTableCellValue("table15",i,0);
						KYC_Remediation.mLogger.debug("product_typ--"+product_typ);
						if(!"".equalsIgnoreCase(product_typ))
						{
							product_typ = getProductCode(product_typ, iform);
							if(!"".equalsIgnoreCase(product_typ) && !productArray.contains(product_typ))
								productArray.add(product_typ);
						}
						String product_curr = iform.getTableCellValue("table15",i,1);
						KYC_Remediation.mLogger.debug("product_curr--"+product_curr);
						if(!"".equalsIgnoreCase(product_curr) && !currencyArray.contains(product_curr))
						{
							currencyArray.add(product_curr);
						}
					}
					req.put("product", productArray);
					req.put("currency", currencyArray);
					req.put("adverseMediaResults", "N");
					String countryOfBirth = (String) iform.getValue("CountryOfBirth");
					JSONArray countryOfBirthArray = new JSONArray();
					countryOfBirthArray.add(countryOfBirth);
					req.put("countryOfBirth", countryOfBirthArray);
					req.put("annualTurnoverExpected", hnwiValue);
					req.put("personalAccountsUtilizedForCommercialActivity", "N");
					req.put("customerReportedToRegulator", "N");
					String deliveryChannel = (String) iform.getValue("DeliveryChannel");
					req.put("deliveryChannel", deliveryChannel);
					req.put("lengthOfEstablishment", null);
					JSONArray countryOfEstablishmentArray = new JSONArray();
					req.put("countryOfEstablishment", countryOfEstablishmentArray);
					req.put("layersInComplexOwnershipStructure", null);
					String residentCountry = (String) iform.getValue("ResidentCountry");
					if(!"AE".equalsIgnoreCase(residentCountry)) req.put("nonResidentUboOrCustomer", "Y");
					else req.put("nonResidentUboOrCustomer", "N");
					
					//insertCRAMParametersinDB(iform,val);
	            }
	            
		}catch (Exception e){
			KYC_Remediation.mLogger.debug("Exception makeJSONRequest--:"+e);
		}
	}




	 private String getProductCode(String product_typ, IFormReference iform) {
		 String code = "";
			try{
			String query = "SELECT TOP 1 SCHM_CODE FROM NG_MASTER_KYC_REM_PRODUCT_NAME with(nolock) WHERE CD_DESC = '"+product_typ+"' AND CD_DESC IS NOT NULL";
			List<List<String>> dataFromDB = iform.getDataFromDB(query);
			KYC_Remediation.mLogger.debug("dataFromDB1: " + dataFromDB);
			if(!dataFromDB.isEmpty()){
			code = (String)dataFromDB.get(0).get(0);
			KYC_Remediation.mLogger.debug("CRAM Flag Value: " + code);
			}
			}catch(Exception e){
				KYC_Remediation.mLogger.debug("Exception in getIndustryCode...");
				return code;
			}
			return code;
	}

	public static String convertToDDMMYYYY(String inputDate) {
	        if (inputDate == null || inputDate.trim().isEmpty()) {
	            return "";
	        }

	        try {
	            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

	            LocalDate date = LocalDate.parse(inputDate, inputFormatter);

	            return date.format(outputFormatter);

	        } catch (Exception e) {
	            return "";
	        }
	    }



private String getIndustryCode(String subSegment, IFormReference iform) {
	String code = "";
	try{
	String query = "SELECT SubSegmentCRAMCode FROM NG_KYC_REM_Industry_SubSegment_MASTER with(nolock) WHERE SubSegment = '"+subSegment+"'";
	List<List<String>> dataFromDB = iform.getDataFromDB(query);
	KYC_Remediation.mLogger.debug("dataFromDB1: " + dataFromDB);
	code = (String)dataFromDB.get(0).get(0);
	KYC_Remediation.mLogger.debug("CRAM Flag Value: " + code);
	}catch(Exception e){
		KYC_Remediation.mLogger.debug("Exception in getIndustryCode...");
		return code;
	}
	return code;
	}

private String getPersonaCode(String persona, IFormReference iform) {
	String code = "";
	try{
	String query = "SELECT Code FROM NG_KYC_REM_Persona_MASTER with(nolock) WHERE Persona = '"+persona+"'";
	List<List<String>> dataFromDB = iform.getDataFromDB(query);
	KYC_Remediation.mLogger.debug("dataFromDB1: " + dataFromDB);
	code = (String)dataFromDB.get(0).get(0);
	KYC_Remediation.mLogger.debug("CRAM Flag Value: " + code);
	}catch(Exception e){
		KYC_Remediation.mLogger.debug("Exception in getCRAMFlag");
		return code;
	}
	return code;
	}

public static String getYearMonthDiff(String inputDate) {

        if (inputDate == null || inputDate.trim().isEmpty()) {
            return "00.00";
        }

        List<DateTimeFormatter> formats = Arrays.asList(
                DateTimeFormatter.ofPattern("yyyy-MM-dd"),
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
                DateTimeFormatter.ofPattern("yyyy/MM/dd"),
                DateTimeFormatter.ofPattern("dd-MM-yyyy"),
                DateTimeFormatter.ofPattern("dd/MM/yyyy"),
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
        );

        LocalDate startDate = null;

        for (DateTimeFormatter formatter : formats) {
            try {
                startDate = LocalDate.parse(inputDate, formatter);
                break;
            } catch (Exception e) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(inputDate, formatter);
                    startDate = dateTime.toLocalDate();
                    break;
                } catch (Exception ex) {
                }
            }
        }

        if (startDate == null) {
            return "";
        }

        LocalDate currentDate = LocalDate.now();

        Period period = Period.between(startDate, currentDate);

        return String.format("%02d.%02d", period.getYears(), period.getMonths());
    }



	
	public String getCRAMFlag(IFormReference iform){
		String value = "";
		try{
		String query = "Select Value from NG_KYC_REM_Variable_TABLE with(nolock) WHERE Variable = 'CRAM RRC Integration'";
		List<List<String>> dataFromDB = iform.getDataFromDB(query);
		KYC_Remediation.mLogger.debug("dataFromDB1: " + dataFromDB);
		value = (String)dataFromDB.get(0).get(0);
		KYC_Remediation.mLogger.debug("CRAM Flag Value: " + value);
		}catch(Exception e){
			KYC_Remediation.mLogger.debug("Exception in getCRAMFlag");
			return value;
		}
		return value;
	}
	
	public String getMasterData(String query, IFormReference iform, String type){
				
		List<List<String>> query_outputList = iform.getDataFromDB(query);
		KYC_Remediation.mLogger.debug("query_output--: "+query_outputList);
		
		String rv = type + "::";
		if (query_outputList != null && !query_outputList.isEmpty()) {
			
		    for (List<String> row : query_outputList) {
		        if (row != null && !row.isEmpty())
		            rv += row.get(1) + "__" + row.get(0);
		        
		        rv += "#";
		    }
		} else {
		    KYC_Remediation.mLogger.debug("RPEmailList is empty or null.");
		    return "Empty list output";
		}
		
		rv = rv.substring(0, rv.length()-1);
		
		return rv + " ~ ";
	}
	
	public String updateWInameInext(IFormReference iform,String WINAme){
		IFormXmlResponse xmlParserData = new IFormXmlResponse();
		StringBuffer ipXMLBuffer=new StringBuffer();
		String sCabname = getCabinetName(iform);
		KYC_Remediation.mLogger.debug("sCabname" + sCabname);
		String sSessionId = getSessionId(iform);
		KYC_Remediation.mLogger.debug("sSessionId" + sSessionId);
		iform.setValue("Mandatory_Field_List", WINAme);
		String columnNames="Mandatory_Field_List";
		String columnValues="'"+WINAme+"'";
		String sWhereClause ="WINAME ='"+WINAme+"'";
		
		ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
		ipXMLBuffer.append("<APUpdate_Input>\n");
		ipXMLBuffer.append("<Option>APUpdate</Option>\n");
		ipXMLBuffer.append("<TableName>");
		ipXMLBuffer.append("RB_KYC_REM_EXTTABLE");
		ipXMLBuffer.append("</TableName>\n");
		ipXMLBuffer.append("<ColName>");
		ipXMLBuffer.append(columnNames);
		ipXMLBuffer.append("</ColName>\n");
		ipXMLBuffer.append("<Values>");
		ipXMLBuffer.append(columnValues);
		ipXMLBuffer.append("</Values>\n");
		ipXMLBuffer.append("<WhereClause>");
		ipXMLBuffer.append(sWhereClause);
		ipXMLBuffer.append("</WhereClause>\n");
		ipXMLBuffer.append("<EngineName>");
		ipXMLBuffer.append(sCabname);
		ipXMLBuffer.append("</EngineName>\n");
		ipXMLBuffer.append("<SessionId>");
		ipXMLBuffer.append(sSessionId);
		ipXMLBuffer.append("</SessionId>\n");
		ipXMLBuffer.append("</APUpdate_Input>");
		
		String apUpdateinput = ipXMLBuffer.toString();
		KYC_Remediation.mLogger.debug("apUpdateinput--->"+apUpdateinput);
		String OutputXML = ExecuteQueryOnServer(apUpdateinput, iform);
		KYC_Remediation.mLogger.debug("sOutputXML--->"+OutputXML);
		xmlParserData.setXmlString((OutputXML));
		String status_get = xmlParserData.getVal("MainCode");
		KYC_Remediation.mLogger.debug("status for wf table--->"+status_get);
		return "";
		
	}
	
	public static String addRows(List<List<String>> entityList) {
    	
    	StringBuilder sb = new StringBuilder();
    	for(int i=0; i<entityList.size(); i++) {
    		sb.append("<tr>");
    		
    		List<String> subList = entityList.get(i);
    		for(int j=0; j<subList.size(); j++) {
    			sb.append("<td>");
    			
    			sb.append(subList.get(j));
    			
    			sb.append("</td>");
    		}
    		
    		sb.append("</tr>");
    	}    	
    	
    	return sb.toString();
    }
    
	public static String addRows(String arr[]) {
    	
    	StringBuilder sb = new StringBuilder();
    	for(int i=0; i<arr.length; i++) {
    		sb.append("<tr>");
    		
    		String subArr[] = arr[i].split("~");
    		for(int j=0; j<subArr.length; j++) {
    			sb.append("<td>");
    			
    			sb.append(subArr[j]);
    			
    			sb.append("</td>");
    		}
    		
    		sb.append("</tr>");
    	}    	
    	
    	return sb.toString();
    }
	
    public static String encodeImageToBase64(String imagePath) throws Exception {
        File file = new File(imagePath);
        FileInputStream imageInFile = new FileInputStream(file);
        byte[] imageData = new byte[(int) file.length()];
        imageInFile.read(imageData);
        imageInFile.close();
        return Base64.getEncoder().encodeToString(imageData);
    }

    
    // trial
    public String generateExtraForm1(IFormReference iform) throws DocumentException, IOException{

    	String basePath = System.getProperty("user.dir")+ File.separator + "CustomConfig"+ File.separator+"KYC_Remediation"+ File.separator;
		// Read HTML content from the file
		String htmlFilePath =  basePath + "index.html";
		String pdfPath = basePath + "generatedDocs"+File.separator+ "generatedDoc.pdf";
		KYC_Remediation.mLogger.debug("htmlFilePath: " + htmlFilePath);
		KYC_Remediation.mLogger.debug("pdfPath: " + pdfPath);
		
        doIt(htmlFilePath);

        KYC_Remediation.mLogger.debug("Do it done!");
        
        generatePDF(htmlFilePath, pdfPath);

        KYC_Remediation.mLogger.debug("Done!");
		
		return "Success";
	}
    
    public static void doIt(String htmlPath){
        
    	ArrayList<String> lines = new ArrayList<String>();
        String line = null;
        
    	try
        {
            File f1 = new File(htmlPath);
            FileReader fr = new FileReader(f1);
            BufferedReader br = new BufferedReader(fr);
            while ((line = br.readLine()) != null) {
            	
                if (line.contains("&<BankName>&")) {
                	System.out.println("replacing");                	
                    line = line.replace("&<BankName>&", "RakBankVV");
                }
                lines.add(line);
            }
            fr.close();
            br.close();
 
            FileWriter fw = new FileWriter(f1);
            BufferedWriter out = new BufferedWriter(fw);
            for(String s : lines)
                 out.write(s);
            out.flush();
            out.close();
            
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            KYC_Remediation.mLogger.debug("Exception: " + ex);
        }
    }
	
    public static void generatePDF(String inputHtmlPath, String outputPdfPath)
    {
        try {
        	HtmlConverter.convertToPdf(new FileInputStream(inputHtmlPath), new FileOutputStream(outputPdfPath));

            KYC_Remediation.mLogger.debug("Converted!");
            
        } catch (Exception e) {
            e.printStackTrace();
            KYC_Remediation.mLogger.debug("Exception: " + e);
        }
    }
    
	public String createCustomPDf(IFormReference iform) {
		try {
			
			com.itextpdf.text.Document document = new com.itextpdf.text.Document();
			document.setPageSize(PageSize.A4);
			document.setMargins(50, 45, 50, 60);
			document.setMarginMirroring(false);
			
			Properties properties = new Properties();
			try {
				properties.load(new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")+ "CustomConfig" + System.getProperty("file.separator")+ "KYC_Remediation" + System.getProperty("file.separator")+ "KYC_Config.properties"));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
						
			String basePath = System.getProperty("user.dir") + System.getProperty("file.separator") + properties.getProperty("KYC_Remediation_PDF_PATH");
			KYC_Remediation.mLogger.debug("basePath: " + basePath);
			
			String TemplatePath = basePath + "generatedDocs"+File.separator+ "generatedDoc.pdf";
			KYC_Remediation.mLogger.debug("TemplatePath: " + TemplatePath);
			
//			PdfWriter.getInstance(document, new FileOutputStream(TemplatePath));
			
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(TemplatePath));
			Footer event = new Footer();
			writer.setPageEvent(event);
			
			document.open();
			KYC_Remediation.mLogger.debug("****************After document.open()******************");
			
			Font bold = new Font(FontFamily.HELVETICA, 10);
			Font bold1 = new Font(FontFamily.HELVETICA, 10, Font.BOLD);
			Font small = new Font(FontFamily.HELVETICA, 7);
			
//			String font = "Arial Unicode MS Regular";
//			String TemplatePathfont =basePath+ File.separator + font + ".ttf";//to place actual font properties
									
			// Rak header for PDF
			String imageRakHeaderPath = basePath + "KYC_template_assets" + File.separator + "rak-header_annexure.PNG";
			Image HeaderImg = Image.getInstance(imageRakHeaderPath);
			HeaderImg.scalePercent(43);
			document.add(HeaderImg);
			
			document.add(new Paragraph("\n"));
			document.add(new Paragraph("\n"));
			
			// Table header for entity
			String imageFile2 = basePath + "KYC_template_assets" + File.separator + "table-header_entity.PNG";
			Image dataEntityTblImg = Image.getInstance(imageFile2);
			dataEntityTblImg.scalePercent(43);
			document.add(dataEntityTblImg);
			
			document.add(new Paragraph("\n"));
			
			// Entity grid starts here			
			PdfPTable tableEntity = new PdfPTable(9);
			tableEntity.setWidthPercentage(100);
			tableEntity.setWidths(new float[] {15, 15, 10, 10, 10, 10, 10, 10, 10});
			
						
			List<List<String>> entityList = new ArrayList<>();
    		
    		// performing the task for Individual Tab
    		JSONArray entityGridArray = iform.getDataFromGrid("table26");    		
    		    		
    		// get distinct CIF IDs
    		for(int i=0; i<entityGridArray.size(); i++){
    			List<String> list = new ArrayList<>();
    			
    			JSONObject rowObj = (JSONObject)entityGridArray.get(i);
                
                list.add((String) rowObj.get("Level"));
                list.add((String) rowObj.get("Name of Shareholder"));
                list.add((String) rowObj.get("Type"));
                list.add((String) rowObj.get("Main Holder"));
                list.add((String) rowObj.get("Nationality"));
                list.add((String) rowObj.get("Country of Residence"));
                list.add((String) rowObj.get("Date of Birth/Date of Incorporation"));
                list.add((String) rowObj.get("% Shareholding(If applicable)"));
                list.add((String) rowObj.get("UBO"));
                
                entityList.add(list);
    		}
    		KYC_Remediation.mLogger.debug("entityList: " + entityList.toString());
			
    		createHeaders("Entity", document, bold1, tableEntity);
			
    		for(List<String> list : entityList){
    			
    			PdfPCell englishCell1 = new PdfPCell(new Paragraph(list.get(0), bold));
    			englishCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell1.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell1);
    			
    			PdfPCell englishCell2 = new PdfPCell(new Paragraph(list.get(1), bold));
    			englishCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell2.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell2);
    			
    			PdfPCell englishCell3 = new PdfPCell(new Paragraph(list.get(2), bold));
    			englishCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell3.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell3);
    			
    			PdfPCell englishCell4 = new PdfPCell(new Paragraph(list.get(3), bold));
    			englishCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell4.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell4);
    			
    			PdfPCell englishCell5 = new PdfPCell(new Paragraph(getCountryDesc(iform, list.get(4)), bold));
    			englishCell5.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell5.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell5);
    			
    			PdfPCell englishCell6 = new PdfPCell(new Paragraph(getCountryDesc(iform, list.get(5)), bold));
    			englishCell6.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell6.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell6);
    			
    			PdfPCell englishCell7 = new PdfPCell(new Paragraph(list.get(6), bold));
    			englishCell7.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell7.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell7);
    			
    			PdfPCell englishCell8 = new PdfPCell(new Paragraph(list.get(7), bold));
    			englishCell8.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell8.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell8);
    			
    			PdfPCell englishCell9 = new PdfPCell(new Paragraph(list.get(8), bold));
    			englishCell9.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell9.setBorder(PdfPCell.NO_BORDER);
    			tableEntity.addCell(englishCell9);
    			
    			KYC_Remediation.mLogger.debug("Row made for list: " + list.toString());
    		}
    		KYC_Remediation.mLogger.debug("Out of the loop, entity.");
    		
    		document.add(tableEntity);
    		
    		
    		// BoD grid starts here
    		document.add(new Paragraph("\n"));
    		document.add(new Paragraph("\n"));
    		
    		String imageFile3 = basePath + "KYC_template_assets" + File.separator + "table-header_annexure.PNG";
			Image dataBoDTblImg = Image.getInstance(imageFile3);
			dataBoDTblImg.scalePercent(43);
			document.add(dataBoDTblImg);
			
			document.add(new Paragraph("\n"));
			
			// Entity grid starts here			
			PdfPTable tableBoD = new PdfPTable(4);
			tableBoD.setWidthPercentage(100);
			tableBoD.setWidths(new float[] {25, 25, 25, 25});
    		
			List<List<String>> BoDList = new ArrayList<>();
    		
    		// performing the task for Individual Tab
    		JSONArray BoDGridArray = iform.getDataFromGrid("table24"); // toChange		
    		    		
    		// get distinct CIF IDs
    		for(int i=0; i<BoDGridArray.size(); i++){
    			List<String> list = new ArrayList<>();
    			
    			JSONObject rowObj = (JSONObject)BoDGridArray.get(i);
                
                list.add((String) rowObj.get("Name"));              
                list.add((String) rowObj.get("Nationality"));
                list.add((String) rowObj.get("Designation"));
                list.add((String) rowObj.get("Address"));                
                
                BoDList.add(list);
    		}
    		KYC_Remediation.mLogger.debug("BoDList: " + BoDList.toString());
			
    		createHeaders("BoD", document, bold1, tableBoD);
			 
    		for(List<String> list : BoDList){
    			
    			PdfPCell englishCell1 = new PdfPCell(new Paragraph(list.get(0), bold));
    			englishCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell1.setBorder(PdfPCell.NO_BORDER);
    			tableBoD.addCell(englishCell1);
    			
    			PdfPCell englishCell2 = new PdfPCell(new Paragraph(getCountryDesc(iform, list.get(1)), bold));
    			englishCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell2.setBorder(PdfPCell.NO_BORDER);
    			tableBoD.addCell(englishCell2);
    			
    			PdfPCell englishCell3 = new PdfPCell(new Paragraph(list.get(2), bold));
    			englishCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell3.setBorder(PdfPCell.NO_BORDER);
    			tableBoD.addCell(englishCell3);
    			
    			PdfPCell englishCell4 = new PdfPCell(new Paragraph(list.get(3), bold));
    			englishCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
    			englishCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
//    			englishCell4.setBorder(PdfPCell.NO_BORDER);
    			tableBoD.addCell(englishCell4);
    			    			
    			KYC_Remediation.mLogger.debug("Row made for list: " + list.toString());
    		}
    		KYC_Remediation.mLogger.debug("Out of the loop, entity.");
    		
    		document.add(tableBoD);   		
    		
    		document.close();		
    		
    		// merge this PDF into the parent PDF
    		mergePDFs(iform, basePath); // toDo
    		
			return "Success" + "~" + "For the document creation";
			
		} catch (Exception e) {
			KYC_Remediation.mLogger.debug("Exception in generating pdf " + e.getMessage());
			e.printStackTrace();
			return "Failure";
		}
	}
	
	public static void createHeaders(String type, com.itextpdf.text.Document document, Font bold1, PdfPTable table){
		
		if("Entity".equals(type)){
			PdfPCell englishCell1 = new PdfPCell(new Paragraph("Level", bold1));
			englishCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell1.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell1);
			
			PdfPCell englishCell2 = new PdfPCell(new Paragraph("Name of Shareholder", bold1));
			englishCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell2.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell2);
			
			PdfPCell englishCell3 = new PdfPCell(new Paragraph("Type", bold1));
			englishCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell3.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell3);
			
			PdfPCell englishCell4 = new PdfPCell(new Paragraph("Main Holder", bold1));
			englishCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell4.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell4);
			
			PdfPCell englishCell5 = new PdfPCell(new Paragraph("Nationality", bold1));
			englishCell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell5.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell5);
			
			PdfPCell englishCell6 = new PdfPCell(new Paragraph("Country of Residence", bold1));
			englishCell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell6.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell6);
			
			PdfPCell englishCell7 = new PdfPCell(new Paragraph("Date of Birth/Date of Incorporation", bold1));
			englishCell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell7.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell7);
			
			PdfPCell englishCell8 = new PdfPCell(new Paragraph("% Shareholding(If applicable)", bold1));
			englishCell8.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell8.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell8);
			
			PdfPCell englishCell9 = new PdfPCell(new Paragraph("UBO", bold1));
			englishCell9.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell9.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell9);
		}
		else{
			PdfPCell englishCell1 = new PdfPCell(new Paragraph("Name", bold1));
			englishCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell9.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell1);
			
			PdfPCell englishCell2 = new PdfPCell(new Paragraph("Nationality", bold1));
			englishCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell9.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell2);
			
			PdfPCell englishCell3 = new PdfPCell(new Paragraph("Designation", bold1));
			englishCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell9.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell3);
			
			PdfPCell englishCell4 = new PdfPCell(new Paragraph("Address", bold1));
			englishCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			englishCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
	//		englishCell9.setBorder(PdfPCell.NO_BORDER);
			table.addCell(englishCell4);
		}
		
		KYC_Remediation.mLogger.debug("Headers made for type: " + type);
	}
    
	public static String mergePDFs(IFormReference iform, String basePath){
		
		try{
//			/ibm/IBM/WebSphere/AppServer/profiles/AppSrv01/installedApps/ant1casapps01Node01Cell/KYC_Remediation_war.ear/KYC_Remediation.war/PDFTemplates/KYC_Templates
			String secondaryPDF_path = basePath + "generatedDocs"+File.separator+ "generatedDoc.pdf";
			String primaryPDF_path = basePath + getWorkitemName(iform) + "KYC_Form_Corporate.pdf";
			KYC_Remediation.mLogger.debug("primaryPDF_path: " + primaryPDF_path);
			KYC_Remediation.mLogger.debug("secondaryPDF_path: " + secondaryPDF_path);
			
			PDFMergerUtility pdfMerger = new PDFMergerUtility();
			
			pdfMerger.setDestinationFileName(basePath + "generatedDocs"+File.separator+ getWorkitemName(iform) + "KYC_Form_Corporate.pdf");
			
			pdfMerger.addSource(new File(primaryPDF_path));
			pdfMerger.addSource(new File(secondaryPDF_path));

			KYC_Remediation.mLogger.debug("Sources added in PDF.");

			pdfMerger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());			
			
			KYC_Remediation.mLogger.debug("Successful in merging the documents.");
			
			return "Success";
		}
		catch(Exception e){
			KYC_Remediation.mLogger.debug("Exception in generating pdf " + e.getMessage());
			e.printStackTrace();
			
			return "Failure in merging the docs.";
		}

	}

	static class Footer extends PdfPageEventHelper{
		
		@Override
		public void onEndPage(PdfWriter writer, com.itextpdf.text.Document document){
			
			PdfContentByte cb = writer.getDirectContent();
			PdfPTable footer = new PdfPTable(3);
			Font footerFont = new Font(Font.FontFamily.HELVETICA, 6, Font.NORMAL, BaseColor.LIGHT_GRAY);
			
			try{
				footer.setWidths(new int[]{24, 24, 24});
				footer.setTotalWidth(527);
				footer.setLockedWidth(true);
				footer.getDefaultCell().setFixedHeight(20);
				
				PdfPCell cellLeft = new PdfPCell(new Phrase("The national Bank of Ras Al Khaimah(P.S.C) (the \"Bank\" or \"Rakbank\""
						+ " \n is a commercial bank regulated and licensed by the Central Bank of UAE.", footerFont));
				cellLeft.setBorder(0);
				cellLeft.setHorizontalAlignment(Element.ALIGN_CENTER);
				
//				PdfPCell cellMid= new PdfPCell(new Phrase("The Rak Bank is a commercial Bank.", footerFont));
//				cellMid.setBorder(0);
//				cellMid.setHorizontalAlignment(Element.ALIGN_CENTER);
				

				footer.addCell(cellLeft);
//				footer.addCell(cellRight);
				
				footer.writeSelectedRows(0,  -1,  14, 25,  cb);
				
			} catch(Exception e){
				KYC_Remediation.mLogger.debug("Exception in Footer." + e.getMessage());
				e.printStackTrace();
			}			
		}
	}
	
	private String createCustomPDfFI(IFormReference iform){
		
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")+ "CustomConfig" + System.getProperty("file.separator")+ "KYC_Remediation" + System.getProperty("file.separator")+ "KYC_Config.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return "Failure in reading property file";
		} catch (IOException e) {
			e.printStackTrace();
			return "Failure in reading property file";
		}
		
		String basePath = System.getProperty("user.dir") + System.getProperty("file.separator") + properties.getProperty("KYC_Remediation_PDF_PATH");
		KYC_Remediation.mLogger.debug("basePath: " + basePath);
		
		String TemplatePath = basePath;
		KYC_Remediation.mLogger.debug("TemplatePath: " + TemplatePath);
		
		try {

			KYC_Remediation.mLogger.debug("Starting PDF creation...");

			com.itextpdf.text.Document document = new com.itextpdf.text.Document(PageSize.A4, 50, 50, 50, 50); // Added margins for padding
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(TemplatePath + getWorkitemName(iform) + "KYC_Form.pdf"));
			document.open();
			KYC_Remediation.mLogger.debug("Document opened successfully.");

			// Draw outer rectangle border
			PdfContentByte canvas = writer.getDirectContent();
			Rectangle border = new Rectangle(50, 50, 545, 792); // Adjusted for margins
			border.setBorder(Rectangle.BOX);
			border.setBorderWidth(2);
			border.setBorderColor(BaseColor.BLACK);
			canvas.rectangle(border);
			KYC_Remediation.mLogger.debug("Outer border created.");

			// Insert image placeholder
			String TemplateImgPath = TemplatePath + "rakbank-logo.jpg";
			KYC_Remediation.mLogger.debug("TemplatePathImg: " + TemplateImgPath);
			Image img = Image.getInstance(TemplateImgPath);
			img.scaleToFit(500, 100);
			img.setAlignment(Image.ALIGN_CENTER);
			document.add(img);
			KYC_Remediation.mLogger.debug("Image loaded and added.");

			document.add(Chunk.NEWLINE);

			PdfPTable fieldTable = new PdfPTable(2);
			fieldTable.setWidthPercentage(100);
			fieldTable.setSpacingBefore(10);
			fieldTable.setSpacingAfter(20);
			fieldTable.setWidths(new float[]{1f, 1f}); // Equal width for both columns
			
			String[][] FI_DetailsList1 = {
			    { "Name of Institution", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionName" },
			    { "Country of Institution", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionCountry" },
			    { "Office/Shop No", "Q_NG_KYC_REM_FI_TR_TABLE_OfficeShopNo" },
			    { "Building", "Q_NG_KYC_REM_FI_TR_TABLE_Building" },
			    { "Street", "Q_NG_KYC_REM_FI_TR_TABLE_Street" },
			    { "Landmark", "Q_NG_KYC_REM_FI_TR_TABLE_Landmark" },
			    { "PO Box", "Q_NG_KYC_REM_FI_TR_TABLE_POBox" },
			    { "Emirate/City", "Q_NG_KYC_REM_FI_TR_TABLE_CityEmirate" },
			    { "Country", "Q_NG_KYC_REM_FI_TR_TABLE_Country" },
			    { "ID Type", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionIDType" },
			    { "Trade License / Reg Number / Emiri Decree Number/Bank License", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseNo" },
			    { "Trade License / Reg Number / Emiri Decree Number/Bank License - Issue Date", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseIssueDate" },
			    { "Bank License/Trade License/ Registration Number - Expiry Date", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionLicenseExpiryDate" },
			    { "Type of Institution", "Q_NG_KYC_REM_FI_TR_TABLE_InstitutionType" },
			    { "Risk Profile", "Q_NG_KYC_REM_FI_TR_TABLE_RiskProfile" },
			    { "Legal status of the company", "Q_NG_KYC_REM_FI_TR_TABLE_LegalStatus" },
			    { "Next KYC Review Date", "Q_NG_KYC_REM_FI_TR_TABLE_NextKYCReviewDate" }
			};
			
			fieldTable = addFields(FI_DetailsList1, iform);
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");


			/*
			// Add initial fields
			for (String label_value[] : FI_DetailsList1) {
			    PdfPCell labelCell = new PdfPCell(new Phrase(label_value[0]));
			    labelCell.setBorder(Rectangle.NO_BORDER);
			    labelCell.setPaddingBottom(8f);
			    fieldTable.addCell(labelCell);

			    String  value = (String)iform.getValue(label_value[1]);
			    if(label_value[0].equals("Country of Institution") || label_value[0].equals("Country"))
            		value = getCountryDesc(iform, value);	
			    if(label_value[0].equals("Emirate/City"))
            		value = getCityDesc(iform, value);	
			    if(label_value[0].equals("ID Type"))
            		value = getIDTypeDesc(iform, value);
			    
			    PdfPCell valueCell = new PdfPCell(new Phrase(value));
			    valueCell.setBorder(Rectangle.BOX);
			    valueCell.setBorderColor(BaseColor.LIGHT_GRAY);
			    valueCell.setPadding(8f);
			    fieldTable.addCell(valueCell);
			}
			*/

			// Insert Parent Details heading
			PdfPCell parentHeader = new PdfPCell(new Phrase("Parent Details"));
			parentHeader.setColspan(2);
			parentHeader.setHorizontalAlignment(Element.ALIGN_LEFT);
			parentHeader.setBorder(Rectangle.NO_BORDER);
			parentHeader.setPaddingTop(12f);
			parentHeader.setPaddingBottom(8f);
			parentHeader.setPhrase(new Phrase("Parent Details", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
			
			fieldTable = new PdfPTable(2);
			fieldTable.setWidthPercentage(100);
			fieldTable.setSpacingBefore(10);
			fieldTable.setSpacingAfter(20);
			fieldTable.setWidths(new float[]{1f, 1f}); // Equal width for both columns
			fieldTable.addCell(parentHeader);
			document.add(fieldTable);
			

			// Add parent detail fields
			String[][] ParentDetailsTable = {
			    { "Parent CIF", "Q_NG_KYC_REM_FI_TR_TABLE_ParentCIF" },
			    { "Name of Company", "Q_NG_KYC_REM_FI_TR_TABLE_ParentCompanyName" },
			    { "Country of Incorporation", "Q_NG_KYC_REM_FI_TR_TABLE_ParentIncorporationCountry" },
			    { "ID Type", "Q_NG_KYC_REM_FI_TR_TABLE_ParentIDType" },
			    { "Trade License / Reg Number / Emiri Decree Number/Bank License", "Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseNo" },
			    { "Trade License / Reg Number / Emiri Decree Number/Bank License - Issue Date", "Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseIssueDate" },
			    { "Bank License/Trade License/ Registration Number - Expiry Date", "Q_NG_KYC_REM_FI_TR_TABLE_ParentLicenseExpiryDate" }
			};
			
			fieldTable = addFields(ParentDetailsTable, iform);
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");

			/*
			for (String label_value[] : ParentDetailsTable) {
			    PdfPCell labelCell = new PdfPCell(new Phrase(label_value[0]));
			    labelCell.setBorder(Rectangle.NO_BORDER);
			    labelCell.setPaddingBottom(8f);
			    fieldTable.addCell(labelCell);

			    String  value = (String)iform.getValue(label_value[1]);
			    if(label_value[0].equals("Country of Incorporation"))
            		value = getCountryDesc(iform, value);	
			    if(label_value[0].equals("ID Type"))
            		value = getIDTypeDesc(iform, value);
			    
			    PdfPCell valueCell = new PdfPCell(new Phrase(value));
			    valueCell.setBorder(Rectangle.BOX);
			    valueCell.setBorderColor(BaseColor.LIGHT_GRAY);
			    valueCell.setPadding(8f);
			    fieldTable.addCell(valueCell);
			}

			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");
			*/
			
			
			// Branch/Subsidiary Table			
			List<List<String>> data = new ArrayList<>();
			data.add(Arrays.asList(
			    "Branch/Subsidiary CIF","Branch with which Relationship needs to be established","Branch/Subsidiary Country","Branch/Subsidiary Name","Branch/Subsidiary Address"
			));
                        
            JSONArray branchSubTableJsonArray = iform.getDataFromGrid("table40");
            for (int i = 0; i < branchSubTableJsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) branchSubTableJsonArray.get(i);
                KYC_Remediation.mLogger.debug("jsonObj - " + jsonObj);

                List<String> row = new ArrayList<String>();
                for(String header : data.get(0)){
                	String value = (String)jsonObj.getOrDefault(header, "");
                	if(header.equals("Branch/Subsidiary Country"))
                		value = getCountryDesc(iform, value);
                	row.add(value);
                }
                KYC_Remediation.mLogger.debug("Adding row.");
                data.add(row);
            }
			
			PdfPTable dataTable = addTable(data);

			document.add(dataTable);
			KYC_Remediation.mLogger.debug("Table added.");
			
			
			// Rest of the FI Details
			String[][] FI_DetailsList2 = {
			    { "Incorporation Address", "Q_NG_KYC_REM_FI_TR_TABLE_IncorporationAddress" },
			    { "Scope of Relationship with Bank", "Q_NG_KYC_REM_FI_TR_TABLE_BankRelationshipScope" },
			    { "Does the government own directly or indirectly 10% or more of the applicant entity's shares?", "Q_NG_KYC_REM_FI_TR_TABLE_GovtOwnershipFlag" },
			    { "Listed in Stock Exchange", "Q_NG_KYC_REM_FI_TR_TABLE_ListedFlag" },
			    { "Name of Stock Exchange", "Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeName" },
			    { "Website of Stock Exchange", "Q_NG_KYC_REM_FI_TR_TABLE_StockExchangeWebsite" },
			    { "Customer Website", "Q_NG_KYC_REM_FI_TR_TABLE_CustomerWebsite" },
			    { "PEP Hit", "Q_NG_KYC_REM_FI_TR_TABLE_PEPHit" },
			    { "PEP Status", "Q_NG_KYC_REM_FI_TR_TABLE_PEPStatus" },
			    { "PEP Hit Reference Number - ENC", "Q_NG_KYC_REM_FI_TR_TABLE_PEPRefENC" },
			    { "PEP Hit Reference Number - OFAC", "Q_NG_KYC_REM_FI_TR_TABLE_PEPRefOFAC" },
			    { "Customer Segment", "Q_NG_KYC_REM_FI_TR_TABLE_CustomerSegment" },
			    { "Customer Sub Segment", "Q_NG_KYC_REM_FI_TR_TABLE_CustomerSubSegment" },
			    { "RM Name", "Q_NG_KYC_REM_FI_TR_TABLE_RMName" },
			    { "RM Code", "Q_NG_KYC_REM_FI_TR_TABLE_RMCode" },
			    { "WBG MD / Unit Head Approval Required?", "Q_NG_KYC_REM_FI_TR_TABLE_WBGApprovalRequired" }
			};
			
			// Add rest of FI Detail fields
			
			fieldTable = addFields(FI_DetailsList2, iform);
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");
			
			/*
			for (String label_value[] : FI_DetailsList2) {
			    PdfPCell labelCell = new PdfPCell(new Phrase(label_value[0]));
			    labelCell.setBorder(Rectangle.NO_BORDER);
			    labelCell.setPaddingBottom(8f);
			    fieldTable.addCell(labelCell);

			    String  value = (String)iform.getValue(label_value[1]);			    
			    PdfPCell valueCell = new PdfPCell(new Phrase(value));
			    valueCell.setBorder(Rectangle.BOX);
			    valueCell.setBorderColor(BaseColor.LIGHT_GRAY);
			    valueCell.setPadding(8f);
			    fieldTable.addCell(valueCell);
			}
			
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");
			*/
			
			// FI Presence Countries Table
			data = new ArrayList<>();
			data.add(
				Arrays.asList("Country")
			);
			
			JSONArray FICountriesTableJsonArray = iform.getDataFromGrid("table34");
            for (int i = 0; i < FICountriesTableJsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) FICountriesTableJsonArray.get(i);
                KYC_Remediation.mLogger.debug("jsonObj - " + jsonObj);

                List<String> row = new ArrayList<>();
                for(String header : data.get(0)){
                	String value = (String)jsonObj.getOrDefault(header, "");
                	if(header.equals("Country"))
                		value = getCountryDesc(iform, value);
                	row.add(value);
                }
                data.add(row);
            }			
			
			dataTable = addTable(data);
			
			document.add(dataTable);
			KYC_Remediation.mLogger.debug("Table added.");
			
			
			// Industry Segment/Sub-segment Table						
			data = new ArrayList<>();
			data.add(
				Arrays.asList("Industry Segment","Industry Sub Segment")
			);
			
			JSONArray segment_subsegmentTableJsonArray = iform.getDataFromGrid("table38");
            for (int i = 0; i < segment_subsegmentTableJsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) segment_subsegmentTableJsonArray.get(i);
                KYC_Remediation.mLogger.debug("jsonObj - " + jsonObj);

                List<String> row = new ArrayList<>();
                for(String header : data.get(0)){
                	String value = (String)jsonObj.getOrDefault(header, "");
                	row.add(value);
                }
                data.add(row);
            }			
			
			dataTable = addTable(data);
			
			document.add(dataTable);
			KYC_Remediation.mLogger.debug("Table added.");
			
			// Contact Details
			String[][] ContactDetailsLabels = {
			    { "PO Box", "Q_NG_KYC_REM_FI_TR_TABLE_ContactPOBox" },
			    { "Country", "Q_NG_KYC_REM_FI_TR_TABLE_ContactCountry" },
			    { "City Emirates", "Q_NG_KYC_REM_FI_TR_TABLE_ContactCityEmirate" },
			    { "Email ID", "Q_NG_KYC_REM_FI_TR_TABLE_ContactEmail" },
			    { "Country Code", "Q_NG_KYC_REM_FI_TR_TABLE_CountryCode" },
			    { "Contact No.", "Q_NG_KYC_REM_FI_TR_TABLE_ContactNumber" }
			};
			
			fieldTable = addFields(ContactDetailsLabels, iform);
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");
			
			// FI Financial & Regulatory Details
			String[][] RegulatoryDetailsLabels = {
			    { "World Rank", "Q_NG_KYC_REM_FI_TR_TABLE_WorldRank" },
			    { "Balance Sheet Size (AED)", "Q_NG_KYC_REM_FI_TR_TABLE_BalanceSheetSize" },
			    { "Credit Ratings", "Q_NG_KYC_REM_FI_TR_TABLE_CreditRatings" },
			    { "Is the Applicant Entity Regulated?", "Q_NG_KYC_REM_FI_TR_TABLE_IsRegulated" },
			    { "Name of Regulator", "Q_NG_KYC_REM_FI_TR_TABLE_RegulatorName" },
			    { "Country of the Primary Financial Regulator or Supervisory Authority", "Q_NG_KYC_REM_FI_TR_TABLE_RegulatorCountry" }
			};

			fieldTable = addFields(RegulatoryDetailsLabels, iform);
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");
			
			
			// KYC Details
			String[][] KYCDetailsLabels = {
			    { "Wolfsberg Questionnaire Obtained", "Q_NG_KYC_REM_FI_TR_TABLE_WolfsbergObtained" },
			    { "Bankers Almanac Legality Report", "Q_NG_KYC_REM_FI_TR_TABLE_LegalityReport" },
			    { "Screening Results", "Q_NG_KYC_REM_FI_TR_TABLE_ScreeningResults" },
			    { "GIIN Number", "Q_NG_KYC_REM_FI_TR_TABLE_GIINNumber" },
			    { "BIC Code", "Q_NG_KYC_REM_FI_TR_TABLE_BICCode" },
			    { "US RELATION (Are you an entity organized in the USA or under the laws of the USA or any state thereof? If yes, Kindly complete W9 and W8 BEN Form.)", "Q_NG_KYC_REM_FI_TR_TABLE_USRelationFlag" },
			    { "Documents Available", "Q_NG_KYC_REM_FI_TR_TABLE_DocumentsAvailable" },
			    { "Signed Date", "Q_NG_KYC_REM_FI_TR_TABLE_SignedDate" },
			    { "Expiry Date", "Q_NG_KYC_REM_FI_TR_TABLE_ExpiryDate" },
			    { "Sanctions Declaration", "Q_NG_KYC_REM_FI_TR_TABLE_SanctionsDeclared" },
			    { "Remarks for Sanction Declaration", "Q_NG_KYC_REM_FI_TR_TABLE_SanctionsRemarks" }
			};

			fieldTable = addFields(KYCDetailsLabels, iform);
			document.add(fieldTable);
			KYC_Remediation.mLogger.debug("Label-value fields added.");
			
			
			// Shareholder Table			
			data = new ArrayList<>();
			data.add(
				Arrays.asList("Name of Shareholder", "Type of Shareholder", "Nationality", "Country of Residence / Country of Incorporation", "Date of Birth / Date of Incorporation", "% Shareholding", "E-Name Screening", "Public Domain Adverse Screening", "Website Links", "PEP Hit", "PEP Status", "PEP Hit Reference Number - ENC", "PEP Hit Reference Number - OFAC")
			);
			
			JSONArray shareholdingTableJsonArray = iform.getDataFromGrid("table41");
            for (int i = 0; i < shareholdingTableJsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) shareholdingTableJsonArray.get(i);
                KYC_Remediation.mLogger.debug("jsonObj - " + jsonObj);

                List<String> row = new ArrayList<>();
                for(String header : data.get(0)){
                	String value = (String)jsonObj.getOrDefault(header, "");
                	if(header.equals("Nationality") || header.equals("Country of Residence / Country of Incorporation"))
                		value = getCountryDesc(iform, value);
                	
                	row.add(value);
                }
                data.add(row);
            }
			
			dataTable = addTable(data);
			
			document.add(dataTable);
			KYC_Remediation.mLogger.debug("Table added.");
			
			
			// Board of Directors Table			
			data = new ArrayList<>();
			data.add(
				Arrays.asList("Name", "Nationality", "Country of Residence", "Designation", "E-Name Screening", "Public Domain Adverse Screening", "Website Links", "PEP Hit", "PEP Status", "PEP Hit Reference Number - ENC", "PEP Hit Reference Number - OFAC")
			);
			
			JSONArray BODTableJsonArray = iform.getDataFromGrid("table42");
            for (int i = 0; i < BODTableJsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) BODTableJsonArray.get(i);
                KYC_Remediation.mLogger.debug("jsonObj - " + jsonObj);

                List<String> row = new ArrayList<>();
                for(String header : data.get(0)){
                	String value = (String)jsonObj.getOrDefault(header, "");
                	KYC_Remediation.mLogger.debug("value: " + value);
                	if(header.equals("Nationality") || header.equals("Country of Residence"))
                		value = getCountryDesc(iform, value);
                	
                	row.add(value);
                }
                data.add(row);
            }
			
			dataTable = addTable(data);
			
			document.add(dataTable);
			KYC_Remediation.mLogger.debug("Table added.");
			
			
			
			document.close();
			KYC_Remediation.mLogger.debug("Document closed. PDF creation complete.");
			System.out.println("PDF created successfully.");


        } catch (Exception e) {
            e.printStackTrace();
            KYC_Remediation.mLogger.debug("Exception: " + e);
            return "Failure";
        }
		
		return "Success";
	}
	
	private PdfPTable addTable(List<List<String>> data){
		
		PdfPTable dataTable = new PdfPTable(data.get(0).size());
		dataTable.setWidthPercentage(100);
		dataTable.setSpacingBefore(10);
		dataTable.setKeepTogether(true); // Ensures table stays together

		for (List<String> row : data) {
		    KYC_Remediation.mLogger.debug("Adding table row: " + row);
		    for (String cell : row) {
		        PdfPCell pdfCell = new PdfPCell(new Phrase(cell));
		        pdfCell.setPadding(8f); // Added cell padding
		        if (data.indexOf(row) == 0) {
		            pdfCell.setBackgroundColor(BaseColor.LIGHT_GRAY); // Header styling
		        }
		        dataTable.addCell(pdfCell);
		    }
		}

		return dataTable;		
	}
	
	private PdfPTable addFields(String[][] FieldList, IFormReference iform) throws DocumentException{
		
		PdfPTable fieldTable = new PdfPTable(2);
		fieldTable.setWidthPercentage(100);
		fieldTable.setSpacingBefore(10);
		fieldTable.setSpacingAfter(20);
		fieldTable.setWidths(new float[]{1f, 1f}); // Equal width for both columns

		for (String label_value[] : FieldList) {
		    PdfPCell labelCell = new PdfPCell(new Phrase(label_value[0]));
		    labelCell.setBorder(Rectangle.NO_BORDER);
		    labelCell.setPaddingBottom(8f);
		    fieldTable.addCell(labelCell);

		    String  value = (String)iform.getValue(label_value[1]);
		    if(label_value[0].equalsIgnoreCase("Country") || label_value[0].equalsIgnoreCase("Country of the Primary Financial Regulator or Supervisory Authority") || label_value[0].equals("Country of Institution") || label_value[0].equals("Country of Incorporation"))
		    	value = getCountryDesc(iform, value);
		    if(label_value[0].equalsIgnoreCase("City Emirates") || label_value[0].equals("Emirate/City"))
		    	value = getCityDesc(iform, value);	
		    if(label_value[0].equals("ID Type"))
        		value = getIDTypeDesc(iform, value);
		    if(label_value[0].equals("PEP Status"))
        		value = getPEPdesc(iform, value);
		    
		    PdfPCell valueCell = new PdfPCell(new Phrase(value));
		    valueCell.setBorder(Rectangle.BOX);
		    valueCell.setBorderColor(BaseColor.LIGHT_GRAY);
		    valueCell.setPadding(8f);
		    fieldTable.addCell(valueCell);
		}
		
		return fieldTable;
	}
	
	
	
	
}
